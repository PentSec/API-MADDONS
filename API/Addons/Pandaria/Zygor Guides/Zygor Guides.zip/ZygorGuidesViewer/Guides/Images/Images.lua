ZGV.guide_images_installed = true
