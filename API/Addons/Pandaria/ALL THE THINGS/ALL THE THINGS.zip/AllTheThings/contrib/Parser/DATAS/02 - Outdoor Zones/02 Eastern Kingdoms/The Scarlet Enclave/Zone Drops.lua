---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	{	-- Eastern Kingdoms
		["mapID"] = 13,
		["g"] = {
			{	-- Eastern Plaguelands
				["mapID"] = 23,
				["g"] = {
					{	-- The Scarlet Enclave
						["mapID"] = 124,
						["g"] = {
							n(0, {	-- Zone Drop
								i(16252, {	-- Formula: Enchant Weapon - Crusader
									["crs"] = {
										9451,	-- Scarlet Archmage
									},
								}),
							}),
						},
					},
				},
			},
		},
	},
};