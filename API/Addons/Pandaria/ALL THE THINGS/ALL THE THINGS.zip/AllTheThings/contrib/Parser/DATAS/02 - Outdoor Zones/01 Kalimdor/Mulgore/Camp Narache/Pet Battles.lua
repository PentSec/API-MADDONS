---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(7, {	-- Mulgore
			m(462, {	-- Camp Narache
				["groups"] = {
					n(-25, {	-- Pet Battle
						p(385),	-- Mouse
						p(386),	-- Prairie Dog
						p(378),	-- Rabbit
					}),
				},
			}),
		}),
	}),
};
