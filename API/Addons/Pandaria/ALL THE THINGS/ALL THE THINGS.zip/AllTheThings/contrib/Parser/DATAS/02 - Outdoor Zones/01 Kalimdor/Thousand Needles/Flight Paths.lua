---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(64, {	-- Thousand Needles
			["groups"] = {
				n(-228, {	-- Flight Paths
					fp(513, { -- Fizzle & Pozzik's Speedbarge, Thousand Needles
						["coord"] = { 79, 71.8, 64 },
					}),
					fp(30, { -- Westreach Summit, Thousand Needles
						["coord"] = { 11, 11.6, 64 },
					}),
				}),
			},
		}),
	}),
};
