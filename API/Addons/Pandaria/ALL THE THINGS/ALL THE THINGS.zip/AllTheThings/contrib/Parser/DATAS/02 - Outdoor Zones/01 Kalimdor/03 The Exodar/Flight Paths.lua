---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(103, {	-- The Exodar
			["groups"] = {
				n(-228, {	-- Flight Paths
					fp(94, {	-- The Exodar [A]
						["description"] = "The Exodar - Alliance Only",
						["coord"] = { 54.5, 36.3 },
					}),
				}),
			},
		}),
	}),
};
