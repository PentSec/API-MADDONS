_.ItemDB = {};
local i = function(itemID)
	local item = { ["f"] = 104 };
	_.ItemDB[itemID] = item;
	return item;
end


i(86425);		--[[Cooking School Bell]]
i(20461);		--[[Brann Bronzebeard's Lost Letter]]
i(17204);		--[[Eye of Sulfuras]]

i(51316);		--[[Unsealed Chest]]
i(51317);		--[[Alexandros' Soul Shard]]
i(51318);		--[[Jaina's Locket]]
i(51319);		--[[Arthas' Training Sword]]
i(51320);		--[[Badge of the Silver Hand]]
i(51321);		--[[Blood of Sylvanas]]
