---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(113, { 	-- Northrend
		["achievementID"] = 45,
		["icon"] = "Interface\\Icons\\Achievement_Zone_Northrend_01",
		["description"] = "|cff66ccffNorthrend is the northern, icy continent of the world of Azeroth, and the source of the evil Scourge. It is also the home of Icecrown Citadel, the seat of the malevolent Lich King.|r",
	}),
};