---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(327, {	-- Ahn'Qiraj: The Fallen Kingdom
			["groups"] = {
				n(-16, {	-- Rares
					n(50747, {	-- Tix
						i(10377),	-- Commander's Vambraces
						i(10235),	-- Engraved Helm
						i(10227),	-- Nightshade Leggings
						i(10211),	-- Elegant Boots
						i(10379),	-- Commander's Helm
						i(10281),	-- Emerald Pauldrons
						i(10138),	-- High Councillor's Cloak
						i(10225),	-- Nightshade Gloves
						i(10104),	-- Councillor's Tunic
						i(10159),	-- Mercurial Cloak
						i(10145),	-- Mighty Girdle
						i(10214),	-- Elegant Gloves
						i(10280),	-- Emerald Legplates
						i(10234),	-- Engraved Boots
						i(10236),	-- Engraved Leggings
						i(10222),	-- Nightshade Boots
					}),
				}),
			},
		}),
	}),
};
