---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(63, {	-- Ashenvale
			["groups"] = {
				n(0, {	-- Zone Drops
					i(78343),	-- Formula: Enchant Gloves - Herbalism
				}),
			},
		}),
	}),
};
