---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	{	-- Eastern Kingdoms
		["mapID"] = 13,	-- Eastern Kingdoms
		["g"] = {
			{	-- Stormwind City
				["mapID"] = 84,	-- Stormwind City
				["g"] = {
					{	-- Flight Master
						["npcID"] = -228,	-- Flight Point
						["g"] = {
							fp(2, { -- Stormwind, Elwynn
								["coord"] = { 71, 72.6 },
							}),
						},
					},
				},
			},
		},
	},
};