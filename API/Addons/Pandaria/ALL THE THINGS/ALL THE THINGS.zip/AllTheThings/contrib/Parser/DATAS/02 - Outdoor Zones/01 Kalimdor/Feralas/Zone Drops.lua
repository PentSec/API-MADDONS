---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(69, {	-- Feralas
			["groups"] = {
				n(0, {	-- Zone Drop
					{	-- Sprite Darter Egg
						["itemID"] = 11474,
						["crs"] = {
							5300,	-- Frayfeather Hippogryph
							5304,	-- Frayfeather Stagwing
							39949,	-- Grimtotem Marauder
							11440,	-- Gordok Enforcer
							39384,	-- Noxious Whelp
							5278,	-- Sprite Darter
							5249,	-- Woodpaw Mogrel
							5246,	-- Zukk'ash Worker
						},
					},
					{	-- Emerald Whelping
						["itemID"] = 8498,
						["crs"] = {
							39384,	-- Noxious Whelp
						},
					},
				}),
			},
		}),
	}),
};
