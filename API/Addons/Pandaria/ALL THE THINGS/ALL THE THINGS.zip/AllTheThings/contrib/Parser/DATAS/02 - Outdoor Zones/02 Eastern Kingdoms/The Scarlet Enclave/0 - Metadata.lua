---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	{	-- Eastern Kingdoms
		["mapID"] = 13,
		["g"] = {
			{	-- Eastern Plaguelands
				["mapID"] = 23,
				["g"] = {
					{	-- The Scarlet Enclave
						["mapID"] = 124,
						["icon"] = "Interface\\Icons\\Classicon_deathknight",
						["description"] = "|cff66ccffThe Scarlet Enclave is the name of the starting area for all Death Knight players in World of Warcraft: Wrath of the Lich King.|r",
					},
				},
			}
		},
	},
};