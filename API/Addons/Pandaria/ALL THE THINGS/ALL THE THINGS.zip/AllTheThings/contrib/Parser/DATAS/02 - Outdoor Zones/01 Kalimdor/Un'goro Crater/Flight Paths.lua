---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(78, {	-- Un'Goro Crater
			["groups"] = {
				n(-228, {	-- Flight Paths
					fp(79, {	-- Marshal's Stand, Un'Goro Crater
						["coord"] = { 56, 64 },
					}),
					fp(386, {	-- Mossy Pile, Un'Goro Crater
						["coord"] = { 44, 40.2 },
					}),
				}),
			},
		}),
	}),
};
