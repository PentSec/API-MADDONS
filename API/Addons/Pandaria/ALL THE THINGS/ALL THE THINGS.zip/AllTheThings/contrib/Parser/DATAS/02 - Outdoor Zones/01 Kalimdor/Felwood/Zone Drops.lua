---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(77, {	-- Felwood
			["groups"] = {
				n(0, {	-- Zone Drop
					i(13491, {	-- Recipe: Elixir of the Mongoose
						["crs"] = {
							7106,	-- Jadefire Rogue
						},
					}),
				}),
			},
		}),
	}),
};
