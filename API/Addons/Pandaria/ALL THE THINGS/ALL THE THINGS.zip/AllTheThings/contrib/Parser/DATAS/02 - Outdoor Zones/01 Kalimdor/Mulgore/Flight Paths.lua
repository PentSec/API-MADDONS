---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(7, {	-- Mulgore
			["groups"] = {
				n(-228, {	-- Flight Paths
					fp(402, { -- Bloodhoof Village, Mulgore
						["coord"] = { 47.4, 58.6, 7 },
					}),
				}),
			},
		}),
	}),
};
