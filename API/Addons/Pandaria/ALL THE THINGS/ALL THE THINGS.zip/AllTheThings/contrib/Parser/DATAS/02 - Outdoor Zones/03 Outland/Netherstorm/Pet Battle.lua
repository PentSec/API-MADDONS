---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	{	-- Outland
		["mapID"] = 101,	-- Outland
		["groups"] = {
			{	-- Netherstorm
				["mapID"] = 109,	-- Netherstorm
				["groups"] = {
					n(-25,  {	-- Pet Battle
						{	-- Fledgling Nether Ray
							["crs"] = { 62627 },	-- Fledgling Nether Ray
							["speciesID"] = 521,	-- Fledgling Nether Ray
						},
						{	-- Nether Roach
							["crs"] = { 62625 },	-- Nether Roach
							["speciesID"] = 638,	-- Nether Roach
						},						
					}),
				},
			},
		},
	},
};