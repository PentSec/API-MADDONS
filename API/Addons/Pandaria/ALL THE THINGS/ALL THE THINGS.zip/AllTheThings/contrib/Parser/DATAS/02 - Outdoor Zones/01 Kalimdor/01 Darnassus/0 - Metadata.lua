---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(89, {	-- Darnassus
			["icon"] = "Interface\\Icons\\Inv_misc_tournaments_symbol_nightelf",
			["lvl"] = 1,
			["isRaid"] = true,
			["description"] = "|cff66ccffDarnassus is the capital town of the Night Elves of the Alliance. The high priestess, Tyrande Whisperwind, resides in the Temple of the Moon, surrounded by other sisters of Elune. The city is arranged in a series of terraces around the central tree surrounded by a lake.|r",
		}),
	}),
};
