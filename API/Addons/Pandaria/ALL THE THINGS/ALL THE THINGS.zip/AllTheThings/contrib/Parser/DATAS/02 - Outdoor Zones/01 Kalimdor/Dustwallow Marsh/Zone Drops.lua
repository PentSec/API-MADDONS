---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(70, {	-- Dustwallow Marsh
			["groups"] = {
				n(0, {	-- Zone Drop
					i(10822, {	-- Dark Whelpling
						["crs"] = {
							4323,	-- Searing Hatchling
							4324,	-- Searing Whelp
						},
					}),
				}),
			},
		}),
	}),
};
