LH_QIDMap = {
  [1] = 2,
  [2] = 10848,
  [3] = 12762,
  [4] = 25485,
  [5] = 28749,
  ["vars"] = {
    [1] = "LH_Data_A",
    [2] = "LH_Data_B",
    [3] = "LH_Data_C",
    [4] = "LH_Data_D",
    [5] = "LH_Data_E",
  },
  ["addons"] = {
    [1] = "LightHeaded_Data_A",
    [2] = "LightHeaded_Data_B",
    [3] = "LightHeaded_Data_C",
    [4] = "LightHeaded_Data_D",
    [5] = "LightHeaded_Data_E",
  },
}
