if not WeakAuras.IsCorrectVersion() then return end

if not(GetLocale() == "ruRU") then
  return
end

local L = WeakAuras.L

--@localization(locale="ruRU", format="lua_additive_table", namespace="WeakAuras / Options")@
