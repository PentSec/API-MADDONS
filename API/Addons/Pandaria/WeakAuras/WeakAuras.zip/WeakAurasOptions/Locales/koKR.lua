if not WeakAuras.IsCorrectVersion() then return end

if not(GetLocale() == "koKR") then
  return
end

local L = WeakAuras.L

--@localization(locale="koKR", format="lua_additive_table", namespace="WeakAuras / Options")@
