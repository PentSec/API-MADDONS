if not(GetLocale() == "zhTW") then
  return
end

local L = WeakAuras.L

--@localization(locale="zhTW", format="lua_additive_table", namespace="WeakAuras", handle-subnamespaces="none")@
