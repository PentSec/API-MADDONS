if not(GetLocale() == "esES") then
  return
end

local L = WeakAuras.L

--@localization(locale="esES", format="lua_additive_table", namespace="WeakAuras", handle-subnamespaces="none")@
