if not(GetLocale() == "esMX") then
  return
end

local L = WeakAuras.L

--@localization(locale="esMX", format="lua_additive_table", namespace="WeakAuras", handle-subnamespaces="none")@
