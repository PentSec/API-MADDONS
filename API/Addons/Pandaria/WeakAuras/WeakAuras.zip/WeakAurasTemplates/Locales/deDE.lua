if not WeakAuras.IsCorrectVersion() then return end

if not(GetLocale() == "deDE") then
  return
end

local L = WeakAuras.L

--@localization(locale="deDE", format="lua_additive_table", namespace="WeakAuras / Templates")@
