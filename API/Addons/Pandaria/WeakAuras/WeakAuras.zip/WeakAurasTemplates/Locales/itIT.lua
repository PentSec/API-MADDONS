if not WeakAuras.IsCorrectVersion() then return end

if not(GetLocale() == "itIT") then
  return
end

local L = WeakAuras.L

--@localization(locale="itIT", format="lua_additive_table", namespace="WeakAuras / Templates")@
