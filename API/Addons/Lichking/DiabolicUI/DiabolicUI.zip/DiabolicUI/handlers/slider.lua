local _, Engine = ...
local Handler = Engine:NewHandler("Slider")

Handler.OnEnable = function(self)
end
