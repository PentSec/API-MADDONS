local _, Engine = ...
local Handler = Engine:NewHandler("Tooltip")

Handler.OnEnable = function(self)
end
