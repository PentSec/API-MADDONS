local ADDON, Engine = ...
local Module = Engine:NewModule("NamePlates")






Module.OnInit = function(self)
end

Module.OnEnable = function(self)
end

