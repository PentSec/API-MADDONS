local _, Engine = ...
local Module = Engine:GetModule("ActionBars")
local BarWidget = Module:SetWidget("Bar: Custom")

BarWidget.OnEnable = function(self)
	
end
