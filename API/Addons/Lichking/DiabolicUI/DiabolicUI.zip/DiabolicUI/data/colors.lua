local _, Engine = ...

local config = {
	
}

Engine:NewStaticConfig("Data: Colors", config)