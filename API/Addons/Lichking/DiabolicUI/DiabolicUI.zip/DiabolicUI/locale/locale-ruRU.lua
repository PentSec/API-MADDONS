local _, Engine = ...

local L = Engine:NewLocale("ruRU")
if not L then return end

