local L = LibStub("AceLocale-3.0"):NewLocale("Details_ChartViewer", "koKR")
if not L then return end

L["STRING_ADDEDOKAY"] = "성공적으로 추가되었습니다."
L["STRING_CONFIRM"] = "확인"
L["STRING_NEWTAB"] = "새로운 탭"
L["STRING_OPTIONS"] = "Chart Viewer 옵션"
L["STRING_OPTIONS_SHOWICON"] = "아이콘 표시"
L["STRING_OPTIONS_WINDOWSCALE"] = "창 크기 비율"
L["STRING_PLUGIN_DESC"] = "Details!에서 수집한 데이터를 꺾은선 그래프로 확인합니다."
L["STRING_PLUGIN_NAME"] = "Chart Viewer"
L["STRING_TOOLTIP"] = "Chart Viewer 열기"
L["STRING_TOOSHORTNAME"] = "이름이 너무 짧습니다."

