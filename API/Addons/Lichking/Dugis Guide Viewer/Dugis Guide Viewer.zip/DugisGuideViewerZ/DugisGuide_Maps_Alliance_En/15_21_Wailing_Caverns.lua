DugisGuideViewer:RegisterGuide("Wailing Caverns (15-21 Map)", nil, "Alliance", "M", function()
return [[
 <html><body>
<img align="center" src='Interface\Addons\DugisGuideViewerZ\DugisGuide_Maps_Alliance_En\Artwork\Wailing_Caverns_A' />
 </body></html>
]]
end)
