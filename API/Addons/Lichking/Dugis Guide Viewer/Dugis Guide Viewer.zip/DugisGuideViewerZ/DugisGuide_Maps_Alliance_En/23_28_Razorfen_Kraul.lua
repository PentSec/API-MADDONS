
DugisGuideViewer:RegisterGuide("Razorfen Kraul (23-28 Map)", nil, "Alliance", "M", function()
return [[
 <html><body>
<img align="center" src='Interface\Addons\DugisGuideViewerZ\DugisGuide_Maps_Alliance_En\Artwork\Razorfen_Kraul_A' />
 </body></html>
]]
end)