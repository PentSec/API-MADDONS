DugisGuideViewer:RegisterGuide("The Stockade (21-25 Map)", nil, "Alliance", "M", function()
return [[
 <html><body>
<img align="center" src='Interface\Addons\DugisGuideViewerZ\DugisGuide_Maps_Alliance_En\Artwork\The_Stockade_A' />
 </body></html>
]]
end)