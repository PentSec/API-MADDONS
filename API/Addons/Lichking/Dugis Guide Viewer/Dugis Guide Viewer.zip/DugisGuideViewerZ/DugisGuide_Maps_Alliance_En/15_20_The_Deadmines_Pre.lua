DugisGuideViewer:RegisterGuide("The Deadmines Pre-Instance (15-20 Map)", nil, "Alliance", "M", function()
return [[
 <html><body>
<img align="center" src='Interface\Addons\DugisGuideViewerZ\DugisGuide_Maps_Alliance_En\Artwork\The_Deadmines_Pre_A' />
 </body></html>
]]
end)