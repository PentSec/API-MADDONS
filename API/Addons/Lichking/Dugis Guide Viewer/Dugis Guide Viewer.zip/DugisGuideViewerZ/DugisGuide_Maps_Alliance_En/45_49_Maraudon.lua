DugisGuideViewer:RegisterGuide("Maraudon (45-49 Map)", nil, "Alliance", "M", function()
    return [[
 <html><body>
<img align="center" src='Interface\Addons\DugisGuideViewerZ\DugisGuide_Maps_Alliance_En\Artwork\Maraudon_A' />
 </body></html>
]]
end)