DugisGuideViewer:RegisterGuide("Blackfathom Deeps (20-24 Map)", nil, "Alliance", "M", function()
return [[
 <html><body>
<img align="center" src='Interface\Addons\DugisGuideViewerZ\DugisGuide_Maps_Alliance_En\Artwork\Blackfathom_Deeps_A' />
 </body></html>
]]
end)