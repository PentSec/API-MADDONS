DugisGuideViewer:RegisterGuide("Mana-Tombs (64-67 Map)", nil, "Alliance", "M", function()
    return [[
 <html><body>
<img align="center" src='Interface\Addons\DugisGuideViewerZ\DugisGuide_Maps_Alliance_En\Artwork\Mana_Tombs_A' />
 </body></html>
]]
end)