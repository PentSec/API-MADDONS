DugisGuideViewer:RegisterGuide("Hallow's End Outland", nil, "Alliance", "D", function() 
return [[

N Manual Tick Required |N|The guide will detect the trick or treats that you have already done, but you will still need to manually tick the step as you complete them or press the Reload button|
R Shattrath City |N|Travel to Shattrath City|

A Shattrath City |N|Go to your faction Scryers Tier (56.2, 81.8) Aldor Rise (28.1, 49)| |AID|969| |AC|13| |Z|Shattrath City| 
A Hellfire Peninsula, Honor Hold |N|Honor Hold (54.3, 63.6)| |AID|969| |AC|3| |Z|Hellfire Peninsula|
A Hellfire Peninsula, Temple of Telhamat |N|Temple of Telhamat (23.4, 36.5)| |AID|969| |AC|4| |Z|Hellfire Peninsula|
A Zangarmarsh, Cenarion Refuge |N|Cenarion Refuge (78.5, 62.9)| |AID|969| |AC|14| |Z|Zangarmarsh|
A Zangarmarsh, Telredor |N|Telredor (67.2, 49)| |AID|969| |AC|3| |Z|Zangarmarsh|
A Blade's Edge Mountains, Toshley's Station |N|Toshley's Station (61, 68.1)| |AID|969| |AC|2| |Z|Blade's Edge Mountains|
A Netherstorm, Area 52 |N|Area 52 (32.1, 64.5)| |AID|969| |AC|11| |Z|Netherstorm|
A Netherstorm, The Stormspire |N|The Stormspire (43.4, 36.1)| |AID|969| |AC|12| |Z|Netherstorm|
A Blade's Edge Mountains, Evergrove |N|Evergrove (62.9, 38.3)| |AID|969| |AC|10| |Z|Blade's Edge Mountains|
A Blade's Edge Mountains, Sylvanaar |N|Sylvanaar (38.5, 63.8)| |AID|969| |AC|1| |Z|Blade's Edge Mountains|
A Zangarmarsh, Orebor Harborage |N|Orebor Harborage (41.9, 26.2)| |AID|969| |AC|8| |Z|Zangarmarsh|
A Nagrand, Telaar |N|Telaar (54.2, 75.8)| |AID|969| |AC|5| |Z|Nagrand|
A Terokkar Forest, Allerian Stronghold |N|Allerian Stronghold (56.6, 53.2)| |AID|969| |AC|7| |Z|Terokkar Forest|
A Shadowmoon Valley, Wildhammer Stronghold |N|Wildhammer Stronghold (37.1, 58.2)| |AID|969| |AC|6| |Z|Shadowmoon Valley|
A Shadowmoon Valley, Aldor or Scryer Inn |N|Go to your faction Altar of Shatar (61, 28.2) Sanctum of the Stars (56.3, 59.8)| |AID|969| |AC|15| |QID|12409| |Z|Shadowmoon Valley|

N Outland Guide Complete! 

]]
end)
