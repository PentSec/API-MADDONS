DugisGuideViewer:RegisterGuide("Midsummer Festival - Lord Ahune (70+)", nil, "Alliance", "D", function() 
return [[

A Unusual Activity |N|You can pick up this quest from Earthen Ring Elder found in any major city Valley of Wisdom in Orgrimmar or Hall of Explorer in Ironforge| |QID|11886|
R Astranaar |N|Travel to Astranaar in Ashenvale | 
C Unusual Activity |N|Kill the Twilights NPC (15, 17) to get [Twilight Correspondence]| |QID|11886| |Z|Ashenvale|
T Unusual Activity |N|Use the [Totemic Beacon] to summon the NPC to turn in the quest| |QID|11886| |U|35828|
A An Innocent Disguise |QID|11891|
C An Innocent Disguise |N|Follow the blue torches to (9.5, 93.2) and use the [Orb of the Crawler]| |QID|11891| |U|35237| |Z|Ashenvale|
T An Innocent Disguise |N|Use the [Totemic Beacon] to summon the NPC to turn in the quest|  |QID|11891| |U|35828|
A Inform the Elder |QID|12012|
T Inform the Elder |N|Go back to the elder in any capital city| |QID|12012|
R The Frost Lord Ahune  |N|Use the Dungeon Finder to queue for Lord Ahune| |I|
K Lord Ahune |N|Just kill the adds until Lord Ahune becomes vunerable, then everyone can damage Lord Ahune| |L|35723|
A Shards of Ahune |U|35723| |O| |QID|11972|
T Shards of Ahune |N|Luma Skymother inside the slave pens| |O| |QID|11972|
N Guide Complete

]]
end)
