DugisGuideViewer:RegisterGuide("|cfff0c502_____________ Event Guides ________________|r ", nil, "Alliance", "D", function()
return [[

N Do not tick |N|Do not tick, this is not a guide|
N Do not tick |N|Do not tick, this is not a guide|

]]
end)
