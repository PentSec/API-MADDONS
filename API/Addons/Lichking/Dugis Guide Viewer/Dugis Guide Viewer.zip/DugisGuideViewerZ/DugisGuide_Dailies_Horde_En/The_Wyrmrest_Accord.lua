DugisGuideViewer:RegisterGuide("The Wyrmrest_Accord (750 +Rep)", nil, "Horde", "D", function()
return [[

F Transitus Shield |N|Fly to Transitus Shield in Borean Tundra|

A Drake Hunt |N|Raelorasz (33.3, 34.5)| |QID|11940| |Z|Borean Tundra|  |D|
C Drake Hunt |N|Go to the valley at (27, 30) and look for a Nexus Drake up above then use [Raelorasz's Spear]| |U|35506| |QID|11940| |Z|Borean Tundra|  |D|
T Drake Hunt |N|Raelorasz (33.3, 34.5)| |QID|11940| |Z|Borean Tundra|  |D|

A Aces High! |N|Corastrasza (29.5, 24.8)| |QID|13414| |Z|Borean Tundra|  |D|
C Aces High! |N|Kill the Felsworn Elite using the Drake by using this ability combo 1, 1, 1, 1, 1, 5, 3  NOTE: When you press 3 you need to self-cast or target yourself| |QID|13414| |Z|Borean Tundra| |D|
T Aces High! |N|Corastrasza (29.5, 24.8)| |QID|13414| |Z|Borean Tundra| |D|

F Wyrmrest Temple |N|Fly to Wyrmrest Temple in Dragonblight|
A Defending Wyrmrest Temple |N|Lord Afrasastrasz (59.2, 54.3)| |QID|12372| |Z|Dragonblight| |D|
C Defending Wyrmrest Temple |N|Kill 3 Azure Dragons, 5 Azure Drakes and Destabilize the Azure Dragonshrine (55.5, 66), the little dragons only need 1 Fireball and 1 Immolate to kill, while the big dragons will need 4 - 5 Fireball and an Immolate to die| |QID|12372| |Z|Dragonblight| |D|
T Defending Wyrmrest Temple |N|Lord Afrasastrasz (59.2, 54.3)| |QID|12372| |Z|Dragonblight|  |D|

N Guide Complete 
]]
end)
