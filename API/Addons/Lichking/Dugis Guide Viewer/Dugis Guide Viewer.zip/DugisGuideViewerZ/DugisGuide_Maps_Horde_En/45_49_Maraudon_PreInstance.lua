DugisGuideViewer:RegisterGuide("Maraudon PreInstance (45-49 Map)", nil, "Horde", "M", function()
    return [[
 <html><body>
<img align="center" src='Interface\Addons\DugisGuideViewerZ\DugisGuide_Maps_Horde_En\Artwork\Maraudon_Preinstance_H' />
 </body></html>
]]
end)