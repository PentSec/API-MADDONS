
DugisGuideViewer:RegisterGuide("Razorfen Downs (33-38 Map)", "Scarlet Monestary Armory / Cathedral (34-40) ", "Horde", "M", function()
return [[
 <html><body>
<img align="center" src='Interface\Addons\DugisGuideViewerZ\DugisGuide_Maps_Horde_En\Artwork\Razorfen_Downs_H' />
 </body></html>
]]
end)