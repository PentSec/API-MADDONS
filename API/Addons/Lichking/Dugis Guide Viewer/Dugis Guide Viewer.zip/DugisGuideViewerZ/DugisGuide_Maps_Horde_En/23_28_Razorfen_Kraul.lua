
DugisGuideViewer:RegisterGuide("Razorfen Kraul (23-28 Map)", nil, "Horde", "M", function()
return [[
 <html><body>
<img align="center" src='Interface\Addons\DugisGuideViewerZ\DugisGuide_Maps_Horde_En\Artwork\Razorfen_Kraul_H' />
 </body></html>
]]
end)