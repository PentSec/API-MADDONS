DugisGuideViewer:RegisterGuide("Old Hillsbrad Foothills (66-68 Map)", nil, "Horde", "M", function()
    return [[
 <html><body>
<img align="center" src='Interface\Addons\DugisGuideViewerZ\DugisGuide_Maps_Horde_En\Artwork\Old_Hillsbrad_Foothills_H' />
 </body></html>
]]
end)