DugisGuideViewer:RegisterGuide("Scarlet Monestary (27-39 Map)", nil, "Horde", "M", function()
    return [[
 <html><body>
<img align="center" src='Interface\Addons\DugisGuideViewerZ\DugisGuide_Maps_Horde_En\Artwork\Scarlet_Monastery_H' />
 </body></html>
]]
end)