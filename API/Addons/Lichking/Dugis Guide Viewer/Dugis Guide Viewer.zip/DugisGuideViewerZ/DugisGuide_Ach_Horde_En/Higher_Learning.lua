DugisGuideViewer:RegisterGuide("Higher Learning Achievement", nil, "Horde", "E", function()
return [[

N Higher Learning |N|These books are on a rare spawn timer in Dalaran. You must be able to get to Dalaran to do this Achievement. This is also a video on the spawn points in the Member's area of the website. Once all books are read, you'll get a non-combat pet, Kirin Tor Familiar.|

U The Schools of Arcane Magic - Introduction |N|In the Teleportation Room of the Violet Gate. (56.5, 45.7)| |AID|1956| |AC|1| |Z|Dalaran|
U The Schools of Arcane Magic - Illusion |N|In the corner of the Violet Hold near Archmage Timear. (64.4, 52.4)| |AID|1956| |AC|6| |Z|Dalaran|
U The Schools of Arcane Magic - Abjuration |N|On the floor of the Dalaran Visitor Center near the little table. (52.3, 54.8)| |AID|1956| |AC|2| |Z|Dalaran|
U The Schools of Arcane Magic - Enchantment |N|Upstairs balcony of The Threads of Fate shop. (43.4, 46.7)| |AID|1956| |AC|5| |Z|Dalaran|
U The Schools of Arcane Magic - Conjuration |N|On the bookshelf to the right as you enter the Violet Citadel. (30.8, 46.1)| |AID|1956| |AC|3| |Z|Dalaran|
U The Schools of Arcane Magic - Divination |N|Second floor Violet Citadel between the bookshelves to the left, near the portal to Caverns of Time. (26.5, 52.2)| |AID|1956| |AC|4| |Z|Dalaran|
U The Schools of Arcane Magic - Transmutation |N|First floor of the Legerdemain Lounge, on the right bookshelf near the stove. (46.8, 39.2)| |AID|1956| |AC|8| |Z|Dalaran|
U The Schools of Arcane Magic - Necromancy |N|Second floor of the Legerdemain Lounge, on the bookshelf in the room with 4 beds. (46.8, 40.0)| |AID|1956| |AC|7| |Z|Dalaran|

N Guide Complete
]]
end)