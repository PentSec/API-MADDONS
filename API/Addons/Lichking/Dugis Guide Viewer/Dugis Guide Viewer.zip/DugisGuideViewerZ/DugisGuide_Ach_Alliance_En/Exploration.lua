DugisGuideViewer:RegisterGuide("|cfff0c502________________ Exploration ________________|r ", nil, "Alliance", "E", function()
return [[

N Do Not Tick |N|This is not a guide do not tick|
N Do Not Tick |N|This is not a guide do not tick|

]]
end)
