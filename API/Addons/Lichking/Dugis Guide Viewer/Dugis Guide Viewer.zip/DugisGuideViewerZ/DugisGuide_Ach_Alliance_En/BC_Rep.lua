DugisGuideViewer:RegisterGuide("|cfff0c502_________ Burning Crusade Reputation _________|r ", nil, "Alliance", "E", function()
return [[

N Do Not Tick |N|This is not a guide do not tick|
N Do Not Tick |N|This is not a guide do not tick|

]]
end)
