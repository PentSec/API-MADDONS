DugisGuideViewer:RegisterGuide("Midsummer Festival Outland (60+)", nil, "Horde", "D", function() 
return [[

N Manual Tick Required |N|Due to the unique nature of the Midsummer event, DugisGuideViewerZ is currently unable to automatically detect the quest and you will need to tick the completed quest manually. We are working on a solution|
R Shattrath City |N|Travel to Shattrath City|
A Honor the Flame (Terokkar Forest) |N|Stonebreaker Hold (52, 43)| |Z|Terokkar Forest| |QID|11858| |E|
A Desecrate this Fire! (Terokkar Forest) |N|Allerian Stronghold (55, 55)| |Z|Terokkar Forest| QID|11754|  |E|
A Honor the Flame (Shadowmoon Valley) |N|Shadowmoon Village (33, 30)| |Z|Shadowmoon Valley| |QID|11855| |E|
A Desecrate this Fire! (Shadowmoon Valley) |N|Wildhammer Stronghold (40, 55)| |Z|Shadowmoon Valley| |QID|11752| |E|
A Honor the Flame (Nagrand) |N|Garadar (51, 34)| |Z|Nagrand| |QID|11854| |E|
A Desecrate this Fire! (Nagrand) |N|Telaar (50, 70)| |Z|Nagrand| |QID|11750| |E|
A Honor the Flame (Zangarmarsh) |N|Zabra'Jin (36, 52)| |Z|Zangarmarsh| |QID|11863| |E|
A Desecrate this Fire! (Zangarmarsh) |N|Telredor (69, 52)| |Z|Zangarmarsh| |QID|11758| |E|
A Honor the Flame (Hellfire Peninsula) |N|Thrallmar (57, 42)| |Z|Hellfire Peninsula| |QID|11851| |E|
A Desecrate this Fire! (Hellfire Peninsula) |N|Honor Hold (62, 58)| |Z|Hellfire Peninsula| |QID|11747| |E|
A Honor the Flame (Blade's Edge Mountains) |N|Thunderlord Stronghold (50, 59)| |Z|Blade's Edge Mountains| |QID|11843| |E|
A Desecrate this Fire! (Blade's Edge Mountains) |N|Sylvanaar (42, 66)| |Z|Blade's Edge Mountains| |QID|11736| |E|
A Desecrate this Fire! (Netherstorm) |N|Area 52 (31, 63)| |Z|Netherstorm| |QID|11759| |E|
A Honor the Flame (Netherstorm) |N|Area 52 (32, 68)| |Z|Netherstorm| |QID|11835| |E|
N Guide Complete!

]]
end)
