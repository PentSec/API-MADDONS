DugisGuideViewer:RegisterGuide("Hallow's End Outland", nil, "Horde", "D", function() 
return [[

N Manual Tick Required |N|The guide will detect the trick or treats that you have already done, but you will still need to manually tick the step as you complete them or press the Reload button|
R Shattrath City |N|Travel to Shattrath City|
A Shattrath City |N|Go to your respective faction, Aldor Rise (28.1,49) Scryers Tier (56.2,81.8)| |AID|968| |AC|12| |Z|Shattrath City|
A Hellfire Peninsula, Thrallmar |N|Thrallmar (56.8, 37.5)| |AID|968| |AC|5| |Z|Hellfire Peninsula|
A Hellfire Peninsula, Falcon Watch |N|Falcon Watch (26.9, 59.6)| |AID|968| |AC|3| |Z|Hellfire Peninsula|
A Zangarmarsh, Cenarion Refuge |N|Cenarion Refuge (78.5, 62.9)| |AID|968| |AC|13| |Z|Zangarmarsh|
A Blade's Edge Mountains, Mok'Nathal Village |N|Mok'Nathal Village (76.2, 60.4)| |AID|968| |AC|1| |QID|12394| |Z|Blade's Edge Mountains|
A Netherstorm, Area 52 |N|Netherstorm-Area 52 (32.1, 64.5)| |AID|968| |AC|10| |Z|Netherstorm|
A Netherstorm, The Stormspire |N|Netherstorm-The Stormspire (43.4, 36.1)| |AID|968| |AC|11||Z|Netherstorm|
A Blade's Edge Mountains, Evergrove |N|Evergrove (62.9, 38.3)| |AID|968| |AC|9| |Z|Blade's Edge Mountains|
A Blade's Edge Mountains, Thunderlord Stronghold |N|Thunderlord Stronghold (53.4, 55.5)| |AID|968| |AC|2| |Z|Blade's Edge Mountains|
A Zangarmarsh, Zabra'jin |N|Zabra'jin (30.7, 50.9)| |AID|968| |AC|8| |Z|Zangarmarsh|
A Nagrand, Garadar |N|Garadar (56.7, 34.6)| |AID|968| |AC|4| |Z|Nagrand|
A Terokkar Forest, Stonebreaker Hold |N|Stonebreaker Hold (48.8, 45.2)| |AID|968| |AC|7| |Z|Terokkar Forest|
A Shadowmoon Valley, Shadowmoon Village |N|Shadowmoon Village (30.3, 27.8)| |AID|968| |AC|6| |Z|Shadowmoon Valley|
A Shadowmoon Valley, Aldor or Scryer Inn |N|Go to your respective faction Altar of Sha'tar (61, 28.2), Sanctum of the Stars (56.3,59.8)| |AID|968| |AC|14| |Z|Shadowmoon Valley|
N Outland Guide Complete!

]]
end)
