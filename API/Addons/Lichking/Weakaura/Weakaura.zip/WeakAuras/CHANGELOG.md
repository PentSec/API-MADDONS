# [2.17.4](https://github.com/WeakAuras/WeakAuras2/tree/2.17.4) (2020-04-22)

[Full Changelog](https://github.com/WeakAuras/WeakAuras2/compare/2.17.3...2.17.4)

## Highlights

 - fix a buff tracking and nameplates regression 

## Commits

InfusOnWoW (3):

- BT2 Fix Multi by adjusting it to recent changes (#2139)
- Clean up match data if a unit ceases to exists
- Fix nameplates auras sometimes not being applied if in a raid group

