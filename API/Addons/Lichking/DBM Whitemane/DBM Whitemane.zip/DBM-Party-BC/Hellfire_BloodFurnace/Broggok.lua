local mod	= DBM:NewMod(556, "DBM-Party-BC", 2, 256)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20220518110528")
mod:SetCreatureID(17380)

mod:SetModelID(19372)
mod:RegisterCombat("combat")

mod:RegisterEventsInCombat(
)
