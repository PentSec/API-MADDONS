assert(ZygorGuidesViewer,"Zygor Guides Viewer failed to load.")
ZygorGuidesViewer.revision = tonumber(string.sub("$Revision: 1327 $", 12, -3))
ZygorGuidesViewer.version = "2.0." .. ZygorGuidesViewer.revision
ZygorGuidesViewer.date = string.sub("$Date: 2010-09-21 07:30:48 -0500 (Tue, 21 Sep 2010) $", 8, 17)
--2010/09/21 08:30:37.52442
