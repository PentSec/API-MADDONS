if GetLocale()~="zhTW" then return end

ZygorTalentAdvisor_L("Main", "zhTW", function() return {
	-- ["English"] = "Localized",
} end)
