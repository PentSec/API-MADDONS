if GetLocale()~="ruRU" then return end

ZygorTalentAdvisor_L("Main", "ruRU", function() return {
	-- ["English"] = "Localized",
} end)
