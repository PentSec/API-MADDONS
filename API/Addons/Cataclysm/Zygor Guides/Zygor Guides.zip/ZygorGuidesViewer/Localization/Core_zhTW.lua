if GetLocale()~="zhTW" then return end

ZygorGuidesViewer.LocaleFont = [[Fonts\bLEI00D.ttf]]

ZygorGuidesViewer_L("Main", "zhTW", function() return {
	-- ["English"] = "Localized",
} end)
