local name,addon = ...

local data={}
addon.LibRoverData = data

data.MapIDsByName = {
 ['Abyssal Depths']=614,  ['Ahn\'Qiraj']=766,  ['Ahn\'Qiraj: The Fallen Kingdom']=772,  ['Ahn\'kahet: The Old Kingdom']=522,  ['Alterac Valley']=401,  ['Arathi Basin']=461,  ['Arathi Highlands']=16,  ['Ashenvale']=43,  ['Auchenai Crypts']=722,  ['Azjol-Nerub']=533,  ['Azshara']=181,  ['Azuremyst Isle']=464,  ['Badlands']=17,  ['Baradin Hold']=752,  ['Black Temple']=796,  ['Blackfathom Deeps']=688,  ['Blackrock Caverns']=753,  ['Blackrock Depths']=704,  ['Blackrock Spire']=721,  ['Blackwing Descent']=754,  ['Blackwing Lair']=755,  ['Blade\'s Edge Mountains']=475,  ['Blasted Lands']=19,  ['Bloodmyst Isle']=476,  ['Borean Tundra']=486,  ['Burning Steppes']=29,  ['Crystalsong Forest']=510,  ['Dalaran']=504,  ['Darkshore']=42,  ['Darkmoon Island']=823,  ['Darnassus']=381,  ['Deadwind Pass']=32,  ['Deepholm']=640,  ['Desolace']=101,  ['Dire Maul']=699,  ['Dragon Soul']=824,  ['Dragonblight']=488,  ['Drak\'Tharon Keep']=534,  ['Dun Morogh']=27,  ['Durotar']=4,  ['Duskwood']=34,  ['Dustwallow Marsh']=141,  ['Kalimdor']=13, ['Eastern Kingdoms']=14, ['Eastern Plaguelands']=23,  ['Elwynn Forest']=30,  ['End Time']=820,  ['Eversong Woods']=462,  ['Eye of the Storm']=482,  ['Felwood']=182,  ['Feralas']=121,  ['Firelands']=800,  ['Ghostlands']=463,  ['Gilneas City']=611,  ['Gilneas']={539,545,678,679},  ['Gnomeregan']=691,  ['Grim Batol']=757,  ['Grizzly Hills']=490,  ['Gruul\'s Lair']=776,  ['Gundrak']=530,  ['Halls of Lightning']=525,  ['Halls of Origination']=759,  ['Halls of Reflection']=603,  ['Halls of Stone']=526,  ['Hellfire Peninsula']=465,  ['Hellfire Ramparts']=797,  ['Hillsbrad Foothills']=24,  ['Howling Fjord']=491,  ['Hour of Twilight']=819,  ['Hrothgar\'s Landing']=541,  ['Hyjal Summit']=775,  ['Icecrown Citadel']=604,  ['Icecrown']=492,  ['Ironforge']=341,  ['Isle of Conquest']=540,  ['Isle of Quel\'Danas']=499,  ['Karazhan']=799,  ['Kelp\'thar Forest']=610,  ['Kezan']=605,  ['Loch Modan']=35,  ['Lost City of the Tol\'vir']=747,  ['Magisters\' Terrace']=798,  ['Magtheridon\'s Lair']=779,  ['Mana-Tombs']=732,  ['Maraudon']=750,  ['Molten Core']=696,  ['Molten Front']=795,  ['Moonglade']=241,  ['Mount Hyjal']={606,683},  ['Mulgore']=9,  ['Nagrand']=477,  ['Naxxramas']=535,  ['Netherstorm']=479,  ['Northern Barrens']=11,  ['Northern Stranglethorn']=37,  ['Old Hillsbrad Foothills']=734,  ['Onyxia\'s Lair']=718,  ['Orgrimmar']=321,  ['Pit of Saron']=602,  ['Plaguelands: The Scarlet Enclave']=502,  ['Ragefire Chasm']=680,  ['Razorfen Downs']=760,  ['Razorfen Kraul']=761,  ['Redridge Mountains']=36,  ['Ruins of Ahn\'Qiraj']=717,  ['Ruins of Gilneas City']=685,  ['Ruins of Gilneas']=684,  ['Scarlet Monastery']=762,  ['Scholomance']=763,  ['Searing Gorge']=28,  ['Serpentshrine Cavern']=780,  ['Sethekk Halls']=723,  ['Shadow Labyrinth']=724,  ['Shadowfang Keep']=764,  ['Shadowmoon Valley']=473,  ['Shattrath City']=481,  ['Shimmering Expanse']=615,  ['Sholazar Basin']=493,  ['Silithus']=261,  ['Silvermoon City']=480,  ['Silverpine Forest']=21,  ['Southern Barrens']=607,  ['Stonetalon Mountains']=81,  ['Stormwind City']=301,  ['Strand of the Ancients']=512,  ['Stranglethorn Vale']=689,  ['Stratholme']=765,  ['Sunwell Plateau']=789,  ['Swamp of Sorrows']=38,  ['Tanaris']=161,  ['Teldrassil']=41,  ['Tempest Keep']=782,  ['Terokkar Forest']=478,  ['The Arcatraz']=731,  ['The Bastion of Twilight']=758,  ['The Battle for Gilneas (Old City Map)']=677,  ['The Battle for Gilneas']=736,  ['The Black Morass']=733,  ['The Blood Furnace']=725,  ['The Botanica']=729,  ['The Cape of Stranglethorn']=673,  ['The Culling of Stratholme']=521,  ['The Deadmines']=756,  ['The Exodar']=471,  ['The Eye of Eternity']=527,  ['The Forge of Souls']=601,  ['The Hinterlands']=26,  ['The Lost Isles']={544,681,682},  ['The Maelstrom']={737,751},  ['The Mechanar']=730,  ['The Nexus']={520,803},  ['The Obsidian Sanctum']=531,  ['The Oculus']=528,  ['The Ruby Sanctum']=609,  ['The Shattered Halls']=710,  ['The Slave Pens']=728,  ['The Steamvault']=727,  ['The Stockade']=690,  ['The Stonecore']=768,  ['The Storm Peaks']=495,  ['The Temple of Atal\'Hakkar']=687,  ['The Underbog']=726,  ['The Violet Hold']=536,  ['The Vortex Pinnacle']=769,  ['Thousand Needles']=61,  ['Throne of the Four Winds']=773,  ['Throne of the Tides']=767,  ['Thunder Bluff']=362,  ['Tirisfal Glades']=20,  ['Tol Barad Peninsula']=709,  ['Tol Barad']=708,  ['Trial of the Champion']=542,  ['Trial of the Crusader']=543,  ['Twilight Highlands']={700,770},  ['Twin Peaks']=626,  ['Uldaman']=692,  ['Ulduar']=529,  ['Uldum']={720,748},  ['Un\'Goro Crater']=201,  ['Undercity']=382,  ['Utgarde Keep']=523,  ['Utgarde Pinnacle']=524,  ['Vashj\'ir']=613,  ['Vault of Archavon']=532,  ['Wailing Caverns']=749,  ['Warsong Gulch']=443,  ['Well of Eternity']=816,  ['Western Plaguelands']=22,  ['Westfall']=39,  ['Wetlands']=40,  ['Wintergrasp']=501,  ['Winterspring']=281,  ['Zangarmarsh']=467,  ['Zul\'Aman']=781,  ['Zul\'Drak']=496,  ['Zul\'Farrak']=686,  ['Zul\'Gurub']={697,793},
 ['The Wandering Isle']=808, ['Pandaria']=862, ['Kun-Lai Summit']=809, ['The Jade Forest']=806, ['Vale of Eternal Blossoms']=811, ['Townlong Steppes']=810, ['Dread Wastes']=858, ['Valley of the Four Winds']=807, ['Krasarang Wilds']=857,
}

data.basenodes = {}

data.basenodes.setup = {
	--"REGION fuselightbtspre Badlands 79.1,31.6 <150",
}

	--[[
		YE OLDE HELP TEXT

		Okay, to clarify, there's multiple ways to write a map link now. It's a mess, but it works.

		The first, simplest way, is two nodes linked, written in plain text (let's hope they're accessible by some means):
			"First Zone/2 11.22,33.44 -x- Second Zone/3 55.66,77.88",

		The "-x-" means it's a crossing, two-way. You can use "-to-" to make a one-way link.


		NODE NAMES:

		Adding @something after the node coordinates gives the node a name, for later reuse.
			"Stormwind 11.22,33.44 -x- Elwynn Forest 55.66,77.88 @stormgate",
			"Elwynn 77.77,66.66 -x- @stormgate",

		You can also use @+ to indicate the last node created or mentioned, whether it was named or not.
			"Stormwind 11.22,33.44 -x- Elwynn Forest 55.66,77.88",
			"@+ -x- Elwynn 77.77,66.66",

		This allows for easy chaining of nodes.


		ONE NODE?

		You can create just one node:
			"Solitary 11.1,22.2"

		This only makes sense if you @+ link to it later, or give it an explicit @name and refer to that.


		ADDITIONAL NODE DATA:

		Writing <field:value> after a node's coordinates assigns additional data.
			"Stormwind 11.1,22.2 <title:Watch out, dog poo> <dist:5>"

		Data fields include (among others):
			'title' to caption a node,
			'dist' to set the node's player-detection radius,
			'region' to assign a node to a special region,
			'nofly' set to 1 means the node cannot be flown to,
			'noallzone' set to 1 means the node can only be seen by the player from a small distance, but suffers no penalty when chained between other nodes


		ADDITIONAL LINK DATA:

		Writing {field:value} after both nodes assigns data to their link:
			"Stormwind 11.1,22.2 -x- Elwynn Forest 55.5,66.6 {cost:999}"   -- this is a very time-costly connection


		ADVANCED FORMAT:

		If that's not enough, you can use a "raw" format to write node links:
			{ "@+" , "Orgrimmar/1 11.1,22.2" , tag="portalauto", faction="H", cost=123 }

		Within that, you can go even deeper and write the node(s) in raw mode, too:
			{ "@+" , {"Orgrimmar/1 11.1,22.2",title="Something in Orgri",region="whatever"} , oneway=1 }

		Very advanced, messy, "fake zone"-based mapping (Maraudon the Zone of Nightmares) makes extensive use of that.

	--]]


	--[[
		REGIONS:

		These define explicit connections between floors in certain maps.
		Use the usual map node notation.
		Just adding a map here and providing notes is enough for them to work.
		Note Scarlet Monastery - an empty entry says that direct travel between floors is PROHIBITED.
	--]]
data.basenodes.MapsWithExplicitFloors = {
	[321] = { -- Orgrimmar
		-- Cleft of Shadow, two entries
		"Orgrimmar/1 45.90,66.94 -x- Orgrimmar/2 35.85,79.06", "@+ -x- Orgrimmar/1 42.09,61.03",
		"Orgrimmar/1 55.12,51.43 -x- Orgrimmar/2 67.37,36.52",
	},
	[504] = { -- Dalaran
		-- Underbelly, a few entries
		"Dalaran/1 34.89,45.42 -x- Dalaran/2 34.28,43.57",
		"Dalaran/1 60.28,47.77 -x- Dalaran/2 64.16,48.00",
		"Dalaran/1 48.30,32.54 <dist:2> -to- Dalaran/2 62.74,48.83", -- well jump!
	},
	[750] = { -- Maraudon
		"Maraudon/1 15.53,56.75 -x- Maraudon/2 28.99,4.84",
	},
	[762] = { -- Scarlet Monastery - this is funny; yes, it should be empty: floors are wings, inaccessible from each other. Rely on normal entrance/exit paths.
	},
	[691] = { -- Gnomeregan
		"Gnomeregan/1 57.67,50.98 -to- Gnomeregan/2 81.36,46.02",
		"Gnomeregan/1 47.05,86.94 -x- Gnomeregan/2 75.38,74.06",
		"Gnomeregan/2 35.21,88.08 -x- Gnomeregan/3 38.60,50.33",
		"Gnomeregan/3 48.26,71.95 -x- Gnomeregan/4 71.25,77.54",
	},
	[688] = { -- Blackfathom Deeps
		"Blackfathom Deeps/1 61.51,71.88 -x- Blackfathom Deeps/2 39.21,31.65",
		"Blackfathom Deeps/2 47.24,79.12 -x- Blackfathom Deeps/3 43.60,61.06",
	}
}

--[[
	Regions are custom subzones. Two nodes cannot connect to each other automatically if they're in different regions (or game maps, too).
	A region must have a name (and many regions can share a name), and either:
		- center (map+coords), radius (number in yards) : for coordinate-based detection
		- minimapzone (English, from GetMinimapZoneText()), optionally mapzone : for subzone name-based detection
	After those, regions can have any properties, the ones in use are:
		- nofly : nodes in the region get the 'nofly' attribute, becoming unreachable for flight
		- noallzone : nodes become 'noallzone', and the region goes "dark": nodes can connect as written in this file, but the player can only connect
			to their nearest node and is thus prevented from beelining across the region.

	In general, if you want a region to have a specific route through it, set it to noallzone so that the system doesn't ignore the route and plan a beeline instead.
	Conversely, if you set noallzone and don't plan some paths across the area, it'll become a "swamp", an area the system will try to avoid altogether.
--]]
data.basenodes.advanced = {
	{"REGION",{name="fuselight",center="Badlands 65.9,35.3",radius=100}},
	{"REGION",{name="fuselightbts",center="Badlands 90.7,36.3",radius=150}},
	{"REGION",{name="fuselightbtspre",center="Badlands 79.1,31.6",radius=150}},

	--"REGION lochmodanclimb Loch Modan 48.1,77.3 <80",

	--"REGION lochmodanclimb Loch Modan 46.1,77.3 <75",
	--"REGION lochmodanclimb Loch Modan 50.1,77.3 <75",
	{"REGION",{name="lochmodanclimb",center="Loch Modan 46.1,77.3",radius=75}},
	{"REGION",{name="lochmodanclimb",center="Loch Modan 51.1,77.3",radius=55}},
	{"REGION",{name="lochmodanclimb",center="Loch Modan 47.6,79.9",radius=50}},

	--[[
	{"REGION",{name="dmentry",mapzone=39,minimapzone="Defias Hideout",nofly=1,noallzone=1}},
	{"REGION",{name="dmentry2",mapzone=39,minimapzone="The Deadmines",nofly=1,noallzone=1}},
	{"REGION",{name="maraudon",mapzone=101,minimapzone="Maraudon",nofly=1,noallzone=1}},
	{"REGION",{name="sm_gv",mapzone=20,minimapzone="The Grand Vestibule",nofly=1}},
	{"REGION",{name="gnomer",mapzone=27,minimapzone="Gnomeregan",nofly=1,noallzone=1}},
	{"REGION",{name="gnomertrain",mapzone=27,minimapzone="Train Depot",nofly=1,noallzone=1}},
	{"REGION",{name="blackfathom",mapzone=43,minimapzone="Blackfathom Deeps",nofly=1,noallzone=1}},
	{"REGION",{name="wailingcave1",mapzone=11,minimapzone="The Wailing Caverns",nofly=1,noallzone=1}},
	{"REGION",{name="wailingcave2",mapzone=11,minimapzone="Cavern of Mists",nofly=1,noallzone=1}},
	{"REGION",{name="cotime",mapzone=161,minimapzone="Caverns of Time",nofly=1,noallzone=1}},
	--]]

	--{"REGION",{name="ironforgecenter",center="Ironforge 48,43",radius=100,nofly=1}},
}

-- different data layout, live with it
-- WATCH OUT. These are GROUND ONLY, and WILL be ignored by flight!
data.basenodes.borders = {
	[1] = {
		"Ashenvale,20.7,15.8 -x- Darkshore,38.8,96.4",
		"Ashenvale,36.8,73.8 -x- Stonetalon Mountains,73.3,40.0",
		"Ashenvale,55.8,28.8 -x- Felwood,54.7,90.8",
		"Ashenvale,68.6,86.8 -x- Northern Barrens,42.8,12.5",
		"Ashenvale,95.4,48.4 -x- Azshara,7.8,69.9",
		"Azshara,26.6,79.2 -x- Orgrimmar,76.5,1.8",
		"Azuremyst Isle,36.9,46.9 -x- The Exodar,88.3,64.9",
		"Azuremyst Isle,42.0,1.5 -x- Bloodmyst Isle,65.5,95.4",
		"Darnassus,77.0,46.4 -x- Teldrassil,38.1,47.5",
		"Desolace,42.5,97.3 -x- Feralas,44.9,2.2",
		"Desolace,54.2,2.9 -x- Stonetalon Mountains,35.7,77.2",
		"Durotar,34.1,42.4 -x- Northern Barrens,69.0,39.0",
		"Durotar,45.5,11.7 -x- Orgrimmar,49.5,93.2",
		"Dustwallow Marsh,28.5,47.2 -x- Southern Barrens,51.6,78.7",
		"Dustwallow Marsh,50.3,94.3 -x- Thousand Needles,72.3,46.6",
		"Felwood,64.3,10.3 -x- Moonglade,35.7,72.5 {name:Timbermaw Hold}",
		"Felwood,64.3,10.3 -x- Winterspring,21.2,46.1 {name:Timbermaw Hold}",
		"Feralas,89.3,42.1 -x- Thousand Needles,89.3,42.1",
		"Mulgore,38.3,33.9 -x- Thunder Bluff,38.1,79.0",
		"Mulgore,70.1,59.6 -x- Southern Barrens",
		"Northern Barrens,27.3,48.0 -x- Southern Barrens,36.7,4.8",
		"Northern Barrens,70.2,73.3 -x- The Cape of Stranglethorn,39.0,67.0",
		"Silithus,85.0,13.2 -x- Un'Goro Crater,27.0,10.7",
		"Southern Barrens,29.1,9.0 -x- Stonetalon Mountains,79.7,92.6",
		"Southern Barrens,43.3,96.5 -x- Thousand Needles,32.2,20.5",
		"Tanaris,25.9,66.3 -x- Uldum,70.6,22.5",
		"Tanaris,28.0,51.3 -x- Un'Goro Crater,70.8,91.9",

		"Un'Goro Crater,50.4,7.9 -x- Sholazar Basin,40.4,83.0 (B:PORTAL) {tag:portalauto} {cond:PlayerCompletedQuest(12613)}",
	},
	[2] = {
		"Westfall 61.8,17.8 -x- Elwynn Forest 21.0,79.7",
		"Elwynn Forest 32,50 -x- Stormwind City",
		"Westfall 67.3,62.5 -x- Duskwood 10.6,63.0",
		"Duskwood 44.9,79.2 -x- Northern Stranglethorn 51.3,11.5",
		"Northern Stranglethorn 51.1,69.8 -x- The Cape of Stranglethorn 59.2,24.3",
		"Duskwood 87.7,41.1 -x- Deadwind Pass 34.9,35.6",
		"Deadwind Pass 59.2,41.3 -x- Swamp of Sorrows 16.8,52.0",
		"Swamp of Sorrows 67.5,14.1 -x- Redridge Mountains 90.2,56.7",
		"Swamp of Sorrows 36.2,66.4 -x- Blasted Lands 48.9,10.5",
		"Elwynn Forest 91.2,73.2 -x- Redridge Mountains 13.5,64.3",
		"Redridge Mountains 16.0,69.5 -x- Duskwood 92.9,12.3",
		"Redridge Mountains 43.0,17.0 -x- Burning Steppes 67.3,81.0",
		"Redridge Mountains 64.0,17.5 -x- Burning Steppes 83.9,79.7",
		"Searing Gorge 35.3,83.9 -x- Burning Steppes 20.8,38.2",
		"Searing Gorge 72.7,55.7 -x- Badlands 7.4,52.8",
		--"Badlands 45.8,7.3 -x- Loch Modan 47.0,73.5 {title:Cross the chasm carefully!}", -- point before the chasm
		--"Badlands 45.8,7.3 -x- Loch Modan 48.13,79.19", -- for the climb, point after / in the chasm
		"Dun Morogh 90.0,51.2 -x- Loch Modan 20.8,63.5",
		"Loch Modan 13.2,22.2 -x- Dun Morogh 91.7,29.3",
		"Loch Modan 21.4,17.5 -x- Wetlands 50.1,81.8",
		"Wetlands 51.0,10.2 -x- Arathi Highlands 38.6,91.0",
		"Wetlands 79.0,47.3 -x- Twilight Highlands 24.3,37.4",
		"Arathi Highlands 13.7,31.1 -x- Hillsbrad Foothills 68.4,69.8",
		"The Hinterlands 9.7,55.7 -x- Hillsbrad Foothills 65.1,46.8",
		"The Hinterlands 24.3,42.1 -x- Western Plaguelands 65.1,86.5",
		"Hillsbrad Foothills 65.6,25.9 -x- Western Plaguelands 43.5,88.1",
		"Silverpine Forest 69.4,80.5 -x- Hillsbrad Foothills 29.4,63.3",
		"Silverpine Forest 64.9,8.4 -x- Tirisfal Glades 53.9,77.1",
		"Tirisfal Glades 84.6,70.3 -x- Western Plaguelands 29.7,57.3",
		"Western Plaguelands 69.1,50.2 -x- Eastern Plaguelands 9.3,66.1",
		"Ghostlands 47.8,13.9 -x- Eversong Woods 48.5,90.4",
		"Eversong Woods 56.4,52.0 -x- Silvermoon City 72.7,86.0",
		"Dun Morogh 58.3,37.7 -x- Ironforge 21.5,77.4",
		"Tirisfal Glades 61.9,65.0 -x- Undercity 66.2,0.4",
		"Silverpine Forest 45.3,85.7 -x- Ruins of Gilneas 60.2,9.6",
		"Twilight Highlands,24.0,37.3 -x- Wetlands,80.0,47.9",

		"Tol Barad Peninsula 66.73,82.02 -x- Tol Barad 40.95,18.53",

		"Dun Morogh 02.0,28.0 -x- Kelp'thar Forest 71.0,63.0 (B:FLY)", -- anyone can fly this one, really
		"Eastern Kingdoms 40.34,69.07 @sw_lighthouse -x- Stormwind City (B:WALK)",
		"@sw_lighthouse -x- Shimmering Expanse 70.0,74.0 (B:FLY) {cond:LibRover.HasAchievement(5180)}", -- only for epic flyers!
		"Ruins of Gilneas 72.77,99.94 -x- Dun Morogh 35.08,2.95 (B:FLY)", -- TODO: try on a normal flyer
	},
	[3] = {
		"Blade's Edge Mountains,28.5,93.9 -x- Zangarmarsh,43.3,27.5 (A:_)",
		"Blade's Edge Mountains,52.0,98.8 -x- Zangarmarsh,68.7,32.9 (H:_)",
		"Blade's Edge Mountains,82.5,28.7 -x- Netherstorm,20.0,56.1",
		"Hellfire Peninsula,31.1,92.2 -x- Terokkar Forest,58.3,19.3",
		"Hellfire Peninsula,4.7,50.6 -x- Zangarmarsh,83.0,65.5",
		"Nagrand,34.0,13.0 -x- Zangarmarsh,21.0,70.5",
		"Nagrand,74.1,32.9 -x- Zangarmarsh,74.1,32.6",
		"Nagrand,77.9,82.6 -x- Terokkar Forest,20.3,55.6",
		"Nagrand,78.3,54.5 -x- Shattrath City,12.8,56.4",
		"Shadowmoon Valley,18.0,23.7 -x- Terokkar Forest,71.3,50.4",
		"Shattrath City,76.2,77.3 -x- Terokkar Forest,36.0,31.9",
		"Shattrath City,88.0,45.0 -x- Terokkar Forest,38.9,24.1",
		"Terokkar Forest,32.3,4.7 -x- Zangarmarsh,82.2,92.5",
	},
	[4] = {
		"Borean Tundra,52.8,7.0 -x- Sholazar Basin,32.2,91.4",
		"Borean Tundra,78.9,53.6 -x- Dragonblight,48.0,78.7",
		"Borean Tundra,93.7,35.8 -x- Dragonblight,8.2,54.9",
		"Crystalsong Forest,39.8,38.4 -x- Dalaran,82.4,47.1",
		"Crystalsong Forest,46.1,71.7 -x- Dragonblight,61.3,10.1",
		"Crystalsong Forest,58.2,33.2 -x- Icecrown,89.1,84.3",
		"Crystalsong Forest,63.6,44.3 -x- The Storm Peaks,30.0,94.8",
		"Crystalsong Forest,86.3,44.3 -x- The Storm Peaks,38.6,94.8",
		"Crystalsong Forest,97.1,58.5 -x- Zul'Drak,12.0,66.9",
		"Dragonblight,48.0,78.7 -x- Borean Tundra,78.9,53.6",
		"Dragonblight,49.6,78.4 -x- Howling Fjord,23.5,57.8",
		"Dragonblight,89.0,24.0 -x- Zul'Drak,15.4,89.7",
		"Dragonblight,92.0,30.8 -x- Grizzly Hills,8.1,31.2",
		"Dragonblight,93.2,64.0 -x- Grizzly Hills,9.4,66.7",
		"Grizzly Hills,33.7,81.3 -x- Howling Fjord,24.5,11.3",
		"Grizzly Hills,67.3,70.0 -x- Howling Fjord,53.7,1.3",
		"Grizzly Hills,87.9,69.9 -x- Howling Fjord,71.6,1.3",
		"Grizzly Hills,43.0,25.3 -x- Zul'Drak,55.4,91.1",
		"Grizzly Hills,58.7,13.8 -x- Zul'Drak,71.9,79.1",
		--"Sholazar Basin,40.4,83.0 -x- Un'Goro Crater,50.4,7.9",
	},
}

data.basenodes.travel = {

	-- == SHIPS/ZEPPELINS == --

	"Orgrimmar,43.0,64.9 -x- Thunder Bluff,15.2,25.8 (H:ZEPPELIN)",
	"Orgrimmar,52.5,53.1 -x- Northern Stranglethorn,37.2,52.4 (H:ZEPPELIN)",
	"Orgrimmar,50.8,55.9 -x- Tirisfal Glades,60.7,58.8 (H:ZEPPELIN)",
	{"Orgrimmar,44.7,62.3","Borean Tundra,41.4,53.6",faction="H",mode="zeppelin"},--,cost=7*60+30},

	"Tirisfal Glades,59.1,59.0 <port:Undercity> -x- Howling Fjord,77.7,28.3 (H:ZEPPELIN)",
	"Tirisfal Glades,61.9,59.1 <port:Undercity> -x- Northern Stranglethorn,37.5,50.9 (H:ZEPPELIN)",

	"Stormwind City,18.0,25.8 -x- Borean Tundra 59.7,69.4 (A:SHIP) {cost:300}",
	"Stormwind City,22.5,55.8 -x- Teldrassil 55.0,93.7 <port:Darnassus> (A:SHIP)",
	"Stormwind City,70.5,30.0 @tramsw <noallzone:1> -x- Ironforge 78,51 (A:TRAM)",   "Stormwind City,66.4,35.0 -x- @tramsw (A:WALK) {dontsetborder:1}",
	{"Wetlands,6.4,62.2 <port:Menethil Harbor>","Dustwallow Marsh,71.5,56.3",faction="A",mode="ship"},
	{"Wetlands,5.1,55.7 <port:Menethil Harbor>","Howling Fjord,61.3,62.6 <port:Valgarde>",faction="A",mode="ship"},--,cost=300}, --ship turnaround is 450, but takes forever to depart/arrive

	-- NEUTRAL SHIPS
	"The Cape of Stranglethorn,39.0,67.0 <port:Booty Bay> -x- Northern Barrens,70.2,73.3 <port:Ratchet> (B:SHIP)", -- booty-ratchet
	"Borean Tundra 11.1,22.2 <port:Unu'pe> -x- Dragonblight 47.3,67.3 <port:Moa'ki Harbor> (B:SHIP) {tag:turtle}", -- unu'pe-moa'ki
	"@+ -x- Howling Fjord 11.1,22.2 <port:Kamagua> (B:SHIP) {tag:turtle}", -- moa'ki-kamagua


	"Eastern Plaguelands 54.5,8.4 <tag:darkportal> -x- Ghostlands 45.7,71.6 <tag:darkportal> (B:PORTAL)",

	-- == PORTALS == --

	-- ORGRIMMAR PORTALS:
	"Orgrimmar 49.2,36.5 -to- Kelp'thar Forest 44,28 (H:PORTAL) {cond:PlayerCompletedQuest(26784) and not PlayerCompletedQuest(25222)}",
	"Orgrimmar 49.2,36.5 -to- Shimmering Expanse 49.5,40.5 (H:PORTAL) {cond:PlayerCompletedQuest(25222) and not PlayerCompletedQuest(99999)}",
	"Orgrimmar 49.2,36.5 -to- Abyssal Depths 51.4,61.0 (H:PORTAL) {cond:PlayerCompletedQuest(26784)}",
	"Orgrimmar 48.9,38.5 -to- Uldum 54.9,34.3 (H:PORTAL) {cond:PlayerCompletedQuest(28112)}",
	"Orgrimmar 50.8,36.4 -to- Deepholm 50.6,52.9 (H:PORTAL) {cond:PlayerCompletedQuest(27123)}",	"Deepholm 50.9,53.1 -to- Orgrimmar 50.0,37.7 (H:PORTAL) {cond:PlayerCompletedQuest(27123)}",
	"Orgrimmar 51.1,38.3 -to- Mount Hyjal 63.5,23.4 (H:PORTAL) {cond:PlayerCompletedQuest(25316)}",	"Mount Hyjal 63.5,24.4 -to- Orgrimmar 50.0,37.7 (H:PORTAL) {cond:PlayerCompletedQuest(25316)}",
	"Orgrimmar 47.4,39.3 -to- Tol Barad Peninsula 55.8,80.1 (H:PORTAL) {cond:UnitLevel('player')>=85}", 	"Tol Barad Peninsula 56.3,79.7 -to- Orgrimmar 47.6,39.1 (H:PORTAL) {cond:UnitLevel('player')>=85}",
	--"Orgrimmar 50.2,39.4 -to- Twilight Highlands 73.6,53.4 (H:PORTAL)",	"Twilight Highlands 73.6,53.5 -to- Orgrimmar 50.1,37.9 (H:PORTAL)",
	"Orgrimmar 50.2,39.4 -x- Twilight Highlands 73.6,53.4 (H:PORTAL) {cond:PlayerCompletedQuest(26784)}",

	-- STORMWIND PORTALS
	"Stormwind City,73.2,16.9 -to- Kelp'thar Forest 44,28 (A:PORTAL) {cond:PlayerCompletedQuest(14482) and not PlayerCompletedQuest(25222)}",
	"Stormwind City,73.2,16.9 -to- Shimmering Expanse 47.2,57.5 (A:PORTAL) {cond:PlayerCompletedQuest(25222) and not PlayerCompletedQuest(99999)}",
	"Stormwind City,73.2,16.9 -to- Abyssal Depths 55.7,72.8 (A:PORTAL) {cond:PlayerCompletedQuest(14482)}",
	"Stormwind City,75.3,20.5 -to- Uldum,54.9,34.3 (A:PORTAL) {cond:PlayerCompletedQuest(28112)}",
	"Stormwind City,73.2,19.6 -to- Deepholm,48.7,53.6 (A:PORTAL) {cond:PlayerCompletedQuest(27123)}",	"Deepholm,48.5,53.8 -to- Stormwind City,74.5,18.3 (A:PORTAL) {cond:PlayerCompletedQuest(27123)}",
	"Stormwind City,76.2,18.7 -x- Mount Hyjal,62.6,23.1 (A:PORTAL) {cond:PlayerCompletedQuest(25316)}",
	"Stormwind City,73.2,18.4 -to- Tol Barad Peninsula,73.7,60.9 (A:PORTAL) {cond:UnitLevel('player')>=85}",  "Tol Barad Peninsula,75.2,58.9 -to- Stormwind City,73.4,18.3 (A:PORTAL) {cond:UnitLevel('player')>=85}",
	"Stormwind City,75.2,16.8 -x- Twilight Highlands,79.5,77.8 (A:PORTAL) {cond:PlayerCompletedQuest(27537)}",

	"The Exodar,47.6,62.2 -x- Darnassus,43.5,78.7 (A:PORTAL)",
	"Darnassus,37.3,50.5 <tag:pinkportal> -x- Teldrassil,55.1,88.4 <tag:pinkportal><port:Rut'theran Village> (B:PORTAL)",  -- Teldrassil,55.1,88.4  NO  Teldrassil,38.1,47.5

	-- portals -to- Blasted Lands
	"Blasted Lands,53.9,46.1 @bl_port_dst",
	-- Horde
	"Orgrimmar/2 44.7,68.0 -to- Blasted Lands 53.9,46.1 (H:PORTAL)",
	"Silvermoon City,49.4,14.8 -x- Undercity,56.9,11.4 (H:PORTAL) {tag:teleport}",
	-- Ally
	"Ironforge,27.2,7.0 -to- @bl_port_dst (B:PORTAL) {cond:UnitLevel('player')>=58}",
	"Stormwind City,49.0,87.3 -to- @bl_port_dst (B:PORTAL) {cond:UnitLevel('player')>=58}",
	"The Exodar,48.2,63.0 -to- @bl_port_dst (B:PORTAL) {cond:UnitLevel('player')>=58}",
	"Darnassus,44.1,78.2 -to- @bl_port_dst (B:PORTAL) {cond:UnitLevel('player')>=58}",

	-- missing: more horde BL portals

	"Blasted Lands,55.0,54.2 <tag:darkportal> -x- Hellfire Peninsula,89.4,50.2 (B:PORTAL) <tag:darkportal> {cond:UnitLevel('player')>=58}",

	"Hellfire Peninsula 88.64,52.82 -to- Stormwind City 49,87 (A:PORTAL)",
	"Hellfire Peninsula 88.6,47.7 -to- Orgrimmar 48.3,64.5 (H:PORTAL)",
	"Twilight Highlands 79.5,77.8 -to- Stormwind City 75.2,16.9 (A:PORTAL)",

	-- DALARAN PORTALS:
	"Dalaran 40.1,62.8 -to- Stormwind City 49.6,86.5 (A:PORTAL)", --COORDS BAD
	"Dalaran 55.4,25.4 -to- Orgrimmar 48.3,64.5 (H:PORTAL)",
	"Dalaran 33.6,68.6 -to- Wintergrasp,50.0,16.7 (A:PORTAL)",
	"Dalaran 58.1,25.8 -to- Wintergrasp,50.0,16.7 (H:PORTAL)",

	"Dalaran 25.5,51.4 -to- Tanaris 65.2,49.8 @cot_from_dala <region:cotime> (B:PORTAL) {cond:LibRover.cfg.use_cot or (ZGV and ZGV:GetReputation('Keepers of Time').standing>=5)}",

	-- MAGE TELEPORTS:
	"Dalaran 55.86,46.81 <spell:53140>",
	"Shattrath City 54.97,40.23 <spell:33690>",
	"Shattrath City 53.0,49.2 <spell:35715>",
	"The Exodar 47.62,59.82 <spell:32271>",
	"Dustwallow Marsh 66.00,49.00 <spell:49359>",
	"Darnassus 43.47,78.67 <spell:3565>",
	"Ironforge 25.51,08.43 <spell:3562>",
	"Moonglade 50,50 <spell:18960>",
	"Stormwind City 49.6,86.5 @sw_tp_dst <spell:3561>",
	"Orgrimmar 48.3,64.5 @org_tp_dst <spell:3567>",
	"Silvermoon City 58.3,19.2 <spell:32272>",
	"Swamp of Sorrows 49.8,55.8 <spell:49358>", --stonard
	"Thunder Bluff 22.2,16.9 <spell:3566>",
	"Tol Barad 50,50 <spell:88342>",
	"Tol Barad 50,50 <spell:88344>",
	"Undercity 84.6,16.3 <spell:3563>",
	-- DK DEATHGATE
	"Eastern Plaguelands 83.72,50.03 <spell:50977>",

	-- SHATTRATH PORTALS:
	"Shattrath City 57.2,48.3 -to- @sw_tp_dst (A:PORTAL)",
	"Shattrath City 56.8,48.9 -to- @org_tp_dst (H:PORTAL)",
	"Shattrath City 48.6,42.0 -to- Isle of Quel'Danas 48.3,34.5 (B:PORTAL)",

	-- Badlands details
	-- Fuselight-by-the-sea teleport
	"Badlands 72.1,31.6 -x- Badlands 75.6,33.2 (B:WALK)", --access
	"Badlands 82.8078,33.9781 -x- Badlands 88.0642,32.4937 (A:PORTAL) {tag:transporter}",
	-- Fuselight entrances
	"Badlands 60.7,28.3 -x- Badlands 62.8,35.7 <region:fuselight> (B:WALK)",
	"Badlands 68.7,30.9 -x- Badlands 66.7,36.3 <region:fuselight> (B:WALK)",

	-- MISCELLANEAEOAOUS
	--[[
	"Badlands 45.8,7.3 -x- Loch Modan 48.13,79.19 @lochbad01 <dist:10> <noallzone:1> (B:WALK)",
	"@lochbad01 -x- Loch Modan 48.21,77.16 @lochbad02 <dist:10> <noallzone:1> (B:WALK)",
	"@lochbad02 -x- Loch Modan 47.21,73.40 <dist:10> (B:WALK)",
	--]]

	-- Loch Modan / Badlands cross
	"Badlands 45.8,7.3",
	"@+ -x- Loch Modan 48.13,79.19 <dist:10> <noallzone:1> (B:WALK)",  -- @+ means "last one added", it's a nightmare, I know.
	--"@+ -x- Loch Modan 47.15,78.55 <dist:5> <noallzone:1> (B:WALK)",
	--"@+ -x- Loch Modan 48.22,78.08 <dist:5> <noallzone:1> (B:WALK)",
	"@+ -x- Loch Modan 48.21,77.16 <dist:5> <noallzone:1> (B:WALK)",
	"@+ -x- Loch Modan 47.28,76.00 <dist:5> <noallzone:1> (B:WALK)",
	--"@+ -x- Loch Modan 48.32,76.41 <dist:5> <noallzone:1> (B:WALK)",
	--"@+ -x- Loch Modan 46.96,73.77 <dist:5> <noallzone:1> (B:WALK)",
	"@+ -x- Loch Modan 47.21,73.40 <dist:5> (B:WALK)",

	-- Ironforge experiment
	--[[
	 "Ironforge 53,82 @if01 <costmod:0.7> (B:WALK)",
	 "Ironforge 60,70 @ifmw01 -x- Ironforge 50,58 @ifmw02 (B:WALK)",
	 "Ironforge 69,59 @iftt01 -x- Ironforge 71,39 @iftt02 (B:WALK)",
	 "Ironforge 61,27 @ifhe01 -x- Ironforge 56,34 @ifhe02 (B:WALK)",
	 "Ironforge 58,12 @iffc01 -x- Ironforge 39,11 @iffc02 (B:WALK)",
	 "Ironforge 33,23 @ifyw01 -x- Ironforge 38,38 @ifyw02 (B:WALK)",
	 "Ironforge 25,28 @if02 <costmod:0.7> (B:WALK)",
	 "Ironforge 28,55 @ift11 -x- Ironforge 39,46 @ift12 (B:WALK)",
	 "Ironforge 38,72 @ift21 -x- Ironforge 44,58 @ift22 (B:WALK)",
	 "@ifmw02 -x- @iftt02 (B:WALK)",
	 "@iftt02 -x- @ifhe02 (B:WALK)",
	 "@ifhe02 -x- @iffc02 (B:WALK)",
	 "@iffc02 -x- @ifmw02 (B:WALK)",
	 "@ifyw02 -x- @ifyw02 (B:WALK)",
	 "@ifyw02 -x- @ifyw02 (B:WALK)",
	 "@ifyw02 -x- @ifmw02 (B:WALK)",
	--]]

	--"Ironforge 50,50 @honeypot <costmod:0.7>",

	--"Blackrock Spire 50,50 <costmod:0.7>",


-- DUNGEON ENTRANCE/EXITS
	-- {style:portal_dungeon} gives the nice "enter dungeon"/"exit dungeon" mechanics.

	-- RAGEFIRE CHASM
	"Orgrimmar 70.28,48.62 -x- Ragefire Chasm 62.41,7.88 {style:portal_dungeon}",

	-- DEADMINES
	"Westfall 38.24,77.50 -x- The Deadmines 26.48,13.39 {style:portal_dungeon}",

	-- SHADOWFANG KEEP
	"Silverpine Forest 44.75,67.79 -x- Shadowfang Keep 69.46,60.97 {style:portal_dungeon}",

	-- WAILING CAVERNS
	"Northern Barrens 42.08,66.63 -x- Wailing Caverns 45.80,59.68 {style:portal_dungeon}",

	-- BLACKFATHOM DEEPS
	"Ashenvale 16.52,11.03 -x- Blackfathom Deeps 44.29,10.66 {style:portal_dungeon}",

	-- THE STOCKADE
	"Stormwind City 50.42,66.31 -x- The Stockade 50.07,68.09 {style:portal_dungeon}",

	-- GNOMEREGAN
	"Dun Morogh 25.28,36.92 -x- Gnomeregan 64.33,28.96 {style:portal_dungeon}",

	-- SCARLET MONASTERY: GRAVEYARD
	"Tirisfal Glades 84.87,30.59 -x- Scarlet Monastery/1 83.85,82.91 {style:portal_dungeon}",

	-- SCARLET MONASTERY: LIBRARY
	"Tirisfal Glades 85.31,32.21 -x- Scarlet Monastery/2 13.85,25.15 {style:portal_dungeon}",

	-- SCARLET MONASTERY: ARMORY
	"Tirisfal Glades 85.64,31.68 -x- Scarlet Monastery/3 60.26,98.17 {style:portal_dungeon}",

	-- SCARLET MONASTERY: CATHEDRAL
	"Tirisfal Glades 85.34,30.55 -x- Scarlet Monastery/4 60.40,91.31 {style:portal_dungeon}",

	-- RAZORFEN KRAUL
	"Southern Barrens 40.72,94.39 -x- Razorfen Kraul 69.89,82.97 {style:portal_dungeon}",

	-- MARAUDON: EARTHSONG FALLS
	"Desolace 29.28,61.12 -x- Maraudon 62.16,28.18 {style:portal_dungeon}",

	-- MARAUDON: THE WICKED GROTTO
	"Desolace 30.25,54.56 -x- Maraudon 78.48,68.45 {style:portal_dungeon}",

	-- MARAUDON: FOULSPORE CAVERN
	"Desolace 35.95,64.31 -x- Maraudon 62.16,28.18 {style:portal_dungeon}",

	-- ULDAMAN
	"Badlands 34.30,10.19 -x- Uldaman 67.03,72.71 {style:portal_dungeon}",

	-- DIRE MAUL: WARPWOOD QUARTER
	"Feralas 65.84,30.22 -x- Dire Maul/5 6.71,38.29 {style:portal_dungeon}",

	-- DIRE MAUL: CAPITAL GARDENS
	"Feralas 60.31,31.30 -x- Dire Maul/2 93.42,75.90 {style:portal_dungeon}",

	-- DIRE MAUL: GORDOK COMMONS
	"Feralas 62.51,24.89 -x- Dire Maul 71.13,93.54 {style:portal_dungeon}",

	-- SCHOLOMANCE
	"Western Plaguelands 69.03,72.88 -x- Scholomance 39.08,59.47 {style:portal_dungeon}",

	-- STRATHOLME: MAIN GATE
	"Eastern Plaguelands 27.61,11.63 -x- Stratholme 68.02,88.46 {style:portal_dungeon}",

	-- STRATHOLME: SERVICE ENTRACE
	"Eastern Plaguelands 43.82,17.42 -x- Stratholme/2 67.74,86.29 {style:portal_dungeon}",

	-- BLACKROCK DEPTHS
	"Searing Gorge 26.99,72.56 -x- Blackrock Depths 34.70,77.80 {style:portal_dungeon}",

	-- LOWER BLACKROCK SPIRE
	"Burning Steppes 24.34,25.63 -x- Blackrock Spire/4 26.77,38.23 {style:portal_dungeon}",

	-- UPPER BLACKROCK SPIRE
	"Burning Steppes 24.34,25.63 -x- Blackrock Spire/4 26.77,38.23 {style:portal_dungeon}",

	-- ZUL'FARRAK
	"Tanaris 39.22,21.27 -x- Zul'Farrak 56.60,90.95 {style:portal_dungeon}",

	-- RAZORFEN DOWNS
	"Thousand Needles 47.65,23.65 -x- Razorfen Downs 23.79,18.80 {style:portal_dungeon}",

	-- BLACKROCK CAVERNS
	"Burning Steppes 27.40,27.86 -x- Blackrock Caverns 32.02,70.10 {style:portal_dungeon}",

	-- ZUL'FARRAK
	"Tanaris 39.21,21.27 -x- Zul'Farrak 56.60,90.95 {style:portal_dungeon}",

	-- HELLFIRE RAMPARTS
	"Hellfire Peninsula 47.59,53.59 -x- Hellfire Ramparts 50.06,70.37 {style:portal_dungeon}",

	-- THE BLOOD FURNACE
	"Hellfire Peninsula 45.95,51.87 -x- The Blood Furnace 47.75,90.56 {style:portal_dungeon}",

	-- THE SLAVE PENS
	"Zangarmarsh 48.95,35.70 -x- The Slave Pens 19.95,13.37 {style:portal_dungeon}",

	-- THE UNDERBOG
	"Zangarmarsh 54.28,34.40 -x- The Underbog 29.68,67.88 {style:portal_dungeon}",

	-- MANA-TOMBS
	"Terokkar Forest 39.64,57.63 -x- Mana-Tombs 33.52,17.29 {style:portal_dungeon}",

	-- AUCHENAI CRYPTS
	"Terokkar Forest 34.30,65.61 -x- Auchenai Crypts 44.12,75.10 {style:portal_dungeon}",

	-- OLD HILLSBRAD FOOTHILLS
	"Tanaris 55.37,53.37 -x- Old Hillsbrad Foothills 23.23,24.80 {style:portal_dungeon}",

	-- SETHEKK HALLS
	"Terokkar Forest 44.95,65.61 -x- Sethekk Halls 73.35,36.47 {style:portal_dungeon}",

	-- SHADOW LABYRINTH
	"Terokkar Forest 39.63,73.60 -x- Shadow Labyrinth 22.01,12.45 {style:portal_dungeon}",

	-- THE STEAMVAULT
	"Zangarmarsh 50.29,33.33 -x- The Steamvault 17.59,29.76 {style:portal_dungeon}",

	-- THE SHATTERED HALLS
	"Hellfire Peninsula 47.48,52.02 -x- The Shattered Halls 61.14,92.81 {style:portal_dungeon}",

	-- THE BOTANICA
	"Netherstorm 71.76,54.93 -x- The Botanica 89.59,41.09 {style:portal_dungeon}",

	-- THE MECHANAR
	"Netherstorm 70.62,69.78 -x- The Mechanar 49.41,83.51 {style:portal_dungeon}",

	-- THE BLACK MORASS
	"Tanaris 56.95,62.37 -x- The Black Morass 52.06,0.15 {style:portal_dungeon}",

	-- MAGISTERS' TERRACE
	"Isle of Quel'Danas 61.28,30.92 -x- Magisters' Terrace/2 42.53,90.01 {style:portal_dungeon}",

	-- THE ARCATRAZ
	"Netherstorm 74.49,57.68 -x- The Arcatraz 41.26,81.70 {style:portal_dungeon}",

	-- UTGARDE KEEP
	"Howling Fjord 57.28,46.73 -x- Utgarde Keep 69.27,73.00 {style:portal_dungeon}",

	-- THE NEXUS
	"Borean Tundra 27.50,25.98 -x- The Nexus 36.20,88.0 {style:portal_dungeon}",

	-- AZJOL NERUB
	"Dragonblight 25.96,50.90 -x- Azjol-Nerub 9.44,93.32 {style:portal_dungeon}",

	-- THE OLD KINGDOM
	"Dragonblight 28.47,51.72 -x- Ahn'kahet: The Old Kingdom 88.99,79.12 {style:portal_dungeon}",

	-- DRAK'THARON KEEP
	"Zul'Drak 28.52,86.93 -x- Drak'Tharon Keep 29.38,80.96 {style:portal_dungeon}",

	-- VIOLET HOLD
	"Dalaran 68.60,70.39 -x- The Violet Hold 46.15,98.03 {style:portal_dungeon}",

	-- GUNDRAK
	"Zul'Drak 76.12,20.95 -x- Gundrak 58.99,30.92 {style:portal_dungeon}",

	-- HALLS OF STONE
	"The Storm Peaks 39.50,26.92 -x- Halls of Stone 34.4,36.2 {style:portal_dungeon}",

	-- CULLING OF STRATHOLME
	"Tanaris 61.00,62.10 -x- The Culling of Stratholme 87.51,71.21 {style:portal_dungeon}",

	-- THE OCULUS
	"Borean Tundra 27.50,25.98 -x- The Oculus 61.30,47.58 {style:portal_dungeon}",

	-- HALLS OF LIGHTNING
	"The Storm Peaks 45.38,21.37 -x- Halls of Lightning 7.38,53.81 {style:portal_dungeon}",

	-- UTGARDE PINNACLE
	"Howling Fjord 57.26,46.66 -x- Utgarde Pinnacle 44.49,16.12 {style:portal_dungeon}",

	-- TRIAL OF THE CHAMPION
	"Icecrown 74.17,20.52 -x- Trial of the Champion 51.18,30.24 {style:portal_dungeon}",

	-- FORGE OF SOULS
	"Icecrown 54.92,89.76 -x- The Forge of Souls 66.05,88.89 {style:portal_dungeon}",

	-- PIT OF SARON
	"Icecrown 54.78,91.80 -x- Pit of Saron 40.91,80.52 {style:portal_dungeon}",

	-- HALLS OF REFLECTION
	"Icecrown 55.46,90.88 -x- Halls of Reflection 47.33,80.81 {style:portal_dungeon}",
	"Pit of Saron 32.30,6.81 -x- Halls of Reflection 47.33,80.81 {style:portal_dungeon}",

	-- THRONE OF THE TIDES
	"Abyssal Depths 69.49,24.99 -x- Throne of the Tides 49.85,88.23 {style:portal_dungeon}",

	-- BLACKROCK CAVERNS
	"Burning Steppes 27.43,27.87 -x- Blackrock Caverns 32.02,70.10 {style:portal_dungeon}",

	-- THE STONECORE
	"Deepholm 47.70,52.95 -x- The Stonecore 54.27,93.90 {style:portal_dungeon}",

	-- THE VORTEX PINNACLE
	"Uldum 76.81,84.55 -x- The Vortex Pinnacle 54.12,16.81 {style:portal_dungeon}",

	-- GRIM BATOL
	"Twilight Highlands 19.14,53.84 -x- Grim Batol 12.15,55.67 {style:portal_dungeon}",

	-- HALLS OF ORIGINATION
	"Uldum 69.09,52.97 -x- Halls of Origination 49.91,93.73 {style:portal_dungeon}",

	-- LOST CITY OF THE TOL'VIR
	"Uldum 60.55,64.32 -x- Lost City of the Tol'vir 31.78,16.78 {style:portal_dungeon}",

	-- ZUL'GURUB
	"Northern Stranglethorn 72.18,32.91 -x- Zul'Gurub 30.23,48.85 {style:portal_dungeon}",

	-- ZUL'AMAN
	"Ghostlands 82.28,64.3 -x- Zul'Aman 7.32,52.97 {style:portal_dungeon}",

	-- END TIME
	"Tanaris 60.93,52.36 -x- End Time 80.73,44.20 {style:portal_dungeon}",

	-- WELL OF ETERNITY
	"Tanaris 54.56,58.74 -x- Well of Eternity 27.82,63.37 {style:portal_dungeon}",

	-- HOUR OF TWILIGHT
	"Tanaris 62.77,52.42 -x- Hour of Twilight 48.51,19.72 {style:portal_dungeon}",
}

-- These zone pairs see directly into each other, as they share "green" borders.
data.intercross = {
	{"Elwynn Forest","Duskwood"},
	{"Westfall","Duskwood"},
	{"Eversong Woods","Ghostlands"},

	{"Kelp'thar Forest","Shimmering Expanse"},
	{"Shimmering Expanse","Abyssal Depths"},
	{"Abyssal Depths","Kelp'thar Forest"},
}

-- These define zone-wide flags, if that's needed.
data.zoneflags = {
	["Razorfen Kraul"]={noallzone=1},
}

data.basenodes.inns = {
	['Teldrassil']={
		{name="Dolanaar",faction="A",npc="Innkeeper Keldamyr",npcid=6736,x=55.4,y=52.2},
	},
	['Gilneas']={
		{name="Duskhaven",faction="A",npc="Willa Arnes",npcid=38791,x=36.8,y=65.6},
		{name="Stormglen Village",faction="A",npc="Willa Arnes",npcid=38792,x=60.0,y=91.6},
	},
	['Dun Morogh']={
		{name="Gnomeregan",faction="A",npc="Nevin Twistwrench",npcid=45966,x=25.7,y=31.9},
		{name="Thunderbrew Distillery",faction="A",npc="Innkeeper Belm",npcid=1247,x=54.5,y=50.8},
	},
	['Elwynn Forest']={
		{name="Goldshire",faction="A",npc="Innkeeper Farley",npcid=295,x=43.8,y=65.8},
	},
	['Azuremyst Isle']={
		{name="Azure Watch",faction="A",npc="Caregiver Chellan",npcid=16553,x=48.4,y=49.2},
	},
	['Darnassus']={
		{name="Craftsmen's Terrace",faction="A",npc="Innkeeper Saelienne",npcid=6735,x=62.4,y=32.8},
	},
	['Darkshore']={
		{name="Lor'danel",faction="A",npc="Innkeeper Kyteran",npcid=43420,x=50.92,y=18.63},
	},
	['Ironforge']={
		{name="The Commons",faction="A",npc="Innkeeper Firebrew",npcid=5111,x=18.6,y=51.6},
	},
	['Stormwind City']={
		{name="Trade District",faction="A",npc="Innkeeper Allison",npcid=6740,x=60.8,y=74.8},
		{name="Old District",faction="A",npc="Maegan Tillman",npcid=44237,x=75.5,y=54.2},
		{name="Dwarven District",faction="A",npc="Thaegra Tillstone",npcid=44235,x=64.8,y=32.3},
	},
	['The Exodar']={
		{name="The Exodar",faction="A",npc="Caregiver Breel",npcid=16739,x=59.91,y=19.45},
	},
	['Loch Modan']={
		{name="Stoutlager Inn",faction="A",npc="Innkeeper Hearthstove",npcid=6734,x=35.5,y=48.4},
		{name="The Farstrider Lodge",faction="A",npc="Vyrin Swiftmend",npcid=1156,x=81.9,y=64.5},
	},
	['Westfall']={
		{name="Sentinel Hill",faction="A",npc="Innkeeper Heather",npcid=8931,x=52.8,y=53.6},
	},
	['Bloodmyst Isle']={
		{name="Blood Watch",faction="A",npc="Caregiver Topher Loaal",npcid=17553,x=55.6,y=59.6},
	},
	['Redridge Mountains']={
		{name="Lakeshire",faction="A",npc="Innkeeper Brianna",npcid=6727,x=26.4,y=41.4},
	},
	['Wetlands']={
		{name="Deepwater Tavern",faction="A",npc="Innkeeper Helbrek",npcid=1464,x=10.7,y=60.8},
		{name="Greenwarden's Grove",faction="A",npc="Innkeeper Larisal",npcid=43993,x=58.2,y=39.2},
		{name="Swiftgear Station",faction="A",npc="Innkeeper Daughny",npcid=44006,x=25.6,y=25.8},
	},
	['Duskwood']={
		{name="Darkshire",faction="A",npc="Innkeeper Trelayne",npcid=6790,x=73.9,y=44.4},
	},
	['Ashenvale']={
		{name="Astranaar",faction="A",npc="Innkeeper Kimlya",npcid=6738,x=37.0,y=49.2},
		{name="Splintertree Post",faction="H",npc="Innkeeper Kaylisk",npcid=12196,x=74.0,y=60.6},
		{name="Silverwind Refuge",faction="H",npc="Innkeeper Chin'toka",npcid=43633,x=50.4,y=67.0},
		{name="Zoram'gar Outpost",faction="H",npc="Innkeeper Duras",npcid=43606,x=12.8,y=34.0},
		{name="Hellscream's Watch",faction="H",npc="Innkeeper Linkasa",npcid=43624,x=38.6,y=42.2},
	},
	['Stonetalon Mountains']={
		{name="Windshear Hold",faction="A",npc="Alithia Fallowmere",npcid=40898,x=59.0,y=56.4},
		{name="Northwatch Expedition Base Camp",faction="A",npc="Lyanath",npcid=41286,x=71.1,y=79.1},
		{name="Thal\'darah Overlook",faction="A",npc="Valos Shadowrest",npcid=41491,x=39.4,y=32.8},
		{name="Farwatcher's Glen",faction="A",npc="Innkeeper Bernice",npcid=44177,x=31.4,y=60.6},
		{name="Krom'gar Fortress",faction="H",npc="Felonius Stark",npcid=41892,x=66.4,y=64.2},
		{name="Sun Rock Retreat",faction="H",npc="Innkeeper Jayka",npcid=7731,x=50.4,y=63.8},
	},
	['Desolace']={
		{name="Nijel's Point",faction="A",npc="Innkeeper Lyshaerya",npcid=11103,x=66.2,y=6.6},
		{name="Shadowprey Village",faction="H",npc="Innkeeper Sikewa",npcid=11106,x=24.0,y=68.2},
	},
	['Dustwallow Marsh']={
		{name="Theramore Isle",faction="A",npc="Innkeeper Janene",npcid=6272,x=66.6,y=45.2},
		{name="Brackenwall Village",faction="H",npc="\"Little\" Logok",npcid=24208,x=36.8,y=32.2},
		{name="Mudsprocket",faction="B",npc="Axle",npcid=23995,x=41.8,y=74.0},
	},
	['Felwood']={
		{name="Talonbranch Glade",faction="A",npc="Denmother Ulrica",npcid=47931,x=61.8,y=26.6},
	},
	['Borean Tundra']={
		{name="Valiance Keep",faction="A",npc="James Deacon",npcid=25245,x=58.2,y=68.0},
		{name="Fizzcrank Airstrip",faction="A",npc="\"Charlie\" Northtop",npcid=26596,x=57.0,y=18.6},
		{name="Warsong Hold",faction="H",npc="Williamson",npcid=25278,x=41.8,y=54.6},
		{name="Taunka'le Village",faction="H",npc="Pahu Frosthoof",npcid=26709,x=76.2,y=37.2},
		{name="Unu'pe",faction="B",npc="Caregiver Poallu",npcid=27187,x=78.4,y=49.2},
	},
	['Howling Fjord']={
		{name="Valgarde",faction="A",npc="Innkeeper Hazel Lagras",npcid=23731,x=58.4,y=62.6},
		{name="Westguard Keep",faction="A",npc="Innkeeper Celeste Goodhutch",npcid=23937,x=30.8,y=41.4},
		{name="Fort Wildervar",faction="A",npc="Christina Daniels",npcid=24057,x=60.4,y=15.8},
		{name="Vengeance Landing",faction="H",npc="Timothy Holland",npcid=24342,x=79.7,y=30.8},
		{name="New Agamand",faction="H",npc="Basil Osgood",npcid=24149,x=52.2,y=66.4},
		{name="Camp Winterhoof",faction="H",npc="Bori Wintertotem",npcid=24033,x=49.4,y=10.8},
		{name="Kamagua",faction="B",npc="Caregiver Iqniq",npcid=27148,x=25.4,y=59.8},
	},
	['Dragonblight']={
		{name="Wintergarde Keep",faction="A",npc="Illusia Lune",npcid=27042,x=77.4,y=51.6},
		{name="Stars' Rest",faction="A",npc="Naohain",npcid=27052,x=28.8,y=56.0},
		{name="Venomspite",faction="H",npc="Mrs. Winterby",npcid=27027,x=76.8,y=63.0},
		{name="Agmar's Hammer",faction="H",npc="Barracks Master Harga",npcid=26985,x=38.2,y=46.6},
		{name="Moa'ki Harbor",faction="B",npc="Caregiver Mumik",npcid=27174,x=48.2,y=74.6},
		{name="Wyrmrest Temple",faction="B",npc="Demestrasz",npcid=27950,x=59.8,y=54.2},
	},
	['Grizzly Hills']={
		{name="Amberpine Lodge",faction="A",npc="Jennifer Bell",npcid=27066,x=32.0,y=60.2},
		{name="Westfall Brigade Encampment",faction="A",npc="Quartermaster McCarty",npcid=26375,x=59.6,y=26.4},
		{name="Conquest Hold",faction="H",npc="Barracks Master Rhekku",npcid=27125,x=20.8,y=64.6},
		{name="Camp Oneqwah",faction="H",npc="Aiyan Coldwind",npcid=26680,x=65.4,y=47.0},
	},
	['Dalaran']={
		{name="Dalaran",faction="B",npc="Amisi Azuregaze",npcid=28687,x=51.0,y=40.0}, -- this is the universal innkeeper in Dalaran for our purpose. GetBindLocation() returns Dalaran so needed a way to find it.
		{name="The Silver Enclave",faction="A",npc="Isirami Fairwind",npcid=32413,x=44.6,y=63.0},
		{name="Sunreaver's Sanctuary",faction="H",npc="Uda the Beast",npcid=31557,x=65.6,y=32.6},
		{name="Sunreaver's Sanctuary",faction="H",npc="Abohba",npcid=32418,x=69.0,y=33.4},
		{name="Runeweaver Square",faction="B",npc="Amisi Azuregaze",npcid=28687,x=51.0,y=40.0},
		{name="The Underbelly",faction="B",npc="Ajay Green",npcid=29532,x=37.0,y=56.8},
	},
	['The Storm Peaks']={
		{name="Frosthold",faction="A",npc="Gunda Boldhammer",npcid=29926,x=28.6,y=74.4},
		{name="Camp Tunka'lo",faction="H",npc="Wabada Whiteflower",npcid=29971,x=67.6,y=50.6},
		{name="Grom'arsh Crash-Site",faction="H",npc="Peon Gakra",npcid=29944,x=37.0,y=49.6},
		{name="K3",faction="B",npc="Smilin\' Slirk Brassknob",npcid=29904,x=41.0,y=85.8},
		{name="Brunnhildar Village",faction="B",npc="Lodge-Matron Embla",npcid=30005,x=48.8,y=65.0},
		{name="Bouldercrag's Refuge",faction="B",npc="Magorn",npcid=29963,x=30.8,y=37.2},
	},
	['Icecrown']={
		{name="Argent Tournament Grounds",faction="A",npc="Caris Sunlance",npcid=33970,x=76.2,y=19.6},
		{name="Argent Tournament Grounds",faction="H",npc="Jarin Dawnglow",npcid=33971,x=76.0,y=24.0},
		{name="Shadow Vault",faction="H",npc="Initiate Brenners",npcid=30308,x=44.0,y=22.2},
	},
	['Durotar']={
		{name="Razor Hill",faction="H",npc="Innkeeper Grosk",npcid=6928,x=51.6,y=41.6},
	},
	['The Lost Isles']={
		{name="Shipwreck Shore",faction="H",npc="Grimy Greasefingers",npcid=36496,x=28.0,y=75.8},
		{name="Town-In-A-Box",faction="H",npc="Grimy Greasefingers",npcid=42473,x=45.0,y=65.4},
	},
	['Mulgore']={
		{name="Bloodhoof Village",faction="H",npc="Innkeeper Kauth",npcid=6747,x=46.8,y=60.4},
	},
	['Tirisfal Glades']={
		{name="Brill",faction="H",npc="Innkeeper Renee",npcid=5688,x=60.8,y=51.6},
		{name="The Bulwark",faction="H",npc="Provisioner Elda",npcid=46271,x=83.0,y=71.8},
	},
	['Eversong Woods']={
		{name="Falconwing Square",faction="H",npc="Innkeeper Delaniel",npcid=15433,x=48.1,y=47.7},
		{name="Fairbreeze Village",faction="H",npc="Thersa Windsong",npcid=8393,x=49.6,y=70.6},
	},
	['Orgrimmar']={
		{name="Valley of Strength",faction="H",npc="Innkeeper Gryshka",npcid=6929,x=53.6,y=78.8},
		{name="Valley of Honor",faction="H",npc="Innkeeper Nufa",npcid=46642,x=70.6,y=49.2},
		{name="Valley of Wisdom",faction="H",npc="Miwana",npcid=44785,x=39.2,y=48.4},
		{name="Goblin Slums",faction="H",npc="Tinza Silvermug",npcid=45563,x=39.8,y=81.0},
		{name="Valley of Spirits",faction="H",npc="Sijambi",npcid=45086,x=32.8,y=65.6},
	},
	['Thunder Bluff']={
		{name="Lower Rise",faction="H",npc="Innkeeper Pala",npcid=6746,x=45.8,y=64.6},
	},
	['Undercity']={
		{name="The Trade Quarter",faction="H",npc="Innkeeper Norman",npcid=6741,x=67.8,y=38.6},
	},
	['Silvermoon City']={
		{name="The Royal Exchange",faction="H",npc="Innkeeper Velandra",npcid=16618,x=79.6,y=58.6},
		{name="The Bazaar",faction="H",npc="Innkeeper Jovia",npcid=17630,x=79.6,y=58.6},
	},
	['Silverpine Forest']={
		{name="The Sepulcher",faction="H",npc="Innkeeper Velandra",npcid=6739,x=46.4,y=42.6},
		{name="Forsaken Rear Guard",faction="H",npc="Commander Hickley",npcid=45496,x=44.4,y=20.6},
	},
	['Ghostlands']={
		{name="Tranquillien",faction="H",npc="Innkeeper Kalarin",npcid=16542,x=48.8,y=32.4},
	},
	['Northern Barrens']={
		{name="The Crossroads",faction="H",npc="Innkeeper Boorand Plainswind",npcid=3934,x=49.6,y=58.0},
		{name="Grol'dom Farm",faction="H",npc="Innkeeper Kerntis",npcid=43946,x=56.2,y=40.0},
		{name="Nozzlepot's Outpost",faction="H",npc="Innkeeper Kritzle",npcid=43945,x=62.4,y=16.6},
		{name="Ratchet",faction="B",npc="Innkeeper Wiley",npcid=6791,x=67.2,y=74.6},
	},
	['Southern Barrens']={
		{name="Honor's Stand",faction="A",npc="Logistics Officer Renaldo",npcid=44219,x=39.0,y=11.0},
		{name="Northwatch Hold",faction="A", npc="Keep Watcher Kerry",npcid=44268,x=65.6,y=46.6},
		{name="Fort Triumph",faction="A", npc="Logistics Officer Salista",npcid=44267,x=49.0,y=68.5},
		{name="Camp Taurajo",faction="H",npc="Byula",npcid=7714,x=44.2,y=33.6},
		{name="Hunter's Hill",faction="H",npc="Innkeeper Hurnahet",npcid=44270,x=39.2,y=20.0},
		{name="Desolation Hold",faction="H",npc="Innkeeper Lhakadd",npcid=44276,x=40.8,y=69.2},
	},
	['Hillsbrad Foothills']={
		{name="Tarren Mill",faction="H",npc="Innkeeper Shay",npcid=2388,x=57.8,y=47.2},
		{name="The Sludge Fields",faction="H",npc="Innkeeper Hershberg",npcid=49394,x=35.8,y=61.2},
		{name="Eastpoint Tower",faction="H",npc="Innkeeper Durgens",npcid=49430,x=59.6,y=64.8},
	},
	['Thousand Needles']={
		{name="Freewind Post",faction="H",npc="Innkeeper Jayka",npcid=7731,x=50.4,y=63.8},
	},
	['Arathi Highlands']={
		{name="Refuge Pointe",faction="A",npc="Vikki Lonsav",npcid=2808,x=39.9,y=49.0},
		{name="Hammerfall",faction="H",npc="Innkeeper Jayka",npcid=7731,x=50.4,y=63.8},
	},
	['Northern Stranglethorn']={
		{name="Fort Livingston",faction="A",npc="Livingston Marshal",npcid=44019,x=53.2,y=66.8},
		{name="Grom'gol Base Camp",faction="H",npc="Innkeeper Thulbek",npcid=5814,x=37.2,y=51.8},
	},
	['The Cape of Stranglethorn']={
		{name="Booty Bay",faction="B",npc="Innkeeper Skindle",npcid=6807,x=40.8,y=73.8},
		{name="Hardwrench Hideaway",faction="H",npc="Innkeeper Draxle",npcid=44190,x=35.0,y=27.2},
	},
	['Swamp of Sorrows']={
		{name="Bogpaddle",faction="B",npc="Cap'n Geech",npcid=47334,x=71.7,y=13.9},
		{name="The Harborage",faction="A",npc="Verad",npcid=47367,x=29.0,y=32.5},
		{name="Stonard",faction="H",npc="Innkeeper Karakul",npcid=6930,x=46.8,y=56.8},
	},
	['Badlands']={
		{name="Dragon's Mouth",faction="A",npc="Ivan Zypher",npcid=48093,x=20.7,y=56.2},
		{name="New Kargath",faction="H",npc="Innkeeper Shul\'kar",npcid=9356,x=18.2,y=42.8},
	},
	['Feralas']={
		{name="Dreamer's Rest",faction="A",npc="Andoril",npcid=40968,x=51.0,y=17.8},
		{name="Feathermoon Stronghold",faction="A",npc="Innkeeper Shyria",npcid=44391,x=46.0,y=45.2},
		{name="Camp Mojache",faction="H",npc="Innkeeper Greul",npcid=7737,x=74.8,y=45.2},
		{name="Camp Ataya",faction="H",npc="Adene Treetotem",npcid=40467,x=41.4,y=15.6},
		{name="Stonemaul Hold",faction="H",npc="Chonk",npcid=44376,x=51.8,y=47.6},
	},
	['The Hinterlands']={
		{name="Stormfeather Outpost",faction="A",npc="Innkeeper Keirnan",npcid=43699,x=66.2,y=44.4},
		{name="Aerie Peak",faction="A",npc="Innkeeper Thulfram",npcid=7744,x=14.0,y=44.8},
		{name="Revantusk Village",faction="H",npc="Lard",npcid=14731,x=78.2,y=81.2},
		{name="Hiri'watha Research Station",faction="H",npc="Bitsy",npcid=43739,x=31.8,y=58.0},
	},
	['Hellfire Peninsula']={
		{name="Thrallmar",faction="H",npc="Floyd Pinkus",npcid=16602,x=56.6,y=37.6},
		{name="Falcon Watch",faction="H",npc="Innkeeper Bazil Olof'tazun",npcid=18905,x=26.8,y=59.6},
		{name="Honor Hold",faction="A",npc="Sid Libardi",npcid=16826,x=54.2,y=63.5},
		{name="Temple of Telhamat",faction="A",npc="Caregiver Ophera Windfury",npcid=18906,x=23.4,y=36.4},
	},
	['Zangarmarsh']={
		{name="Zabra'jin",faction="H",npc="Innkeeper Bazil Olof\'tazun",npcid=18905,x=26.8,y=59.6},
		{name="Cenarion Refuge",faction="B",npc="Innkeeper Coryth Stoktron",npcid=18907,x=78.6,y=63.0},
		{name="Orebor Harborage",faction="A",npc="Innkeeper Kerp",npcid=18908,x=41.9,y=26.3},
		{name="Telredor",faction="A",npc="Caregiver Abidaar",npcid=18251,x=67.2,y=49.0},
	},
	['Terokkar Forest']={
		{name="Allerian Stronghold",faction="A",npc="Innkeeper Biribi",npcid=19296,x=56.7,y=53.3},
		{name="Stonebreaker Hold",faction="H",npc="Innkeeper Grilka",npcid=18957,x=48.8,y=45.0},
	},
	['Nagrand']={
		{name="Telaar",faction="A",npc="Caregiver Isel",npcid=18914,x=54.2,y=76.0},
		{name="Garadar",faction="H",npc="Matron Tikkit",npcid=18913,x=56.6,y=34.6},
	},
	['Blade\'s Edge Mountains']={
		{name="Sylvanaar",faction="A",npc="Innkeeper Shaunessy",npcid=19495,x=35.8,y=63.9},
		{name="Toshley's Station",faction="A",npc="Fizit \"Doc\" Clocktok",npcid=21110,x=61.0,y=68.1},
		{name="Thunderlord Stronghold",faction="H",npc="Gholah",npcid=19470,x=53.2,y=55.4},
		{name="Mok'Nathal Village",faction="H",npc="Matron Varah",npcid=21088,x=76.0,y=60.2},
		{name="Evergrove",faction="B",npc="Innkeeper Aelerya",npcid=22922,x=62.8,y=38.2},
	},
	['Shadowmoon Valley']={
		{name="Shadowmoon Village",faction="H",npc="Innkeeper Darg Bloodclaw",npcid=19319,x=30.2,y=27.8},
		{name="Altar of Sha'tar",faction="B",npc="Caretaker Aluuro",npcid=21746,x=61.0,y=28.2},-- // ALDOR ONLY
		{name="Sanctum of the Stars",faction="B",npc="Roldemar",npcid=21744,x=56.2,y=59.8},-- // SCRYER ONLY
		{name="Wildhammer Stronghold",faction="A",npc="Dreg Cloudsweeper",npcid=19352,x=37.0,y=58.2},
	},
	['Winterspring']={
		{name="Everlook",faction="B",npc="Innkeeper Vizzie",npcid=11118,x=59.8,y=51.8},
	},
	['Silithus']={
		{name="Cenarion Hold",faction="B",npc="Calandrath",npcid=15174,x=55.4,y=36.6},
	},
	['Eastern Plaguelands']={
		{name="Light's Hope Chapel",faction="B",npc="Jessica Chambers",npcid=16256,x=75.6,y=52.4},
	},
	['Shattrath City']={
		{name="Aldor Rise",faction="B",npc="Minalei",npcid=19046,x=28.2,y=48.4},-- // ALDOR ONLY
		{name="Scryer's Tier",faction="B",npc="Innkeeper Haelthol",npcid=19232,x=56.2,y=81.6},-- // SCRYER ONLY
	},
	['Netherstorm']={
		{name="Area 52",faction="B",npc="Innkeeper Remi Dodoso",npcid=19571,x=32.0,y=64.4},
		{name="The Stormspire",faction="B",npc="Eyonix",npcid=19531,x=43.4,y=36.0},
	},
	['Isle of Quel\'Danas']={
		{name="Sun's Reach Harbor",faction="B",npc="Caregiver Inaara",npcid=25036,x=51.2,y=33.4},
	},
	['Zul\'Drak']={
		{name="The Argent Stand",faction="B",npc="Marissa Everwatch",npcid=28791,x=40.8,y=66.2},
		{name="Zim'Torga",faction="B",npc="Pan\'ya",npcid=29583,x=59.2,y=57.2},
	},
	['Sholazar Basin']={
		{name="Nesingwary Base Camp",faction="B",npc="Purser Boulian",npcid=28038,x=26.8,y=59.2},
	},
	['Western Plaguelands']={
		{name="Chillwind Camp",faction="A",npc="Mother Matterly",npcid=46269,x=43.4,y=84.6},
		{name="Andorhal",faction="H",npc="Roman Garner",npcid=47857,x=48.2,y=63.8},
	},
	['Searing Gorge']={
		{name="Iron Summit",faction="A",npc="Velma Rockslide",npcid=47942,x=39.4,y=66.2},
	},
	['Blasted Lands']={
		{name="Surwich",faction="A",npc="Donna Berrymore",npcid=44334,x=44.4,y=87.6},
		{name="Nethergarde Keep",faction="A",npc="Mama Morton",npcid=44325,x=60.7,y=14.0},
		{name="Dreadmaul Hold",faction="H",npc="Innkeeper Grak",npcid=44309,x=40.4,y=11.4},
	},
	['Kelp\'thar Forest']={
		{name="The Briny Cutter",faction="A",npc="Erunak Stonespeaker",npcid=40697,x=45.2,y=23.4},
		{name="Legion's Fate",faction="H",npc="Erunak Stonespeaker",npcid=41794,x=39.6,y=30.8},
	},
	['Shimmering Expanse']={
		{name="Silver Tide Hollow",faction="A",npc="Caretaker Movra",npcid=39878,x=49.2,y=41.9},
		{name="Tranquil Wash",faction="A",npc="Anissa Matherly",npcid=42873,x=49.7,y=57.4},
		{name="Legion's Rest",faction="H",npc="Zun'ja",npcid=42908,x=51.6,y=62.6},
	},
	['Abyssal Depths']={
		{name="Darkbreak Cove",faction="A",npc="Barracks Officer Milson",npcid=42963,x=54.8,y=72.1},
		{name="Tenebrous Cavern",faction="H",npc="Innkeeper Nerius",npcid=43141,x=51.2,y=60.6},
	},
	['Uldum']={
		{name="Ramkahen",faction="A",npc="Kazemde",npcid=48886,x=54.7,y=32.9},
		{name="Oasis of Vir'sar",faction="A",npc="Yasmin",npcid=49406,x=26.6,y=7.3},
	},
	['Twilight Highlands']={
		{name="Thundermar",faction="A",npc="Naveen Tendernose",npcid=49591,x=49.5,y=30.4},
		{name="Highbank",faction="A",npc="Innkeeper Francis",npcid=49688,x=79.4,y=78.5},
		{name="Highbank",faction="A",npc="Innkeeper Teresa",npcid=49686,x=79.0,y=77.6},
		{name="Firebeard's Patrol",faction="A",npc="Innkeeper Corlin",npcid=49795,x=60.4,y=58.0},
		{name="Kirthaven",faction="A",npc="Vaughn Blusterbeard",npcid=49574,x=54.6,y=18.0},
		{name="Victor's Point",faction="A",npc="Ben Mora",npcid=49599,x=43.6,y=57.3},
		{name="Dragonmaw Port",faction="H",npc="Innkeeper Lutz",npcid=49498,x=75.8,y=52.6},
		{name="The Krazzworks",faction="H",npc="Innkeeper Geno",npcid=49783,x=75.4,y=16.6},
		{name="Bloodgulch",faction="H",npc="Innkeeper Turk",npcid=49762,x=53.2,y=42.8},
		{name="Crushblow",faction="H",npc="Innkeeper Krum",npcid=49747,x=45.2,y=76.4},
	},
	['Mount Hyjal']={
		{name="Nordrassil Inn",faction="A",npc="Sebelia",npcid=40843,x=63.1,y=24.1},
	},
	['Deepholm']={
		{name="Temple of Earth",faction="B",npc="?",npcid=0,x=50.0,y=50.0},
	},
}

data.flightcost = {
	[1] = {
		["205:745"] = {
			["Name"] = "The Exodar",
			["Neighbors"] = {
				["218:824"] = 89, -- Blood Watch, Bloodmyst Isle
				["410:832"] = 101, -- Rut'theran Village, Teldrassil
				["242:734"] = 40, -- Azure Watch, Azuremyst Isle
			},
		},
		["218:824"] = {
			["Name"] = "Blood Watch, Bloodmyst Isle",
			["Neighbors"] = {
				["205:745"] = 101, -- The Exodar
			},
		},
		["242:734"] = {
			["Name"] = "Azure Watch, Azuremyst Isle",
			["Neighbors"] = {
				["205:745"] = 41, -- The Exodar
			},
		},
		["313:307"] = {
			["Name"] = "Feathermoon, Feralas",
			["Neighbors"] = {
				["396:493"] = 227, -- Nijel's Point, Desolace
				["418:209"] = 153, -- Cenarion Hold, Silithus
			},
		},
		["316:415"] = {
			["Name"] = "Shadowprey Village, Desolace",
			["Neighbors"] = {
				["449:438"] = 178, -- Thunder Bluff, Mulgore
				["442:306"] = 196, -- Camp Mojache, Feralas
				["407:527"] = 199, -- Sun Rock Retreat, Stonetalon Mountains
				["383:445"] = 83, -- Karnum's Glade, Desolace
				["358:469"] = 77, -- Furien's Post, Desolace
				["348:473"] = 91, -- Ethel Rethor, Desolace
				["345:361"] = 71, -- Camp Ataya, Feralas
				["461:483"] = 172, -- Malaka'jin, Stonetalon Mountains
			},
		},
		["342:897"] = {
			["Name"] = "Darnassus, Teldrassil",
			["Neighbors"] = {
				["410:832"] = 109, -- Rut'theran Village, Teldrassil
				["410:893"] = 62, -- Dolanaar, Teldrassil
			},
		},
		["344:418"] = {
			["Name"] = "Thargad's Camp, Desolace",
			["Neighbors"] = {
				["360:304"] = 126, -- Feathermoon, Feralas
				["370:358"] = 54, -- Dreamer's Rest, Feralas
				["348:473"] = 63, -- Ethel Rethor, Desolace
				["396:493"] = 102, -- Nijel's Point, Desolace
				["387:575"] = 158, -- Thal'darah Overlook, Stonetalon Mountains
				["383:445"] = 56, -- Karnum's Glade, Desolace
			},
		},
		["345:361"] = {
			["Name"] = "Camp Ataya, Feralas",
			["Neighbors"] = {
				["316:415"] = 68, -- Shadowprey Village, Desolace
				["372:298"] = 78, -- Stonemaul Hold, Feralas
			},
		},
		["348:473"] = {
			["Name"] = "Ethel Rethor, Desolace",
			["Neighbors"] = {
				["396:493"] = 66, -- Nijel's Point, Desolace
				["383:445"] = 39, -- Karnum's Glade, Desolace
				["316:415"] = 80, -- Shadowprey Village, Desolace
				["358:469"] = 17, -- Furien's Post, Desolace
				["407:465"] = 52, -- Thunk's Abode, Desolace
				["344:418"] = 52, -- Thargad's Camp, Desolace
			},
		},
		["358:469"] = {
			["Name"] = "Furien's Post, Desolace",
			["Neighbors"] = {
				["383:445"] = 38, -- Karnum's Glade, Desolace
				["316:415"] = 68, -- Shadowprey Village, Desolace
				["348:473"] = 10, -- Ethel Rethor, Desolace
				["442:306"] = 249, -- Camp Mojache, Feralas
				["407:527"] = 107, -- Sun Rock Retreat, Stonetalon Mountains
			},
		},
		["360:304"] = {
			["Name"] = "Feathermoon, Feralas",
			["Neighbors"] = {
				["396:493"] = 227, -- Nijel's Point, Desolace
				["418:209"] = 118, -- Cenarion Hold, Silithus
				["370:358"] = 55, -- Dreamer's Rest, Feralas
				["344:418"] = 147, -- Thargad's Camp, Desolace
				["367:527"] = 204, -- Farwatcher's Glen, Stonetalon Mountains
				["447:282"] = 92, -- Shadebough, Feralas
				["464:794"] = 495, -- Lor'danel, Darkshore
				["389:287"] = 31, -- Tower of Estulan, Feralas
			},
		},
		["367:527"] = {
			["Name"] = "Farwatcher's Glen, Stonetalon Mountains",
			["Neighbors"] = {
				["360:304"] = 219, -- Feathermoon, Feralas
				["408:544"] = 44, -- Mirkfallon Post, Stonetalon Mountains
				["462:497"] = 115, -- Northwatch Expedition Base Camp, Stonetalon Mountains
				["396:493"] = 63, -- Nijel's Point, Desolace
				["387:575"] = 53, -- Thal'darah Overlook, Stonetalon Mountains
				["432:539"] = 76, -- Windshear Fortress, Stonetalon Mountains
			},
		},
		["370:358"] = {
			["Name"] = "Dreamer's Rest, Feralas",
			["Neighbors"] = {
				["360:304"] = 56, -- Feathermoon, Feralas
				["344:418"] = 68, -- Thargad's Camp, Desolace
			},
		},
		["372:298"] = {
			["Name"] = "Stonemaul Hold, Feralas",
			["Neighbors"] = {
				["416:207"] = 106, -- Cenarion Hold, Silithus
				["345:361"] = 66, -- Camp Ataya, Feralas
				["442:306"] = 70, -- Camp Mojache, Feralas
			},
		},
		["383:445"] = {
			["Name"] = "Karnum's Glade, Desolace",
			["Neighbors"] = {
				["316:415"] = 83, -- Shadowprey Village, Desolace
				["358:469"] = 39, -- Furien's Post, Desolace
				["348:473"] = 40, -- Ethel Rethor, Desolace
				["407:465"] = 29, -- Thunk's Abode, Desolace
				["407:527"] = 91, -- Sun Rock Retreat, Stonetalon Mountains
				["344:418"] = 49, -- Thargad's Camp, Desolace
				["396:493"] = 56, -- Nijel's Point, Desolace
				["387:575"] = 121, -- Thal'darah Overlook, Stonetalon Mountains
			},
		},
		["387:575"] = {
			["Name"] = "Thal'darah Overlook, Stonetalon Mountains",
			["Neighbors"] = {
				["423:647"] = 127, -- Blackfathom Camp, Ashenvale
				["408:544"] = 41, -- Mirkfallon Post, Stonetalon Mountains
				["444:691"] = 168, -- Grove of the Ancients, Darkshore
				["462:497"] = 101, -- Northwatch Expedition Base Camp, Stonetalon Mountains
				["344:418"] = 143, -- Thargad's Camp, Desolace
				["396:493"] = 109, -- Nijel's Point, Desolace
				["462:603"] = 171, -- Astranaar, Ashenvale
				["367:527"] = 63, -- Farwatcher's Glen, Stonetalon Mountains
				["464:794"] = 253, -- Lor'danel, Darkshore
				["463:565"] = 87, -- Stardust Spire, Ashenvale
				["383:445"] = 121, -- Karnum's Glade, Desolace
				["432:539"] = 83, -- Windshear Fortress, Stonetalon Mountains
			},
		},
		["389:287"] = {
			["Name"] = "Tower of Estulan, Feralas",
			["Neighbors"] = {
				["360:304"] = 34, -- Feathermoon, Feralas
				["447:282"] = 61, -- Shadebough, Feralas
			},
		},
		["396:493"] = {
			["Name"] = "Nijel's Point, Desolace",
			["Neighbors"] = {
				["313:307"] = 232, -- Feathermoon, Feralas
				["636:330"] = 308, -- Theramore, Dustwallow Marsh
				["360:304"] = 232, -- Feathermoon, Feralas
				["344:418"] = 81, -- Thargad's Camp, Desolace
				["367:527"] = 52, -- Farwatcher's Glen, Stonetalon Mountains
				["462:497"] = 81, -- Northwatch Expedition Base Camp, Stonetalon Mountains
				["463:565"] = 105, -- Stardust Spire, Ashenvale
				["387:575"] = 101, -- Thal'darah Overlook, Stonetalon Mountains
				["464:794"] = 337, -- Lor'danel, Darkshore
				["348:473"] = 49, -- Ethel Rethor, Desolace
				["383:445"] = 50, -- Karnum's Glade, Desolace
				["407:465"] = 31, -- Thunk's Abode, Desolace
				["432:539"] = 73, -- Windshear Fortress, Stonetalon Mountains
			},
		},
		["399:577"] = {
			["Name"] = "Cliffwalker Post, Stonetalon Mountains",
			["Neighbors"] = {
				["471:612"] = 62, -- Hellscream's Watch, Ashenvale
				["420:562"] = 21, -- The Sludgewerks, Stonetalon Mountains
				["407:527"] = 43, -- Sun Rock Retreat, Stonetalon Mountains
				["407:625"] = 50, -- Zoram'gar Outpost, Ashenvale
				["461:483"] = 63, -- Malaka'jin, Stonetalon Mountains
				["451:525"] = 44, -- Krom'gar Fortress, Stonetalon Mountains
			},
		},
		["407:465"] = {
			["Name"] = "Thunk's Abode, Desolace",
			["Neighbors"] = {
				["383:445"] = 56, -- Karnum's Glade, Desolace
				["348:473"] = 63, -- Ethel Rethor, Desolace
				["449:438"] = 46, -- Thunder Bluff, Mulgore
				["396:493"] = 33, -- Nijel's Point, Desolace
			},
		},
		["407:527"] = {
			["Name"] = "Sun Rock Retreat, Stonetalon Mountains",
			["Neighbors"] = {
				["316:415"] = 143, -- Shadowprey Village, Desolace
				["557:469"] = 150, -- Crossroads, Northern Barrens
				["449:438"] = 175, -- Thunder Bluff, Mulgore
				["407:625"] = 121, -- Zoram'gar Outpost, Ashenvale
				["383:445"] = 108, -- Karnum's Glade, Desolace
				["358:469"] = 102, -- Furien's Post, Desolace
				["399:577"] = 49, -- Cliffwalker Post, Stonetalon Mountains
				["471:612"] = 110, -- Hellscream's Watch, Ashenvale
				["420:562"] = 42, -- The Sludgewerks, Stonetalon Mountains
				["461:483"] = 67, -- Malaka'jin, Stonetalon Mountains
				["451:525"] = 43, -- Krom'gar Fortress, Stonetalon Mountains
			},
		},
		["407:625"] = {
			["Name"] = "Zoram'gar Outpost, Ashenvale",
			["Neighbors"] = {
				["554:582"] = 172, -- Splintertree Post, Ashenvale
				["557:469"] = 235, -- Crossroads, Northern Barrens
				["464:695"] = 137, -- Bloodvenom Post, Felwood
				["505:650"] = 122, -- Emerald Sanctuary, Felwood
				["407:527"] = 121, -- Sun Rock Retreat, Stonetalon Mountains
				["449:438"] = 247, -- Thunder Bluff, Mulgore
				["399:577"] = 73, -- Cliffwalker Post, Stonetalon Mountains
				["471:612"] = 82, -- Hellscream's Watch, Ashenvale
			},
		},
		["408:544"] = {
			["Name"] = "Mirkfallon Post, Stonetalon Mountains",
			["Neighbors"] = {
				["367:527"] = 53, -- Farwatcher's Glen, Stonetalon Mountains
				["387:575"] = 39, -- Thal'darah Overlook, Stonetalon Mountains
				["432:539"] = 28, -- Windshear Fortress, Stonetalon Mountains
			},
		},
		["410:832"] = {
			["Name"] = "Rut'theran Village, Teldrassil",
			["Neighbors"] = {
				["464:794"] = 61, -- Lor'danel, Darkshore
				["205:745"] = 100, -- The Exodar
				["342:897"] = 111, -- Darnassus, Teldrassil
			},
		},
		["410:893"] = {
			["Name"] = "Dolanaar, Teldrassil",
			["Neighbors"] = {
				["342:897"] = 61, -- Darnassus, Teldrassil
			},
		},
		["416:207"] = {
			["Name"] = "Cenarion Hold, Silithus",
			["Neighbors"] = {
				["442:306"] = 130, -- Camp Mojache, Feralas
				["607:196"] = 241, -- Gadgetzan, Tanaris
				["372:298"] = 106, -- Stonemaul Hold, Feralas
				["495:201"] = 77, -- Mossy Pile, Un'Goro Crater
				["514:177"] = 120, -- Marshal's Stand, Un'Goro Crater
			},
		},
		["416:842"] = {
			["Name"] = "Rut'theran Village, Teldrassil",
			["Neighbors"] = {
			},
		},
		["418:209"] = {
			["Name"] = "Cenarion Hold, Silithus",
			["Neighbors"] = {
				["313:307"] = 175, -- Feathermoon, Feralas
				["605:192"] = 188, -- Gadgetzan, Tanaris
				["360:304"] = 120, -- Feathermoon, Feralas
				["495:201"] = 72, -- Mossy Pile, Un'Goro Crater
				["514:177"] = 113, -- Marshal's Stand, Un'Goro Crater
			},
		},
		["420:562"] = {
			["Name"] = "The Sludgewerks, Stonetalon Mountains",
			["Neighbors"] = {
				["399:577"] = 31, -- Cliffwalker Post, Stonetalon Mountains
				["407:527"] = 37, -- Sun Rock Retreat, Stonetalon Mountains
				["451:525"] = 44, -- Krom'gar Fortress, Stonetalon Mountains
			},
		},
		["423:647"] = {
			["Name"] = "Blackfathom Camp, Ashenvale",
			["Neighbors"] = {
				["444:691"] = 69, -- Grove of the Ancients, Darkshore
				["505:650"] = 110, -- Emerald Sanctuary, Felwood
				["462:603"] = 60, -- Astranaar, Ashenvale
				["387:575"] = 137, -- Thal'darah Overlook, Stonetalon Mountains
			},
		},
		["432:539"] = {
			["Name"] = "Windshear Fortress, Stonetalon Mountains",
			["Neighbors"] = {
				["463:565"] = 57, -- Stardust Spire, Ashenvale
				["408:544"] = 31, -- Mirkfallon Post, Stonetalon Mountains
				["462:497"] = 58, -- Northwatch Expedition Base Camp, Stonetalon Mountains
				["396:493"] = 62, -- Nijel's Point, Desolace
				["367:527"] = 92, -- Farwatcher's Glen, Stonetalon Mountains
				["387:575"] = 65, -- Thal'darah Overlook, Stonetalon Mountains
			},
		},
		["442:306"] = {
			["Name"] = "Camp Mojache, Feralas",
			["Neighbors"] = {
				["549:265"] = 107, -- Freewind Post, Thousand Needles
				["449:438"] = 259, -- Thunder Bluff, Mulgore
				["557:469"] = 264, -- Crossroads, Northern Barrens
				["316:415"] = 200, -- Shadowprey Village, Desolace
				["416:207"] = 130, -- Cenarion Hold, Silithus
				["607:196"] = 201, -- Gadgetzan, Tanaris
				["372:298"] = 66, -- Stonemaul Hold, Feralas
				["358:469"] = 256, -- Furien's Post, Desolace
				["520:352"] = 104, -- Desolation Hold, Southern Barrens
				["488:310"] = 43, -- Westreach Summit, Thousand Needles
			},
		},
		["444:691"] = {
			["Name"] = "Grove of the Ancients, Darkshore",
			["Neighbors"] = {
				["464:794"] = 92, -- Lor'danel, Darkshore
				["423:647"] = 65, -- Blackfathom Camp, Ashenvale
				["462:603"] = 85, -- Astranaar, Ashenvale
				["387:575"] = 162, -- Thal'darah Overlook, Stonetalon Mountains
				["487:682"] = 58, -- Wildheart Point, Felwood
				["505:650"] = 82, -- Emerald Sanctuary, Felwood
				["527:742"] = 136, -- Talonbranch Glade, Felwood
			},
		},
		["447:282"] = {
			["Name"] = "Shadebough, Feralas",
			["Neighbors"] = {
				["611:238"] = 177, -- Fizzle & Pozzik's Speedbarge, Thousand Needles
				["583:300"] = 134, -- Mudsprocket, Dustwallow Marsh
				["360:304"] = 84, -- Feathermoon, Feralas
				["605:192"] = 215, -- Gadgetzan, Tanaris
				["636:330"] = 207, -- Theramore, Dustwallow Marsh
				["389:287"] = 60, -- Tower of Estulan, Feralas
			},
		},
		["449:438"] = {
			["Name"] = "Thunder Bluff, Mulgore",
			["Neighbors"] = {
				["407:527"] = 181, -- Sun Rock Retreat, Stonetalon Mountains
				["549:265"] = 204, -- Freewind Post, Thousand Needles
				["316:415"] = 159, -- Shadowprey Village, Desolace
				["557:469"] = 103, -- Crossroads, Northern Barrens
				["442:306"] = 252, -- Camp Mojache, Feralas
				["567:358"] = 238, -- Brackenwall Village, Dustwallow Marsh
				["528:389"] = 87, -- Camp Taurajo, The Barrens
				["631:638"] = 251, -- Valormok, Azshara
				["607:196"] = 290, -- Gadgetzan, Tanaris
				["407:625"] = 264, -- Zoram'gar Outpost, Ashenvale
				["629:561"] = 208, -- Orgrimmar, Durotar
				["709:633"] = 316, -- Bilgewater Harbor, Azshara
				["488:310"] = 210, -- Westreach Summit, Thousand Needles
				["407:465"] = 66, -- Thunk's Abode, Desolace
				["461:483"] = 54, -- Malaka'jin, Stonetalon Mountains
				["466:393"] = 51, -- Bloodhoof Village, Mulgore
				["516:454"] = 66, -- Hunter's Hill, Southern Barrens
			},
		},
		["451:525"] = {
			["Name"] = "Krom'gar Fortress, Stonetalon Mountains",
			["Neighbors"] = {
				["399:577"] = 70, -- Cliffwalker Post, Stonetalon Mountains
				["420:562"] = 47, -- The Sludgewerks, Stonetalon Mountains
				["497:576"] = 77, -- Silverwind Refuge, Ashenvale
				["541:537"] = 137, -- The Mor'Shan Ramparts, Ashenvale
				["407:527"] = 46, -- Sun Rock Retreat, Stonetalon Mountains
				["461:483"] = 68, -- Malaka'jin, Stonetalon Mountains
			},
		},
		["461:483"] = {
			["Name"] = "Malaka'jin, Stonetalon Mountains",
			["Neighbors"] = {
				["316:415"] = 164, -- Shadowprey Village, Desolace
				["399:577"] = 111, -- Cliffwalker Post, Stonetalon Mountains
				["557:469"] = 86, -- Crossroads, Northern Barrens
				["407:527"] = 74, -- Sun Rock Retreat, Stonetalon Mountains
				["449:438"] = 47, -- Thunder Bluff, Mulgore
				["451:525"] = 69, -- Krom'gar Fortress, Stonetalon Mountains
			},
		},
		["462:497"] = {
			["Name"] = "Northwatch Expedition Base Camp, Stonetalon Mountains",
			["Neighbors"] = {
				["463:565"] = 83, -- Stardust Spire, Ashenvale
				["432:539"] = 61, -- Windshear Fortress, Stonetalon Mountains
				["396:493"] = 67, -- Nijel's Point, Desolace
				["367:527"] = 121, -- Farwatcher's Glen, Stonetalon Mountains
				["387:575"] = 114, -- Thal'darah Overlook, Stonetalon Mountains
				["513:473"] = 51, -- Honor's Stand, Southern Barrens
			},
		},
		["462:603"] = {
			["Name"] = "Astranaar, Ashenvale",
			["Neighbors"] = {
				["582:610"] = 135, -- Forest Song, Ashenvale
				["636:330"] = 388, -- Theramore, Dustwallow Marsh
				["605:450"] = 193, -- Ratchet, The Barrens
				["504:651"] = 78, -- Emerald Sanctuary, Felwood
				["505:650"] = 78, -- Emerald Sanctuary, Felwood
				["423:647"] = 52, -- Blackfathom Camp, Ashenvale
				["444:691"] = 88, -- Grove of the Ancients, Darkshore
				["387:575"] = 176, -- Thal'darah Overlook, Stonetalon Mountains
				["464:794"] = 205, -- Lor'danel, Darkshore
				["463:565"] = 43, -- Stardust Spire, Ashenvale
			},
		},
		["463:565"] = {
			["Name"] = "Stardust Spire, Ashenvale",
			["Neighbors"] = {
				["462:603"] = 39, -- Astranaar, Ashenvale
				["396:493"] = 94, -- Nijel's Point, Desolace
				["387:575"] = 95, -- Thal'darah Overlook, Stonetalon Mountains
				["513:473"] = 103, -- Honor's Stand, Southern Barrens
				["462:497"] = 65, -- Northwatch Expedition Base Camp, Stonetalon Mountains
				["432:539"] = 64, -- Windshear Fortress, Stonetalon Mountains
			},
		},
		["464:695"] = {
			["Name"] = "Bloodvenom Post, Felwood",
			["Neighbors"] = {
				["557:469"] = 241, -- Crossroads, Northern Barrens
				["504:651"] = 68, -- Emerald Sanctuary, Felwood
				["640:767"] = 190, -- Everlook, Winterspring
				["631:638"] = 246, -- Valormok, Azshara
				["537:794"] = 165, -- Moonglade
				["407:625"] = 136, -- Zoram'gar Outpost, Ashenvale
				["629:561"] = 258, -- Orgrimmar, Durotar
				["505:650"] = 69, -- Emerald Sanctuary, Felwood
				["621:610"] = 246, -- Valormok, Azshara
			},
		},
		["464:794"] = {
			["Name"] = "Lor'danel, Darkshore",
			["Neighbors"] = {
				["360:304"] = 495, -- Feathermoon, Feralas
				["527:742"] = 96, -- Talonbranch Glade, Felwood
				["387:575"] = 267, -- Thal'darah Overlook, Stonetalon Mountains
				["636:330"] = 502, -- Theramore, Dustwallow Marsh
				["552:794"] = 92, -- Moonglade
				["444:691"] = 93, -- Grove of the Ancients, Darkshore
				["396:493"] = 348, -- Nijel's Point, Desolace
				["462:603"] = 225, -- Astranaar, Ashenvale
				["410:832"] = 61, -- Rut'theran Village, Teldrassil
			},
		},
		["466:393"] = {
			["Name"] = "Bloodhoof Village, Mulgore",
			["Neighbors"] = {
				["449:438"] = 50, -- Thunder Bluff, Mulgore
			},
		},
		["471:612"] = {
			["Name"] = "Hellscream's Watch, Ashenvale",
			["Neighbors"] = {
				["505:650"] = 91, -- Emerald Sanctuary, Felwood
				["554:582"] = 106, -- Splintertree Post, Ashenvale
				["399:577"] = 85, -- Cliffwalker Post, Stonetalon Mountains
				["541:537"] = 120, -- The Mor'Shan Ramparts, Ashenvale
				["407:527"] = 113, -- Sun Rock Retreat, Stonetalon Mountains
				["407:625"] = 60, -- Zoram'gar Outpost, Ashenvale
				["497:576"] = 47, -- Silverwind Refuge, Ashenvale
			},
		},
		["485:737"] = {
			["Name"] = "Whisperwind Grove, Felwood",
			["Neighbors"] = {
				["517:770"] = 41, -- Irontree Clearing, Felwood
				["505:650"] = 90, -- Emerald Sanctuary, Felwood
				["487:682"] = 60, -- Wildheart Point, Felwood
				["527:742"] = 59, -- Talonbranch Glade, Felwood
			},
		},
		["487:682"] = {
			["Name"] = "Wildheart Point, Felwood",
			["Neighbors"] = {
				["505:650"] = 35, -- Emerald Sanctuary, Felwood
				["485:737"] = 68, -- Whisperwind Grove, Felwood
				["444:691"] = 52, -- Grove of the Ancients, Darkshore
			},
		},
		["488:310"] = {
			["Name"] = "Westreach Summit, Thousand Needles",
			["Neighbors"] = {
				["583:300"] = 83, -- Mudsprocket, Dustwallow Marsh
				["567:358"] = 97, -- Brackenwall Village, Dustwallow Marsh
				["520:352"] = 100, -- Desolation Hold, Southern Barrens
				["607:196"] = 153, -- Gadgetzan, Tanaris
				["557:469"] = 186, -- Crossroads, Northern Barrens
				["611:238"] = 118, -- Fizzle & Pozzik's Speedbarge, Thousand Needles
				["442:306"] = 50, -- Camp Mojache, Feralas
				["449:438"] = 215, -- Thunder Bluff, Mulgore
			},
		},
		["495:201"] = {
			["Name"] = "Mossy Pile, Un'Goro Crater",
			["Neighbors"] = {
				["607:196"] = 98, -- Gadgetzan, Tanaris
				["416:207"] = 84, -- Cenarion Hold, Silithus
				["514:177"] = 29, -- Marshal's Stand, Un'Goro Crater
				["605:192"] = 97, -- Gadgetzan, Tanaris
				["418:209"] = 83, -- Cenarion Hold, Silithus
			},
		},
		["497:576"] = {
			["Name"] = "Silverwind Refuge, Ashenvale",
			["Neighbors"] = {
				["554:582"] = 64, -- Splintertree Post, Ashenvale
				["471:612"] = 43, -- Hellscream's Watch, Ashenvale
				["541:537"] = 70, -- The Mor'Shan Ramparts, Ashenvale
				["451:525"] = 77, -- Krom'gar Fortress, Stonetalon Mountains
			},
		},
		["504:651"] = {
			["Name"] = "Emerald Sanctuary, Felwood",
			["Neighbors"] = {
				["464:695"] = 79, -- Bloodvenom Post, Felwood
				["554:582"] = 83, -- Splintertree Post, Ashenvale
				["462:603"] = 80, -- Astranaar, Ashenvale
				["582:610"] = 103, -- Forest Song, Ashenvale
			},
		},
		["505:650"] = {
			["Name"] = "Emerald Sanctuary, Felwood",
			["Neighbors"] = {
				["407:625"] = 114, -- Zoram'gar Outpost, Ashenvale
				["462:603"] = 80, -- Astranaar, Ashenvale
				["464:695"] = 79, -- Bloodvenom Post, Felwood
				["554:582"] = 83, -- Splintertree Post, Ashenvale
				["582:610"] = 103, -- Forest Song, Ashenvale
				["527:742"] = 128, -- Talonbranch Glade, Felwood
				["471:612"] = 70, -- Hellscream's Watch, Ashenvale
				["485:737"] = 97, -- Whisperwind Grove, Felwood
				["487:682"] = 43, -- Wildheart Point, Felwood
				["423:647"] = 96, -- Blackfathom Camp, Ashenvale
				["444:691"] = 77, -- Grove of the Ancients, Darkshore
			},
		},
		["513:473"] = {
			["Name"] = "Honor's Stand, Southern Barrens",
			["Neighbors"] = {
				["462:497"] = 58, -- Northwatch Expedition Base Camp, Stonetalon Mountains
				["463:565"] = 112, -- Stardust Spire, Ashenvale
				["544:358"] = 103, -- Fort Triumph, Southern Barrens
				["605:450"] = 85, -- Ratchet, The Barrens
				["597:400"] = 100, -- Northwatch Hold, Southern Barrens
			},
		},
		["514:177"] = {
			["Name"] = "Marshal's Stand, Un'Goro Crater",
			["Neighbors"] = {
				["607:196"] = 93, -- Gadgetzan, Tanaris
				["416:207"] = 126, -- Cenarion Hold, Silithus
				["495:201"] = 38, -- Mossy Pile, Un'Goro Crater
				["605:192"] = 91, -- Gadgetzan, Tanaris
				["418:209"] = 121, -- Cenarion Hold, Silithus
			},
		},
		["516:454"] = {
			["Name"] = "Hunter's Hill, Southern Barrens",
			["Neighbors"] = {
				["520:352"] = 93, -- Desolation Hold, Southern Barrens
				["557:469"] = 43, -- Crossroads, Northern Barrens
				["449:438"] = 66, -- Thunder Bluff, Mulgore
			},
		},
		["517:770"] = {
			["Name"] = "Irontree Clearing, Felwood",
			["Neighbors"] = {
				["640:767"] = 123, -- Everlook, Winterspring
				["537:794"] = 76, -- Moonglade
				["485:737"] = 41, -- Whisperwind Grove, Felwood
			},
		},
		["520:352"] = {
			["Name"] = "Desolation Hold, Southern Barrens",
			["Neighbors"] = {
				["583:300"] = 76, -- Mudsprocket, Dustwallow Marsh
				["567:358"] = 47, -- Brackenwall Village, Dustwallow Marsh
				["488:310"] = 101, -- Westreach Summit, Thousand Needles
				["442:306"] = 97, -- Camp Mojache, Feralas
				["516:454"] = 98, -- Hunter's Hill, Southern Barrens
			},
		},
		["527:742"] = {
			["Name"] = "Talonbranch Glade, Felwood",
			["Neighbors"] = {
				["505:650"] = 129, -- Emerald Sanctuary, Felwood
				["645:766"] = 107, -- Everlook, Winterspring
				["552:794"] = 67, -- Moonglade
				["444:691"] = 121, -- Grove of the Ancients, Darkshore
				["464:794"] = 115, -- Lor'danel, Darkshore
				["485:737"] = 51, -- Whisperwind Grove, Felwood
			},
		},
		["528:389"] = {
			["Name"] = "Camp Taurajo, The Barrens",
			["Neighbors"] = {
				["557:469"] = 79, -- Crossroads, Northern Barrens
				["567:358"] = 60, -- Brackenwall Village, Dustwallow Marsh
				["449:438"] = 114, -- Thunder Bluff, Mulgore
				["549:265"] = 125, -- Freewind Post, Thousand Needles
			},
		},
		["537:794"] = {
			["Name"] = "Moonglade",
			["Neighbors"] = {
				["464:695"] = 157, -- Bloodvenom Post, Felwood
				["640:767"] = 141, -- Everlook, Winterspring
				["517:770"] = 73, -- Irontree Clearing, Felwood
			},
		},
		["541:537"] = {
			["Name"] = "The Mor'Shan Ramparts, Ashenvale",
			["Neighbors"] = {
				["589:535"] = 58, -- Nozzlepot's Outpost, Northern Barrens
				["629:561"] = 102, -- Orgrimmar, Durotar
				["554:582"] = 46, -- Splintertree Post, Ashenvale
				["471:612"] = 93, -- Hellscream's Watch, Ashenvale
				["557:469"] = 65, -- Crossroads, Northern Barrens
				["497:576"] = 70, -- Silverwind Refuge, Ashenvale
				["451:525"] = 143, -- Krom'gar Fortress, Stonetalon Mountains
			},
		},
		["544:358"] = {
			["Name"] = "Fort Triumph, Southern Barrens",
			["Neighbors"] = {
				["583:300"] = 66, -- Mudsprocket, Dustwallow Marsh
				["513:473"] = 103, -- Honor's Stand, Southern Barrens
				["597:400"] = 76, -- Northwatch Hold, Southern Barrens
			},
		},
		["549:265"] = {
			["Name"] = "Freewind Post, Thousand Needles",
			["Neighbors"] = {
				["567:358"] = 96, -- Brackenwall Village, Dustwallow Marsh
				["583:300"] = 69, -- Mudsprocket, Dustwallow Marsh
				["528:389"] = 137, -- Camp Taurajo, The Barrens
				["557:469"] = 192, -- Crossroads, Northern Barrens
				["442:306"] = 123, -- Camp Mojache, Feralas
				["449:438"] = 222, -- Thunder Bluff, Mulgore
				["607:196"] = 93, -- Gadgetzan, Tanaris
			},
		},
		["549:807"] = {
			["Name"] = "Nighthaven, Moonglade",
			["Neighbors"] = {
				["449:438"] = 400, -- Thunder Bluff, Mulgore
			},
		},
		["552:97"] = {
			["Name"] = "Dawnrise Expedition, Tanaris",
			["Neighbors"] = {
				["607:196"] = 94, -- Gadgetzan, Tanaris
				["618:130"] = 62, -- Bootlegger Outpost, Tanaris
			},
		},
		["552:794"] = {
			["Name"] = "Moonglade",
			["Neighbors"] = {
				["645:766"] = 119, -- Everlook, Winterspring
				["464:794"] = 86, -- Lor'danel, Darkshore
				["597:717"] = 0, -- Nordrassil, Hyjal
				["527:742"] = 61, -- Talonbranch Glade, Felwood
			},
		},
		["554:582"] = {
			["Name"] = "Splintertree Post, Ashenvale",
			["Neighbors"] = {
				["557:469"] = 160, -- Crossroads, Northern Barrens
				["631:638"] = 92, -- Valormok, Azshara
				["504:651"] = 85, -- Emerald Sanctuary, Felwood
				["407:625"] = 167, -- Zoram'gar Outpost, Ashenvale
				["629:561"] = 96, -- Orgrimmar, Durotar
				["505:650"] = 85, -- Emerald Sanctuary, Felwood
				["621:610"] = 92, -- Valormok, Azshara
				["709:633"] = 158, -- Bilgewater Harbor, Azshara
				["471:612"] = 82, -- Hellscream's Watch, Ashenvale
				["541:537"] = 54, -- The Mor'Shan Ramparts, Ashenvale
				["497:576"] = 58, -- Silverwind Refuge, Ashenvale
			},
		},
		["557:469"] = {
			["Name"] = "Crossroads, Northern Barrens",
			["Neighbors"] = {
				["528:389"] = 73, -- Camp Taurajo, The Barrens
				["464:695"] = 254, -- Bloodvenom Post, Felwood
				["407:527"] = 151, -- Sun Rock Retreat, Stonetalon Mountains
				["605:450"] = 52, -- Ratchet, The Barrens
				["567:358"] = 163, -- Brackenwall Village, Dustwallow Marsh
				["442:306"] = 252, -- Camp Mojache, Feralas
				["554:582"] = 162, -- Splintertree Post, Ashenvale
				["549:265"] = 184, -- Freewind Post, Thousand Needles
				["449:438"] = 107, -- Thunder Bluff, Mulgore
				["631:638"] = 163, -- Valormok, Azshara
				["607:196"] = 303, -- Gadgetzan, Tanaris
				["407:625"] = 231, -- Zoram'gar Outpost, Ashenvale
				["629:561"] = 117, -- Orgrimmar, Durotar
				["589:535"] = 67, -- Nozzlepot's Outpost, Northern Barrens
				["709:633"] = 228, -- Bilgewater Harbor, Azshara
				["488:310"] = 188, -- Westreach Summit, Thousand Needles
				["541:537"] = 63, -- The Mor'Shan Ramparts, Ashenvale
				["461:483"] = 115, -- Malaka'jin, Stonetalon Mountains
				["516:454"] = 49, -- Hunter's Hill, Southern Barrens
			},
		},
		["560:692"] = {
			["Name"] = "Shrine of Aviana, Hyjal",
			["Neighbors"] = {
				["597:717"] = 0, -- Nordrassil, Hyjal
			},
		},
		["567:358"] = {
			["Name"] = "Brackenwall Village, Dustwallow Marsh",
			["Neighbors"] = {
				["449:438"] = 224, -- Thunder Bluff, Mulgore
				["583:300"] = 62, -- Mudsprocket, Dustwallow Marsh
				["549:265"] = 104, -- Freewind Post, Thousand Needles
				["528:389"] = 49, -- Camp Taurajo, The Barrens
				["605:450"] = 90, -- Ratchet, The Barrens
				["557:469"] = 162, -- Crossroads, Northern Barrens
				["607:196"] = 205, -- Gadgetzan, Tanaris
				["629:561"] = 217, -- Orgrimmar, Durotar
				["520:352"] = 56, -- Desolation Hold, Southern Barrens
				["488:310"] = 111, -- Westreach Summit, Thousand Needles
			},
		},
		["572:97"] = {
			["Name"] = "Gunstan's Dig, Tanaris",
			["Neighbors"] = {
				["605:192"] = 87, -- Gadgetzan, Tanaris
				["618:130"] = 50, -- Bootlegger Outpost, Tanaris
			},
		},
		["582:610"] = {
			["Name"] = "Forest Song, Ashenvale",
			["Neighbors"] = {
				["504:651"] = 110, -- Emerald Sanctuary, Felwood
				["462:603"] = 142, -- Astranaar, Ashenvale
				["505:650"] = 110, -- Emerald Sanctuary, Felwood
			},
		},
		["583:300"] = {
			["Name"] = "Mudsprocket, Dustwallow Marsh",
			["Neighbors"] = {
				["636:330"] = 53, -- Theramore, Dustwallow Marsh
				["549:265"] = 71, -- Freewind Post, Thousand Needles
				["567:358"] = 63, -- Brackenwall Village, Dustwallow Marsh
				["611:238"] = 60, -- Fizzle & Pozzik's Speedbarge, Thousand Needles
				["520:352"] = 88, -- Desolation Hold, Southern Barrens
				["488:310"] = 100, -- Westreach Summit, Thousand Needles
				["544:358"] = 66, -- Fort Triumph, Southern Barrens
				["447:282"] = 144, -- Shadebough, Feralas
			},
		},
		["589:535"] = {
			["Name"] = "Nozzlepot's Outpost, Northern Barrens",
			["Neighbors"] = {
				["557:469"] = 65, -- Crossroads, Northern Barrens
				["541:537"] = 58, -- The Mor'Shan Ramparts, Ashenvale
			},
		},
		["597:400"] = {
			["Name"] = "Northwatch Hold, Southern Barrens",
			["Neighbors"] = {
				["513:473"] = 104, -- Honor's Stand, Southern Barrens
				["544:358"] = 78, -- Fort Triumph, Southern Barrens
				["636:330"] = 73, -- Theramore, Dustwallow Marsh
				["605:450"] = 46, -- Ratchet, The Barrens
			},
		},
		["597:717"] = {
			["Name"] = "Nordrassil, Hyjal",
			["Neighbors"] = {
				["645:766"] = 0, -- Everlook, Winterspring
				["552:794"] = 0, -- Moonglade
			},
		},
		["605:192"] = {
			["Name"] = "Gadgetzan, Tanaris",
			["Neighbors"] = {
				["572:97"] = 89, -- Gunstan's Dig, Tanaris
				["418:209"] = 198, -- Cenarion Hold, Silithus
				["514:177"] = 96, -- Marshal's Stand, Un'Goro Crater
				["636:330"] = 154, -- Theramore, Dustwallow Marsh
				["447:282"] = 214, -- Shadebough, Feralas
				["605:450"] = 247, -- Ratchet, The Barrens
				["495:201"] = 105, -- Mossy Pile, Un'Goro Crater
				["618:130"] = 54, -- Bootlegger Outpost, Tanaris
				["611:238"] = 49, -- Fizzle & Pozzik's Speedbarge, Thousand Needles
			},
		},
		["605:450"] = {
			["Name"] = "Ratchet, The Barrens",
			["Neighbors"] = {
				["636:330"] = 105, -- Theramore, Dustwallow Marsh
				["557:469"] = 68, -- Crossroads, Northern Barrens
				["462:603"] = 197, -- Astranaar, Ashenvale
				["567:358"] = 101, -- Brackenwall Village, Dustwallow Marsh
				["607:196"] = 241, -- Gadgetzan, Tanaris
				["629:561"] = 104, -- Orgrimmar, Durotar
				["605:192"] = 245, -- Gadgetzan, Tanaris
				["513:473"] = 90, -- Honor's Stand, Southern Barrens
				["597:400"] = 55, -- Northwatch Hold, Southern Barrens
			},
		},
		["607:196"] = {
			["Name"] = "Gadgetzan, Tanaris",
			["Neighbors"] = {
				["549:265"] = 87, -- Freewind Post, Thousand Needles
				["567:358"] = 194, -- Brackenwall Village, Dustwallow Marsh
				["442:306"] = 199, -- Camp Mojache, Feralas
				["449:438"] = 308, -- Thunder Bluff, Mulgore
				["557:469"] = 300, -- Crossroads, Northern Barrens
				["629:561"] = 350, -- Orgrimmar, Durotar
				["605:450"] = 243, -- Ratchet, The Barrens
				["416:207"] = 233, -- Cenarion Hold, Silithus
				["552:97"] = 98, -- Dawnrise Expedition, Tanaris
				["488:310"] = 167, -- Westreach Summit, Thousand Needles
				["618:130"] = 57, -- Bootlegger Outpost, Tanaris
				["514:177"] = 100, -- Marshal's Stand, Un'Goro Crater
				["495:201"] = 102, -- Mossy Pile, Un'Goro Crater
				["611:238"] = 50, -- Fizzle & Pozzik's Speedbarge, Thousand Needles
			},
		},
		["611:238"] = {
			["Name"] = "Fizzle & Pozzik's Speedbarge, Thousand Needles",
			["Neighbors"] = {
				["583:300"] = 72, -- Mudsprocket, Dustwallow Marsh
				["607:196"] = 39, -- Gadgetzan, Tanaris
				["488:310"] = 132, -- Westreach Summit, Thousand Needles
				["605:192"] = 43, -- Gadgetzan, Tanaris
				["447:282"] = 180, -- Shadebough, Feralas
			},
		},
		["618:130"] = {
			["Name"] = "Bootlegger Outpost, Tanaris",
			["Neighbors"] = {
				["552:97"] = 64, -- Dawnrise Expedition, Tanaris
				["607:196"] = 61, -- Gadgetzan, Tanaris
				["605:192"] = 60, -- Gadgetzan, Tanaris
				["572:97"] = 51, -- Gunstan's Dig, Tanaris
			},
		},
		["621:610"] = {
			["Name"] = "Valormok, Azshara",
			["Neighbors"] = {
				["629:561"] = 102, -- Orgrimmar, Durotar
				["709:633"] = 86, -- Bilgewater Harbor, Azshara
				["464:695"] = 232, -- Bloodvenom Post, Felwood
				["554:582"] = 94, -- Splintertree Post, Ashenvale
			},
		},
		["629:561"] = {
			["Name"] = "Orgrimmar, Durotar",
			["Neighbors"] = {
				["640:767"] = 240, -- Everlook, Winterspring
				["449:438"] = 225, -- Thunder Bluff, Mulgore
				["631:638"] = 95, -- Valormok, Azshara
				["605:450"] = 108, -- Ratchet, The Barrens
				["554:582"] = 93, -- Splintertree Post, Ashenvale
				["567:358"] = 228, -- Brackenwall Village, Dustwallow Marsh
				["607:196"] = 417, -- Gadgetzan, Tanaris
				["646:498"] = 55, -- Razor Hill, Durotar
				["464:695"] = 252, -- Bloodvenom Post, Felwood
				["557:469"] = 108, -- Crossroads, Northern Barrens
				["709:633"] = 114, -- Bilgewater Harbor, Azshara
				["541:537"] = 99, -- The Mor'Shan Ramparts, Ashenvale
				["706:596"] = 93, -- Southern Rocketway, Azshara
			},
		},
		["631:638"] = {
			["Name"] = "Valormok, Azshara",
			["Neighbors"] = {
				["464:695"] = 232, -- Bloodvenom Post, Felwood
				["640:767"] = 130, -- Everlook, Winterspring
				["449:438"] = 250, -- Thunder Bluff, Mulgore
				["557:469"] = 164, -- Crossroads, Northern Barrens
				["554:582"] = 93, -- Splintertree Post, Ashenvale
				["629:561"] = 101, -- Orgrimmar, Durotar
			},
		},
		["636:330"] = {
			["Name"] = "Theramore, Dustwallow Marsh",
			["Neighbors"] = {
				["462:603"] = 369, -- Astranaar, Ashenvale
				["583:300"] = 63, -- Mudsprocket, Dustwallow Marsh
				["396:493"] = 334, -- Nijel's Point, Desolace
				["605:450"] = 116, -- Ratchet, The Barrens
				["464:794"] = 500, -- Lor'danel, Darkshore
				["605:192"] = 157, -- Gadgetzan, Tanaris
				["597:400"] = 81, -- Northwatch Hold, Southern Barrens
				["447:282"] = 201, -- Shadebough, Feralas
			},
		},
		["640:767"] = {
			["Name"] = "Everlook, Winterspring",
			["Neighbors"] = {
				["537:794"] = 134, -- Moonglade
				["631:638"] = 135, -- Valormok, Azshara
				["464:695"] = 195, -- Bloodvenom Post, Felwood
				["629:561"] = 243, -- Orgrimmar, Durotar
				["709:633"] = 148, -- Bilgewater Harbor, Azshara
				["517:770"] = 122, -- Irontree Clearing, Felwood
			},
		},
		["645:766"] = {
			["Name"] = "Everlook, Winterspring",
			["Neighbors"] = {
				["552:794"] = 110, -- Moonglade
				["527:742"] = 107, -- Talonbranch Glade, Felwood
			},
		},
		["646:498"] = {
			["Name"] = "Razor Hill, Durotar",
			["Neighbors"] = {
				["651:455"] = 36, -- Sen'jin Village, Durotar
				["629:561"] = 60, -- Orgrimmar, Durotar
			},
		},
		["651:455"] = {
			["Name"] = "Sen'jin Village, Durotar",
			["Neighbors"] = {
				["646:498"] = 36, -- Razor Hill, Durotar
			},
		},
		["706:596"] = {
			["Name"] = "Southern Rocketway, Azshara",
			["Neighbors"] = {
				["629:561"] = 88, -- Orgrimmar, Durotar
				["709:633"] = 39, -- Bilgewater Harbor, Azshara
			},
		},
		["709:633"] = {
			["Name"] = "Bilgewater Harbor, Azshara",
			["Neighbors"] = {
				["740:677"] = 53, -- Northern Rocketway, Azshara
				["706:596"] = 33, -- Southern Rocketway, Azshara
				["621:610"] = 83, -- Valormok, Azshara
				["557:469"] = 234, -- Crossroads, Northern Barrens
				["629:561"] = 98, -- Orgrimmar, Durotar
				["554:582"] = 149, -- Splintertree Post, Ashenvale
				["449:438"] = 304, -- Thunder Bluff, Mulgore
				["640:767"] = 150, -- Everlook, Winterspring
			},
		},
		["740:677"] = {
			["Name"] = "Northern Rocketway, Azshara",
			["Neighbors"] = {
				["709:633"] = 50, -- Bilgewater Harbor, Azshara
			},
		},
	},
	[2] = {
		["276:344"] = {
			["Name"] = "Tranquil Wash, Vashj'ir",
			["Neighbors"] = {
				["277:361"] = 0, -- Silver Tide Hollow, Vashj'ir
			},
		},
		["277:361"] = {
			["Name"] = "Silver Tide Hollow, Vashj'ir",
			["Neighbors"] = {
				["290:391"] = 0, -- Sandy Beach, Vashj'ir
				["305:414"] = 0, -- Smuggler's Scar, Vashj'ir
			},
		},
		["290:391"] = {
			["Name"] = "Sandy Beach, Vashj'ir",
			["Neighbors"] = {
				["466:406"] = 0, -- Ironforge, Dun Morogh
				["305:414"] = 0, -- Smuggler's Scar, Vashj'ir
			},
		},
		["305:414"] = {
			["Name"] = "Smuggler's Scar, Vashj'ir",
			["Neighbors"] = {
				["290:391"] = 0, -- Sandy Beach, Vashj'ir
				["277:361"] = 84, -- Silver Tide Hollow, Vashj'ir
			},
		},
		["372:196"] = {
			["Name"] = "Moonbrook, Westfall",
			["Neighbors"] = {
				["390:207"] = 27, -- Sentinel Hill, Westfall
			},
		},
		["372:590"] = {
			["Name"] = "The Sepulcher, Silverpine Forest",
			["Neighbors"] = {
				["416:628"] = 122, -- Undercity, Tirisfal
				["456:573"] = 97, -- Tarren Mill, Hillsbrad
				["380:569"] = 25, -- The Forsaken Front, Silverpine Forest
				["373:610"] = 51, -- Forsaken Rear Guard, Silverpine Forest
			},
		},
		["373:610"] = {
			["Name"] = "Forsaken Rear Guard, Silverpine Forest",
			["Neighbors"] = {
				["372:590"] = 31, -- The Sepulcher, Silverpine Forest
			},
		},
		["380:569"] = {
			["Name"] = "The Forsaken Front, Silverpine Forest",
			["Neighbors"] = {
				["372:590"] = 36, -- The Sepulcher, Silverpine Forest
				["410:552"] = 38, -- Southpoint Gate, Hillsbrad
			},
		},
		["381:232"] = {
			["Name"] = "Furlbrow's Pumpkin Farm, Westfall",
			["Neighbors"] = {
				["409:266"] = 59, -- Stormwind, Elwynn
				["390:207"] = 28, -- Sentinel Hill, Westfall
			},
		},
		["390:207"] = {
			["Name"] = "Sentinel Hill, Westfall",
			["Neighbors"] = {
				["409:266"] = 86, -- Stormwind, Elwynn
				["409:71"] = 186, -- Booty Bay, Stranglethorn
				["433:180"] = 62, -- Rebel Camp, Stranglethorn Vale
				["469:208"] = 97, -- Darkshire, Duskwood
				["503:246"] = 130, -- Lakeshire, Redridge
				["381:232"] = 33, -- Furlbrow's Pumpkin Farm, Westfall
				["416:201"] = 31, -- Raven Hill, Duskwood
				["372:196"] = 25, -- Moonbrook, Westfall
			},
		},
		["400:112"] = {
			["Name"] = "Hardwrench Hideaway, Stranglethorn",
			["Neighbors"] = {
				["420:142"] = 39, -- Grom'gol, Stranglethorn
				["408:72"] = 48, -- Booty Bay, Stranglethorn
				["454:154"] = 73, -- Bambala, Stranglethorn
			},
		},
		["408:72"] = {
			["Name"] = "Booty Bay, Stranglethorn",
			["Neighbors"] = {
				["539:210"] = 238, -- Stonard, Swamp of Sorrows
				["420:142"] = 76, -- Grom'gol, Stranglethorn
				["400:112"] = 41, -- Hardwrench Hideaway, Stranglethorn
				["510:342"] = 309, -- New Kargath, Badlands
				["532:144"] = 170, -- Sunveil Excursion, Blasted Lands
			},
		},
		["409:266"] = {
			["Name"] = "Stormwind, Elwynn",
			["Neighbors"] = {
				["469:208"] = 117, -- Darkshire, Duskwood
				["521:283"] = 150, -- Morgan's Vigil, Burning Steppes
				["409:71"] = 199, -- Booty Bay, Stranglethorn
				["545:188"] = 176, -- Nethergarde Keep, Blasted Lands
				["503:246"] = 113, -- Lakeshire, Redridge
				["466:346"] = 133, -- Thorium Point, Searing Gorge
				["433:180"] = 93, -- Rebel Camp, Stranglethorn Vale
				["466:406"] = 216, -- Ironforge, Dun Morogh
				["390:207"] = 78, -- Sentinel Hill, Westfall
				["423:246"] = 32, -- Goldshire, Elwynn
				["381:232"] = 50, -- Furlbrow's Pumpkin Farm, Westfall
			},
		},
		["409:71"] = {
			["Name"] = "Booty Bay, Stranglethorn",
			["Neighbors"] = {
				["469:208"] = 166, -- Darkshire, Duskwood
				["433:180"] = 118, -- Rebel Camp, Stranglethorn Vale
				["409:266"] = 199, -- Stormwind, Elwynn
				["390:207"] = 148, -- Sentinel Hill, Westfall
				["429:101"] = 50, -- Explorers' League Digsite, Stranglethorn
				["527:130"] = 144, -- Surwich, Blasted Lands
			},
		},
		["410:552"] = {
			["Name"] = "Southpoint Gate, Hillsbrad",
			["Neighbors"] = {
				["380:569"] = 39, -- The Forsaken Front, Silverpine Forest
				["444:550"] = 37, -- Ruins of Southshore, Hillsbrad
			},
		},
		["413:652"] = {
			["Name"] = "Brill, Tirisfal Glades",
			["Neighbors"] = {
				["451:633"] = 45, -- The Bulwark, Tirisfal
				["416:628"] = 59, -- Undercity, Tirisfal
			},
		},
		["416:201"] = {
			["Name"] = "Raven Hill, Duskwood",
			["Neighbors"] = {
				["469:208"] = 63, -- Darkshire, Duskwood
				["390:207"] = 43, -- Sentinel Hill, Westfall
				["433:180"] = 40, -- Rebel Camp, Stranglethorn Vale
			},
		},
		["416:628"] = {
			["Name"] = "Undercity, Tirisfal",
			["Neighbors"] = {
				["372:590"] = 100, -- The Sepulcher, Silverpine Forest
				["547:542"] = 301, -- Hammerfall, Arathi
				["589:551"] = 272, -- Revantusk Village, The Hinterlands
				["611:652"] = 262, -- Light's Hope Chapel, Eastern Plaguelands
				["456:573"] = 145, -- Tarren Mill, Hillsbrad
				["481:540"] = 248, -- Galen's Fall, Arathi
				["413:652"] = 62, -- Brill, Tirisfal Glades
				["519:641"] = 157, -- Thondroril River, Eastern Plaguelands
				["510:342"] = 476, -- New Kargath, Badlands
				["451:633"] = 89, -- The Bulwark, Tirisfal
			},
		},
		["420:142"] = {
			["Name"] = "Grom'gol, Stranglethorn",
			["Neighbors"] = {
				["501:313"] = 198, -- Flame Crest, Burning Steppes
				["408:72"] = 78, -- Booty Bay, Stranglethorn
				["539:210"] = 173, -- Stonard, Swamp of Sorrows
				["400:112"] = 39, -- Hardwrench Hideaway, Stranglethorn
				["510:342"] = 243, -- New Kargath, Badlands
				["454:154"] = 57, -- Bambala, Stranglethorn
			},
		},
		["423:246"] = {
			["Name"] = "Goldshire, Elwynn",
			["Neighbors"] = {
				["409:266"] = 26, -- Stormwind, Elwynn
				["469:208"] = 68, -- Darkshire, Duskwood
				["471:244"] = 57, -- Eastvale Logging Camp, Elwynn
			},
		},
		["429:101"] = {
			["Name"] = "Explorers' League Digsite, Stranglethorn",
			["Neighbors"] = {
				["409:71"] = 53, -- Booty Bay, Stranglethorn
				["440:128"] = 46, -- Fort Livingston, Stranglethorn
			},
		},
		["433:180"] = {
			["Name"] = "Rebel Camp, Stranglethorn Vale",
			["Neighbors"] = {
				["409:266"] = 98, -- Stormwind, Elwynn
				["409:71"] = 116, -- Booty Bay, Stranglethorn
				["469:208"] = 48, -- Darkshire, Duskwood
				["390:207"] = 66, -- Sentinel Hill, Westfall
				["416:201"] = 39, -- Raven Hill, Duskwood
				["440:128"] = 54, -- Fort Livingston, Stranglethorn
			},
		},
		["440:128"] = {
			["Name"] = "Fort Livingston, Stranglethorn",
			["Neighbors"] = {
				["433:180"] = 55, -- Rebel Camp, Stranglethorn Vale
				["429:101"] = 44, -- Explorers' League Digsite, Stranglethorn
			},
		},
		["443:377"] = {
			["Name"] = "Kharanos, Dun Morogh",
			["Neighbors"] = {
				["466:406"] = 46, -- Ironforge, Dun Morogh
				["480:375"] = 47, -- Gol'Bolar Quarry, Dun Morogh
			},
		},
		["444:550"] = {
			["Name"] = "Ruins of Southshore, Hillsbrad",
			["Neighbors"] = {
				["456:573"] = 28, -- Tarren Mill, Hillsbrad
				["410:552"] = 45, -- Southpoint Gate, Hillsbrad
				["462:554"] = 19, -- Eastpoint Tower, Hillsbrad
			},
		},
		["451:633"] = {
			["Name"] = "The Bulwark, Tirisfal",
			["Neighbors"] = {
				["416:628"] = 89, -- Undercity, Tirisfal
				["413:652"] = 48, -- Brill, Tirisfal Glades
				["460:595"] = 45, -- Strahnbrad, Alterac Mountains
				["519:641"] = 73, -- Thondroril River, Eastern Plaguelands
				["481:626"] = 35, -- Andorhal, Western Plaguelands
				["456:573"] = 74, -- Tarren Mill, Hillsbrad
			},
		},
		["453:442"] = {
			["Name"] = "Menethil Harbor, Wetlands",
			["Neighbors"] = {
				["466:406"] = 90, -- Ironforge, Dun Morogh
				["527:385"] = 163, -- Thelsamar, Loch Modan
				["513:530"] = 113, -- Refuge Pointe, Arathi
				["495:462"] = 47, -- Whelgar's Retreat, Wetlands
			},
		},
		["454:154"] = {
			["Name"] = "Bambala, Stranglethorn",
			["Neighbors"] = {
				["420:142"] = 48, -- Grom'gol, Stranglethorn
				["400:112"] = 70, -- Hardwrench Hideaway, Stranglethorn
			},
		},
		["456:573"] = {
			["Name"] = "Tarren Mill, Hillsbrad",
			["Neighbors"] = {
				["589:551"] = 162, -- Revantusk Village, The Hinterlands
				["547:542"] = 118, -- Hammerfall, Arathi
				["372:590"] = 104, -- The Sepulcher, Silverpine Forest
				["416:628"] = 139, -- Undercity, Tirisfal
				["451:633"] = 69, -- The Bulwark, Tirisfal
				["444:550"] = 30, -- Ruins of Southshore, Hillsbrad
				["460:595"] = 28, -- Strahnbrad, Alterac Mountains
				["519:641"] = 108, -- Thondroril River, Eastern Plaguelands
				["462:554"] = 25, -- Eastpoint Tower, Hillsbrad
				["524:573"] = 104, -- Hiri'watha Research Station, The Hinterlands
			},
		},
		["460:595"] = {
			["Name"] = "Strahnbrad, Alterac Mountains",
			["Neighbors"] = {
				["451:633"] = 49, -- The Bulwark, Tirisfal
				["456:573"] = 32, -- Tarren Mill, Hillsbrad
			},
		},
		["461:292"] = {
			["Name"] = "Flamestar Post, Burning Steppes",
			["Neighbors"] = {
				["492:300"] = 36, -- Chiselgrip, Burning Steppes
				["468:326"] = 45, -- Iron Summit, Searing Gorge
			},
		},
		["462:554"] = {
			["Name"] = "Eastpoint Tower, Hillsbrad",
			["Neighbors"] = {
				["481:540"] = 32, -- Galen's Fall, Arathi
				["456:573"] = 22, -- Tarren Mill, Hillsbrad
				["444:550"] = 25, -- Ruins of Southshore, Hillsbrad
			},
		},
		["464:346"] = {
			["Name"] = "Thorium Point, Searing Gorge",
			["Neighbors"] = {
				["501:313"] = 61, -- Flame Crest, Burning Steppes
				["468:326"] = 24, -- Iron Summit, Searing Gorge
				["510:342"] = 67, -- New Kargath, Badlands
			},
		},
		["466:346"] = {
			["Name"] = "Thorium Point, Searing Gorge",
			["Neighbors"] = {
				["527:385"] = 88, -- Thelsamar, Loch Modan
				["409:266"] = 126, -- Stormwind, Elwynn
				["466:406"] = 89, -- Ironforge, Dun Morogh
				["521:283"] = 90, -- Morgan's Vigil, Burning Steppes
				["468:326"] = 25, -- Iron Summit, Searing Gorge
			},
		},
		["466:406"] = {
			["Name"] = "Ironforge, Dun Morogh",
			["Neighbors"] = {
				["513:530"] = 204, -- Refuge Pointe, Arathi
				["611:652"] = 349, -- Light's Hope Chapel, Eastern Plaguelands
				["409:266"] = 211, -- Stormwind, Elwynn
				["475:606"] = 257, -- Chillwind Camp, Western Plaguelands
				["495:583"] = 240, -- Aerie Peak, The Hinterlands
				["527:385"] = 102, -- Thelsamar, Loch Modan
				["453:442"] = 115, -- Menethil Harbor, Wetlands
				["466:346"] = 85, -- Thorium Point, Searing Gorge
				["582:942"] = 675, -- Shattered Sun Staging Area
				["290:391"] = 0, -- Sandy Beach, Vashj'ir
				["480:375"] = 56, -- Gol'Bolar Quarry, Dun Morogh
				["443:377"] = 46, -- Kharanos, Dun Morogh
			},
		},
		["468:326"] = {
			["Name"] = "Iron Summit, Searing Gorge",
			["Neighbors"] = {
				["461:292"] = 47, -- Flamestar Post, Burning Steppes
				["464:346"] = 25, -- Thorium Point, Searing Gorge
				["466:346"] = 25, -- Thorium Point, Searing Gorge
			},
		},
		["469:208"] = {
			["Name"] = "Darkshire, Duskwood",
			["Neighbors"] = {
				["409:266"] = 88, -- Stormwind, Elwynn
				["433:180"] = 47, -- Rebel Camp, Stranglethorn Vale
				["409:71"] = 171, -- Booty Bay, Stranglethorn
				["545:188"] = 97, -- Nethergarde Keep, Blasted Lands
				["503:246"] = 60, -- Lakeshire, Redridge
				["390:207"] = 93, -- Sentinel Hill, Westfall
				["423:246"] = 68, -- Goldshire, Elwynn
				["416:201"] = 63, -- Raven Hill, Duskwood
			},
		},
		["470:621"] = {
			["Name"] = "Andorhal, Western Plaguelands",
			["Neighbors"] = {
				["487:638"] = 25, -- The Menders' Stead, Western Plaguelands
				["495:583"] = 80, -- Aerie Peak, The Hinterlands
				["475:606"] = 19, -- Chillwind Camp, Western Plaguelands
			},
		},
		["471:244"] = {
			["Name"] = "Eastvale Logging Camp, Elwynn",
			["Neighbors"] = {
				["423:246"] = 53, -- Goldshire, Elwynn
				["503:246"] = 41, -- Lakeshire, Redridge
			},
		},
		["475:606"] = {
			["Name"] = "Chillwind Camp, Western Plaguelands",
			["Neighbors"] = {
				["611:652"] = 146, -- Light's Hope Chapel, Eastern Plaguelands
				["495:583"] = 65, -- Aerie Peak, The Hinterlands
				["466:406"] = 260, -- Ironforge, Dun Morogh
				["470:621"] = 26, -- Andorhal, Western Plaguelands
				["487:638"] = 42, -- The Menders' Stead, Western Plaguelands
				["519:641"] = 59, -- Thondroril River, Eastern Plaguelands
			},
		},
		["478:672"] = {
			["Name"] = "Hearthglen, Western Plaguelands",
			["Neighbors"] = {
				["531:676"] = 61, -- Plaguewood Tower, Eastern Plaguelands
				["487:638"] = 45, -- The Menders' Stead, Western Plaguelands
			},
		},
		["480:375"] = {
			["Name"] = "Gol'Bolar Quarry, Dun Morogh",
			["Neighbors"] = {
				["466:406"] = 69, -- Ironforge, Dun Morogh
				["443:377"] = 44, -- Kharanos, Dun Morogh
			},
		},
		["481:540"] = {
			["Name"] = "Galen's Fall, Arathi",
			["Neighbors"] = {
				["416:628"] = 199, -- Undercity, Tirisfal
				["462:554"] = 34, -- Eastpoint Tower, Hillsbrad
				["547:542"] = 74, -- Hammerfall, Arathi
			},
		},
		["481:626"] = {
			["Name"] = "Andorhal, Western Plaguelands",
			["Neighbors"] = {
				["451:633"] = 37, -- The Bulwark, Tirisfal
				["487:638"] = 16, -- The Menders' Stead, Western Plaguelands
				["524:573"] = 90, -- Hiri'watha Research Station, The Hinterlands
			},
		},
		["487:638"] = {
			["Name"] = "The Menders' Stead, Western Plaguelands",
			["Neighbors"] = {
				["519:641"] = 37, -- Thondroril River, Eastern Plaguelands
				["475:606"] = 43, -- Chillwind Camp, Western Plaguelands
				["481:626"] = 26, -- Andorhal, Western Plaguelands
				["478:672"] = 44, -- Hearthglen, Western Plaguelands
				["470:621"] = 29, -- Andorhal, Western Plaguelands
			},
		},
		["492:300"] = {
			["Name"] = "Chiselgrip, Burning Steppes",
			["Neighbors"] = {
				["521:283"] = 39, -- Morgan's Vigil, Burning Steppes
				["461:292"] = 35, -- Flamestar Post, Burning Steppes
				["501:313"] = 17, -- Flame Crest, Burning Steppes
			},
		},
		["495:583"] = {
			["Name"] = "Aerie Peak, The Hinterlands",
			["Neighbors"] = {
				["475:606"] = 57, -- Chillwind Camp, Western Plaguelands
				["611:652"] = 164, -- Light's Hope Chapel, Eastern Plaguelands
				["466:406"] = 256, -- Ironforge, Dun Morogh
				["513:530"] = 75, -- Refuge Pointe, Arathi
				["568:584"] = 80, -- Stormfeather Outpost, The Hinterlands
				["470:621"] = 70, -- Andorhal, Western Plaguelands
			},
		},
		["495:462"] = {
			["Name"] = "Whelgar's Retreat, Wetlands",
			["Neighbors"] = {
				["453:442"] = 53, -- Menethil Harbor, Wetlands
				["511:481"] = 29, -- Dun Modr, Wetlands
				["520:459"] = 30, -- Greenwarden's Grove, Wetlands
			},
		},
		["501:313"] = {
			["Name"] = "Flame Crest, Burning Steppes",
			["Neighbors"] = {
				["539:210"] = 192, -- Stonard, Swamp of Sorrows
				["420:142"] = 206, -- Grom'gol, Stranglethorn
				["464:346"] = 61, -- Thorium Point, Searing Gorge
				["510:342"] = 82, -- New Kargath, Badlands
				["561:235"] = 108, -- Bogpaddle, Swamp of Sorrows
				["492:300"] = 17, -- Chiselgrip, Burning Steppes
			},
		},
		["503:246"] = {
			["Name"] = "Lakeshire, Redridge",
			["Neighbors"] = {
				["409:266"] = 113, -- Stormwind, Elwynn
				["521:283"] = 61, -- Morgan's Vigil, Burning Steppes
				["469:208"] = 61, -- Darkshire, Duskwood
				["390:207"] = 134, -- Sentinel Hill, Westfall
				["525:222"] = 47, -- The Harborage, Swamp of Sorrows
				["524:245"] = 21, -- Camp Everstill, Redridge
				["471:244"] = 39, -- Eastvale Logging Camp, Elwynn
			},
		},
		["510:342"] = {
			["Name"] = "New Kargath, Badlands",
			["Neighbors"] = {
				["416:628"] = 470, -- Undercity, Tirisfal
				["464:346"] = 63, -- Thorium Point, Searing Gorge
				["560:345"] = 57, -- Fuselight, Badlands
				["548:334"] = 45, -- Bloodwatcher Point, Badlands
				["547:542"] = 252, -- Hammerfall, Arathi
				["539:210"] = 228, -- Stonard, Swamp of Sorrows
				["501:313"] = 73, -- Flame Crest, Burning Steppes
				["408:72"] = 301, -- Booty Bay, Stranglethorn
				["420:142"] = 243, -- Grom'gol, Stranglethorn
			},
		},
		["511:481"] = {
			["Name"] = "Dun Modr, Wetlands",
			["Neighbors"] = {
				["495:462"] = 33, -- Whelgar's Retreat, Wetlands
				["513:530"] = 52, -- Refuge Pointe, Arathi
				["520:459"] = 36, -- Greenwarden's Grove, Wetlands
			},
		},
		["513:530"] = {
			["Name"] = "Refuge Pointe, Arathi",
			["Neighbors"] = {
				["495:583"] = 72, -- Aerie Peak, The Hinterlands
				["453:442"] = 126, -- Menethil Harbor, Wetlands
				["527:385"] = 170, -- Thelsamar, Loch Modan
				["466:406"] = 271, -- Ironforge, Dun Morogh
				["511:481"] = 59, -- Dun Modr, Wetlands
				["568:584"] = 85, -- Stormfeather Outpost, The Hinterlands
			},
		},
		["515:329"] = {
			["Name"] = "Dragon's Mouth, Badlands",
			["Neighbors"] = {
				["560:345"] = 54, -- Fuselight, Badlands
				["544:344"] = 35, -- Dustwind Dig, Badlands
				["521:283"] = 55, -- Morgan's Vigil, Burning Steppes
			},
		},
		["519:641"] = {
			["Name"] = "Thondroril River, Eastern Plaguelands",
			["Neighbors"] = {
				["611:652"] = 101, -- Light's Hope Chapel, Eastern Plaguelands
				["475:606"] = 58, -- Chillwind Camp, Western Plaguelands
				["451:633"] = 77, -- The Bulwark, Tirisfal
				["416:628"] = 161, -- Undercity, Tirisfal
				["487:638"] = 39, -- The Menders' Stead, Western Plaguelands
				["554:639"] = 45, -- Crown Guard Tower, Eastern Plaguelands
				["456:573"] = 100, -- Tarren Mill, Hillsbrad
				["524:573"] = 86, -- Hiri'watha Research Station, The Hinterlands
				["568:584"] = 109, -- Stormfeather Outpost, The Hinterlands
			},
		},
		["520:459"] = {
			["Name"] = "Greenwarden's Grove, Wetlands",
			["Neighbors"] = {
				["511:481"] = 28, -- Dun Modr, Wetlands
				["495:462"] = 26, -- Whelgar's Retreat, Wetlands
				["521:431"] = 33, -- Slabchisel's Survey, Wetlands
			},
		},
		["521:283"] = {
			["Name"] = "Morgan's Vigil, Burning Steppes",
			["Neighbors"] = {
				["466:346"] = 91, -- Thorium Point, Searing Gorge
				["545:188"] = 197, -- Nethergarde Keep, Blasted Lands
				["409:266"] = 151, -- Stormwind, Elwynn
				["503:246"] = 63, -- Lakeshire, Redridge
				["515:329"] = 55, -- Dragon's Mouth, Badlands
				["561:235"] = 77, -- Bogpaddle, Swamp of Sorrows
				["492:300"] = 43, -- Chiselgrip, Burning Steppes
			},
		},
		["521:431"] = {
			["Name"] = "Slabchisel's Survey, Wetlands",
			["Neighbors"] = {
				["520:459"] = 33, -- Greenwarden's Grove, Wetlands
				["527:385"] = 60, -- Thelsamar, Loch Modan
			},
		},
		["522:194"] = {
			["Name"] = "Dreadmaul Hold, Blasted Lands",
			["Neighbors"] = {
				["539:210"] = 44, -- Stonard, Swamp of Sorrows
				["532:144"] = 56, -- Sunveil Excursion, Blasted Lands
			},
		},
		["524:245"] = {
			["Name"] = "Camp Everstill, Redridge",
			["Neighbors"] = {
				["546:239"] = 33, -- Shalewind Canyon, Redridge
				["503:246"] = 24, -- Lakeshire, Redridge
			},
		},
		["524:573"] = {
			["Name"] = "Hiri'watha Research Station, The Hinterlands",
			["Neighbors"] = {
				["589:551"] = 85, -- Revantusk Village, The Hinterlands
				["456:573"] = 81, -- Tarren Mill, Hillsbrad
				["519:641"] = 82, -- Thondroril River, Eastern Plaguelands
				["481:626"] = 74, -- Andorhal, Western Plaguelands
				["547:542"] = 70, -- Hammerfall, Arathi
			},
		},
		["525:222"] = {
			["Name"] = "The Harborage, Swamp of Sorrows",
			["Neighbors"] = {
				["559:220"] = 38, -- Marshtide Watch, Swamp of Sorrows
				["503:246"] = 46, -- Lakeshire, Redridge
			},
		},
		["527:130"] = {
			["Name"] = "Surwich, Blasted Lands",
			["Neighbors"] = {
				["545:188"] = 73, -- Nethergarde Keep, Blasted Lands
				["409:71"] = 152, -- Booty Bay, Stranglethorn
			},
		},
		["527:385"] = {
			["Name"] = "Thelsamar, Loch Modan",
			["Neighbors"] = {
				["466:406"] = 110, -- Ironforge, Dun Morogh
				["453:442"] = 152, -- Menethil Harbor, Wetlands
				["466:346"] = 81, -- Thorium Point, Searing Gorge
				["513:530"] = 163, -- Refuge Pointe, Arathi
				["573:377"] = 46, -- Farstrider Lodge, Loch Modan
				["521:431"] = 60, -- Slabchisel's Survey, Wetlands
				["544:344"] = 46, -- Dustwind Dig, Badlands
			},
		},
		["531:676"] = {
			["Name"] = "Plaguewood Tower, Eastern Plaguelands",
			["Neighbors"] = {
				["577:682"] = 57, -- Northpass Tower, Eastern Plaguelands
				["591:661"] = 67, -- Eastwall Tower, Eastern Plaguelands
				["554:639"] = 53, -- Crown Guard Tower, Eastern Plaguelands
				["579:652"] = 61, -- Light's Shield Tower, Eastern Plaguelands
				["478:672"] = 62, -- Hearthglen, Western Plaguelands
			},
		},
		["532:144"] = {
			["Name"] = "Sunveil Excursion, Blasted Lands",
			["Neighbors"] = {
				["522:194"] = 60, -- Dreadmaul Hold, Blasted Lands
				["408:72"] = 172, -- Booty Bay, Stranglethorn
			},
		},
		["539:210"] = {
			["Name"] = "Stonard, Swamp of Sorrows",
			["Neighbors"] = {
				["501:313"] = 176, -- Flame Crest, Burning Steppes
				["420:142"] = 178, -- Grom'gol, Stranglethorn
				["408:72"] = 230, -- Booty Bay, Stranglethorn
				["522:194"] = 27, -- Dreadmaul Hold, Blasted Lands
				["510:342"] = 228, -- New Kargath, Badlands
				["561:235"] = 45, -- Bogpaddle, Swamp of Sorrows
			},
		},
		["544:344"] = {
			["Name"] = "Dustwind Dig, Badlands",
			["Neighbors"] = {
				["515:329"] = 37, -- Dragon's Mouth, Badlands
				["560:345"] = 29, -- Fuselight, Badlands
				["527:385"] = 53, -- Thelsamar, Loch Modan
			},
		},
		["545:188"] = {
			["Name"] = "Nethergarde Keep, Blasted Lands",
			["Neighbors"] = {
				["521:283"] = 209, -- Morgan's Vigil, Burning Steppes
				["409:266"] = 189, -- Stormwind, Elwynn
				["469:208"] = 92, -- Darkshire, Duskwood
				["559:220"] = 39, -- Marshtide Watch, Swamp of Sorrows
				["527:130"] = 92, -- Surwich, Blasted Lands
			},
		},
		["546:239"] = {
			["Name"] = "Shalewind Canyon, Redridge",
			["Neighbors"] = {
				["524:245"] = 24, -- Camp Everstill, Redridge
				["561:235"] = 34, -- Bogpaddle, Swamp of Sorrows
			},
		},
		["547:542"] = {
			["Name"] = "Hammerfall, Arathi",
			["Neighbors"] = {
				["416:628"] = 259, -- Undercity, Tirisfal
				["589:551"] = 88, -- Revantusk Village, The Hinterlands
				["456:573"] = 117, -- Tarren Mill, Hillsbrad
				["481:540"] = 68, -- Galen's Fall, Arathi
				["510:342"] = 249, -- New Kargath, Badlands
				["524:573"] = 53, -- Hiri'watha Research Station, The Hinterlands
			},
		},
		["548:334"] = {
			["Name"] = "Bloodwatcher Point, Badlands",
			["Neighbors"] = {
				["510:342"] = 39, -- New Kargath, Badlands
				["560:345"] = 25, -- Fuselight, Badlands
			},
		},
		["554:639"] = {
			["Name"] = "Crown Guard Tower, Eastern Plaguelands",
			["Neighbors"] = {
				["577:682"] = 62, -- Northpass Tower, Eastern Plaguelands
				["531:676"] = 53, -- Plaguewood Tower, Eastern Plaguelands
				["519:641"] = 39, -- Thondroril River, Eastern Plaguelands
				["579:652"] = 35, -- Light's Shield Tower, Eastern Plaguelands
			},
		},
		["559:220"] = {
			["Name"] = "Marshtide Watch, Swamp of Sorrows",
			["Neighbors"] = {
				["545:188"] = 44, -- Nethergarde Keep, Blasted Lands
				["525:222"] = 41, -- The Harborage, Swamp of Sorrows
				["561:235"] = 30, -- Bogpaddle, Swamp of Sorrows
			},
		},
		["560:345"] = {
			["Name"] = "Fuselight, Badlands",
			["Neighbors"] = {
				["611:652"] = 358, -- Light's Hope Chapel, Eastern Plaguelands
				["548:334"] = 18, -- Bloodwatcher Point, Badlands
				["510:342"] = 51, -- New Kargath, Badlands
				["515:329"] = 51, -- Dragon's Mouth, Badlands
				["573:377"] = 49, -- Farstrider Lodge, Loch Modan
				["544:344"] = 19, -- Dustwind Dig, Badlands
			},
		},
		["561:235"] = {
			["Name"] = "Bogpaddle, Swamp of Sorrows",
			["Neighbors"] = {
				["539:210"] = 42, -- Stonard, Swamp of Sorrows
				["501:313"] = 109, -- Flame Crest, Burning Steppes
				["559:220"] = 25, -- Marshtide Watch, Swamp of Sorrows
				["546:239"] = 33, -- Shalewind Canyon, Redridge
				["521:283"] = 81, -- Morgan's Vigil, Burning Steppes
			},
		},
		["568:584"] = {
			["Name"] = "Stormfeather Outpost, The Hinterlands",
			["Neighbors"] = {
				["611:652"] = 88, -- Light's Hope Chapel, Eastern Plaguelands
				["495:583"] = 83, -- Aerie Peak, The Hinterlands
				["519:641"] = 120, -- Thondroril River, Eastern Plaguelands
				["513:530"] = 99, -- Refuge Pointe, Arathi
			},
		},
		["573:377"] = {
			["Name"] = "Farstrider Lodge, Loch Modan",
			["Neighbors"] = {
				["560:345"] = 47, -- Fuselight, Badlands
				["527:385"] = 46, -- Thelsamar, Loch Modan
			},
		},
		["573:794"] = {
			["Name"] = "Fairbreeze Village, Eversong Woods",
			["Neighbors"] = {
				["591:816"] = 29, -- Silvermoon City
				["578:754"] = 46, -- Tranquillien, Ghostlands
			},
		},
		["577:682"] = {
			["Name"] = "Northpass Tower, Eastern Plaguelands",
			["Neighbors"] = {
				["591:661"] = 30, -- Eastwall Tower, Eastern Plaguelands
				["531:676"] = 50, -- Plaguewood Tower, Eastern Plaguelands
				["554:639"] = 52, -- Crown Guard Tower, Eastern Plaguelands
			},
		},
		["577:820"] = {
			["Name"] = "Falconwing Square, Eversong Woods",
			["Neighbors"] = {
				["591:816"] = 19, -- Silvermoon City
			},
		},
		["578:754"] = {
			["Name"] = "Tranquillien, Ghostlands",
			["Neighbors"] = {
				["591:816"] = 74, -- Silvermoon City
				["611:726"] = 53, -- Zul'Aman, Ghostlands
				["611:652"] = 128, -- Light's Hope Chapel, Eastern Plaguelands
				["573:794"] = 53, -- Fairbreeze Village, Eversong Woods
			},
		},
		["579:652"] = {
			["Name"] = "Light's Shield Tower, Eastern Plaguelands",
			["Neighbors"] = {
				["591:661"] = 20, -- Eastwall Tower, Eastern Plaguelands
				["531:676"] = 61, -- Plaguewood Tower, Eastern Plaguelands
				["554:639"] = 30, -- Crown Guard Tower, Eastern Plaguelands
				["611:652"] = 39, -- Light's Hope Chapel, Eastern Plaguelands
			},
		},
		["582:942"] = {
			["Name"] = "Shattered Sun Staging Area",
			["Neighbors"] = {
				["611:726"] = 232, -- Zul'Aman, Ghostlands
				["611:652"] = 444, -- Light's Hope Chapel, Eastern Plaguelands
				["591:816"] = 166, -- Silvermoon City
			},
		},
		["589:551"] = {
			["Name"] = "Revantusk Village, The Hinterlands",
			["Neighbors"] = {
				["547:542"] = 94, -- Hammerfall, Arathi
				["416:628"] = 269, -- Undercity, Tirisfal
				["611:652"] = 134, -- Light's Hope Chapel, Eastern Plaguelands
				["456:573"] = 156, -- Tarren Mill, Hillsbrad
				["524:573"] = 76, -- Hiri'watha Research Station, The Hinterlands
			},
		},
		["591:661"] = {
			["Name"] = "Eastwall Tower, Eastern Plaguelands",
			["Neighbors"] = {
				["577:682"] = 31, -- Northpass Tower, Eastern Plaguelands
				["531:676"] = 66, -- Plaguewood Tower, Eastern Plaguelands
				["579:652"] = 18, -- Light's Shield Tower, Eastern Plaguelands
				["611:652"] = 30, -- Light's Hope Chapel, Eastern Plaguelands
			},
		},
		["591:816"] = {
			["Name"] = "Silvermoon City",
			["Neighbors"] = {
				["582:942"] = 185, -- Shattered Sun Staging Area
				["578:754"] = 65, -- Tranquillien, Ghostlands
				["577:820"] = 24, -- Falconwing Square, Eversong Woods
				["573:794"] = 31, -- Fairbreeze Village, Eversong Woods
			},
		},
		["611:652"] = {
			["Name"] = "Light's Hope Chapel, Eastern Plaguelands",
			["Neighbors"] = {
				["466:406"] = 369, -- Ironforge, Dun Morogh
				["622:655"] = 70, -- Acherus: The Ebon Hold
				["582:942"] = 460, -- Shattered Sun Staging Area
				["611:726"] = 223, -- Zul'Aman, Ghostlands
				["475:606"] = 149, -- Chillwind Camp, Western Plaguelands
				["495:583"] = 162, -- Aerie Peak, The Hinterlands
				["578:754"] = 123, -- Tranquillien, Ghostlands
				["589:551"] = 144, -- Revantusk Village, The Hinterlands
				["416:628"] = 261, -- Undercity, Tirisfal
				["591:661"] = 24, -- Eastwall Tower, Eastern Plaguelands
				["519:641"] = 96, -- Thondroril River, Eastern Plaguelands
				["579:652"] = 35, -- Light's Shield Tower, Eastern Plaguelands
				["560:345"] = 175, -- Fuselight, Badlands
				["568:584"] = 96, -- Stormfeather Outpost, The Hinterlands
			},
		},
		["611:726"] = {
			["Name"] = "Zul'Aman, Ghostlands",
			["Neighbors"] = {
				["611:652"] = 227, -- Light's Hope Chapel, Eastern Plaguelands
				["582:942"] = 251, -- Shattered Sun Staging Area
				["578:754"] = 52, -- Tranquillien, Ghostlands
			},
		},
		["622:655"] = {
			["Name"] = "Acherus: The Ebon Hold",
			["Neighbors"] = {
				["611:652"] = 52, -- Light's Hope Chapel, Eastern Plaguelands
			},
		},
	},
	[3] = {
		["232:496"] = {
			["Name"] = "Zabra'jin, Zangarmarsh",
			["Neighbors"] = {
				["378:677"] = 112, -- Thunderlord Stronghold, Blade's Edge Mountains
				["288:375"] = 82, -- Garadar, Nagrand
				["444:485"] = 112, -- Swamprat Post, Zangarmarsh
				["535:430"] = 147, -- Falcon Watch, Hellfire Peninsula
				["437:328"] = 151, -- Shattrath, Terokkar Forest
			},
		},
		["266:556"] = {
			["Name"] = "Orebor Harborage, Zangarmarsh",
			["Neighbors"] = {
				["315:656"] = 64, -- Sylvanaar, Blade's Edge Mountains
				["375:495"] = 52, -- Telredor, Zangarmarsh
			},
		},
		["272:684"] = {
			["Name"] = "Ogri'La",
			["Neighbors"] = {
				["572:203"] = 242, -- Skettis
			},
		},
		["274:255"] = {
			["Name"] = "Telaar, Nagrand",
			["Neighbors"] = {
				["437:328"] = 87, -- Shattrath, Terokkar Forest
				["375:495"] = 126, -- Telredor, Zangarmarsh
				["554:234"] = 121, -- Allerian Stronghold, Terokkar Forest
			},
		},
		["288:375"] = {
			["Name"] = "Garadar, Nagrand",
			["Neighbors"] = {
				["437:328"] = 77, -- Shattrath, Terokkar Forest
				["232:496"] = 67, -- Zabra'jin, Zangarmarsh
				["535:430"] = 127, -- Falcon Watch, Hellfire Peninsula
			},
		},
		["315:656"] = {
			["Name"] = "Sylvanaar, Blade's Edge Mountains",
			["Neighbors"] = {
				["576:729"] = 119, -- Area 52, Netherstorm
				["266:556"] = 76, -- Orebor Harborage, Zangarmarsh
				["421:720"] = 51, -- Evergrove, Blade's Edge Mountains
				["628:816"] = 154, -- The Stormspire, Netherstorm
				["418:629"] = 57, -- Toshley's Station, Blade's Edge Mountains
				["375:495"] = 81, -- Telredor, Zangarmarsh
			},
		},
		["375:495"] = {
			["Name"] = "Telredor, Zangarmarsh",
			["Neighbors"] = {
				["274:255"] = 124, -- Telaar, Nagrand
				["524:494"] = 81, -- Temple of Telhamat, Hellfire Peninsula
				["418:629"] = 68, -- Toshley's Station, Blade's Edge Mountains
				["315:656"] = 91, -- Sylvanaar, Blade's Edge Mountains
				["266:556"] = 62, -- Orebor Harborage, Zangarmarsh
				["437:328"] = 97, -- Shattrath, Terokkar Forest
			},
		},
		["378:677"] = {
			["Name"] = "Thunderlord Stronghold, Blade's Edge Mountains",
			["Neighbors"] = {
				["232:496"] = 148, -- Zabra'jin, Zangarmarsh
				["576:729"] = 96, -- Area 52, Netherstorm
				["486:643"] = 55, -- Mok'Nathal Village, Blade's Edge Mountains
				["421:720"] = 26, -- Evergrove, Blade's Edge Mountains
				["444:485"] = 116, -- Swamprat Post, Zangarmarsh
				["628:816"] = 158, -- The Stormspire, Netherstorm
			},
		},
		["418:629"] = {
			["Name"] = "Toshley's Station, Blade's Edge Mountains",
			["Neighbors"] = {
				["421:720"] = 53, -- Evergrove, Blade's Edge Mountains
				["375:495"] = 72, -- Telredor, Zangarmarsh
				["576:729"] = 83, -- Area 52, Netherstorm
				["315:656"] = 59, -- Sylvanaar, Blade's Edge Mountains
			},
		},
		["421:720"] = {
			["Name"] = "Evergrove, Blade's Edge Mountains",
			["Neighbors"] = {
				["315:656"] = 55, -- Sylvanaar, Blade's Edge Mountains
				["418:629"] = 44, -- Toshley's Station, Blade's Edge Mountains
				["576:729"] = 77, -- Area 52, Netherstorm
				["378:677"] = 36, -- Thunderlord Stronghold, Blade's Edge Mountains
			},
		},
		["437:328"] = {
			["Name"] = "Shattrath, Terokkar Forest",
			["Neighbors"] = {
				["274:255"] = 88, -- Telaar, Nagrand
				["288:375"] = 81, -- Garadar, Nagrand
				["554:234"] = 75, -- Allerian Stronghold, Terokkar Forest
				["535:430"] = 76, -- Falcon Watch, Hellfire Peninsula
				["648:423"] = 111, -- Honor Hold, Hellfire Peninsula
				["509:268"] = 68, -- Stonebreaker Hold, Terokkar Forest
				["232:496"] = 136, -- Zabra'jin, Zangarmarsh
				["444:485"] = 79, -- Swamprat Post, Zangarmarsh
				["375:495"] = 83, -- Telredor, Zangarmarsh
				["655:496"] = 131, -- Thrallmar, Hellfire Peninsula
			},
		},
		["444:485"] = {
			["Name"] = "Swamprat Post, Zangarmarsh",
			["Neighbors"] = {
				["486:643"] = 70, -- Mok'Nathal Village, Blade's Edge Mountains
				["232:496"] = 111, -- Zabra'jin, Zangarmarsh
				["437:328"] = 87, -- Shattrath, Terokkar Forest
				["378:677"] = 106, -- Thunderlord Stronghold, Blade's Edge Mountains
				["535:430"] = 62, -- Falcon Watch, Hellfire Peninsula
			},
		},
		["486:643"] = {
			["Name"] = "Mok'Nathal Village, Blade's Edge Mountains",
			["Neighbors"] = {
				["444:485"] = 73, -- Swamprat Post, Zangarmarsh
				["576:729"] = 56, -- Area 52, Netherstorm
				["378:677"] = 63, -- Thunderlord Stronghold, Blade's Edge Mountains
			},
		},
		["509:268"] = {
			["Name"] = "Stonebreaker Hold, Terokkar Forest",
			["Neighbors"] = {
				["655:496"] = 125, -- Thrallmar, Hellfire Peninsula
				["437:328"] = 56, -- Shattrath, Terokkar Forest
				["661:232"] = 67, -- Shadowmoon Village, Shadowmoon Valley
			},
		},
		["524:494"] = {
			["Name"] = "Temple of Telhamat, Hellfire Peninsula",
			["Neighbors"] = {
				["375:495"] = 80, -- Telredor, Zangarmarsh
				["648:423"] = 87, -- Honor Hold, Hellfire Peninsula
			},
		},
		["535:430"] = {
			["Name"] = "Falcon Watch, Hellfire Peninsula",
			["Neighbors"] = {
				["655:496"] = 73, -- Thrallmar, Hellfire Peninsula
				["437:328"] = 71, -- Shattrath, Terokkar Forest
				["444:485"] = 68, -- Swamprat Post, Zangarmarsh
				["232:496"] = 149, -- Zabra'jin, Zangarmarsh
				["288:375"] = 132, -- Garadar, Nagrand
			},
		},
		["554:234"] = {
			["Name"] = "Allerian Stronghold, Terokkar Forest",
			["Neighbors"] = {
				["274:255"] = 149, -- Telaar, Nagrand
				["694:153"] = 79, -- Wildhammer Stronghold, Shadowmoon Valley
				["437:328"] = 74, -- Shattrath, Terokkar Forest
				["648:423"] = 96, -- Honor Hold, Hellfire Peninsula
			},
		},
		["572:203"] = {
			["Name"] = "Skettis",
			["Neighbors"] = {
				["272:684"] = 243, -- Ogri'La
			},
		},
		["576:729"] = {
			["Name"] = "Area 52, Netherstorm",
			["Neighbors"] = {
				["378:677"] = 108, -- Thunderlord Stronghold, Blade's Edge Mountains
				["486:643"] = 64, -- Mok'Nathal Village, Blade's Edge Mountains
				["315:656"] = 126, -- Sylvanaar, Blade's Edge Mountains
				["628:816"] = 48, -- The Stormspire, Netherstorm
				["719:720"] = 66, -- Cosmowrench, Netherstorm
				["418:629"] = 93, -- Toshley's Station, Blade's Edge Mountains
				["421:720"] = 80, -- Evergrove, Blade's Edge Mountains
			},
		},
		["628:816"] = {
			["Name"] = "The Stormspire, Netherstorm",
			["Neighbors"] = {
				["576:729"] = 53, -- Area 52, Netherstorm
				["719:720"] = 68, -- Cosmowrench, Netherstorm
				["378:677"] = 146, -- Thunderlord Stronghold, Blade's Edge Mountains
				["315:656"] = 154, -- Sylvanaar, Blade's Edge Mountains
			},
		},
		["648:423"] = {
			["Name"] = "Honor Hold, Hellfire Peninsula",
			["Neighbors"] = {
				["437:328"] = 119, -- Shattrath, Terokkar Forest
				["554:234"] = 118, -- Allerian Stronghold, Terokkar Forest
				["786:451"] = 64, -- Hellfire Peninsula, The Dark Portal, Alliance
				["748:500"] = 56, -- Shatter Point, Hellfire Peninsula
				["524:494"] = 75, -- Temple of Telhamat, Hellfire Peninsula
			},
		},
		["655:496"] = {
			["Name"] = "Thrallmar, Hellfire Peninsula",
			["Neighbors"] = {
				["786:463"] = 70, -- Hellfire Peninsula, The Dark Portal, Horde
				["509:268"] = 128, -- Stonebreaker Hold, Terokkar Forest
				["677:370"] = 66, -- Spinebreaker Ridge, Hellfire Peninsula
				["535:430"] = 67, -- Falcon Watch, Hellfire Peninsula
				["437:328"] = 123, -- Shattrath, Terokkar Forest
			},
		},
		["661:232"] = {
			["Name"] = "Shadowmoon Village, Shadowmoon Valley",
			["Neighbors"] = {
				["808:228"] = 84, -- Altar of Sha'tar, Shadowmoon Valley
				["509:268"] = 73, -- Stonebreaker Hold, Terokkar Forest
				["778:146"] = 65, -- Sanctum of the Stars, Shadowmoon Valley
			},
		},
		["677:370"] = {
			["Name"] = "Spinebreaker Ridge, Hellfire Peninsula",
			["Neighbors"] = {
				["655:496"] = 63, -- Thrallmar, Hellfire Peninsula
			},
		},
		["694:153"] = {
			["Name"] = "Wildhammer Stronghold, Shadowmoon Valley",
			["Neighbors"] = {
				["554:234"] = 100, -- Allerian Stronghold, Terokkar Forest
				["808:228"] = 83, -- Altar of Sha'tar, Shadowmoon Valley
				["778:146"] = 42, -- Sanctum of the Stars, Shadowmoon Valley
			},
		},
		["719:720"] = {
			["Name"] = "Cosmowrench, Netherstorm",
			["Neighbors"] = {
				["628:816"] = 60, -- The Stormspire, Netherstorm
				["576:729"] = 64, -- Area 52, Netherstorm
			},
		},
		["748:500"] = {
			["Name"] = "Shatter Point, Hellfire Peninsula",
			["Neighbors"] = {
				["648:423"] = 57, -- Honor Hold, Hellfire Peninsula
				["786:451"] = 32, -- Hellfire Peninsula, The Dark Portal, Alliance
			},
		},
		["778:146"] = {
			["Name"] = "Sanctum of the Stars, Shadowmoon Valley",
			["Neighbors"] = {
				["694:153"] = 41, -- Wildhammer Stronghold, Shadowmoon Valley
				["661:232"] = 61, -- Shadowmoon Village, Shadowmoon Valley
			},
		},
		["786:451"] = {
			["Name"] = "Hellfire Peninsula, The Dark Portal, Alliance",
			["Neighbors"] = {
				["524:494"] = 115, -- Temple of Telhamat, Hellfire Peninsula
				["648:423"] = 73, -- Honor Hold, Hellfire Peninsula
				["748:500"] = 27, -- Shatter Point, Hellfire Peninsula
			},
		},
		["786:463"] = {
			["Name"] = "Hellfire Peninsula, The Dark Portal, Horde",
			["Neighbors"] = {
				["535:430"] = 122, -- Falcon Watch, Hellfire Peninsula
				["655:496"] = 60, -- Thrallmar, Hellfire Peninsula
			},
		},
		["808:228"] = {
			["Name"] = "Altar of Sha'tar, Shadowmoon Valley",
			["Neighbors"] = {
				["694:153"] = 80, -- Wildhammer Stronghold, Shadowmoon Valley
				["661:232"] = 66, -- Shadowmoon Village, Shadowmoon Valley
			},
		},
	},
	[4] = {
		["121:472"] = {
			["Name"] = "Transitus Shield, Coldarra",
			["Neighbors"] = {
				["165:473"] = 45, -- Amber Ledge, Borean Tundra
			},
		},
		["148:430"] = {
			["Name"] = "Warsong Hold, Borean Tundra",
			["Neighbors"] = {
				["287:464"] = 87, -- Taunka'le Village, Borean Tundra
				["182:530"] = 68, -- Bor'gorok Outpost, Borean Tundra
				["290:430"] = 92, -- Unu'pe, Borean Tundra
				["165:473"] = 35, -- Amber Ledge, Borean Tundra
			},
		},
		["165:473"] = {
			["Name"] = "Amber Ledge, Borean Tundra",
			["Neighbors"] = {
				["217:388"] = 66, -- Valiance Keep, Borean Tundra
				["287:464"] = 71, -- Taunka'le Village, Borean Tundra
				["121:472"] = 37, -- Transitus Shield, Coldarra
				["208:508"] = 35, -- Fizzcrank Airstrip, Borean Tundra
				["148:430"] = 41, -- Warsong Hold, Borean Tundra
				["182:530"] = 34, -- Bor'gorok Outpost, Borean Tundra
			},
		},
		["175:603"] = {
			["Name"] = "Nesingwary Base Camp, Sholazar Basin",
			["Neighbors"] = {
				["182:530"] = 60, -- Bor'gorok Outpost, Borean Tundra
				["208:508"] = 77, -- Fizzcrank Airstrip, Borean Tundra
				["278:721"] = 91, -- Death's Rise, Icecrown
				["244:597"] = 51, -- River's Heart, Sholazar Basin
			},
		},
		["182:530"] = {
			["Name"] = "Bor'gorok Outpost, Borean Tundra",
			["Neighbors"] = {
				["175:603"] = 47, -- Nesingwary Base Camp, Sholazar Basin
				["287:464"] = 77, -- Taunka'le Village, Borean Tundra
				["165:473"] = 58, -- Amber Ledge, Borean Tundra
				["148:430"] = 72, -- Warsong Hold, Borean Tundra
				["244:597"] = 56, -- River's Heart, Sholazar Basin
			},
		},
		["208:508"] = {
			["Name"] = "Fizzcrank Airstrip, Borean Tundra",
			["Neighbors"] = {
				["244:597"] = 63, -- River's Heart, Sholazar Basin
				["423:467"] = 133, -- Stars' Rest, Dragonblight
				["165:473"] = 44, -- Amber Ledge, Borean Tundra
				["217:388"] = 70, -- Valiance Keep, Borean Tundra
				["175:603"] = 76, -- Nesingwary Base Camp, Sholazar Basin
				["290:430"] = 64, -- Unu'pe, Borean Tundra
			},
		},
		["217:388"] = {
			["Name"] = "Valiance Keep, Borean Tundra",
			["Neighbors"] = {
				["423:467"] = 145, -- Stars' Rest, Dragonblight
				["290:430"] = 63, -- Unu'pe, Borean Tundra
				["165:473"] = 63, -- Amber Ledge, Borean Tundra
				["208:508"] = 75, -- Fizzcrank Airstrip, Borean Tundra
				["522:617"] = 0, -- Dalaran
			},
		},
		["244:597"] = {
			["Name"] = "River's Heart, Sholazar Basin",
			["Neighbors"] = {
				["182:530"] = 61, -- Bor'gorok Outpost, Borean Tundra
				["175:603"] = 42, -- Nesingwary Base Camp, Sholazar Basin
				["208:508"] = 69, -- Fizzcrank Airstrip, Borean Tundra
				["278:721"] = 93, -- Death's Rise, Icecrown
				["313:566"] = 0, -- Warsong Camp, Wintergrasp
				["522:617"] = 301, -- Dalaran
				["410:571"] = 0, -- Valiance Landing Camp, Wintergrasp
			},
		},
		["278:721"] = {
			["Name"] = "Death's Rise, Icecrown",
			["Neighbors"] = {
				["175:603"] = 117, -- Nesingwary Base Camp, Sholazar Basin
				["377:785"] = 93, -- The Shadow Vault, Icecrown
				["244:597"] = 116, -- River's Heart, Sholazar Basin
				["410:571"] = 0, -- Valiance Landing Camp, Wintergrasp
				["313:566"] = 0, -- Warsong Camp, Wintergrasp
			},
		},
		["287:464"] = {
			["Name"] = "Taunka'le Village, Borean Tundra",
			["Neighbors"] = {
				["182:530"] = 72, -- Bor'gorok Outpost, Borean Tundra
				["453:491"] = 91, -- Agmar's Hammer, Dragonblight
				["148:430"] = 84, -- Warsong Hold, Borean Tundra
				["290:430"] = 30, -- Unu'pe, Borean Tundra
				["165:473"] = 76, -- Amber Ledge, Borean Tundra
				["313:566"] = 0, -- Warsong Camp, Wintergrasp
			},
		},
		["290:430"] = {
			["Name"] = "Unu'pe, Borean Tundra",
			["Neighbors"] = {
				["148:430"] = 87, -- Warsong Hold, Borean Tundra
				["208:508"] = 79, -- Fizzcrank Airstrip, Borean Tundra
				["287:464"] = 21, -- Taunka'le Village, Borean Tundra
				["493:421"] = 118, -- Moa'ki, Dragonblight
				["423:467"] = 97, -- Stars' Rest, Dragonblight
				["217:388"] = 59, -- Valiance Keep, Borean Tundra
			},
		},
		["313:566"] = {
			["Name"] = "Warsong Camp, Wintergrasp",
			["Neighbors"] = {
				["522:617"] = 141, -- Dalaran
				["244:597"] = 76, -- River's Heart, Sholazar Basin
				["453:491"] = 100, -- Agmar's Hammer, Dragonblight
				["521:655"] = 159, -- Crusaders' Pinnacle, Icecrown
				["287:464"] = 79, -- Taunka'le Village, Borean Tundra
				["278:721"] = 0, -- Death's Rise, Icecrown
				["377:785"] = 0, -- The Shadow Vault, Icecrown
			},
		},
		["377:785"] = {
			["Name"] = "The Shadow Vault, Icecrown",
			["Neighbors"] = {
				["278:721"] = 77, -- Death's Rise, Icecrown
				["521:655"] = 120, -- Crusaders' Pinnacle, Icecrown
				["555:639"] = 134, -- The Argent Vanguard, Icecrown
				["573:789"] = 121, -- Bouldercrag's Refuge, The Storm Peaks
				["410:571"] = 0, -- Valiance Landing Camp, Wintergrasp
				["494:789"] = 0, -- Argent Tournament Grounds, Icecrown
				["313:566"] = 0, -- Warsong Camp, Wintergrasp
			},
		},
		["410:571"] = {
			["Name"] = "Valiance Landing Camp, Wintergrasp",
			["Neighbors"] = {
				["521:655"] = 109, -- Crusaders' Pinnacle, Icecrown
				["244:597"] = 136, -- River's Heart, Sholazar Basin
				["522:617"] = 91, -- Dalaran
				["423:467"] = 80, -- Stars' Rest, Dragonblight
				["460:539"] = 49, -- Fordragon Hold, Dragonblight
				["377:785"] = 0, -- The Shadow Vault, Icecrown
				["278:721"] = 0, -- Death's Rise, Icecrown
			},
		},
		["423:467"] = {
			["Name"] = "Stars' Rest, Dragonblight",
			["Neighbors"] = {
				["460:539"] = 80, -- Fordragon Hold, Dragonblight
				["596:481"] = 123, -- Wintergarde Keep, Dragonblight
				["493:421"] = 70, -- Moa'ki, Dragonblight
				["217:388"] = 132, -- Valiance Keep, Borean Tundra
				["208:508"] = 129, -- Fizzcrank Airstrip, Borean Tundra
				["535:477"] = 89, -- Wyrmrest Temple, Dragonblight
				["290:430"] = 100, -- Unu'pe, Borean Tundra
				["410:571"] = 0, -- Valiance Landing Camp, Wintergrasp
			},
		},
		["453:491"] = {
			["Name"] = "Agmar's Hammer, Dragonblight",
			["Neighbors"] = {
				["493:421"] = 63, -- Moa'ki, Dragonblight
				["594:451"] = 88, -- Venomspite, Dragonblight
				["476:561"] = 65, -- Kor'koron Vanguard, Dragonblight
				["535:477"] = 51, -- Wyrmrest Temple, Dragonblight
				["287:464"] = 113, -- Taunka'le Village, Borean Tundra
				["313:566"] = 0, -- Warsong Camp, Wintergrasp
			},
		},
		["460:539"] = {
			["Name"] = "Fordragon Hold, Dragonblight",
			["Neighbors"] = {
				["636:578"] = 118, -- Ebon Watch, Zul'Drak
				["423:467"] = 73, -- Stars' Rest, Dragonblight
				["522:617"] = 65, -- Dalaran
				["535:477"] = 65, -- Wyrmrest Temple, Dragonblight
				["596:481"] = 86, -- Wintergarde Keep, Dragonblight
				["410:571"] = 0, -- Valiance Landing Camp, Wintergrasp
			},
		},
		["476:561"] = {
			["Name"] = "Kor'koron Vanguard, Dragonblight",
			["Neighbors"] = {
				["636:578"] = 106, -- Ebon Watch, Zul'Drak
				["535:477"] = 67, -- Wyrmrest Temple, Dragonblight
				["522:617"] = 56, -- Dalaran
				["594:451"] = 90, -- Venomspite, Dragonblight
				["453:491"] = 52, -- Agmar's Hammer, Dragonblight
			},
		},
		["493:421"] = {
			["Name"] = "Moa'ki, Dragonblight",
			["Neighbors"] = {
				["535:477"] = 48, -- Wyrmrest Temple, Dragonblight
				["594:451"] = 61, -- Venomspite, Dragonblight
				["290:430"] = 132, -- Unu'pe, Borean Tundra
				["596:481"] = 85, -- Wintergarde Keep, Dragonblight
				["453:491"] = 64, -- Agmar's Hammer, Dragonblight
				["522:617"] = 122, -- Dalaran
				["738:292"] = 184, -- Kamagua, Howling Fjord
				["423:467"] = 54, -- Stars' Rest, Dragonblight
			},
		},
		["521:655"] = {
			["Name"] = "Crusaders' Pinnacle, Icecrown",
			["Neighbors"] = {
				["377:785"] = 123, -- The Shadow Vault, Icecrown
				["522:617"] = 70, -- Dalaran
				["555:639"] = 32, -- The Argent Vanguard, Icecrown
				["278:721"] = 0, -- Death's Rise, Icecrown
				["313:566"] = 0, -- Warsong Camp, Wintergrasp
				["494:789"] = 0, -- Argent Tournament Grounds, Icecrown
			},
		},
		["522:617"] = {
			["Name"] = "Dalaran",
			["Neighbors"] = {
				["521:655"] = 39, -- Crusaders' Pinnacle, Icecrown
				["596:602"] = 57, -- Sunreaver's Command, Crystalsong Forest
				["535:477"] = 122, -- Wyrmrest Temple, Dragonblight
				["555:639"] = 32, -- The Argent Vanguard, Icecrown
				["493:421"] = 159, -- Moa'ki, Dragonblight
				["460:539"] = 100, -- Fordragon Hold, Dragonblight
				["476:561"] = 73, -- Kor'koron Vanguard, Dragonblight
				["619:641"] = 54, -- K3, The Storm Peaks
				["585:566"] = 52, -- Windrunner's Overlook, Crystalsong Forest
				["636:578"] = 81, -- Ebon Watch, Zul'Drak
				["410:571"] = 0, -- Valiance Landing Camp, Wintergrasp
				["244:597"] = 212, -- River's Heart, Sholazar Basin
				["217:388"] = 261, -- Valiance Keep, Borean Tundra
				["494:789"] = 123, -- Argent Tournament Grounds, Icecrown
				["875:278"] = 0, -- Valgarde Port, Howling Fjord
				["313:566"] = 161, -- Warsong Camp, Wintergrasp
			},
		},
		["535:477"] = {
			["Name"] = "Wyrmrest Temple, Dragonblight",
			["Neighbors"] = {
				["522:617"] = 65, -- Dalaran
				["636:578"] = 105, -- Ebon Watch, Zul'Drak
				["453:491"] = 69, -- Agmar's Hammer, Dragonblight
				["423:467"] = 66, -- Stars' Rest, Dragonblight
				["596:481"] = 50, -- Wintergarde Keep, Dragonblight
				["594:451"] = 50, -- Venomspite, Dragonblight
				["476:561"] = 66, -- Kor'koron Vanguard, Dragonblight
				["493:421"] = 53, -- Moa'ki, Dragonblight
				["460:539"] = 58, -- Fordragon Hold, Dragonblight
			},
		},
		["555:639"] = {
			["Name"] = "The Argent Vanguard, Icecrown",
			["Neighbors"] = {
				["521:655"] = 27, -- Crusaders' Pinnacle, Icecrown
				["568:672"] = 40, -- Frosthold, The Storm Peaks
				["377:785"] = 147, -- The Shadow Vault, Icecrown
				["522:617"] = 31, -- Dalaran
				["599:749"] = 103, -- Grom'arsh Crash-Site, The Storm Peaks
			},
		},
		["494:789"] = {
			["Name"] = "Argent Tournament Grounds, Icecrown",
			["Neighbors"] = {
				["377:785"] = 89, -- The Shadow Vault, Icecrown
				["573:789"] = 0, -- Bouldercrag's Refuge, The Storm Peaks
				["522:617"] = 140, -- Dalaran
				["521:655"] = 73, -- Crusaders' Pinnacle, Icecrown
			},
		},
		["568:672"] = {
			["Name"] = "Frosthold, The Storm Peaks",
			["Neighbors"] = {
				["637:814"] = 97, -- Ulduar, The Storm Peaks
				["555:639"] = 33, -- The Argent Vanguard, Icecrown
				["573:789"] = 65, -- Bouldercrag's Refuge, The Storm Peaks
				["619:641"] = 48, -- K3, The Storm Peaks
			},
		},
		["573:789"] = {
			["Name"] = "Bouldercrag's Refuge, The Storm Peaks",
			["Neighbors"] = {
				["377:785"] = 112, -- The Shadow Vault, Icecrown
				["599:749"] = 40, -- Grom'arsh Crash-Site, The Storm Peaks
				["637:814"] = 44, -- Ulduar, The Storm Peaks
				["568:672"] = 78, -- Frosthold, The Storm Peaks
				["494:789"] = 0, -- Argent Tournament Grounds, Icecrown
			},
		},
		["585:566"] = {
			["Name"] = "Windrunner's Overlook, Crystalsong Forest",
			["Neighbors"] = {
				["619:641"] = 46, -- K3, The Storm Peaks
				["522:617"] = 47, -- Dalaran
				["636:578"] = 46, -- Ebon Watch, Zul'Drak
				["596:481"] = 75, -- Wintergarde Keep, Dragonblight
			},
		},
		["594:451"] = {
			["Name"] = "Venomspite, Dragonblight",
			["Neighbors"] = {
				["636:578"] = 83, -- Ebon Watch, Zul'Drak
				["698:452"] = 59, -- Conquest Hold, Grizzly Hills
				["476:561"] = 120, -- Kor'koron Vanguard, Dragonblight
				["743:377"] = 98, -- Apothecary Camp, Howling Fjord
				["535:477"] = 52, -- Wyrmrest Temple, Dragonblight
				["493:421"] = 82, -- Moa'ki, Dragonblight
				["694:576"] = 106, -- Light's Breach, Zul'Drak
				["453:491"] = 133, -- Agmar's Hammer, Dragonblight
				["845:267"] = 186, -- New Agamand, Howling Fjord
			},
		},
		["596:481"] = {
			["Name"] = "Wintergarde Keep, Dragonblight",
			["Neighbors"] = {
				["535:477"] = 54, -- Wyrmrest Temple, Dragonblight
				["460:539"] = 96, -- Fordragon Hold, Dragonblight
				["764:328"] = 125, -- Westguard Keep, Howling Fjord
				["585:566"] = 71, -- Windrunner's Overlook, Crystalsong Forest
				["493:421"] = 98, -- Moa'ki, Dragonblight
				["694:576"] = 88, -- Light's Breach, Zul'Drak
				["729:464"] = 77, -- Amberpine Lodge, Grizzly Hills
				["423:467"] = 114, -- Stars' Rest, Dragonblight
				["636:578"] = 64, -- Ebon Watch, Zul'Drak
			},
		},
		["596:602"] = {
			["Name"] = "Sunreaver's Command, Crystalsong Forest",
			["Neighbors"] = {
				["636:578"] = 37, -- Ebon Watch, Zul'Drak
				["522:617"] = 55, -- Dalaran
				["619:641"] = 33, -- K3, The Storm Peaks
			},
		},
		["599:749"] = {
			["Name"] = "Grom'arsh Crash-Site, The Storm Peaks",
			["Neighbors"] = {
				["637:814"] = 51, -- Ulduar, The Storm Peaks
				["619:641"] = 87, -- K3, The Storm Peaks
				["573:789"] = 37, -- Bouldercrag's Refuge, The Storm Peaks
				["555:639"] = 79, -- The Argent Vanguard, Icecrown
				["733:745"] = 96, -- Camp Tunka'lo, The Storm Peaks
			},
		},
		["619:641"] = {
			["Name"] = "K3, The Storm Peaks",
			["Neighbors"] = {
				["596:602"] = 37, -- Sunreaver's Command, Crystalsong Forest
				["733:745"] = 90, -- Camp Tunka'lo, The Storm Peaks
				["568:672"] = 43, -- Frosthold, The Storm Peaks
				["720:713"] = 100, -- Dun Niffelem, The Storm Peaks
				["636:578"] = 43, -- Ebon Watch, Zul'Drak
				["599:749"] = 75, -- Grom'arsh Crash-Site, The Storm Peaks
				["585:566"] = 53, -- Windrunner's Overlook, Crystalsong Forest
				["522:617"] = 72, -- Dalaran
			},
		},
		["636:578"] = {
			["Name"] = "Ebon Watch, Zul'Drak",
			["Neighbors"] = {
				["522:617"] = 67, -- Dalaran
				["585:566"] = 33, -- Windrunner's Overlook, Crystalsong Forest
				["476:561"] = 108, -- Kor'koron Vanguard, Dragonblight
				["535:477"] = 91, -- Wyrmrest Temple, Dragonblight
				["694:576"] = 44, -- Light's Breach, Zul'Drak
				["460:539"] = 111, -- Fordragon Hold, Dragonblight
				["619:641"] = 40, -- K3, The Storm Peaks
				["596:481"] = 61, -- Wintergarde Keep, Dragonblight
				["724:598"] = 63, -- The Argent Stand, Zul'Drak
				["596:602"] = 26, -- Sunreaver's Command, Crystalsong Forest
				["594:451"] = 98, -- Venomspite, Dragonblight
			},
		},
		["637:814"] = {
			["Name"] = "Ulduar, The Storm Peaks",
			["Neighbors"] = {
				["784:614"] = 153, -- Zim'Torga, Zul'Drak
				["568:672"] = 102, -- Frosthold, The Storm Peaks
				["573:789"] = 48, -- Bouldercrag's Refuge, The Storm Peaks
				["720:713"] = 103, -- Dun Niffelem, The Storm Peaks
				["599:749"] = 43, -- Grom'arsh Crash-Site, The Storm Peaks
				["733:745"] = 87, -- Camp Tunka'lo, The Storm Peaks
			},
		},
		["694:576"] = {
			["Name"] = "Light's Breach, Zul'Drak",
			["Neighbors"] = {
				["724:598"] = 43, -- The Argent Stand, Zul'Drak
				["594:451"] = 121, -- Venomspite, Dragonblight
				["729:464"] = 83, -- Amberpine Lodge, Grizzly Hills
				["596:481"] = 83, -- Wintergarde Keep, Dragonblight
				["636:578"] = 39, -- Ebon Watch, Zul'Drak
				["698:452"] = 74, -- Conquest Hold, Grizzly Hills
				["844:492"] = 105, -- Camp Oneqwah, Grizzly Hills
			},
		},
		["698:452"] = {
			["Name"] = "Conquest Hold, Grizzly Hills",
			["Neighbors"] = {
				["694:576"] = 79, -- Light's Breach, Zul'Drak
				["743:377"] = 57, -- Apothecary Camp, Howling Fjord
				["835:412"] = 85, -- Camp Winterhoof, Howling Fjord
				["594:451"] = 87, -- Venomspite, Dragonblight
				["844:492"] = 102, -- Camp Oneqwah, Grizzly Hills
			},
		},
		["720:713"] = {
			["Name"] = "Dun Niffelem, The Storm Peaks",
			["Neighbors"] = {
				["784:614"] = 88, -- Zim'Torga, Zul'Drak
				["637:814"] = 84, -- Ulduar, The Storm Peaks
				["619:641"] = 87, -- K3, The Storm Peaks
				["733:745"] = 32, -- Camp Tunka'lo, The Storm Peaks
			},
		},
		["724:598"] = {
			["Name"] = "The Argent Stand, Zul'Drak",
			["Neighbors"] = {
				["784:614"] = 41, -- Zim'Torga, Zul'Drak
				["844:492"] = 99, -- Camp Oneqwah, Grizzly Hills
				["694:576"] = 24, -- Light's Breach, Zul'Drak
				["636:578"] = 52, -- Ebon Watch, Zul'Drak
				["826:537"] = 71, -- Westfall Brigade, Grizzly Hills
			},
		},
		["729:464"] = {
			["Name"] = "Amberpine Lodge, Grizzly Hills",
			["Neighbors"] = {
				["694:576"] = 66, -- Light's Breach, Zul'Drak
				["826:537"] = 83, -- Westfall Brigade, Grizzly Hills
				["877:400"] = 116, -- Fort Wildervar, Howling Fjord
				["764:328"] = 83, -- Westguard Keep, Howling Fjord
				["596:481"] = 81, -- Wintergarde Keep, Dragonblight
			},
		},
		["733:745"] = {
			["Name"] = "Camp Tunka'lo, The Storm Peaks",
			["Neighbors"] = {
				["784:614"] = 98, -- Zim'Torga, Zul'Drak
				["599:749"] = 101, -- Grom'arsh Crash-Site, The Storm Peaks
				["637:814"] = 73, -- Ulduar, The Storm Peaks
				["619:641"] = 114, -- K3, The Storm Peaks
				["720:713"] = 45, -- Dun Niffelem, The Storm Peaks
			},
		},
		["738:292"] = {
			["Name"] = "Kamagua, Howling Fjord",
			["Neighbors"] = {
				["875:278"] = 80, -- Valgarde Port, Howling Fjord
				["764:328"] = 36, -- Westguard Keep, Howling Fjord
				["845:267"] = 63, -- New Agamand, Howling Fjord
				["493:421"] = 194, -- Moa'ki, Dragonblight
				["743:377"] = 55, -- Apothecary Camp, Howling Fjord
			},
		},
		["743:377"] = {
			["Name"] = "Apothecary Camp, Howling Fjord",
			["Neighbors"] = {
				["845:267"] = 92, -- New Agamand, Howling Fjord
				["835:412"] = 60, -- Camp Winterhoof, Howling Fjord
				["698:452"] = 47, -- Conquest Hold, Grizzly Hills
				["594:451"] = 117, -- Venomspite, Dragonblight
				["738:292"] = 54, -- Kamagua, Howling Fjord
			},
		},
		["764:328"] = {
			["Name"] = "Westguard Keep, Howling Fjord",
			["Neighbors"] = {
				["875:278"] = 69, -- Valgarde Port, Howling Fjord
				["738:292"] = 51, -- Kamagua, Howling Fjord
				["877:400"] = 85, -- Fort Wildervar, Howling Fjord
				["596:481"] = 151, -- Wintergarde Keep, Dragonblight
				["729:464"] = 76, -- Amberpine Lodge, Grizzly Hills
			},
		},
		["784:614"] = {
			["Name"] = "Zim'Torga, Zul'Drak",
			["Neighbors"] = {
				["637:814"] = 154, -- Ulduar, The Storm Peaks
				["826:537"] = 56, -- Westfall Brigade, Grizzly Hills
				["724:598"] = 52, -- The Argent Stand, Zul'Drak
				["818:687"] = 53, -- Gundrak, Zul'Drak
				["733:745"] = 86, -- Camp Tunka'lo, The Storm Peaks
				["844:492"] = 82, -- Camp Oneqwah, Grizzly Hills
				["720:713"] = 85, -- Dun Niffelem, The Storm Peaks
			},
		},
		["818:687"] = {
			["Name"] = "Gundrak, Zul'Drak",
			["Neighbors"] = {
				["784:614"] = 55, -- Zim'Torga, Zul'Drak
			},
		},
		["826:537"] = {
			["Name"] = "Westfall Brigade, Grizzly Hills",
			["Neighbors"] = {
				["729:464"] = 78, -- Amberpine Lodge, Grizzly Hills
				["784:614"] = 72, -- Zim'Torga, Zul'Drak
				["724:598"] = 81, -- The Argent Stand, Zul'Drak
				["877:400"] = 85, -- Fort Wildervar, Howling Fjord
			},
		},
		["835:412"] = {
			["Name"] = "Camp Winterhoof, Howling Fjord",
			["Neighbors"] = {
				["743:377"] = 57, -- Apothecary Camp, Howling Fjord
				["844:492"] = 58, -- Camp Oneqwah, Grizzly Hills
				["845:267"] = 79, -- New Agamand, Howling Fjord
				["951:365"] = 73, -- Vengeance Landing, Howling Fjord
				["698:452"] = 93, -- Conquest Hold, Grizzly Hills
			},
		},
		["844:492"] = {
			["Name"] = "Camp Oneqwah, Grizzly Hills",
			["Neighbors"] = {
				["694:576"] = 92, -- Light's Breach, Zul'Drak
				["784:614"] = 92, -- Zim'Torga, Zul'Drak
				["951:365"] = 105, -- Vengeance Landing, Howling Fjord
				["724:598"] = 99, -- The Argent Stand, Zul'Drak
				["698:452"] = 97, -- Conquest Hold, Grizzly Hills
				["835:412"] = 49, -- Camp Winterhoof, Howling Fjord
			},
		},
		["845:267"] = {
			["Name"] = "New Agamand, Howling Fjord",
			["Neighbors"] = {
				["951:365"] = 80, -- Vengeance Landing, Howling Fjord
				["835:412"] = 80, -- Camp Winterhoof, Howling Fjord
				["743:377"] = 103, -- Apothecary Camp, Howling Fjord
				["738:292"] = 76, -- Kamagua, Howling Fjord
				["594:451"] = 191, -- Venomspite, Dragonblight
			},
		},
		["875:278"] = {
			["Name"] = "Valgarde Port, Howling Fjord",
			["Neighbors"] = {
				["877:400"] = 70, -- Fort Wildervar, Howling Fjord
				["738:292"] = 95, -- Kamagua, Howling Fjord
				["764:328"] = 69, -- Westguard Keep, Howling Fjord
			},
		},
		["877:400"] = {
			["Name"] = "Fort Wildervar, Howling Fjord",
			["Neighbors"] = {
				["826:537"] = 97, -- Westfall Brigade, Grizzly Hills
				["764:328"] = 80, -- Westguard Keep, Howling Fjord
				["875:278"] = 73, -- Valgarde Port, Howling Fjord
				["729:464"] = 96, -- Amberpine Lodge, Grizzly Hills
			},
		},
		["951:365"] = {
			["Name"] = "Vengeance Landing, Howling Fjord",
			["Neighbors"] = {
				["845:267"] = 88, -- New Agamand, Howling Fjord
				["835:412"] = 73, -- Camp Winterhoof, Howling Fjord
				["844:492"] = 104, -- Camp Oneqwah, Grizzly Hills
				["522:617"] = 303, -- Dalaran
			},
		},
	}
}