--[[
Name: LibTaxi-1.0
Revision: $Rev: 1 $
Author(s): sinus (sinus@sinpi.net)
Description: A library recording all player's currently known/unknown taxi routes.
Dependencies: None
License: Free for non-commercial use, except for Zygor Guides.
]]

local MAJOR_VERSION = "LibTaxi-1.0"
local MINOR_VERSION = tonumber(("$Revision: 1 $"):match("%d+"))

local addon,_L = ...
-- #AUTODOC_NAMESPACE prototype

local GAME_LOCALE = GetLocale()

do
	local LIB_MAJOR, LIB_MINOR = "LibTaxi-1.0", 1

	local Lib = LibStub:NewLibrary(LIB_MAJOR, LIB_MINOR)
	if not Lib then return end

	_L.Lib = Lib

	Lib.master = { }
	Lib.saved_tables = { }

	local Astrolabe = DongleStub("Astrolabe-ZGV")

	--Lib.TaxiNames_Local = nil
	--Lib.TaxiNames_English = nil

	-- Initialize localization. All taxis are stored as ENGLISH - lookups need pre-translation.
		if Lib.TaxiNames_Local then
			for en,lo in pairs(Lib.TaxiNames_Local) do if lo==1 then Lib.TaxiNames_Local[en]=en end end

			Lib.TaxiNames_English = {}
			for en,lo in pairs(Lib.TaxiNames_Local) do
				Lib.TaxiNames_English[lo]=en
			end

			local mt = { __index = function(t,k)  v=rawget(t,k)  if not v then print("|cffff4400Taxi |cffff8800"..k.."|r not translated to "..GetLocale()..", please report this to Zygor") return k elseif v==true then return k else return v end  end }
			setmetatable(Lib.TaxiNames_Local,mt)
			setmetatable(Lib.TaxiNames_English,mt)
		else
			local loc_stub = {}
			setmetatable(loc_stub,{ __index = function(t,k)  return k  end } )
			Lib.TaxiNames_Local = loc_stub
			Lib.TaxiNames_English = loc_stub
		end


	local minimap_exceptions = {
		["Trade District"] = "Stormwind",
		["The Great Forge"] = "Ironforge",
		["Terrace of Light"] = "Shattrath City",
		["The Stair of Destiny"] = "Hellfire Peninsula, The Dark Portal",
		["Valley of Strength"] = "Orgrimmar"
	}

	local ERR_NEWTAXIPATH=ERR_NEWTAXIPATH

	-- Add taxi to known.
	local function addTaxi(name)
		local taxi
		if type(name)=="string" then
			local eng = Lib.TaxiNames_English[name] or Lib.TaxiNames_English[name:gsub(", .*","")]
			if type(eng)=="string" then name=eng end
			--print(i..": "..TaxiNodeName(i).." = "..name)
			if not name then
				print("|cffff8888LibTaxi Error: Untranslated taxi "..name.."|r")
				return
			end
			taxi = Lib:FindTaxi(name)
		else
			taxi = name
		end

		if taxi then
			Lib.master[taxi.name]=true
			taxi.known=true
		else
			print("|cffff8888LibTaxi Error: Unknown taxi "..name.."|r")
		end
	end

	local function onEvent(this, event, arg1)
		if event == "ADDON_LOADED" and not Lib.loaded then
			Lib.loaded=true
		elseif event == "TAXIMAP_OPENED" then
			Lib:ScanTaxiMap()
		elseif event == "UI_INFO_MESSAGE" then
			if arg1==ERR_NEWTAXIPATH then
				-- discovery! cheating by zone name.
				local name=GetMinimapZoneText()
				name = Lib.TaxiNames_English[name]
				if not name then
					print("|cffff8888LibTaxi Error: Unknown zone "..GetMinimapZoneText().."|r")
					return
				end
				name = minimap_exceptions[name] or name
				Lib.master[name]=true
			end
		elseif event == "UPDATE_FACTION" then
			Lib:MarkKnownByLevels() --Only needs to be ran once after the faction's information has been made available at startup
			-- Ran again once QUEST_QUERY_COMPLETE returns. Ran in QuestTracking.lua
			Lib.frame:UnregisterEvent("UPDATE_FACTION")
		end
	end

	Lib.frame = CreateFrame("Frame", "LibTaxiFrame")
	Lib.frame:RegisterEvent("TAXIMAP_OPENED")
	Lib.frame:RegisterEvent("UI_INFO_MESSAGE")
	Lib.frame:RegisterEvent("ADDON_LOADED")
	Lib.frame:RegisterEvent("UPDATE_FACTION")
	Lib.frame:SetScript("OnEvent", onEvent)

	--- Gets all the known flight paths, in current locale.
	function Lib:GetTaxis()
		local paths = {}
		for fpath,t in pairs(Lib.master) do paths[Lib.TaxiNames_Local[fpath] or fpath]=t end
		return paths
	end

	--- Gets all the known flight paths, in English.
	function Lib:GetTaxisEnglish()
		local paths = {}
		for fpath,t in pairs(Lib.master) do paths[fpath]=t end
		return paths
	end

	local initialized_continents={}
	function Lib:Startup(newsave)
		if not ZGV.db.char.taxis_were_updated then ZGV.db.char.taxis={}   ZGV.db.char.taxis_were_updated=true  end -- reset after taxi system got updated.

		Lib.master=newsave
		Lib:InitializeTaxis()

		setmetatable(newsave,Lib.known_by_continent_mt)
		table.insert(Lib.saved_tables,newsave)
	end

	local function warn(message)
		local _, ret = pcall(error, message, 3)
		geterrorhandler()(ret)
	end

	-- return three-way node known status.
	-- true = known, obviously.  false = there's a marker indicating the continent is known, but the node is not.  nil = entirely unknown if known :P
	Lib.known_by_continent_mt = { __index=function(t,i)
			if rawget(t,i) then
				return true
			else
				local c = Lib.path2cont[i]
				if rawget(t,c) then
					return false
				else
					return nil
				end
			end
		end
	}
		
	Lib.MapIDsByName = {
	 ['Abyssal Depths']=614,  ['Ahn\'Qiraj']=766,  ['Ahn\'Qiraj: The Fallen Kingdom']=772,  ['Ahn\'kahet: The Old Kingdom']=522,  ['Alterac Valley']=401,  ['Arathi Basin']=461,  ['Arathi Highlands']=16,  ['Ashenvale']=43,  ['Auchenai Crypts']=722,  ['Azjol-Nerub']=533,  ['Azshara']=181,  ['Azuremyst Isle']=464,  ['Badlands']=17,  ['Baradin Hold']=752,  ['Black Temple']=796,  ['Blackfathom Deeps']=688,  ['Blackrock Caverns']=753,  ['Blackrock Depths']=704,  ['Blackrock Spire']=721,  ['Blackwing Descent']=754,  ['Blackwing Lair']=755,  ['Blade\'s Edge Mountains']=475,  ['Blasted Lands']=19,  ['Bloodmyst Isle']=476,  ['Borean Tundra']=486,  ['Burning Steppes']=29,  ['Crystalsong Forest']=510,  ['Dalaran']=504,  ['Darkshore']=42,  ['Darkmoon Island']=823,  ['Darnassus']=381,  ['Deadwind Pass']=32,  ['Deepholm']=640,  ['Desolace']=101,  ['Dire Maul']=699,  ['Dragon Soul']=824,  ['Dragonblight']=488,  ['Drak\'Tharon Keep']=534,  ['Dun Morogh']=27,  ['Durotar']=4,  ['Duskwood']=34,  ['Dustwallow Marsh']=141,  ['Eastern Plaguelands']=23,  ['Elwynn Forest']=30,  ['End Time']=820,  ['Eversong Woods']=462,  ['Eye of the Storm']=482,  ['Felwood']=182,  ['Feralas']=121,  ['Firelands']=800,  ['Ghostlands']=463,  ['Gilneas City']=611,  ['Gilneas']={539,545,678,679},  ['Gnomeregan']=691,  ['Grim Batol']=757,  ['Grizzly Hills']=490,  ['Gruul\'s Lair']=776,  ['Gundrak']=530,  ['Halls of Lightning']=525,  ['Halls of Origination']=759,  ['Halls of Reflection']=603,  ['Halls of Stone']=526,  ['Hellfire Peninsula']=465,  ['Hellfire Ramparts']=797,  ['Hillsbrad Foothills']=24,  ['Howling Fjord']=491,  ['Hour of Twilight']=819,  ['Hrothgar\'s Landing']=541,  ['Hyjal Summit']=775,  ['Icecrown Citadel']=604,  ['Icecrown']=492,  ['Ironforge']=341,  ['Isle of Conquest']=540,  ['Isle of Quel\'Danas']=499,  ['Karazhan']=799,  ['Kelp\'thar Forest']=610,  ['Kezan']=605,  ['Loch Modan']=35,  ['Lost City of the Tol\'vir']=747,  ['Magisters\' Terrace']=798,  ['Magtheridon\'s Lair']=779,  ['Mana-Tombs']=732,  ['Maraudon']=750,  ['Molten Core']=696,  ['Molten Front']=795,  ['Moonglade']=241,  ['Mount Hyjal']={606,683},  ['Mulgore']=9,  ['Nagrand']=477,  ['Naxxramas']=535,  ['Netherstorm']=479,  ['Northern Barrens']=11,  ['Northern Stranglethorn']=37,  ['Old Hillsbrad Foothills']=734,  ['Onyxia\'s Lair']=718,  ['Orgrimmar']=321,  ['Pit of Saron']=602,  ['Plaguelands: The Scarlet Enclave']=502,  ['Ragefire Chasm']=680,  ['Razorfen Downs']=760,  ['Razorfen Kraul']=761,  ['Redridge Mountains']=36,  ['Ruins of Ahn\'Qiraj']=717,  ['Ruins of Gilneas City']=685,  ['Ruins of Gilneas']=684,  ['Scarlet Monastery']=762,  ['Scholomance']=763,  ['Searing Gorge']=28,  ['Serpentshrine Cavern']=780,  ['Sethekk Halls']=723,  ['Shadow Labyrinth']=724,  ['Shadowfang Keep']=764,  ['Shadowmoon Valley']=473,  ['Shattrath City']=481,  ['Shimmering Expanse']=615,  ['Sholazar Basin']=493,  ['Silithus']=261,  ['Silvermoon City']=480,  ['Silverpine Forest']=21,  ['Southern Barrens']=607,  ['Stonetalon Mountains']=81,  ['Stormwind City']=301,  ['Strand of the Ancients']=512,  ['Stranglethorn Vale']=689,  ['Stratholme']=765,  ['Sunwell Plateau']=789,  ['Swamp of Sorrows']=38,  ['Tanaris']=161,  ['Teldrassil']=41,  ['Tempest Keep']=782,  ['Terokkar Forest']=478,  ['The Arcatraz']=731,  ['The Bastion of Twilight']=758,  ['The Battle for Gilneas (Old City Map)']=677,  ['The Battle for Gilneas']=736,  ['The Black Morass']=733,  ['The Blood Furnace']=725,  ['The Botanica']=729,  ['The Cape of Stranglethorn']=673,  ['The Culling of Stratholme']=521,  ['The Deadmines']=756,  ['The Exodar']=471,  ['The Eye of Eternity']=527,  ['The Forge of Souls']=601,  ['The Hinterlands']=26,  ['The Lost Isles']={544,681,682},  ['The Maelstrom']={737,751},  ['The Mechanar']=730,  ['The Nexus']={520,803},  ['The Obsidian Sanctum']=531,  ['The Oculus']=528,  ['The Ruby Sanctum']=609,  ['The Shattered Halls']=710,  ['The Slave Pens']=728,  ['The Steamvault']=727,  ['The Stockade']=690,  ['The Stonecore']=768,  ['The Storm Peaks']=495,  ['The Temple of Atal\'Hakkar']=687,  ['The Underbog']=726,  ['The Violet Hold']=536,  ['The Vortex Pinnacle']=769,  ['Thousand Needles']=61,  ['Throne of the Four Winds']=773,  ['Throne of the Tides']=767,  ['Thunder Bluff']=362,  ['Tirisfal Glades']=20,  ['Tol Barad Peninsula']=709,  ['Tol Barad']=708,  ['Trial of the Champion']=542,  ['Trial of the Crusader']=543,  ['Twilight Highlands']={700,770},  ['Twin Peaks']=626,  ['Uldaman']=692,  ['Ulduar']=529,  ['Uldum']={720,748},  ['Un\'Goro Crater']=201,  ['Undercity']=382,  ['Utgarde Keep']=523,  ['Utgarde Pinnacle']=524,  ['Vashj\'ir']=613,  ['Vault of Archavon']=532,  ['Wailing Caverns']=749,  ['Warsong Gulch']=443,  ['Well of Eternity']=816,  ['Western Plaguelands']=22,  ['Westfall']=39,  ['Wetlands']=40,  ['Wintergrasp']=501,  ['Winterspring']=281,  ['Zangarmarsh']=467,  ['Zul\'Aman']=781,  ['Zul\'Drak']=496,  ['Zul\'Farrak']=686,  ['Zul\'Gurub']={697,793},
	}

	Lib.path2cont = {}

	Lib.taxipoints = {
		[1]={
			['Ashenvale']={
				{name="Astranaar",faction="A",npc="Daelyshia",npcid=4267,x=34.4,y=48.0},
				{name="Blackfathom Camp",faction="A",npc="Solais",npcid=34374,x=18.1,y=20.6},
				{name="Forest Song",faction="A",npc="Suralais Farwind",npcid=22935,x=85.1,y=43.5},
				{name="Hellscream's Watch",faction="H",npc="Thraka",npcid=34429,x=38.1,y=42.3},
				{name="Silverwind Refuge",faction="H",npc="Wind Tamer Shoshok",npcid=34943,x=49.3,y=65.3},
				{name="Splintertree Post",faction="H",npc="Vhulgra",npcid=12616,x=73.3,y=61.7},
				{name="Stardust Spire",faction="A",npc="Myre Moonglide",npcid=34378,x=35.0,y=72.1},
				{name="The Mor'sham Ramparts",faction="H",npc="Gort Goreflight",npcid=34927,x=41.98,y=15.87},
				{name="Zoram'gar Outpost",faction="H",npc="Andruk",npcid=11901,x=11.2,y=34.4},
			},
			['Azshara']={
				{name="Bilgewater Harbor",faction="H",npc="Kroum",npcid=8610,x=52.9,y=49.9},
				{name="Northern Rocketway",faction="H",npc="Blitz Blastospazz",npcid=43328,x=66.5,y=20.9},
				{name="Southern Rocketway",faction="H",npc="Friz Groundspin",npcid=37005,x=51.5,y=74.3},
				{name="Valormok",faction="H",npc="Kroum",npcid=36728,x=14.4,y=65.0},
			},
			['Azuremyst Isle']={
				{name="Azure Watch",faction="A",npc="Zaldaan",npcid=43991,x=49.7,y=49.1},
			},
			['Bloodmyst Isle']={
				{name="Blood Watch",faction="A",npc="Laando",npcid=17554,x=57.9,y=53.9},
			},
			['Darkshore']={
				{name="Grove of the Ancients",faction="A",npc="Delanea",npcid=33253,x=44.4,y=75.5},
				{name="Lor'danel",faction="A",npc="Teldira Moonfeather",npcid=3841,x=51.7,y=17.6},
			},
			['Darnassus']={
				{name="Darnassus",faction="A",npc="Leora",npcid=40552,x=36.6,y=47.8},
			},
			['Desolace']={
				{name="Ethel Rethor",faction="B",npc="Korrah's Hippogryph",npcid=35562,x=39.07,y=26.94},
				{name="Furien's Post",faction="H",npc="Narimar",npcid=35315,x=44.27,y=29.67},
				{name="Karnum's Glade",faction="B",npc="Lastrea Greengale",npcid=35478,x=57.72,y=49.75},
				{name="Nijel's Point",faction="A",npc="Baritanas Skyriver",npcid=6706,x=64.7,y=10.6},
				{name="Shadowprey Village",faction="H",npc="Thalon",npcid=6726,x=21.60,y=74.13},
				{name="Thargad's Camp",faction="A",npc="Moira Steelwing",npcid=35481,x=36.8,y=71.7},
				{name="Thunk's Abode",faction="B",npc="Thunk's Wyvern",npcid=35556,x=70.66,y=32.89},
			},
			['Durotar']={
				{name="Razor Hill",faction="H",npc="Burok",npcid=41140,x=53.1,y=43.6},
				{name="Sen'jin Village",faction="H",npc="Handler Marnlek",npcid=41142,x=55.4,y=73.3},
			},
			['Dustwallow Marsh']={
				{name="Brackenwall Village",faction="H",npc="Shardi",npcid=11899,x=35.6,y=31.8},
				{name="Mudsprocket",faction="B",npc="Dyslix Silvergrub",npcid=40358,x=42.8,y=72.4},
				{name="Theramore",faction="A",npc="Baldruc",npcid=4321,x=67.5,y=51.3},
			},
			['Felwood']={
				{name="Emerald Sanctuary",faction="B",npc="Gorrim",npcid=22931,x=51.5,y=80.9},
				{name="Talonbranch Glade",faction="A",npc="Mishellena",npcid=12578,x=60.5,y=25.3},
				{name="Whisperwind Grove",faction="B",npc="Hanah Southsong",npcid=43073,x=43.6,y=28.7},
				{name="Wildheart Point",faction="B",npc="Chyella Hushglade",npcid=43079,x=44.3,y=61.9},
			},
			['Feralas']={
				{name="Camp Ataya",faction="H",npc="Tono",npcid=40473,x=41.54,y=15.46},
				{name="Camp Mojache",faction="H",npc="Shyn",npcid=39898,x=75.4,y=44.3},
				{name="Dreamer's Rest",faction="A",npc="Selor",npcid=40966,x=50.2,y=16.7},
				{name="Feathermoon",faction="A",npc="Irela Moonfeather",npcid=41383,x=46.8,y=45.3},
				{name="Shadebough",faction="A",npc="Seyala Nightwisp",npcid=40367,x=77.3,y=56.8},
				{name="Stonemaul Hold",faction="H",npc="Mergek",npcid=41605,x=51.00,y=48.42},
				{name="Tower of Estulan",faction="A",npc=" Aryenda",npcid=41580,x=57.1,y=54.0},
			},
			['Moonglade']={
				{name="Moonglade",faction="A",npc="Sindrayl",npcid=10897,x=48.1,y=67.3},
				{name="Moonglade",faction="H",npc="Faustron",npcid=12740,x=32.1,y=66.6},
				{name="Nighthaven",faction="H",class="Druid",npc="Bunthen Plainswind",npcid=11798,x=44.2,y=45.6},
				{name="Nighthaven",faction="A",class="Druid",npc="Silva Fil'naveth",npcid=11800,x=44.2,y=45.8},
			},
			['Mount Hyjal']={
				{name="Gates of Sothann",faction="B",quest=25608,npc="Althera",npcid=43549,x=71.6,y=75.3},
				{name="Grove of Aessina",faction="B",npc="Elizil Wintermoth",npcid=41860,x=19.6,y=36.4},
				{name="Nordrassil",faction="B",npc="Fayran Elthas",npcid=41861,x=62.1,y=21.6},
				{name="Sanctuary of Malorne",faction="B",quest=25372,npc="Ranela Featherglen",npcid=54393,x=27.75,y=63.64},
				{name="Shrine of Aviana",faction="B",npc="Dinorae Swiftfeather",npcid=50084,x=41.2,y=42.6},
			},
			['Mulgore']={
				{name="Bloodhoof Village",faction="H",npc="Tak",npcid=40809,x=47.4,y=58.6},
			},
			['Northern Barrens']={
				{name="Nozzlepot's Outpost",faction="H",npc="Gazrix",npcid=40558,x=62.31,y=17.12},
				{name="Ratchet",faction="B",npc="Bragok",npcid=16227,x=69.1,y=70.7},
				{name="The Crossroads",faction="H",npc="Devrak",npcid=3615,x=48.6,y=58.6},
			},
			['Orgrimmar']={
				{name="Orgrimmar",faction="H",npc="Doras",npcid=3310,x=49.7,y=59.2},
			},
			['Silithus']={
				{name="Cenarion Hold",faction="A",npc="Cloud Skydancer",npcid=15177,x=54.4,y=32.7},
				{name="Cenarion Hold",faction="H",npc="Runk Windtamer",npcid=15178,x=52.8,y=34.6},
			},
			['Southern Barrens']={
				{name="Desolation Hold",faction="H",npc="Crador",npcid=39330,x=41.24,y=70.76},
				{name="Fort Triumph",faction="A",npc="Steve Stevenson",npcid=39211,x=49.2,y=67.8},
				{name="Honor's Stand",faction="A",npc="John Johnson",npcid=39210,x=38.9,y=10.9},
				{name="Hunter's Hill",faction="H",npc="Unega",npcid=39340,x=39.79,y=20.26},
				{name="Northwatch Hold",faction="A",npc="Bill Williamson",npcid=39212,x=66.4,y=47.1},
				{name="Vendetta Point",faction="H",npc="Lognah",npcid=52060,x=41.55,y=47.60},
			},
			['Stonetalon Mountains']={
				{name="Farwatcher's Glen",faction="A",npc="Ceyora",npcid=35138,x=32.0,y=61.8},
				{name="Mirkfallon Post",faction="A",npc="Fiora Moonsoar",npcid=41240,x=48.6,y=51.5},
				{name="Northwatch Expedition",faction="A",npc="Kaluna Songflight",npcid=35136,x=70.9,y=80.6},
				{name="Thal'darah Overlook",faction="A",npc="Teloren",npcid=4407,x=40.1,y=32.0},
				{name="Windshear Hold",faction="A",npc="Allana Swiftglide",npcid=35137,x=58.8,y=54.3},
				{name="Cliffwalker Post",faction="H",npc="Orna Skywatcher",npcid=35141,x=45.11,y=30.87},
				{name="Krom'gar Fortress",faction="H",npc="Kormal the Swift",npcid=35140,x=66.5,y=62.8},
				{name="Sun Rock Retreat",faction="H",npc="Tharm",npcid=4312,x=48.48,y=61.95},
				{name="The Sludgewerks",faction="H",npc="Flok",npcid=41246,x=53.87,y=40.12},
			},
			['Tanaris']={
				{name="Bootlegger Outpost",faction="B",npc="Slick Dropdip",npcid=41214,x=55.9,y=60.6},
				{name="Dawnrise Expedition",faction="H",npc="Raina Sunglide",npcid=41215,x=33.3,y=77.4},
				{name="Gadgetzan",faction="A",npc="Bera Stonehammer",npcid=7823,x=51.4,y=29.5},
				{name="Gadgetzan",faction="H",npc="Bulkrek Ragefist",npcid=7824,x=52.0,y=27.6},
				{name="Gunstan's Dig",faction="A",npc="Thurda",npcid=40827,x=40.0,y=77.5},
				{name="Southmoon Ruins",faction="A",npc="Thurda",npcid=40827,x=40.0,y=77.5},
			},
			['Teldrassil']={
				{name="Dolanaar",faction="A",npc="Fidelio",npcid=40553,x=55.5,y=50.4},
				{name="Rut'theran Village",faction="A",npc="Vesprystus",npcid=3838,x=55.4,y=88.4},
			},
			['The Exodar']={
				{name="The Exodar",faction="A",npc="Stephanos",npcid=17555,x=54.5,y=36.3},
			},
			['Thousand Needles']={
				{name="Fizzle & Pozzik's Speedbarge",faction="B",npc="Tilly Topspin",npcid=40768,x=79.2,y=72.0},
			},
			['Thunder Bluff']={
				{name="Thunder Bluff",faction="H",npc="Tal",npcid=2995,x=46.8,y=49.8},
			},
			['Uldum']={
				{name="Oasis of Vir'sar",faction="B",npc="Jock Lindsey",npcid=48274,x=26.6,y=8.4},
				{name="Ramkahen",faction="B",npc="Kurzel",npcid=48275,x=56.2,y=33.6},
				{name="Schnottz's Landing",faction="B",npc="Evax Oilspark",npcid=48273,x=22.3,y=64.9},
			},
			['Un\'Goro Crater']={
				{name="Marshal's Stand",faction="B",npc="Gryfe",npcid=10583,x=56.0,y=64.2},
				{name="Mossy Pile",faction="B",npc="Flizzy Coilspanner",npcid=39175,x=44.1,y=40.3},
			},
			['Winterspring']={
				{name="Everlook",faction="A",npc="Maethrya",npcid=11138,x=61.0,y=48.6},
				{name="Everlook",faction="H",npc="Yugrek",npcid=11139,x=58.8,y=48.3},
			},
		},
		[2]={
			['Abyssal Depths']={
				{name="Darkbreak Cove",faction="A",npc="Swift Seahorse",npcid=40866,x=56.9,y=75.5,taxioperator="seahorse"},
				{name="Tenebrous Cavern",faction="H",npc="Swift Seahorse",npcid=40873,x=53.9,y=59.6,taxioperator="seahorse"},
			},
			['Arathi Highlands']={
				{name="Galen's Fall",faction="H",npc="Rhoda Bowers",npcid=43104,x=13.3,y=34.8},
				{name="Hammerfall",faction="H",npc="Urda",npcid=2851,x=68.2,y=33.4},
				{name="Refuge Pointe",faction="A",npc="Cedrik Prose",npcid=2835,x=39.9,y=47.3},
			},
			['Badlands']={
				{name="Bloodwatcher Point",faction="H",npc="Selara",npcid=44408,x=52.4,y=50.8},
				{name="Dragon's Mouth",faction="A",npc="Jake Badlands",npcid=44410,x=21.7,y=57.8},
				{name="Dustwind Dig",faction="A",npc="Nancy Skybrew",npcid=44409,x=49.0,y=36.2},
				{name="Fuselight",faction="B",npc="Mixi Sweetride",npcid=44407,x=64.3,y=35.0},
				{name="New Kargath",faction="H",npc="Gorrik",npcid=2861,x=17.2,y=40.0},
			},
			['Blasted Lands']={
				{name="Dreadmaul Hold",faction="H",npc="Preda",npcid=43121,x=43.7,y=14.3},
				{name="Nethergarde Keep",faction="A",npc="Alexandra Constantine",npcid=8609,x=61.3,y=21.6},
				{name="Sunveil Excursion",faction="H",npc="Salena",npcid=43114,x=50.9,y=72.9},
				{name="Surwich",faction="A",npc="Graham McAllister",npcid=43107,x=47.1,y=89.3},
			},
			['Burning Steppes']={
				{name="Chiselgrip",faction="B",npc="Grimly Singefeather",npcid=48321,x=46.2,y=41.8},
				{name="Flame Crest",faction="A",npc="Vahgruk",npcid=13177,x=54.1,y=24.3},
				{name="Flame Crest",faction="H",npc="Vahgruk",npcid=13177,x=54.1,y=24.3},
				{name="Flamestar Post",faction="B",npc="Hans Oreflight",npcid=48318,x=17.79,y=52.75},
				{name="Morgan's Vigil",faction="A",npc="Borgus Stoutarm",npcid=2299,x=72.1,y=65.7},
			},
			['Dun Morogh']={
				{name="Gol'Bolar Quarry",faction="A",npc="Dominic Galebeard",npcid=43702,x=75.9,y=54.4},
				{name="Kharanos",faction="A",npc="Brolan Galebeard",npcid=43701,x=53.8,y=52.8},
			},
			['Duskwood']={
				{name="Darkshire",faction="A",npc="Felicia Maline",npcid=2409,x=77.5,y=44.3},
				{name="Raven Hill",faction="A",npc="John Shelby",npcid=43697,x=21.1,y=56.4},
			},
			['Eastern Plaguelands']={
				{name="Acherus: The Ebon Hold",faction="B",class="Death Knight", npc="Grimwing",npcid=29480,x=83.8,y=50.3},
				{name="Light's Hope Chapel",faction="H",npc="Georgia",npcid=12636,x=75.8,y=53.3},
				{name="Light's Hope Chapel",faction="A",npc="Khaelyn Steelwing",npcid=12617,x=75.84,y=53.41},
				{name="Eastwall Tower",faction="B",npc="Richard Trueflight",npcid=44230,x=61.6,y=43.9},
				{name="Northpass Tower",faction="B",npc="Grayson Ironwing",npcid=28621,x=51.4,y=21.3},
				{name="Light's Shield Tower",faction="B",npc="Devon Manning",npcid=44231,x=52.8,y=53.6},
				{name="Crown Guard Tower",faction="B",npc="Janice Myers",npcid=44232,x=34.9,y=67.9},
				{name="Plaguewood Tower",faction="B",npc="William Kielar Jr.",npcid=44233,x=18.5,y=27.4},
				{name="Thondroril River",faction="B",npc="Frax Bucketdrop",npcid=37888,x=10.1,y=65.7},
			},
			['Elwynn Forest']={
				{name="Goldshire",faction="A",npc="Bartlett the Brave",npcid=42983,x=41.7,y=64.6},
				{name="Eastvale Logging Camp",faction="A",npc="Goss the Swift",npcid=43000,x=81.8,y=66.6},
			},
			['Eversong Woods']={
				{name="Fairbreeze Village",faction="H",npc="Skymaster Brightdawn",npcid=44036,x=43.9,y=70.0},
				{name="Silvermoon City",faction="H",npc="Skymistress Gloaming",npcid=16192,x=54.4,y=50.7},
			},
			['Ghostlands']={
				{name="Tranquillien",faction="H",npc="Skymaster Sunwing",npcid=16189,x=45.4,y=30.5},
				{name="Zul'Aman",faction="B",npc="Kiz Coilspanner",npcid=24851,x=74.8,y=67.2},
			},
			['Hillsbrad Foothills']={
				{name="Eastpoint Tower",faction="H",npc="Darren Longfellow",npcid=47661,x=59.62,y=63.25},
				{name="Ruins of Southshore",faction="H",npc="Darla Harris",npcid=47644,x=49.0,y=66.2},
				{name="Southpoint Gate",faction="H",npc="Pamela Stutzka",npcid=47655,x=29.1,y=64.4},
				{name="Strahnbrad",faction="H",npc="Phillip Harding",npcid=47665,x=58.2,y=26.5},
				{name="Tarren Mill",faction="H",npc="Zarise",npcid=2389,x=56.1,y=46.1},
			},
			['Ironforge']={
				{name="Ironforge",faction="A",npc="Gryth Thurden",npcid=1573,x=55.5,y=47.8},
			},
			['Isle of Quel\'Danas']={
				{name="Shattered Sun Staging Area",faction="B",npc="Ohura",npcid=26560,x=48.4,y=25.1}, -- Sun's Reach Harbor ?
			},
			['Kelp\'thar Forest']={
				{name="Smuggler's Scar",faction="B",npc="Swift Seahorse",npcid=40852,x=56.1,y=31.2,taxioperator="seahorse"},
				{name="Kelp'thar Forest",faction="A",npc="Swift Seahorse",npcid=43287,x=42.4,y=66.2,taxioperator="seahorse"},
				{name="Kelp'that Forest",faction="H",npc="Swift Seahorse",npcid=43216,x=49.3,y=87.9,taxioperator="seahorse"},
				{name="Stygian Bounty",faction="H",npc="Brogdul",npcid=43225,x=64.8,y=68.0},
			},
			['Loch Modan']={
				{name="Farstrider Lodge",faction="A",npc="Eeryven Grayer",npcid=41332,x=81.9,y=64.1},
				{name="Thelsamar",faction="A",npc="Thorgrum Borrelson",npcid=1572,x=34.0,y=50.9},
			},
			['Northern Stranglethorn']={
				{name="Bambala",faction="H",npc="Raskha",npcid=43052,x=62.4,y=39.3},
				{name="Fort Livingston",faction="A",npc="Robert Rhodes",npcid=43042,x=52.6,y=66.1},
				{name="Grom'gol Base Camp",faction="H",npc="Thysta",npcid=1387,x=39.0,y=51.3},
				{name="Rebel Camp",faction="A",npc="James Stillair",npcid=43045,x=47.9,y=11.9},
			},
			['Redridge Mountains']={
				{name="Camp Everstill",faction="A",npc="Arlen Marsters",npcid=43371,x=52.9,y=54.6},
				{name="Lakeshire",faction="A",npc="Ariena Stormfeather",npcid=931,x=29.4,y=53.8},
				{name="Shalewind Canyon",faction="A",npc="Nora Baldwin",npcid=43072,x=78.0,y=65.9},
			},
			['Searing Gorge']={
				{name="Iron Summit",faction="B",npc="Doug Deepdown",npcid=47927,x=41.1,y=68.8},
				{name="Thorium Point",faction="A",npc="Lanie Reed",npcid=2941,x=37.9,y=30.9},
				{name="Thorium Point",faction="H",npc="Grisha",npcid=3305,x=34.8,y=30.9},
			},
			['Shimmering Expanse']={
				{name="Sandy Beach",faction="A",npc="Francis Greene",npcid=43290,x=57.0,y=17.0},
				{name="Silver Tide Hollow",faction="B",npc="Swift Seahorse",npcid=40851,x=49.5,y=41.2,taxioperator="seahorse"},
				{name="Tranquil Wash",faction="A",npc="Swift Seahorse",npcid=40867,x=48.6,y=57.4,taxioperator="seahorse"},
				{name="Voldrin's Hold",faction="A",quest=26005,npc="Salty McTavish",npcid=43295,x=69.4,y=75.2},
				{name="Voldrin's Hold",faction="A",quest=26005,npc="Swift Seahorse",npcid=43289,x=57.1,y=75.2,taxioperator="seahorse"},
				{name="Stygian Bounty",faction="H",quest=26006,npc="Brogdul",npcid=43225,x=49.5,y=65.6},
				{name="Stygian Bounty",faction="H",quest=26006,npc="Swift Seahorse",npcid=40871,x=50.8,y=63.4,taxioperator="seahorse"},
				{name="Sandy Beach",faction="H",npc="Briglar",npcid=43220,x=61.0,y=28.4},
				{name="Legion's Rest",faction="H",npc="Swift Seahorse",npcid=40871,x=50.8,y=63.5,taxioperator="seahorse"},
			},
			['Silverpine Forest']={
				{name="The Forsaken Front",faction="H",npc="Steven Stutzka",npcid=46552,x=50.8,y=63.6},
				{name="The Sepulcher",faction="H",npc="Karos Razok",npcid=2226,x=45.4,y=42.5},
				{name="Forsaken Rear Guard",faction="H",npc="Franny Mertz",npcid=50463,x=45.9,y=21.9},
				{name="Forsaken High Command",quest=26965,faction="H",npc="Bat Handler Maggotbreath",npcid=44825,x=57.9,y=8.7},
			},
			['Stormwind City']={
				{name="Stormwind",faction="A",npc="Dungar Longdrink",npcid=352,x=70.9,y=72.5},
			},
			['Swamp of Sorrows']={
				{name="Bogpaddle",faction="B",npc="Skeezie",npcid=43086,x=72.0,y=12.0},
				{name="Marshtide Watch",faction="A",npc="Paola Baldwin",npcid=43087,x=70.0,y=38.6},
				{name="Stonard",faction="H",npc="Breyk",npcid=6026,x=47.8,y=55.2},
				{name="The Harborage",faction="A",npc="Yedrin",npcid=43088,x=30.8,y=34.6},
			},
			['The Cape of Stranglethorn']={
				{name="Booty Bay",faction="A",npc="Gyll",npcid=2859,x=41.7,y=74.5},
				{name="Booty Bay",faction="H",npc="Gringer",npcid=2858,x=40.6,y=73.4},
				{name="Explorers' League Digsite",faction="A",npc="Colin Swifthammer",npcid=43043,x=55.7,y=41.2},
				{name="Hardwrench Hideaway",faction="H",npc="Hizzle",npcid=43053,x=35.2,y=29.4},
			},
			['The Hinterlands']={
				{name="Aerie Peak",faction="A",npc="Guthrum Thunderfist",npcid=8018,x=11.1,y=46.3},
				{name="Hiri'watha Research Station",faction="H",npc="Kellen Kuhn",npcid=43573,x=32.5,y=58.1},
				{name="Revantusk Village",faction="H",npc="Gorkas",npcid=4314,x=81.7,y=81.8},
				{name="Stormfeather Outpost",faction="A",npc="Brock Rockbeard",npcid=43570,x=65.8,y=44.9},
			},
			['Tirisfal Glades']={
				{name="Brill",faction="H",npc="Anette Williams",npcid=43124,x=58.8,y=51.9},
				{name="The Bulwark",faction="H",npc="Timothy Cunningham",npcid=37915,x=83.6,y=70.0},
				--{name="Forsaken High Command",faction="H",npc="Bat Handler Maggotbreath",npcid=44825,x=57.9,y=8.7},
				--{name="Forsaken Rear Guard",faction="H",npc="Franny Mertz",npcid=50463,x=45.9,y=21.9},
				--{name="The Sepulcher",faction="H",npc="Karos Razok",npcid=2226,x=45.4,y=42.5},
				--{name="The Forsaken Front",faction="H",npc="Steven Stutzka",npcid=46552,x=50.9,y=63.6},
			},
			['Twilight Highlands']={
				{name="Bloodgulch",faction="H",npc="Bramok Gorewing",npcid=47156,x=54.1,y=42.2},
				{name="Crushblow",faction="H",npc="Tokrog",npcid=47116,x=45.8,y=76.2},
				{name="Dragonmaw Port",quest=26830,faction="H",npc="Gorthul",npcid=47174,x=73.8,y=52.8},
				{name="Firebeard's Patrol",faction="A",npc="Farstad Stonegrip",npcid=47147,x=60.4,y=57.6},
				{name="Highbank",faction="A",quest=28598,npc="Glenn Arbuckle",npcid=47119,x=81.6,y=77.0},
				{name="Kirthaven",faction="A",npc="Shaina Talonheart",npcid=47155,x=56.8,y=15.1},
				{name="The Gullet",faction="H",npc="San'shigo",npcid=47133,x=36.9,y=38.0},
				{name="The Krazzworks",faction="H",npc="Harpo Boltknuckle",npcid=47061,x=75.3,y=17.8},
				{name="Thundermar",faction="A",npc="Doran Talonheart",npcid=47154,x=48.5,y=28.1},
				{name="Vermillion Redoubt",faction="N",quest=27504,npc="Aquinastrasz",npcid=47121,x=28.6,y=24.9},
				{name="Victor's Point",faction="A",npc="Desmond Chadsworth",npcid=47118,x=43.9,y=57.3},
			},
			['Undercity']={
				{name="Trade Quarter",faction="H",npc="Michael Garrett",npcid=4551,x=63.3,y=48.6},
			},
			['Western Plaguelands']={
				{name="The Menders' Stead",faction="B",npc="Marge Heffman",npcid=46011,x=50.5,y=52.2},
				{name="Andorhal",faction="H",npc="Rhonda Molver",npcid=46004,x=46.5,y=64.7},
				{name="Hearthglen",faction="B",npc="William Henderson",npcid=47875,x=44.7,y=18.5},
				{name="Chillwind Camp",faction="A",npc="Bibilfaz Featherwhistle",npcid=12596,x=42.9,y=85.1},
				{name="Andorhal",faction="A",quest=27206,npc="Ginny Goodwin",npcid=46006,x=39.4,y=69.5},
			},
			['Westfall']={
				{name="Sentinel Hill",faction="A",npc="Thor",npcid=523,x=56.6,y=49.4},
				{name="Moonbrook",faction="A",npc="Tina Skyden",npcid=42426,x=42.1,y=63.3},
				{name="Furlbrow's Pumpkin Farm",faction="A",npc="Hoboair",npcid=42406,x=49.8,y=18.7},
			},
			['Wetlands']={
				{name="Dun Modr",faction="A",npc="Caleb Baelor",npcid=41325,x=49.9,y=18.6},
				{name="Greenwarden's Grove",faction="A",npc="Halana",npcid=41322,x=56.3,y=41.9},
				{name="Menethil Harbor",faction="A",npc="Shellei Brondir",npcid=1571,x=9.5,y=59.6},
				{name="Slabchisel's Survey",faction="A",npc="Elgin Baelor",npcid=41321,x=56.9,y=71.1},
				{name="Whelgar's Retreat",faction="A",npc="Damon Baelor",npcid=41323,x=38.8,y=39.0},
			},
		},
		[3]={
			['Blade\'s Edge Mountains']={
				{name="Evergrove",faction="B",npc="Fhyn Leafshadow",npcid=22216,x=61.7,y=39.6},
				{name="Skyguard Outpost",faction="B",factionid=1031,npc="Skyguard Handler Irena",npcid=23413,x=28.2,y=52.0},
				{name="Sylvanaar",faction="A",npc="Amerun Leafshade",npcid=18937,x=37.8,y=61.4},
				{name="Thunderlord Stronghold",faction="H",npc="Unoke Tenderhoof",npcid=18953,x=52.0,y=54.1},
				{name="Toshley's Station",faction="A",npc="Rip Pedalslam",npcid=21107,x=61.2,y=70.4},
			},
			['Hellfire Peninsula']={
				{name="Falcon Watch",faction="H",npc="Innalia",npcid=18942,x=27.8,y=60.0},
				{name="Honor Hold",faction="A",npc="Flightmaster Krill Bitterhue",npcid=16822,x=54.7,y=62.4},
				{name="Shatter Point",faction="A",npc="Runetog Wildhammer",npcid=20234,x=78.4,y=34.9},
				{name="Spinebreaker Ridge",faction="H",npc="Amilya Airheart",npcid=19558,x=61.7,y=81.2},
				{name="Temple of Telhamat",faction="A",npc="Kuma",npcid=18785,x=25.2,y=37.2},
				{name="Hellfire Peninsula, The Dark Portal",faction="A",npc="Amish Wildhammer",npcid=18931,x=87.4,y=52.4},
				{name="Hellfire Peninsula, The Dark Portal",faction="H",npc="Vlagga Freyfeather",npcid=18930,x=87.3,y=48.1},
				{name="Thrallmar",faction="H",npc="Barley",npcid=16587,x=56.3,y=36.2},
			},
			['Nagrand']={
				{name="Garadar",faction="H",npc="Gursha",npcid=18808,x=57.2,y=35.3},
				{name="Telaar",faction="A",npc="Furgu",npcid=18789,x=54.2,y=75.1},
			},
			['Netherstorm']={
				{name="Area 52",faction="B",npc="Krexcil",npcid=18938,x=33.8,y=64.0},
				{name="Cosmowrench",faction="B",npc="Harpax",npcid=20515,x=65.2,y=66.8},
				{name="The Stormspire",faction="B",npc="Grennik",npcid=19583,x=45.3,y=34.9},
			},
			['Shadowmoon Valley']={
				{name="Altar of Sha'tar",faction="B",factionid=932,npc="Maddix",npcid=19581,x=63.3,y=30.4},
				{name="Sanctum of the Stars",faction="B",factionid=934,npc="Alieshor",npcid=21766,x=56.3,y=57.8},
				{name="Shadowmoon Village",faction="H",npc="Drek'Gol",npcid=19317,x=30.3,y=29.2},
				{name="Wildhammer Stronghold",faction="A",npc="Brubeck Stormfoot",npcid=18939,x=37.6,y=55.5},
			},
			['Shattrath City']={
				{name="Shattrath",faction="B",npc="Nutral",npcid=18940,x=64.1,y=41.1},
			},
			['Terokkar Forest']={
				{name="Allerian Stronghold",faction="A",npc="Furnan Skysoar",npcid=18809,x=59.4,y=55.4},
				{name="Skyguard Outpost",faction="B",factionid=1031,npc="Skyguard Handler Deesak",npcid=23415,x=63.6,y=65.8},
				{name="Stonebreaker Hold",faction="H",npc="Kerna",npcid=18807,x=49.2,y=43.4},
			},
			['Zangarmarsh']={
				{name="Orebor Harborage",faction="A",npc="Halu",npcid=22485,x=41.3,y=29.0},
				{name="Swamprat Post",faction="H",npc="Gur'zil",npcid=20762,x=84.8,y=55.1},
				{name="Telredor",faction="A",npc="Munci",npcid=18788,x=67.8,y=51.5},
				{name="Zabra'jin",faction="H",npc="Du'ga",npcid=18791,x=33.1,y=51.1},
			},
		},
		[4]={
			['Borean Tundra']={
				{name="Valiance Keep",faction="A",npc="Tomas Riverwell",npcid=26879,x=59.0,y=68.3},
				{name="Warsong Hold",faction="H",npc="Turida Coldwind",npcid=25288,x=40.4,y=51.4},
				{name="Transitus Shield",faction="B",npc="Warmage Adami",npcid=27046,x=33.1,y=34.5},
				{name="Amber Ledge",faction="B",npc="Surristrasz",npcid=24795,x=45.3,y=34.5},
				{name="Bor'gorok Outpost",faction="H",npc="Kimbiza",npcid=26848,x=49.6,y=11.1},
				{name="Fizzcrank Airstrip",faction="A",npc="Kara Thricestar",npcid=26602,x=56.6,y=20.1},
				{name="Unu'pe",faction="B",npc="Bilko Driftspark",npcid=28195,x=78.5,y=51.5},
				{name="Taunka'le Village",faction="H",npc="Omu Spiritbreeze",npcid=26847,x=77.8,y=37.8},
			},
			['Crystalsong Forest']={
				{name="Windrunner's Overlook",faction="A",npc="Galendror Whitewing",npcid=30271,x=72.2,y=81.0},
				{name="Sunreaver's Command",faction="H",npc="Skymaster Baeric",npcid=30269,x=78.5,y=50.5},
			},
			['Dalaran']={
				{name="Dalaran",faction="B",npc="Aludane Whitecloud",npcid=28674,x=72.8,y=45.6},
			},
			['Dragonblight']={
				{name="Stars' Rest",faction="A",npc="Palena Silvercloud",npcid=26881,x=29.2,y=55.3},
				{name="Agmar's Hammer",faction="H",npc="Narzun Skybreaker",npcid=26566,x=37.5,y=45.8},
				{name="Fordragon Hold",faction="A",npc="Derek Rammel",npcid=26877,x=39.5,y=25.9},
				{name="Kor'kron Vanguard",faction="H",npc="Numo Spiritbreeze",npcid=26850,x=43.8,y=17.0},
				{name="Wyrmrest Temple",faction="B",npc="Nethestrasz",npcid=26851,x=60.3,y=51.6},
				{name="Wintergarde Keep",faction="A",npc="Rodney Wells",npcid=26878,x=77.0,y=49.8},
				{name="Venomspite",faction="H",npc="Junter Weiss",npcid=26845,x=76.5,y=62.2},
				{name="Moa'ki",faction="B",npc="Cid Flounderfix",npcid=28196,x=48.51,y=74.39},
			},
			['Gilneas']={
				{name="Forsaken Forward Command",quest=999999,faction="H",npc="Bat Handler Doomair",npcid=45479,x=57.25,y=17.96},
				--enabled after 27290 quest disabled after quest 27405, just assume we dont know it.
			},
			['Grizzly Hills']={
				{name="Amberpine Lodge",faction="A",npc="Vana Grey",npcid=26880,x=31.3,y=59.1},
				{name="Conquest Hold",faction="H",npc="Kragh",npcid=26852,x=22.0,y=64.4},
				{name="Camp Oneqwah",faction="H",npc="Makki Wintergale",npcid=26853,x=65.0,y=46.9},
				{name="Westfall Brigade",faction="A",npc="Samuel Clearbook",npcid=26876,x=59.9,y=26.7},
			},
			['Howling Fjord']={
				{name="Camp Winterhoof",faction="H",npc="Celea Frozenmane",npcid=24032,x=49.6,y=11.6},
				{name="Fort Wildervar",faction="A",npc="James Ormsby",npcid=24061,x=60.1,y=16.1},
				{name="Vengeance Landing",faction="H",npc="Adeline Chambers",npcid=27344,x=79.0,y=29.7},
				{name="Valgarde Port",faction="A",npc="Pricilla Winterwind",npcid=23736,x=59.8,y=63.2},
				{name="New Agamand",faction="H",npc="Tobias Sarkhoff",npcid=24155,x=52.0,y=67.4},
				{name="Kamagua",faction="B",npc="Kip Trawlskip",npcid=28197,x=24.7,y=57.8},
				{name="Westguard Keep",faction="A",npc="Greer Orehammer",npcid=23859,x=31.3,y=44.0},
				{name="Apothecary Camp",faction="H",npc="Lilleth Radescu",npcid=26844,x=26.0,y=25.1},
			},
			['Icecrown']={
				{name="Argent Tournament Grounds",faction="B",npc="Helidan Lightwing",npcid=33849,x=72.6,y=22.6},
				{name="The Shadow Vault",faction="A",quest=12896,npc="Morlia Doomwing",npcid=30314,x=43.7,y=24.4},
				{name="The Shadow Vault",faction="H",quest=12897,npc="Morlia Doomwing",npcid=30314,x=43.7,y=24.4},
				{name="Death's Rise",faction="B",npc="Dreadwind",npcid=31078,x=19.3,y=47.8},
				{name="Crusaders' Pinnacle",faction="B",quest=13141,npc="Penumbrius",npcid=31069,x=79.4,y=72.4},
				{name="The Argent Vanguard",faction="B",npc="Aedan Moran",npcid=30433,x=87.8,y=78.1},
			},
			['Sholazar Basin']={
				{name="River's Heart",faction="B",npc="Marvin Wobblesprocket",npcid=28574,x=50.1,y=61.4},
				{name="Nesingwary Base Camp",faction="B",quest=12523,npc="The Spirit of Gnomeregan",npcid=28037,x=25.3,y=58.4},
			},
			['The Storm Peaks']={
				{name="K3",faction="B",npc="Skizzle Slickslide",npcid=29721,x=40.8,y=84.5},
				{name="Frosthold",faction="A",npc="Faldorf Bitterchill",npcid=29750,x=29.5,y=74.3},
				{name="Grom'arsh Crash-Site",faction="H",npc="Kabarg Windtamer",npcid=29757,x=36.2,y=49.4},
				{name="Dun Niffelem",faction="B",quest=12956,npc="Halvdan",npcid=32571,x=62.6,y=60.9},
				{name="Camp Tunka'lo",faction="H",npc="Hyeyoung Parka",npcid=29762,x=65.4,y=50.6},
				{name="Ulduar",faction="B",npc="Shavalius the Fancy",npcid=29951,x=44.5,y=28.2},
				{name="Bouldercrag's Refuge",faction="B",npc="Breck Rockbrow",npcid=29950,x=30.6,y=36.3},
			},
			['Wintergrasp']={
				{name="Wintergrasp",faction="A",npc="Arzo Safeflight",npcid=30869,x=72.0,y=30.9},
				{name="Warsong Camp",faction="H",npc="Herzo Safeflight",npcid=30870,x=21.6,y=35.0},
				{name="Valiance Landing Camp",faction="A",npc="Arzo Safeflight",npcid=30869,x=72.0,y=31.0},
			},
			['Zul\'Drak']={
				{name="Light's Breach",faction="B",npc="Danica Saint",npcid=28618,x=32.2,y=74.4},
				{name="Ebon Watch",faction="B",npc="Baneflight",npcid=28615,x=14.0,y=73.6},
				{name="The Argent Stand",faction="B",npc=" Gurric",npcid=28623,x=41.5,y=64.4},
				{name="Zim'Torga",faction="B",npc="Maaka",npcid=28624,x=60.0,y=56.7},
				{name="Gundrak",faction="B",npc="Rafae",npcid=30569,x=70.5,y=23.3},
			},
		}
	}

	local enemyfac = "DON'T PRUNE" or (UnitFactionGroup("player")=="Alliance") and "H" or "A"-- TODO: REMOVE
	function Lib:InitializeTaxis()
		for c,cont in pairs(Lib.taxipoints) do
			for z,zone in pairs(cont) do
				z=Lib.MapIDsByName[z] or z
				if type(z)=="table" then z=z[1] end
				local n=1
				while n<=#zone do
					local node=zone[n]
					if not node then break end
					if node.faction~=enemyfac then
						Lib.path2cont[node.name] = c
						node.m = z
						node.c = Astrolabe.WorldMapSize[z].system
						n=n+1
					else
						tremove(zone,n)
					end
				end
			end
		end
	end

	local aliases={["Stormwind City"]="Stormwind", ["Theramore Isle"]="Theramore"}
	function Lib:FindTaxi(name,taxitag)
		taxitag = taxitag or "manataur!!!"
		--name = name:gsub(", .*","")  -- trim zone names (in european languages, at least)
		name = aliases[name] or name
		for c,cont in pairs(Lib.taxipoints) do  for z,zone in pairs(cont) do  for n,node in ipairs(zone) do
			if node.name==name  -- raw name, pretty rare
			or node.name==name:gsub(", .*","")  -- node name with zone appended
			or node.taxitag==taxitag
			then
				return node
			end
		end  end  end
	end

	function Lib:MarkContinentKnown(cont,known)
		for z,zone in pairs(Lib.taxipoints[cont]) do
			local zoneid = LibRover.data.MapIDsByName[z]
			if type(zoneid)=="table" then zoneid=zoneid[1] end  -- might cause trouble on phased maps :/
			zoneid=ZGV.Pointer:SanitizePhase(zoneid)

			if LibRover.MapLevels[zoneid]<UnitLevel("player") then -- only set contin that is our level to false
				for n,node in ipairs(zone) do
					if node.known==true then node.known=false end
					if Lib.master[node.name]==true then Lib.master[node.name]=false end
				end
			end
		end
		Lib.master[cont]=known
	end

	function Lib:ScanTaxiMap()
		if not TaxiFrame:IsShown() then return end

		local cont = GetCurrentMapContinent()

		if ZGV then ZGV:Debug("LibTaxi: Scanning map...") end

		-- We now see the map. Whatever's not on the map, is surely unknown - so, mark everything as unknown and learn what's known.
		Lib:MarkContinentKnown(cont,false)

		for i=1,NumTaxiNodes() do 
			if TaxiNodeGetType(i)~="NONE" then
				local name = TaxiNodeName(i)
				local taxix,taxiy = TaxiNodePosition(i)
				local taxitag = ("%d:%03d:%03d"):format(cont,taxix*1000,taxiy*1000)
				local taxi = Lib:FindTaxi(name)

				if taxi then
					ZGV:Debug("LibTaxi found %s",taxi.name)
					taxi.known = true
					taxi.taxitag = taxitag
					addTaxi(taxi)
				else
					ZGV:Debug("LibTaxi error, can't find taxi: %s [%s]",name,taxitag)
				end
			end  
		end

		-- leech off QH
		if QuestHelper_KnownFlightRoutes then
			for name,_ in pairs(QuestHelper_KnownFlightRoutes) do
				addTaxi(name)
			end
		end
	end

	function Lib:MarkKnownByLevels()
		local level = UnitLevel("player")
		for c,cont in pairs(Lib.taxipoints) do
			for z,zone in pairs(cont) do
				local zoneid = LibRover.data.MapIDsByName[z]
				if type(zoneid)=="table" then zoneid=zoneid[1] end  -- might cause trouble on phased maps :/
				zoneid=ZGV.Pointer:SanitizePhase(zoneid)
				if LibRover.MapLevels[zoneid]<level then
					for n,node in ipairs(zone) do
						if node.known==nil then node.known=true	end

						if node.quest then -- does FP need a quest
							if not ZGV.completedQuests[node.quest] then -- did we do the quest
								node.known=false
								Lib.master[node.name]=false
							end
						end

						if node.factionid then -- FP has a rep!
							local standing=select(3,GetFactionInfoByID(node.factionid))
							if (node.factionid==932 or node.factionid==934) and standing <= 2 then -- test for aldor/scryer
								node.known=false
								Lib.master[node.name]=false
							elseif node.factionid==1031 and standing < 6 then
								node.known=false
								Lib.master[node.name]=false
							end
						end
						if node.class then -- Class only! woo
							local class=UnitClass("player")
							if class~=node.class then node.known=false Lib.master[node.name]=false end
						end

						if Lib.master[node.name]==nil then Lib.master[node.name]=true end
					end
				else 
					for n,node in ipairs(zone) do
						if Lib.master[node.name]==false then --if zone is overlevel and for some reason it is false, set it back to nil
							Lib.master[node.name]=nil
						elseif Lib.master[node.name]==true then -- we know a flightpath that is over our level
							node.known=true
						end
					end
				end
			end
		end
	end

	function Lib:ResetKnowledge()
		for c,cont in pairs(Lib.taxipoints) do
			for z,zone in pairs(cont) do
				for n,node in ipairs(zone) do
					node.known = nil
				end
			end
		end
		Lib:MarkKnownByLevels()
	end

	
	-- And now, the EVIL. Let's peek into a taxi before it flies.
	-- LibTaxi.LastTaxi becomes the node of the last taxi taken!

	local Saved_TakeTaxiNode = TakeTaxiNode
	_G.TakeTaxiNode = function(index)
		local x,y = TaxiNodePosition(index)
		Lib.LastTaxi = {fullname=TaxiNodeName(index)}
		Lib.LastTaxi.node = Lib:FindTaxi(Lib.LastTaxi.fullname)
		if Lib.LastTaxi.node then
			Lib.LastTaxi.name,Lib.LastTaxi.zone = Lib.LastTaxi.node.name,GetMapNameByID(Lib.LastTaxi.node.m)
		else
			Lib.LastTaxi.name,Lib.LastTaxi.zone = Lib.LastTaxi.fullname:match("(.*), (.*)")
		end
		Saved_TakeTaxiNode(index,"",true)
	end

	local function __genOrderedIndex( t )
	    local orderedIndex = {}
	    for key in pairs(t) do
		table.insert( orderedIndex, key )
	    end
	    table.sort( orderedIndex )
	    return orderedIndex
	end

	local function orderedNext(t, state)
	    -- Equivalent of the next function, but returns the keys in the alphabetic
	    -- order. We use a temporary ordered key table that is stored in the
	    -- table being iterated.

	    --print("orderedNext: state = "..tostring(state) )
	    if state == nil then
		-- the first time, generate the index
		t.__orderedIndex = __genOrderedIndex( t )
		key = t.__orderedIndex[1]
		return key, t[key]
	    end
	    -- fetch the next value
	    key = nil
	    for i = 1,table.getn(t.__orderedIndex) do
		if t.__orderedIndex[i] == state then
		    key = t.__orderedIndex[i+1]
		end
	    end

	    if key then
		return key, t[key]
	    end

	    -- no more value to return, cleanup
	    t.__orderedIndex = nil
	    return
	end

	local function ordered_pairs(t)
	    -- Equivalent of the pairs() function on tables. Allows to iterate
	    -- in order
	    return orderedNext, t, nil
	end

	function Lib:DumpTaxiPoints()
		local s="	Lib.taxipoints = {\n"
		for contnum,contdata in ipairs(Lib.taxipoints) do
			s=s.."		["..contnum.."]={\n"
			for zonename,zonedata in ordered_pairs(contdata) do
				s=s.."			['"..zonename:gsub("'","\\'").."']={\n"
				for ti,taxi in ipairs(zonedata) do
					local taxicosts=""
					if taxi.costs then
						for tag,cost in pairs(taxi.costs) do
							taxicosts = taxicosts .. ("{['%s']=%d},"):format(tag,cost)
						end
					end
					local extra=""
					if taxi.class then extra=extra.."class=\""..taxi.class.."\"," end
					if taxi.quest then extra=extra.."quest="..taxi.quest.."," end
					if taxi.factionid then extra=extra.."factionid="..taxi.factionid.."," end
					local operator=""
					if taxi.taxioperator then operator=operator.."taxioperator=\"".. taxi.taxioperator .."\"," end
					s=s..('				{name="%s",faction="%s",%snpc="%s",npcid=%d,x=%.1f,y=%.1f,%staxitag="%s",costs={%s}},\n'):format(taxi.name,taxi.faction,extra,taxi.npc,taxi.npcid,(taxi.x<1 and taxi.x*100 or taxi.x),(taxi.y<1 and taxi.y*100 or taxi.y),operator,taxi.taxitag or "",taxicosts)
				end
				s=s.."			},\n"
			end
			s=s.."		},\n"
		end
		s=s.."	}\n"
		ZGV:ShowDump(s)
	end

	_G['LibTaxi']=Lib
end
