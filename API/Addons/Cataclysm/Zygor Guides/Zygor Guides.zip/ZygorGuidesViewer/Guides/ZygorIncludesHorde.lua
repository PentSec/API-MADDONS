if UnitFactionGroup("player")~="Horde" then return end
local ZygorGuidesViewer=ZygorGuidesViewer
if not ZygorGuidesViewer then return end
if ZGV:DoMutex("IncludesH") then return end



--------------------------------------------------------------------------------------------------------------------------------------
-- Hearth Includes
--------------------------------------------------------------------------------------------------------------------------------------

ZygorGuidesViewer:RegisterInclude("hearth",[[
		'Hearth to the Valley of Strength |goto Orgrimmar |use Hearthstone##6948 |noway |c  
]])


--------------------------------------------------------------------------------------------------------------------------------------
-- Portal Includes
--------------------------------------------------------------------------------------------------------------------------------------
--How to get to the Dark Portal from Orgrimmar--
ZygorGuidesViewer:RegisterInclude("darkportal",[[
		goto Orgrimmar,45.9,66.9 |n
		.' Follow the path down |goto Orgrimmar,45.9,66.9,0.5 |noway |c
	step //1
		goto Orgrimmar/2 45.0,66.4
		.' Click the Portal to Blasted Lands |tip It's a blue swirling portal.
		.' Teleport to the Blasted Lands |goto Blasted Lands |noway |c
	step //2
		goto Blasted Lands,55.0,54.1 |n
		.' Enter the huge green portal 
		.' Teleport to Hellfire Peninsula |goto Hellfire Peninsula |noway |c
]])

ZygorGuidesViewer:RegisterInclude("portal_hyjal",[[
		goto Orgrimmar,51.1,38.3
		.' Click the Portal to Hyjal |tip It looks like a big swirling portal in front of some huge tree roots.
		.' Teleport to Mount Hyjal |goto Mount Hyjal |noway |c
]])

ZygorGuidesViewer:RegisterInclude("HyjalPortaltoOrg",[[
		goto Mount Hyjal,63.5,24.4
		.' Click the Portal to Orgrimmar |tip It looks like a big swirling orange portal next to a big building.
		.' Teleport to Orgrimmar |goto Orgrimmar |noway |c
]])
ZygorGuidesViewer:RegisterInclude("shatport_org",[[
		goto Shattrath City 56.8,48.8
		.' Click the Portal to Orgrimmar |goto Orgrimmar 48.3,64.5 <5 |noway |c
]])
ZygorGuidesViewer:RegisterInclude("portal_deepholm",[[
		goto Orgrimmar,50.8,36.4 |n
		.' Click the Portal to Deepholm |tip It looks like a purple swirling portal.
		.' Teleport to Deepholm |goto Deepholm |noway |c
]])

ZygorGuidesViewer:RegisterInclude("portal_vashj'ir",[[
		goto Orgrimmar,49.3,36.5
		.' Click on the portal to Vashj'ir |tip It looks like a blue swirling portal.
		.' Teleport to Vashj'ir |goto Abyssal Depths |noway |c
]])

ZygorGuidesViewer:RegisterInclude("OrgPortaltoUldum",[[
		goto Orgrimmar,48.9,38.6
		.' Click the Portal to Uldum |tip It looks like a big swirling portal in front of some big stone slabs.
		.' Teleport to Uldum |goto Uldum |noway |c
]])

ZygorGuidesViewer:RegisterInclude("portal_twilight",[[
		goto Orgrimmar,50.2,39.4
		.' Click the Portal to Twilight Highlands |tip It looks like a big swirling portal in front of some big metal twisting spiral objects.
		.' Teleport to Twilight Highlands |goto Twilight Highlands |noway |c
]])

ZygorGuidesViewer:RegisterInclude("TwilightHighlandsPortaltoOrg",[[
		goto Twilight Highlands,73.6,53.5
		.' Go into the Portal to Orgrimmar |tip It looks like a big swirling orange portal at the bottom of this tower.
		.' Teleport to Orgrimmar |goto Orgrimmar |noway |c
]])

ZygorGuidesViewer:RegisterInclude("rideto_org",[[ //coming from UC
		.' Go to Tirisfal |goto Tirisfal Glades |noway |c
	step //3
		goto Tirisfal Glades,60.7,58.8 |n
		.' Ride the Zeppelin to Orgrimmar |goto Orgrimmar |noway |c
]])

--------------------------------------------------------------------------------------------------------------------------------------
-- Flight Path Includes
--------------------------------------------------------------------------------------------------------------------------------------
--Orgrimmar Flightpath--
ZygorGuidesViewer:RegisterInclude("OrgFpath",[[
		goto Orgrimmar 49.6,59.0
		.talk Doras##3310
]])

--------------------------------------------------------------------------------------------------------------------------------------
-- Zeppelin Includes
--------------------------------------------------------------------------------------------------------------------------------------

-- ZEPPELINS DEPARTING FROM ORGRIMMAR --

ZygorGuidesViewer:RegisterInclude("rideto_borean",[[
		goto Orgrimmar,44.7,62.4 |n
		.' Ride the zeppelin to Borean Tundra |goto Borean Tundra |noway |c
]])
ZygorGuidesViewer:RegisterInclude("rideto_tirisfal",[[
		goto Orgrimmar,50.8,55.8 |n
		.' Ride the zeppelin to Tirisfal Glades |goto Tirisfal Glades |noway |c
]])
ZygorGuidesViewer:RegisterInclude("rideto_stranglethorn",[[
		goto Orgrimmar,52.5,53.2 |n
		.' Ride the zeppelin to Stranglethorn Vale |goto Northern Stranglethorn |noway |c
]])
ZygorGuidesViewer:RegisterInclude("rideto_bootybay",[[
		goto Orgrimmar,52.5,53.2 |n
		.' Ride the zeppelin to Stranglethorn Vale |goto Northern Stranglethorn |noway |c
	step //4
		|fly Booty Bay
]])

-- ZEPPELINS DEPARTING FROM TIRISFAL GLADES --

ZygorGuidesViewer:RegisterInclude("TirisfalHowlingShip",[[
	step //5
		goto Tirisfal Glades,59.1,59.0 |n
		.' Ride the zeppelin to Howling Fjord |goto Howling Fjord |noway |c
]])





--------------------------------------------------------------------------------------------------------------------------------------
-- Leveling Eastern Kingdoms
--------------------------------------------------------------------------------------------------------------------------------------
ZygorGuidesViewer:RegisterInclude("H_Eastern_Plaguelands_Argent_Dawn",[[
	step //6
		#include "rideto_tirisfal"
	step //7
		|fly Thondroril River
	step //8
		goto Eastern Plaguelands,9.0,66.5
		.talk Fiona##45417
		..turnin Into the Woods##27683 |only if havequest(27683)
		..accept Gidwin Goldbraids##27367
		..accept Tarenar Sunstrike##27370
	step //9
		goto 4.1,36.0
		.talk Gidwin Goldbraids##45428
		..turnin Gidwin Goldbraids##27367
		..accept Just Encased##27368
	step //10
		goto 4.7,35.6 |n
		.' Enter the tunnel |goto 4.7,35.6,0.5 |noway |c
	step //11
		goto 5.1,33.4
		.from Crypt Stalker##8555+,Crypt Horror##8557+, Crypt Walker##8556+, Crypt Slayer##8558+ |tip All inside this tunnel.
		.get 8 Crypt Bile |q 27368/1
	step //12
		goto 4.7,35.6 |n
		.' Leave the tunnel |goto 4.7,35.6,0.5 |noway |c
	step //13
		goto Eastern Plaguelands,4.1,36.0
		.talk Gidwin Goldbraids##45428
		..turnin Just Encased##27368
		..accept Greasing the Wheel##27369
	step //14
		goto 3.4,38.0
		.click Banshee's Bell##9889+ |tip They are located right along the edge of the water
		.get 10 Banshee's Bells |q 27369/1
	step //15
		goto 9.0,66.5
		.talk Fiona##45417
		..turnin Greasing the Wheel##27369
	step //16
		goto 18.4,74.8
		.talk Tarenar Sunstrike##45429
		..turnin Tarenar Sunstrike##27370
		..accept What I Do Best##27371
	step //17
		goto 18.6,76.9
		.kill 5 Death's Step Miscreation##45444+ |q 27371/1
		.' Click the Quest Complete box that displays on the right side of the screen under your minimap
		..turnin What I Do Best##27371
		..accept A Gift For Fiona##27372
	step //18
		goto 17.2,68.7
		.from Plaguehound Runt##8596+ |tip They share spawn locations with the Carrion Grubs.  So, if you are having trouble finding Plaguehound Runts, kill Carrion Grubs and more should spawn.
		.get 10 Plaguehound Blood |q 27372/1
		.' You can find more Plague Hound Runts around [Eastern Plaguelands,14.4,63.0].
	step //19
		goto 9.0,66.5
		.talk Fiona##45417
		..turnin A Gift For Fiona##27372
		..accept Onward, to Light's Hope Chapel##27373
	step //20
		goto 8.8,66.6
		.clicknpc Fiona's Caravan##10937
		..' Choose 1 of the 3 buffs you can choose from |tip All of the buffs only work while you're in Eastern Plaguelands.  Fiona's Lucky Charm gives you a chance to loot extra gold or items from enemies.  Gidwin's Weapon Oil gives you a chance to do extra Holy damage on melee and ranged attacks.  Tarenar's Talisman gives you a chance to do extra Holy damage on successful spell attacks.
		.' Click here to proceed. |confirm
	step //21
		goto 8.8,66.6
		.clicknpc Fiona's Caravan##45400
		..' Choose to go to the next destination
		.' Ride Fiona's Caravan |q 27373/1
	step //22
		goto 34.9,67.9
		.talk Janice Myers##44232
		.fpath Crown Guard Tower
	step //23
		goto 35.0,68.1
		.talk Urk Gagbaz##45500
		..accept Zaeldarr the Outcast##27432
	step //24
		goto 34.9,69.1
		.talk Fiona##45417
		..turnin Onward, to Light's Hope Chapel##27373
	step //25
		goto 35.3,68.8
		.talk Tarenar Sunstrike##45429
		..accept Traveling Companions##27381
	step //26
		goto 35.6,68.9
		.talk Carlin Redpath##11063
		..accept Little Pamela##27383
	step //27
		goto 35.9,69.3
		.' Go to the top of the tower
		.talk Argus Highbeacon##45451
		..' Ask him if he's interested in joining your caravan
		.' Find a traveling companion |q 27381/1
	step //28
		goto 35.9,69.3
		.talk Argus Highbeacon##45451
		..accept Rough Roads##27382
	step //29
		goto 35.3,68.9
		.talk Tarenar Sunstrike##45429
		..turnin Traveling Companions##27381
	step //30
		goto 32.4,83.7
		.talk Pamela Redpath##10926
		..turnin Little Pamela##27383
		..accept Pamela's Doll##27384
		..accept I'm Not Supposed to Tell You This##27392
	step //31
		goto 35.5,85.3
		.' You can find the doll parts in all of the buildings
		.click Pamela's Doll's Right Side##4233
		.collect Pamela's Doll's Right Side##12888 |q 27384
		.click Pamela's Doll's Left Side##4232
		.collect Pamela's Doll's Left Side##12887 |q 27384
		.click Pamela's Doll's Head##4231
		.collect Pamela's Doll's Head##12886 |q 27384
	step //32
		'Use Pamela's Doll's Head |use Pamela's Doll's Head##12886
		.get Pamela's Doll |q 27384/1
	step //33
		goto 40.3,83.8
		.from The Lone Hunter##45450
		.get Joseph's Hunting Blade |q 27392/1
	step //34
		goto 32.4,83.7
		.talk Pamela Redpath##10926
		..turnin Pamela's Doll##27384
		..turnin I'm Not Supposed to Tell You This##27392
		..accept Uncle Carlin##27385
	step //35
		ding 40
	step //36
		goto 35.6,68.9
		.talk Carlin Redpath##11063
		..turnin Uncle Carlin##27385
		..accept A Strange Historian##27386
	step //37
		goto 35.3,68.0
		.talk Chromie##10667
		..turnin A Strange Historian##27386
		..accept Villains of Darrowshire##27387
		..accept Heroes of Darrowshire##27388
		..accept Marauders of Darrowshire##27389
	step //38
		goto 35.0,68.1
		.talk Urk Gagbaz##45500
		..accept Cenarion Tenacity##27544
	step //39
		goto 35.6,68.9
		.talk Carlin Redpath##11063
		..' Ask him if he has the extended Annals of Darrowshire
		.get Extended Annals of Darrowshire |q 27388/1
	step //40
		goto 39.8,72.4
		.click Shattered Sword of Marduk##4175
		.get Shattered Sword of Marduk |q 27387/2
	step //41
		goto 39.6,72.1
		.kill 13 Plaguebat##8600+ |q 27382/1
	step //42
		goto 35.6,68.7
		.' Go to the top of the tower
		.talk Argus Highbeacon##45451
		..turnin Rough Roads##27382
	step //43
		goto 24.2,78.5 |n
		.' Enter the crypt |goto 24.2,78.5,0.5 |noway |c
	step //44
		goto 23.8,77.9
		.' Go to the bottom of the crypt
		.from Zaeldarr the Outcast##12250
		.get Zaeldarr's Head |q 27432/1
	step //45
		goto 22.1,68.2
		.click Redpath's Shield##4172
		.get Redpath's Shield |q 27388/3
	step //46
		goto 22.3,68.3
		.' Go upstairs
		.click Davil's Libram##430
		.get Davil's Libram |q 27388/2
	step //47
		goto 35.0,68.2
		.talk Urk Gagbaz##45500
		..turnin Zaeldarr the Outcast##27432
	step //48
		goto 35.2,68.1
		.talk Chromie##10667
		..turnin Heroes of Darrowshire##27388
	step //49
		goto 37.3,60.2
		.click Horgus' Skull##4173
		.get Skull of Horgus |q 27387/1
	step //50
		goto 30.2,56.9
		.talk Rayne##16135
		..turnin Cenarion Tenacity##27544
		..accept Postponing the Inevitable##27420
		..accept Amidst Death, Life##27421
	step //51
		goto 33.7,44.4
		.' Go inside the necropolis
		.' Use Rayne's Seeds while standing on the platform above the green liquid |use Rayne's Seeds##61036
		.' Plant a Seed in the Western Necropolis |q 27421/2
	step //52
		goto 37.8,42.5
		.' Go inside the necropolis
		.' Use Rayne's Seeds while standing on the platform above the green liquid |use Rayne's Seeds##61036
		.' Plant a Seed in the Northeastern Necropolis |q 27421/3
	step //53
		goto 37.6,48.3
		.' Go inside the necropolis
		.' Use Rayne's Seeds while standing on the platform above the green liquid |use Rayne's Seeds##61036
		.' Plant a Seed in the Southeastern Necropolis |q 27421/1
	step //54
		goto 36.4,46.0
		.from Scourge Champion##8529+
		.collect Fetid Skull##13157 |n
		.' Use your Mystic Crystal when you have a Fetid Skull |use Mystic Crystal##13156
		.get 5 Resonating Skull |q 27389/1
		.from Shadowmage##8550+, Dark Adept##8546+
		.collect Plague Disseminator Control Rune##61037 |n
		.' Use your Overcharged Mote when you have a Plague Disseminator Control Rune |use Overcharged Mote##61038
		.' Destroy 3 Plague Disseminators |q 27420/1
	step //55
		goto 30.2,56.9
		.talk Rayne##16135
		..turnin Postponing the Inevitable##27420
		..turnin Amidst Death, Life##27421
	step //56
		goto 35.3,68.1
		.talk Chromie##10667
		..turnin Villains of Darrowshire##27387
		..turnin Marauders of Darrowshire##27389
		..accept The Battle of Darrowshire##27390
	step //57
		goto 35.1,84.0
		.' Use your Relic Bundle |use Relic Bundle##15209
		.' Fight in the battle and follow the instructions that appear on your screen
		.from Redpath the Corrupted##10938
		.' Joseph Redpath will appear after the battle at [Eastern Plaguelands,35.1,84.0]
		.talk Joseph Redpath##10936
		.' Accept Redpath's Forgiveness |q 27390/1
	step //58
		goto 32.4,83.7
		.talk Pamela Redpath##10926
		..turnin The Battle of Darrowshire##27390
		..accept Hidden Treasures##27391
	step //59
		goto 32.2,83.4
		.click Joseph's Chest##318
		..turnin Hidden Treasures##27391
	step //60
		goto 34.9,69.2
		.talk Fiona##45417
		..accept The Trek Continues##27448
	step //61
		goto 35.0,69.3
		.clicknpc Fiona's Caravan##45400
		..' Choose to go to the next destination
		.' Ride in Fiona's Caravan |q 27448/1
	step //62
		goto 52.9,53.1
		.talk Fiona##45417
		..turnin The Trek Continues##27448
		..accept Boys Will Be Boys##27455
	step //63
		goto 53.0,53.1
		.clicknpc Fiona's Caravan##45400
		.' Complete the Argus' Journal quest |tip This will give you a 2% experience bonus while in Eastern Plaguelands, so will allow you to level faster.  // %
		|confirm
	step //64
		goto 53.2,54.6
		.talk Betina Bigglezink##11035
		..accept To Kill With Purpose##27451
		..accept Dark Garb##27452
	step //65
		goto 53.8,54.0
		.' Go to the top of the tower
		.talk Frederick Calston##45575
		..accept Frederick's Fish Fancy##27450
	step //66
		goto 52.8,51.4
		.talk Vex'tul##45574
		..accept Honor and Strength##27449
		.kill 3 Mossflayer Rogue##45579+ |q 27449/1
	step //67
		goto 52.8,51.4
		.talk Vex'tul##45574
		..turnin Honor and Strength##27449
	step //68
		ding 41
	step //69
		goto 50.2,61.3
		.clicknpc Plague Puffer##45650+
		.get 8 Plague Puffer |q 27450/1
		.clicknpc Infectis Incher##45655+
		.get 8 Infectis Incher |q 27450/2
		.clicknpc Infectis Scuttler##45657+
		.get 8 Infectis Scuttler |q 27450/3
	step //70
		goto 53.7,62.3
		.from Unseen Servant##8538+, Stitched Horror##8543+, Hate Shrieker##8541+, Dark Caster##8526+, Scourge Warder##8525+, Gibbering Ghoul##8531+
		.collect 7 Living Rot##15447 |n |tip These only last 10 minutes, so keep an eye on the timer and try to get them as fast as you can.
		.' Use Mortar and Pestle once you have 7 Living Rot |use Mortar and Pestle##15454
		.get Coagulated Rot |q 27451/1
		.' Click the Quest Complete box that displays on the right side of the screen under your minimap
		..turnin To Kill With Purpose##27451
	step //71
		goto 55.7,61.0
		.from Dark Summoner##8551+, Vile Tutor##8548+
		.get Death Cultist Headwear |q 27452/1
		.get Death Cultist Robes |q 27452/2
		.' Click the Quest Complete box that displays on the right side of the screen under your minimap
		..turnin Dark Garb##27452
		..accept Catalysm##27453
	step //72
		goto 57.6,72.6
		.' Use Betina's Flasks on Plague Ravagers and Blighted Surges underwater |use Betina's Flasks##61284
		.get 8 Active Liquid Plague Agent |q 27453/1
		.' Click the Quest Complete box that displays on the right side of the screen under your minimap
		..turnin Catalysm##27453
		..accept Just a Drop in the Bucket##27454
	step //73
		goto 61.7,75.5
		.' Use your Death Cultist Disguise |use Death Cultist Disguise##61283
		.' Wear your Death Cultist Disguise |havebuff INTERFACE\ICONS\inv_helmet_152 |q 27454
	step //74
		goto 62.4,76.4
		.click Mereldar Plague Cauldron##4331
		..' Choose to throw in an entire flask
		.' Disturb the Mereldar Plague Cauldron |q 27454/1
	step //75
		goto 53.2,54.6
		.talk Betina Bigglezink##11035
		..turnin Just a Drop in the Bucket##27454
	step //76
		goto 53.8,54.0
		.' Go to the top of the tower
		.talk Frederick Calston##45575
		..turnin Frederick's Fish Fancy##27450
	step //77
		goto 74.4,53.3
		.talk Gidwin Goldbraids##45431
		..turnin Boys Will Be Boys##27455
		..accept A Boyhood Dream##27463
	step //78
		goto 73.8,51.9
		.talk Rimblat Earthshatter##16134
		..accept Gathering Some Grub(s)##27456
	step //79
		goto 74.9,53.5
		.talk Smokey LaRue##11033
		..accept Smokey and the Bandage##27458
	step //80
		goto 75.6,52.4
		.talk Jessica Chambers##16256
		.home Light's Hope Chapel
	step //81
		goto 75.6,52.0
		.talk Leonid Barthalomew the Revered##11036
		..accept The Brotherhood of Light##27459
	step //82
		goto 75.9,52.0
		.talk Lord Maxwell Tyrosus##11034
		..turnin A Boyhood Dream##27463
		..accept Argent Call: The Trial of the Crypt##27464
	step //83
		goto 77.2,50.8 |n
		.' Enter the crypt |goto 77.2,50.8,0.5 |noway |c
	step //84
		goto 77.2,51.4
		.' Go to the bottom of the crypt
		.' Use your Argent Scroll |use Argent Scroll##61309
		.from Argent Warden##45698+
		.from Lord Raymond George##45707
		.' Complete the Trial of the Crypt |q 27464/1
	step //85
		goto 75.9,52.0
		.talk Lord Maxwell Tyrosus##11034
		..turnin Argent Call: The Trial of the Crypt##27464
		..accept Argent Call: The Noxious Glade##27465
	step //86
		goto 75.7,52.0
		.talk Master Craftsman Omarion##16365
		..accept Buried Blades##27467
	step //87
		goto 71.9,45.4
		.from Stephen Browman##46167
		.get Browman's Wrappings |q 27458/1
	step //88
		goto 72.1,41.6 |n
		.' Run up this path |goto 72.1,41.6,0.5 |noway |c
	step //89
		goto 77.4,37.3
		.kill 16 Noxious Glade Scourge |q 27465/1
		.kill 8 Noxious Glade Cultists |q 27465/2
		.clicknpc Slain Scourge Trooper##45695+
		.' Bury 10 Blades |q 27467/1
		' |from Diseased Flayer##8532+, Dread Weaver##8528+, Death Singer##8542+
		' |from Skullmage##45691+, Noxious Assassin##45692+
		|tip Be careful of the patrolling elite, Garginox, in this area.
		|modelnpc Garginox##45681
	step //90
		'Hearth to Light's Hope Chapel |goto 75.6,52.4,0.5 |use Hearthstone##6948 |noway |c
	step //91
		goto 75.7,52.0
		.talk Master Craftsman Omarion##16365
		..turnin Buried Blades##27467
	step //92
		goto 75.9,52.0
		.talk Lord Maxwell Tyrosus##11034
		..turnin Argent Call: The Noxious Glade##27465
	step //93
		goto 74.9,53.5
		.talk Smokey LaRue##11033
		..turnin Smokey and the Bandage##27458
	step //94
		goto 71.1,60.6
		.from Carrion Grub##8603+, Carrion Devourer##8605+
		.get 15 Slab of Carrion Worm Meat |q 27456/1
	step //95
		goto 72.6,74.8
		.talk Archmage Angela Dosantos##16116
		..turnin The Brotherhood of Light##27459
		..accept Soft Landing##27460
	step //96
		goto 73.6,74.8
		.kill 10 Tyr's Hand Scarlet Crusader |q 27460/1
		' |from Scarlet Enchanter##9452+, Scarlet Warder##9447+, Scarlet Cleric##9449+
	step //97
		goto 77.6,79.4
		.click Crusader's Flare##6543
		..turnin Soft Landing##27460
		..accept To Take the Abbey##27461
		..accept To Take the Barracks##27462
	step //98
		goto 75.3,76.2
		.talk Crusade Commander Korfax##16112
		..turnin To Take the Barracks##27462
		..accept Scarlet Salvage##27614
		..accept The Wrathcaster##27615
		..accept The Huntsman##27616
		..accept The Commander##27619
	step //99
		ding 42
	step //100
		goto 74.8,76.7
		.click Battered Chest##10
		.get Crimson Boar |q 27614/1
	step //101
		goto 74.2,78.3
		.click Battered Chest##10
		.get Lihanna's Strand |q 27614/2
	step //102
		goto 75.1,79.0
		.click Battered Chest##10
		.get Shroud of Uther |q 27614/3
	step //103
		goto 75.9,77.5
		.click Battered Chest##10
		.get Gavinrad's Sigil |q 27614/4
	step //104
		goto 75.0,78.3
		.' Go into the basement of the fortress
		.kill Mataus the Wrathcaster##46093 |q 27615/1
	step //105
		goto 74.9,78.3
		.' Go upstairs into the main room of the fortress
		.kill Scarlet Commander Marjhan##46092 |q 27619/1
	step //106
		goto 74.5,77.5
		.' Go down the hall and up more stairs
		.kill Huntsman Leopold##46094 |q 27616/1
	step //107
		goto 75.3,76.2
		.talk Crusade Commander Korfax##16112
		..turnin Scarlet Salvage##27614
		..turnin The Wrathcaster##27615
		..turnin The Huntsman##27616
		..turnin The Commander##27619
		..accept Argent Upheaval##27618
	step //108
		goto 76.1,75.3
		.talk Archmage Angela Dosantos##16116
		..turnin Argent Upheaval##27618
	step //109
		goto 76.7,73.1
		.talk Crusade Commander Eligor Dawnbringer##16115
		..turnin To Take the Abbey##27461
		..accept Victory From Within##27612
		..accept The Assassin##27613
	step //110
		goto 77.8,71.0
		.' Click the Argent Portal |tip It looks like a swirling portal in a room on the north side of the building.  Follow the stairs up in the Library Wing, not the big spiral stairs in the middle of the building.
		.' Open the Portal within the Library Wing |q 27612/2
	step //111
		goto 78.6,72.9
		.' Click the Argent Portal |tip It looks like a swirling portal in a room on the west side of the building.
		.' Open the Portal within the Hall of Arms |q 27612/1
	step //112
		goto 77.6,72.7
		.' Follow the big spiral stairs up to the top of the bell tower
		.kill Rohan the Assassin##46095 |q 27613/1
	step //113
		goto 76.7,73.1
		.talk Crusade Commander Eligor Dawnbringer##16115
		..turnin Victory From Within##27612
		..turnin The Assassin##27613
		..accept Befouled No More##27617
	step //114
		goto 76.1,75.3
		.talk Archmage Angela Dosantos##16116
		..turnin Befouled No More##27617
		..accept Like Rats##27620
	step //115
		goto 82.3,79.4
		.kill Crusader Lord Valdelmar##46096 |q 27620/1
	step //116
		goto 75.6,52.0
		.talk Leonid Barthalomew the Revered##11036
		..turnin Like Rats##27620
	step //117
		 goto Eastern Plaguelands,75.8,52.4
		.talk Tarenar Sunstrike##45729
		..accept Argent Call: Northdale##27466
	step //118
		goto 73.8,51.9
		.talk Rimblat Earthshatter##16134
		..turnin Gathering Some Grub(s)##27456
		..accept An Opportune Alliance##27457
	step //119
		goto 61.8,41.0
		.talk Vex'tul##45574
		..accept Out of the Ziggurat##27481
	step //120
		goto 61.0,43.7
		.talk Deacon Andaal##45736
		..accept Righteous Indignation##27479
	step //121
		goto 61.6,43.1
		.talk Gamella Cracklefizz##45735
		..accept The Corpulent One##27477
	step //122
		goto 61.5,42.7
		.talk Fiona##45417
		..turnin An Opportune Alliance##27457
		..turnin Argent Call: Northdale##27466
	step //123
		goto 61.6,43.2
		.talk Tarenar Sunstrike##45729
		..accept Ix'lar the Underlord##27487
	step //124
		goto 61.8,35.7
		.kill Ix'lar the Underlord##45744 |q 27487/1 |tip He's a big purple bug that walks around this area, so you may need to search for him.
		.kill 10 Ix'lar's minion |q 27487/2
		' |from Scourge Guard##8527+, Gangled Golem##8544+, Nerubian Sycophant##45743+
	step //125
		goto 56.7,27.9
		.kill Borelgore##11896 |q 27477/1 |tip He's a huge yellow grub that walks along in this big trench.
	step //126
		goto 58.9,20.4 |n
		.' Run up this path |goto 58.9,20.4,0.5 |noway |c
	step //127
		goto 66.8,9.9
		.' Don't walk over the dirt piles on the ground, they spawn more enemies
		.from Warlord Thresh'jin##10822 |tip Don't worry that he's elite, you can kill him easily
		.get Body of Warlord Thresh'jin |q 27481/1
		.' Click the Quest Complete box that displays on the right side of the screen under your minimap
		..turnin Out of the Ziggurat##27481
		..accept Into the Flames##27482
	step //128
		goto 67.4,9.0
		.' Use the Body of Warlordw Thresh'jin next to the Bonfire at the top of the temple |use Body of Warlord Thresh'jin##61316
		.' Burn Warlord Thresh'jin's Body |q 27482/1
		.' Click the Quest Complete box that displays on the right side of the screen under your minimap
		..turnin Into the Flames##27482
	step //129
		goto 64.5,13.7
		.' Don't walk over the dirt piles on the ground, they spawn more enemies
		.from Mossflayer Cannibal##8562+, Mossflayer Scout##8560+, Mossflayer Shadowhunter##8561+, Infected Mossflayer##12261+
		.get 30 Mossflayer Eye |q 27479/1
	step //130
		'Hearth to Light's Hope Chapel |goto 75.6,52.4,0.5 |use Hearthstone##6948 |noway |c
	step //131
		goto 75.9,53.4
		.talk Khaelyn Steelwing##12617
		.' Fly to Eastwall Tower, Eastern Plaguelands |goto 61.6,43.9,0.5 |noway |c
	step //132
		goto 61.3,44.5
		.talk Deacon Andaal##45736
		..turnin Righteous Indignation##27479
	step //133
		ding 43
	step //134
		goto 61.6,43.1
		.talk Gamella Cracklefizz##45735
		..turnin The Corpulent One##27477
	step //135
		goto 61.5,42.7
		.talk Fiona##45417
		..turnin Ix'lar the Underlord##27487
	step //136
		goto 61.6,43.2
		.talk Tarenar Sunstrike##45729
		..accept Impatience##27488
	step //137
		goto 65.5,24.4
		.click Open Prayer Book##254
		.get Gidwin's Prayer Book |q 27488/1
	step //138
		goto 61.6,43.2
		.talk Tarenar Sunstrike##45729
		..turnin Impatience##27488
		..accept Nobody to Blame but Myself##27489
	step //139
		goto 61.6,42.5
		.clicknpc Fiona's Caravan##45400
		..' Choose to go to the next destination
		.' Ride Fiona's Caravan to Northpass Tower |q 27489/1
	step //140
		goto 50.4,20.1
		.talk Tarenar Sunstrike##45729
		..turnin Nobody to Blame but Myself##27489
		..accept Beat it Out of Them##27522
	step //141
		goto 50.0,19.5
		.talk Kirkian Dawnshield##45826
		..accept Wretched Hive of Scum and Villainy##27521
	step //142
		goto 54.6,19.1
		.from Scourge Siege Engineer##17878+
		.' Beat 6 Scourge Siege Engineers |q 27522/1
		.' Discover Gidwin's Location |q 27522/2
		.' Discover Gidwin's Captor |q 27522/3
	step //143
		goto 47.0,17.4
		.kill 9 Quel'lithien Wretched |q 27521/1
		' |from Wretched Pathstrider##8565+, Wretched Woodsman##8563+, Wretched Ranger##8564+
	step //144
		goto 48.0,23.0
		.talk Corpseburner Tim##45816
		..accept Duskwing, Oh How I Hate Thee...##27523
	step //145
		goto 46.4,33.8
		.' Use The Corpseburner's Flare in this spot |use The Corpseburner's Flare##61334 |tip If you get a message that there are no valid targets, wait until Duskwing spawns.  He's a big gray bat that flies in the sky around this area.
		.from Duskwing##11897
		.get Patch of Duskwing's Fur |q 27523/1
	step //146
		goto 48.0,23.0
		.talk Corpseburner Tim##45816
		..turnin Duskwing, Oh How I Hate Thee...##27523
	step //147
		goto 50.5,20.2
		.talk Fiona##45417
		..turnin Beat it Out of Them##27522
		..accept Blind Fury##27524
	step //148
		goto 50.5,20.2
		.talk Argus Highbeacon##45451
		..accept The Plaguewood Tower##27532
	step //149
		goto 50.0,19.5
		.talk Kirkian Dawnshield##45826
		..turnin Wretched Hive of Scum and Villainy##27521
	step //150
		goto 27.6,21.2
		.talk Tarenar Sunstrike##45729
		..turnin Blind Fury##27524
		..accept Guardians of Stratholme##27525
	step //151
		goto 27.6,20.9
		.talk Crusader Kevin Frost##45831
		..accept Scourged Mass##27528
		..accept Defenders of Darrowshire##27529
		..accept Add 'em to the Pile##27539
	step //152
		goto 29.4,19.7
		.kill Karthis Darkrune##45868 |q 27525/2
		.collect The Baroness' Missive##61378 |n
		.' Click The Baroness' Missive in your bags |use The Baroness' Missive##61378
		..accept The Baroness' Missive##27551
	step //153
		goto 27.4,21.3
		.talk Tarenar Sunstrike##45729
		..turnin The Baroness' Missive##27551
		..accept Gidwin's Fate Revealed##27526
	step //154
		goto 29.1,26.2
		.' Enter this building and watch the cutscene
		.' Find Gidwin Goldbraids |q 27526/1
	step //155
		goto 28.4,25.9
		.talk Gidwin Goldbraids##45730
		..turnin Gidwin's Fate Revealed##27526
		..accept Journey's End##27527
	step //156
		goto 25.4,19.8
		.kill Omasum Blighthoof##45867 |q 27525/1
	step //157
		goto 31.4,20.3
		.' All around Plaguewood, do the following:
		.from Overstuffed Golem##45851+
		.' Use your Crusader's Torch on their corpses |use Crusader's Torch##61369
		.' Burn 8 Overstuffed Golem Corpses |q 27528/1
		.from Cursed Mage##8524+, Scourge Soldier##8523+
		.get 16 Stinking Skull |q 27539/1
		.from Cannibal Ghoul##8530+
		.talk Darrowshire Spirit##11064 |tip They spawn after you kill Cannibal Ghouls.
		.' Free 8 Darrowshire Spirits |q 27529/1
	step //158
		goto 28.5,25.9
		.talk Tarenar Sunstrike##45729
		..turnin Guardians of Stratholme##27525
	step //159
		goto 27.6,20.9
		.talk Crusader Kevin Frost##45831
		..turnin Scourged Mass##27528
		..turnin Defenders of Darrowshire##27529
		..turnin Add 'em to the Pile##27539
		..accept The Corpsebeasts##27530
	step //160
		ding 44
	step //161
		goto 28.3,32.3
		.' Use your Argent Lightwell Charm next to the big brown monster corpses |use Argent Lightwell Charm##61375 |tip You will have to put 3 around each corpse, and you can't put them too close together.
		.' Destroy 3 Corpsebeasts |q 27530/1
	step //162
		goto 27.6,20.9
		.talk Crusader Kevin Frost##45831
		..turnin The Corpsebeasts##27530
	step //163
		goto 17.7,28.0
		.talk Argent Apothecary Judkins##45828
		..turnin The Plaguewood Tower##27532
		..accept Counter-Plague Research##27531
		..accept Just a Little Touched##27535
	step //164
		goto 25.1,34.5
		.click Flesh Giant Foot##8077
		.get Flesh Giant Foot Scrapings |q 27531/3
	step //165
		goto 23.5,22.4
		.click Rotberry Bush##28+
		.get 20 Rotberry |q 27531/1
		.click Disembodied Arm##8373+
		.get 5 Disembodied Arm |q 27531/2
	step //166
		goto 17.7,28.0
		.talk Argent Apothecary Judkins##45828
		..turnin Counter-Plague Research##27531
	step //167
		goto 11.3,28.6
		.talk Augustus the Touched##12384
		..turnin Just a Little Touched##27535
		..accept A Fate Worse Than Butchery##27533
		..accept Augustus' Receipt Book##27534
	step //168
		goto 14.2,26.3
		.click Augustus' Receipt Book##4872
		.get Augustus' Receipt Book |q 27534/1
	step //169
		goto 14.4,28.5
		.kill 9 Plagued Swine##16117+ |q 27533/1
	step //170
		goto 11.3,28.6
		.talk Augustus the Touched##12384
		..turnin A Fate Worse Than Butchery##27533
		..turnin Augustus' Receipt Book##27534
	step //171
		'Use Gidwin's Hearthstone |use Gidwin's Hearthstone##61379
		.' Teleport to Light's Hope Chapel |goto 75.6,52.4,0.5 |noway |c
	step //172
		goto 73.7,52.1
		.talk Fiona##45417
		..turnin Journey's End##27527
	step //173
	label	"Annals"
		goto 76.1,51.0
		.talk Lord Raymond George##49856
		|tip These are dungeon quests. If you are not high level, you will need to get a group to continue.
		..accept Annals of the Silver Hand##28755 |repeatable
	step //174
		goto 27.8,11.6
		.' Enter Stratholme through this portal
		.' Teleport to Stratholme |goto Stratholme |noway |c
	step //175
		goto Stratholme,32.1,34.6
		.click The Bastion Door##444
		.' Enter the hallway |goto Stratholme,30.5,35.8,0.5 |c
	step //176
		goto Stratholme,22.4,56.6
		.click Hall of the High Command Door##444
		.' Enter the Hallway and turn left |goto 20.1,59.5,0.5 |noway |c
	step //177
		goto Stratholme,27.5,74.7
		.click Annals of the Silver Hand##8133
		.get Annals of the Silver Hand |q 28755/1
	step //178
		goto Eastern Plaguelands,76.2,51.0
		.talk Lord Raymond George##49856
		..turnin Annals of the Silver Hand##28755 |repeatable |next "Annals" |only if rep('Argent Dawn')<=Exalted |tip If you do not reset your instance then you will only be forced to clear mobs one time.
		.' Earn Exalted reputation with the Argent Dawn |condition rep('Argent Dawn')==Exalted |next "exalted" |only if rep('Argent Dawn')==Exalted
	step //179
	label exalted
		.' Congratulations, you are now Exalted with the _Argent Dawn_!
]])

--------------------------------------------------------------------------------------------------------------------------------------
-- Leveling Kalimdor
--------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------------
-- Leveling Outland
--------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------------
-- Leveling Northrend
--------------------------------------------------------------------------------------------------------------------------------------
ZygorGuidesViewer:RegisterInclude("H_Icecrown_Argent_Crusade_Rep",[[
	step //180
		goto Icecrown,87.8,78.1
		.talk Aedan Moran##30433
		.fpath The Argent Vanguard
	step //181
		goto 87.5,75.8
		.talk Highlord Tirion Fordring##28179
		..accept Honor Above All Else##13036
	step //182
		goto 87.1,75.8
		.talk Crusade Commander Entari##30223
		..turnin Honor Above All Else##13036
		..accept Scourge Tactics##13008
	step //183
		goto 86.8,76.7
		.talk Father Gustav##30226
		..accept Curing The Incurable##13040
	step //184
		goto 86.1,75.8
		.talk Crusade Lord Dalfors##30224
		..accept Defending The Vanguard##13039
	step //185
		goto 84.4,74.3
		.from Carrion Fleshstripper##30206+, Forgotten Depths Acolyte##30205+
		.kill 15 Forgotten Depths Nerubian |q 13039/1
		.get 10 Forgotten Depths Venom Sac|q 13040/1
		.' Kill the white spider wrappings around this area.
		|modelnpc Webbed Crusader##17680
		.' Free 8 Webbed Crusaders |q 13008/1
	step //186
		goto 86.1,75.8
		.talk Crusade Lord Dalfors##30224
		..turnin Defending The Vanguard##13039
	step //187
		goto 86.8,76.7
		.talk Father Gustav##30226
		..turnin Curing The Incurable##13040
	step //188
		goto 87.1,75.8
		.talk Crusade Commander Entari##30223
		..turnin Scourge Tactics##13008
		..accept If There Are Survivors...##13044
	step //189
		goto 87.0,79.0
		.talk Penumbrius##30227
		..turnin If There Are Survivors...##13044
		..accept Into The Wild Green Yonder##13045
	step //190
		goto 87.1,79.1
		'Click the Argent Skytalon to ride it |modelnpc Argent Skytalon##30500 |invehicle |c |q 13045
	step //191
		goto 79.0,67.4
		.' Use the Grab Captured Crusader ability near Captured Crusaders to pick them up |petaction Grab Captured Crusader
		.' Once you pick up a Captured Crusader, fly to [86.9,76.5]
		.' Use the Drop Off Captured Crusader ability near the tents to drop off the crusaders
		.' Repeat this process 2 more times
		.' Rescue 3 Captured Crusaders |q 13045/1
	step //192
		.' Click the red arrow on your vehicle hot bar to stop riding the dragon |outvehicle |c
	step //193
		goto 87.5,75.8
		.talk Highlord Tirion Fordring##28179
		..turnin Into The Wild Green Yonder##13045
		..accept A Cold Front Approaches##13070
	step //194
		goto 85.6,76.0
		.talk Siegemaster Fezzik##30657
		..turnin A Cold Front Approaches##13070
		..accept The Last Line Of Defense##13086
	step //195
		goto 85.3,75.9
		'Click the Argent Cannon to get on it |modelnpc Argent Cannon##30236 |invehicle |c |q 13086
	step //196
		'Use the skills on your hotbar to kill scourge mobs and dragons
		'|from Forgotten Depths Slayer##30593+
		.kill 100 Scourge Attacker |q 13086/1
		.kill 3 Frostbrood Destroyer##30575+ |q 13086/2
	step //197
		.' Click the red arrow on your vehicle hot bar to stop using the cannon |outvehicle |c
	step //198
		goto 85.6,76.0
		.talk Siegemaster Fezzik##30657
		..turnin The Last Line Of Defense##13086
	step //199
		goto 86.0,75.8
		.talk Highlord Tirion Fordring##28179
		..accept Once More Unto The Breach, Hero##13105 |only DeathKnight
		..accept Once More Unto The Breach, Hero##13104 |only !DeathKnight
	step //200
		goto 83.0,72.9
		.talk The Ebon Watcher##30596
		..turnin Once More Unto The Breach, Hero##13105 |only DeathKnight
		..turnin Once More Unto The Breach, Hero##13104 |only !DeathKnight
		..accept The Purging Of Scourgeholme##13118
		..accept The Scourgestone##13122
	step //201
		goto 83.0,73.1
		.talk Crusade Architect Silas##30686
		..accept The Stone That Started A Revolution##13130
	step //202
		goto 83.0,73.1
		.talk Crusade Engineer Spitzpatrick##30714
		..accept It Could Kill Us All##13135
	step //203
		goto 82.9,72.8
		.talk Father Gustav##30683
		..accept The Restless Dead##13110
	step //204
		goto 80.4,68.2
		.kill 8 Reanimated Crusader##31043+ |q 13118/3
		.kill 3 Forgotten Depths Underking##31039+ |q 13118/2
		.get 15 Scourgestone |q 13122/1
		.' Use your Holy Water on Reanimated Crusader corpses |use Holy Water##43153
		.' Free 10 Restless Souls |q 13110/1
	step //205
		goto 78.7,60.2
		.kill 3 Forgotten Depths High Priest##31037+ |q 13118/1
		.' You can find another Forgotten Depths High Priest at [76.2,61.0]
	step //206
		goto 82.9,72.8
		.talk Father Gustav##30683
		..turnin The Restless Dead##13110
	step //207
		goto 83.0,72.9
		.talk The Ebon Watcher##30596
		..turnin The Purging Of Scourgeholme##13118
		..turnin The Scourgestone##13122
		..accept The Air Stands Still##13125
	step //208
		goto 77.6,62.2
		.' Use your War Horn of Acherus on Salranax the Flesh Render |use War Horn of Acherus##43206 |tip A Death Knight is summoned to help you, but make sure you get the first hit on Salranax the Flesh Render, or else you won't get credit for the kill.
		.kill Salranax the Flesh Render##30829 |q 13125/1
	step //209
		goto 79.7,60.9
		.' Use your War Horn of Acherus on High Priest Yath'amon |use War Horn of Acherus##43206 |tip A Death Knight is summoned to help you, but make sure you get the first hit on High Priest Yath'amon, or else you won't get credit for the kill.
		.kill High Priest Yath'amon##30831 |q 13125/3
	step //210
		goto 76.6,54.1
		.' Use your War Horn of Acherus on Underking Talonox |use War Horn of Acherus##43206 |tip A Death Knight is summoned to help you, but make sure you get the first hit on Underking Talonox, or else you won't get credit for the kill.
		.kill Underking Talonox##30830 |q 13125/2
	step //211
		.' Click the dark portal that spawns after you kill Underking Talonox to return to the Valley of Echoes |goto Icecrown,83.0,72.6,0.5 |noway |c
	step //212
		goto 83.0,72.9
		.talk The Ebon Watcher##30596
		..turnin The Air Stands Still##13125
	step //213
		goto Crystalsong Forest,59.9,57.2 //// Display ID
		.from Unbound Ent##30862+, Unbound Dryad##30860+
		.get 8 Crystallized Energy |q 13135/1
		.click Crystalline Heartwood##8439  
		.get 10 Crystalline Heartwood |q 13130/1
	step //214
		goto 73.8,53.0
		.click Ancient Elven Masonry##8356 
		.get 10 Ancient Elven Masonry|q 13130/2
		.' You can find more Ancient Elven Masonry around [79.6,61.3] |n
	step //215
		goto Icecrown,83.0,73.1
		.talk Crusade Architect Silas##30686
		..turnin The Stone That Started A Revolution##13130
	step //216
		goto 83.0,73.1
		.talk Crusade Engineer Spitzpatrick##30714
		..turnin It Could Kill Us All##13135
	step //217
		goto 82.9,72.8
		.talk Father Gustav##30683
		..accept Into The Frozen Heart Of Northrend##13139
	step //218
		goto 86.0,75.8
		.talk Highlord Tirion Fordring##28179
		..turnin Into The Frozen Heart Of Northrend##13139
		..accept The Battle For Crusaders' Pinnacle##13141
	step //219
		goto 80.1,72.0
		.' Use your Blessed Banner of the Crusade |use Blessed Banner of the Crusade##43243
		.' Watch the Battle for Crusaders' Pinnacle |q 13141/1
	step //220
		goto 82.9,72.8
		.talk Father Gustav##30683
		..turnin The Battle For Crusaders' Pinnacle##13141
		..accept The Crusaders' Pinnacle##13157
	step //221
		goto 79.8,71.8
		.talk Highlord Tirion Fordring##28179
		..turnin The Crusaders' Pinnacle##13157
		..accept A Tale of Valor##13068
	step //222
		goto 79.5,72.7
		.talk Warlord Hork Strongbrow##31240
		..accept Orgrim's Hammer##13224
	step //223
		goto 79.8,30.8
		.talk Crusader Bridenbrad##30562
		..turnin A Tale of Valor##13068
		..accept A Hero Remains##13072
	step //224
		goto 79.8,71.8
		.talk Highlord Tirion Fordring##28179
		..turnin A Hero Remains##13072
		..accept The Keeper's Favor##13073
	step //225
		goto 87.1,77.0
		.talk Arch Druid Lilliandra##30630
		..' Ask her for a portal to Moonglade
		..' Click the Moonglade Portal that appears next to you |goto Moonglade |noway |c
	step //226
		goto Moonglade,36.2,41.8
		.talk Keeper Remulos##11832
		..turnin The Keeper's Favor##13073
		..accept Hope Within the Emerald Nightmare##13074
	step //227
		goto 33.7,44.1
		.click Emerald Acorn##424
		.get 3 Emerald Acorn|q 13074/1
	step //228
		'Right click your Fitfull Dream buff to awaken from the nightmare |nobuff Spell_Nature_Sleep |q 13074 |tip The Fitfull Dream buff icon looks like a closed eye.
	step //229
		goto 36.2,41.8
		.talk Keeper Remulos##11832
		..turnin Hope Within the Emerald Nightmare##13074
		..accept The Boon of Remulos##13075
	step //230
		.talk Keeper Remulos##11832
		..' Tell him you wish to return to Arch Druid Lilliandra.
		..' Click the Moonglade Return Portal |goto Icecrown |noway |c
	step //231
		goto 79.8,30.8
		.talk Crusader Bridenbrad##30562
		..turnin The Boon of Remulos##13075
		..accept Time Yet Remains##13076
	step //232
		goto 79.8,71.8
		.talk Highlord Tirion Fordring##28179
		..turnin Time Yet Remains##13076
		..accept The Touch of an Aspect##13077
	step //233
		|fly Wyrmrest Temple
	step //234
		goto Dragonblight,57.9,54.2|n
		.talk Tariolstrasz##26443
		..'Tell him you need to go to the top of the temple|goto Dragonblight,59.7,53.1,0.1 |noway |c
	step //235
		goto 59.8,54.7
		.talk Alexstrasza the Life-Binder##26917
		..turnin The Touch of an Aspect##13077
		..accept Dahlia's Tears##13078
	step //236
		goto 59.5,53.3|n
		.talk Torastrasza##26949
		..'Tell him you want to go to the ground level of the temple |goto Dragonblight,58.0,55.2,0.1|noway|c
	step //237
		goto 43.2,51.7
		.' There should be a fight happening, so just wait around until the fight is over |tip If there isn't fight happening, just wait until the fighters spawn again, and there should be some red dragon Ruby Watchers flying above the fight.
		..' At the end of the fight, a Ruby Watcher will blow alot of fire on the ground and the Dahlia's Tears will spawn
		.click Dahlia's Tears##8329 
		..get Dahlia's Tears|q 13078/1
	step //238
		goto 57.9,54.2|n
		.talk Tariolstrasz##26443
		..'Tell him you need to go to the top of the temple |goto Dragonblight,59.7,53.1,0.1|noway|c
	step //239
		goto 59.8,54.7
		.talk Alexstrasza the Life-Binder##26917
		..turnin Dahlia's Tears##13078
		..accept The Boon of Alexstrasza##13079
	step //240
		goto 59.5,53.3|n
		.talk Torastrasza##26949
		..'Tell him you want to go to the ground level of the temple |goto Dragonblight,58.0,55.2,0.1|noway|c
	step //241
		|fly Crusaders' Pinnacle
	step //242
		goto 79.8,30.8
		.talk Crusader Bridenbrad##30562
		..turnin The Boon of Alexstrasza##13079
		..accept Hope Yet Remains##13080
	step //243
		goto 79.8,71.8
		.talk Highlord Tirion Fordring##28179
		..turnin Hope Yet Remains##13080
		..accept The Will of the Naaru##13081
	step //244
		.' Click the Portal to Shattrath that appears near you|goto Shattrath City|noway|c
	step //245
		goto Shattrath City,54,44.8
		.talk A'dal##18481
		..turnin The Will of the Naaru##13081
		..accept The Boon of A'dal##13082
	step //246
		goto Dalaran,72.2,45.8
		.talk Aludane Whitecloud##28674
		..' Fly to Crusaders' Pinnacle in Icecrown|goto Icecrown,79.3,72.3,0.5|noway|c
	step //247
		goto Icecrown,79.8,30.8
		.talk Crusader Bridenbrad##30562
		..turnin The Boon of A'dal##13082
	step //248
		goto 79.8,30.8
		.click Bridenbrad's Possessions##1 
		..accept Light Within the Darkness##13083
	step //249
		goto 79.8,71.8
		.talk Highlord Tirion Fordring##28179
		..turnin Light Within the Darkness##13083
	step //250
		'You should now be above honored with the _Argent Crusade_.
		.' The fastest way to continue to earn reputation with _Argent Crusade_ is to buy a tabard and run any dungeon that gives experience. 
		|confirm
	step //251
		goto Icecrown,87.5,75.6
		.talk Veteran Crusader Aliocha Segard##30431
		.buy 1 Tabard of the Argent Crusade##43154
	step //252
		.' Equip this Tabard in your bags |equipped Tabard of the Argent Crusade##43154 |use Tabard of the Argent Crusade##43154
		.' You can run any dungeon that grants experience to gain reputation for the Argent Crusade.
		.' Friendly with Argent Crusade |condition rep('Argent Crusade')>=Friendly
		.' Honored with Argent Crusade |condition rep('Argent Crusade')>=Honored
		.' Revered with Argent Crusade |condition rep('Argent Crusade')>=Revered
		.' Become Exalted with Argent Crusade |condition rep('Argent Crusade')==Exalted
	step //253
		'Congratulations! You are now Exalted with the _Argent Crusade_!
]])
--------------------------------------------------------------------------------------------------------------------------------------
-- Leveling Cataclysm
--------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------------
-- EVENTS
--------------------------------------------------------------------------------------------------------------------------------------
--Darkmoon Faire--
ZygorGuidesViewer:RegisterInclude("H_Darkmoon_Faire_Dailies",[[
	step //254
		|fly Thunder Bluff
	step //255
		goto Mulgore,36.8,35.8
		.click the Portal to Darkmoon Island
		.' Telport to Darkmoon Island |goto Darkmoon Island |noway |c
	step //256
		goto Darkmoon Island,56.0,52.9 |n
		.' Follow the Path to the Darkmoon Faire |goto Darkmoon Island,56.0,52.9,1 |noway |c
	step //257
		goto Darkmoon Island,54.3,53.1
		.talk Zina Sharpworth##55266
		.buy Sack o' Tokens##78909 |n
		.' Open your Sack o' Tokens in your bags |use Sack o' Tokens##78909
		.collect 20 Darkmoon Faire Game Tokens##71083
	step //258
		goto Darkmoon Island,53.3,54.4
		.talk Mola##54601
		..accept It's Hammer Time##29463 |daily
	step //259
		goto Darkmoon Island,53.3,54.4
		.talk Mola##54601
		.' Tell her:
		.' <Ready to whack!> |havebuff Interface\Icons\inv_hammer_32
	step //260
		.' Use the _Whack!_ on your bar and whack the Gnolls in the Barrels
		.' The Gnolls  will pop up in the Barrels, but be careful not to hit the _Doll_ or you will get stunned.
		.' Whack 30 Gnolls |q 29463/1
	step //261
		goto Darkmoon Island,53.3,54.4
		.talk Mola##54601
		..turnin It's Hammer Time##29463
	step //262
		goto Darkmoon Island,52.5,56.2
		.talk Maxima Blastenheimer##15303
		..accept The Humanoid Cannonball##29436 |daily
		|next "quest"
	step //263
	label	"target"
		goto Darkmoon Island,57.1,89.6
		.talk Teleportologist Fozlebub##57850
		.' Tell him:
		.' <Teleport me to the cannon.> |goto 52.7,56.0,1 |noway |c
	step //264
	label	"quest"
		goto Darkmoon Island,52.5,56.2
		.talk Maxima Blastenheimer##15303
		.' Tell her:
		.' <Launch me!>
		'Wait for the Cannon to Launch you |havebuff Interface\Icons\Spell_Magic_FeatherFall
	step //265
		goto Darkmoon Island,56.4,93.3
		.' You will be launched throught the air. 
		.' You the __ to drop in the water in the target. You will gain more points for getting closer to the middle.
		.' Earn 5 Target Points |q 29436/1
		.' Click here to try again |confirm |next "target"
	step //266
		goto Darkmoon Island,57.1,89.6
		.talk Teleportologist Fozlebub##57850
		.' Tell him:
		.' <Teleport me to the cannon.> |goto 52.7,56.0,1 |noway |c
	step //267
		goto Darkmoon Island,52.5,56.2
		.talk Maxima Blastenheimer##15303
		..turnin The Humanoid Cannonball##29436
	step //268
		goto 49.3,60.8
		.talk Rinling##14841
		..accept He Shoots, He Scores!##29438 |daily
	step //269
		goto 49.3,60.8
		.talk Rinling##14841	
		.' Tell him:
		.' <Let's shoot!> |havebuff Interface\Icons\INV_Weapon_Rifle_05
	step //270
		'Shoot at the 3 targets. 
		.' When you see a green marker appear over a target, make sure that you are aimed at it and _shoot_ |tip To aim, simply move the camera to face your current target.
		.' Shoot 25 Targets |q 29438/1
	step //271
		goto 49.3,60.8
		.talk Rinling##14841
		..turnin He Shoots, He Scores!##29438 |daily
	step //272
		goto Darkmoon Island,50.7,65.1
		.talk Finlay Coolshot##54605
		..accept Tonk Commander##29434 |daily
	step //273
		goto Darkmoon Island,50.7,65.1
		.talk Finlay Coolshot##54605
		.' Tell him:
		.' <Ready to Play.> |invehicle |c
	step //274
		'Use your _Cannon_ ability to shoot _Tonk Targets_.
		.from Tonk Target##33081+
		.' Destroy 30 Tonk Targets |q 29434/1
	step //275
		goto Darkmoon Island,50.7,65.1
		.talk Finlay Coolshot##54605
		..turnin Tonk Commander##29434
	step //276
		goto 51.6,77.8
		.talk Jessica Rogers##54485
		..accept Target: Turtle##29455 |daily
	step //277
		goto 51.6,77.8
		.talk Jessica Rogers##54485
		.' Tell her: 
		.' <Ready to play!> |havebuff Interface\Icons\INV_Jewelry_Ring_03
	step //278
		'Use your _Ring Toss_ ability to throw rings on the turtle.  |tip When aiming, move the marker over the middle of the turtle.
		.' Land 3 Rings on Dubenko |q 29455/1
		'|modelnpc 54490
	step //279
		goto 51.6,77.8
		.talk Jessica Rogers##54485
		..turnin Target: Turtle##29455
]])

ZygorGuidesViewer:RegisterInclude("H_Darkmoon_Faire_Quests",[[
	step //280
		|fly Thunder Bluff
	step //281
		goto Mulgore,36.8,35.8
		.click the Portal to Darkmoon Island
		.' Telport to Darkmoon Island |goto Darkmoon Island |noway |c
	step //282
		goto Darkmoon Island,56.0,52.9 |n
		.' Follow the Path to the Darkmoon Faire |goto Darkmoon Island,56.0,52.9,1 |noway |c
	step //283
		goto Darkmoon Island,49.3,60.8
		.talk Rinling##14841
		..accept Talkin' Tonks##29511
		|only if skill("Engineering")>74
	step //284
		goto Darkmoon Island,49.3,60.7
		.talk Rinling##14841
		..accept Rearm, Reuse, Recycle##29518
		|only if skill("Mining")>74
	step //285
		goto 49.3,60.9
		.talk Rinling##14841
		..accept Eyes on the Prizes##29517
		|only if skill("Leatherworking")>74
	step //286
		goto Darkmoon Island,52.9,68.0
		.talk Stamp Thunderhorn##14845
		..accept Putting the Crunch in the Frog##29509
		|only if skill("Cooking")>74
	step //287
		goto Darkmoon Island,52.9,68.0
		.talk Stamp Thunderhorn##14845		
		..accept Spoilin' for Salty Sea Dogs##29513
		|only if skill("Fishing")>74
	step //288
		goto Darkmoon Island,55.0,70.8
		.talk Chronos##14833
		..accept Putting the Carnies Back Together Again##29512
		|only if skill("First Aid")>74
	step //289
		goto Darkmoon Island,55.0,70.8
		.talk Chronos##14833
		..accept Tan My Hide##29519
		|only if skill("Skinning")>74
	step //290
		goto Darkmoon Island,55.0,70.8
		.talk Chronos##14833
		..accept Herbs for Healing##29514
		|only if skill("Herbalism")>74
	step //291
		goto 50.5,69.6
		.talk Sylannia##14844
		..accept A Fizzy Fusion##29506
		|only if skill("Alchemy")>74
	step //292
		goto 55.0,70.8
		.talk Chronos##14833
		..accept Keeping the Faire Sparkling##29516
		|only if skill("Jewelcrafting")>74
	step //293
		goto Darkmoon Island,53.2,75.8
		.talk Sayge##14822
		..accept Putting Trash to Good Use##29510
		|only if skill("Enchanting")>74
	step //294
		goto Darkmoon Island,51.1,82.0
		.talk Yebb Neblegear##14829
		..accept Baby Needs Two Pair of Shoes##29508
		|only if skill("Blacksmithing")>74
	step //295
		goto 52.5,88.7
		.buy Fishing Pole##6256
		|only if skill("Fishing")>74
	step //296
		goto Darkmoon Island,51.7,91.6
		.' Equip your Fishing Pole |equipped Fishing Pole##6256 |use Fishing Pole##6256 |q 29513
		.' Use your Fishing ability to catch _Sea Herrings_ |cast Fishing##7620
		.' Catch 5 Great Sea Herring |q 29513/1
		|only if skill("Fishing")>74
	step //297
		goto Darkmoon Island,47.9,74.5
		.' Use your Darkmoon Bandage on Injured Carnies |use Darkmoon Bandage##71978
		.' Heal 4 Injured Carnies |q 29512/1
		'|modelnpc 54518
		|only if skill("First Aid")>74
	step //298
		'All around the Island
		.' Click Discarded Weapons
		.collect 6 Discarded Weapon##72018 |n
		.' Disenchant the Discarded Weapons |use Discarded Weapon##72018
		.' Collect 6 Soothsayer's Dust |q 28825/1
		|modeldisplay Discarded Weapon##10777
	step //299
		'All around the Island
		.click Tonk Scrap##6314
		.' Collect 6 pieces of Tonk Scrap |q 29518/1
		|only if skill("Mining")>74
		'|model 7975
	step //300
		'All around the Island
		.click Bits of Glass##238
		.collect 5 Bits of Glass##72052 |n
		.' Click the Bits of Glass in your bags |use Bit of Glass##72052
		.' Make 5 Sparkling Gemstones |q 29516/1
		|only if skill("Jewelcrafting")>74
	step //301
		.' All around the Island
		.' Use your Battered Wrench to repair Damaged Tonk's |use Battered Wrench##72110
		.' Repair 5 Damaged Tonk's |q 29511/1
		'|modelnpc 54504
		|only if skill("Engineering")>74
	step //302
		.' All around the Island
		.click Darkblossom##209284
		.' Gather 6 Darkblossom |q 29514/1
		|only if skill("Herbalism")>74
	step //303
		.' All around the Island
		.' Click Staked Skins
		.' Scrape 4 Staked Skins |q 29519/1
		|modeldisplay Staked Skins##10750
	step //304
		goto 50.5,69.6
		.talk Sylannia##14844
		.buy 5 Fizzy Faire Drink##19299 |q 29506
		|only if skill("Alchemy")>74
	step //305
		goto Darkmoon Island,50.5,90.8
		.click Portal to Mulgore##4397
		.' Teleport to Mulgore |goto Mulgore |noway |c
		|only if skill("Cooking")>74
	step //306
		goto Darkmoon Island,50.5,90.8
		.click Portal to Mulgore##4397
		.' Teleport to Mulgore |goto Mulgore |noway |c
		|only if skill("Alchemy")>74
	step //307
		goto Mulgore,46.8,60.4
		.talk Innkeeper Kauth##6747
		.buy 5 Moonberry Juice##1645 |q 29506
		|only if skill("Alchemy")>74
	step //308
		goto Mulgore,46.4,57.8
		.talk Wunna Darkmane##3081
		.buy 5 Simple Flour##30817 |q 29509
		|only if skill("Cooking")>74
	step //309
		goto Mulgore,36.8,35.8
		.click Portal to Darkmoon Island
		.' Telport to Darkmoon Island |goto Darkmoon Island |noway |c
		|only if skill("Cooking")>74
	step //310
		goto Mulgore,36.8,35.8
		.click Portal to Darkmoon Island
		.' Telport to Darkmoon Island |goto Darkmoon Island |noway |c
		|only if skill("Alchemy")>74
	step //311
		goto Darkmoon Island,56.0,52.9 |n
		.' Follow the Path to the Darkmoon Faire |goto Darkmoon Island,56.0,52.9,1 |noway |c
		|only if skill("Cooking")>74
	step //312
		goto Darkmoon Island,56.0,52.9 |n
		.' Follow the Path to the Darkmoon Faire |goto Darkmoon Island,56.0,52.9,1 |noway |c
		|only if skill("Alchemy")>74
	step //313
		goto Darkmoon Island,50.4,69.5
		.' Use the Cocktail Shaker in your bags to make Moonberry Fizz |use Cocktail Shaker##72043
		.' Create 5 Sevings of Moonberry Fizz |q 29506/1
		|only if skill("Alchemy")>74
	step //314
		goto Darkmoon Island,52.7,68.1
		.' Click the Plump Frogs in your bags |use Plump Frogs##72056
		.collect 5 Breaded Frog##72057 |n
		.' Throw the Breaded Frogs in the cauldron |use Breaded Frog##72057
		.' Fry 5 Crunchy Frogs |q 29509/1
		|only if skill("Cooking")>74
	step //315
		goto 55.3,71.7
		.' Use the Iron Stock in your bags to make Horseshoes |use Iron Stock##71964
		.collect 4 Horseshoes##71967 |q 29508
		|only if skill("Blacksmithing")>74
	step //316
		goto Darkmoon Island,52.9,68.0
		.talk Stamp Thunderhorn##14845
		..turnin Putting the Crunch in the Frog##29509
		|only if skill("Cooking")>74
	step //317
		goto Darkmoon Island,52.9,68.0
		.talk Stamp Thunderhorn##14845		
		..turnin Spoilin' for Salty Sea Dogs##29513
		|only if skill("Fishing")>74
	step //318
		goto Darkmoon Island,55.0,70.8
		.talk Chronos##14833
		..turnin Putting the Carnies Back Together Again##29512
		|only if skill("First Aid")>74
	step //319
		goto Darkmoon Island,55.0,70.8
		.talk Chronos##14833
		..accept Tan My Hide##29519
		|only if skill("Skinning")>74
	step //320
		goto 55.0,70.8
		.talk Chronos##14833
		..turnin Keeping the Faire Sparkling##29516
		|only if skill("Jewelcrafting")>74
	step //321
		goto Darkmoon Island,49.3,60.8
		.talk Rinling##14841
		..turnin Talkin' Tonks##29511
		|only if skill("Engineering")>74
	step //322
		goto Darkmoon Island,55.0,70.8
		.talk Chronos##14833
		..turnin Herbs for Healing##29514
		|only if skill("Herbalism")>74
	step //323
		goto 50.5,69.6
		.talk Sylannia##14844
		..turnin A Fizzy Fusion##29506
		|only if skill("Alchemy")>74
	step //324
		goto Darkmoon Island,49.3,60.7
		.talk Rinling##14841
		..accept Rearm, Reuse, Recycle##29518
		|only if skill("Mining")>74
	step //325
		goto Darkmoon Island,53.2,75.8
		.talk Sayge##14822
		..accept Putting Trash to Good Use##29510
		|only if skill("Enchanting")>74
	step //326
		goto Darkmoon Island,51.3,81.8
		.' Use the Horshoes in your bag on Baby|use Horseshoe##71967
		.' Put New Horshoes On Baby |q 29508/1
		|only if skill("Blacksmithing")>74
		'|modelnpc 54510
	step //327
		goto Darkmoon Island,51.1,82.0
		.talk Yebb Neblegear##14829
		..turnin Baby Needs Two Pair of Shoes##29508
		|only if skill("Blacksmithing")>74
	step //328
		goto Darkmoon Island,47.9,67.1
		.talk Kerri Hicks##14832
		..accept Test Your Strength##29433
	step //329
		goto Darkmoon Island,55.6,55.0
		.talk Selina Dourman##10445
		.' Tell her:
		.' <Darkmoon Adventurer's Guide?>
		.collect Darkmoon Adventurer's Guide##71634 |q 29433
	step //330
		.' Kill any Creature Player or NPC that gives _experiance or honor_ to gain Grisly Trophy's |tip You need to leave Darkmoon Island to find anything to kill.
		.' Collect 250 Grisly Trophy's |q 29433/1
	step //331
		goto Mulgore,36.8,35.8
		.click the Portal to Darkmoon Island
		.' Telport to Darkmoon Island |goto Darkmoon Island |noway |c
	step //332
		goto Darkmoon Island,56.0,52.9 |n
		.' Follow the Path to the Darkmoon Faire |goto Darkmoon Island,56.0,52.9,1 |noway |c
	step //333
		goto Darkmoon Island,47.9,67.1
		.talk Kerri Hicks##14832
		..turnin Test Your Strength##29433
]])

ZygorGuidesViewer:RegisterInclude("H_Darkmoon_Faire_Achievements",[[
	step //334
	label	"main"
		'To earn Achievements for the Darkmoon Faire, you will need to complete Dailies, Quests and other things. 
		.' Click here to do the Dailies Achievments |confirm always |next "dailies" |or
		.' or
		.' Click here to do the Profession Quests Achievements |confirm always |next "professions" |or
		.' or
		.' Click here for the Non-Questing Achievements |confirm always |next "no_quest" |or
	step //335
	label	"dailies"
		'You have earned the Achievement Bullseye! |achieve 6021 |only if achieved(6021)
		.' You still need to earn the Achievement Bullseye! |achieve 6021 |only if not achieved(6021)
		.' You have earned the Achievement Quick Shot! |achieve 6022 |only if achieved(6022)
		.' You still need to earn the Achievement Quick Shot! |achieve 6022 |only if not achieved(6022)
		.' You have earned the Achievement Step Right Up! |achieve 6020 |only if achieved(6020)
		.' You still need to earn the Achievement Step Right Up! |achieve 6020 |only if not achieved(6020)
		|confirm always
	step //336
		|fly Thunder Bluff
	step //337
		goto Mulgore,36.8,35.8
		.click the Portal to Darkmoon Island
		.' Telport to Darkmoon Island |goto Darkmoon Island |noway |c
	step //338
		goto Darkmoon Island,56.0,52.9 |n
		.' Follow the Path to the Darkmoon Faire |goto Darkmoon Island,56.0,52.9,1 |noway |c
	step //339
		goto Darkmoon Island,54.3,53.1
		.talk Zina Sharpworth##55266
		.buy Sack o' Tokens##78909 |n
		.' Open your Sack o' Tokens in your bags |use Sack o' Tokens##78909
		.collect 20 Darkmoon Faire Game Tokens##71083
	step //340
		goto Darkmoon Island,53.3,54.4
		.talk Mola##54601
		..accept It's Hammer Time##29463 |daily
	step //341
		goto Darkmoon Island,53.3,54.4
		.talk Mola##54601
		.' Tell her:
		.' <Ready to whack!> |havebuff Interface\Icons\inv_hammer_32
	step //342
		.' Use the _Whack!_ on your bar and whack the Gnolls in the Barrels
		.' The Gnolls  will pop up in the Barrels, but be careful not to hit the _Doll_ or you will get stunned.
		.' Whack 30 Gnolls |q 29463/1
	step //343
		goto Darkmoon Island,53.3,54.4
		.talk Mola##54601
		..turnin It's Hammer Time##29463
	step //344
		goto Darkmoon Island,52.5,56.2
		.talk Maxima Blastenheimer##15303
		..accept The Humanoid Cannonball##29436 |daily
		|next "quest"
	step //345
	label	"target"
		goto Darkmoon Island,57.1,89.6
		.talk Teleportologist Fozlebub##57850
		.' Tell him:
		.' <Teleport me to the cannon.> |goto 52.7,56.0,1 |noway |c
	step //346
	label	"quest"
		goto Darkmoon Island,52.5,56.2
		.talk Maxima Blastenheimer##15303
		.' Tell her:
		.' <Launch me!>
		'Wait for the Cannon to Launch you |havebuff Interface\Icons\Spell_Magic_FeatherFall
	step //347
		goto Darkmoon Island,56.4,93.3
		.' You will be launched throught the air. 
		.' You the __ to drop in the water in the target. You will gain more points for getting closer to the middle.
		.' Earn 5 Target Points |q 29436/1
		.' Score a Bullseye by landing in the middle of the target
		.' Earn the Achievement Bullseye! |achieve 6021
		.' Click here to try again |confirm |next "target"
	step //348
		goto Darkmoon Island,57.1,89.6
		.talk Teleportologist Fozlebub##57850
		.' Tell him:
		.' <Teleport me to the cannon.> |goto 52.7,56.0,1 |noway |c
	step //349
		goto Darkmoon Island,52.5,56.2
		.talk Maxima Blastenheimer##15303
		..turnin The Humanoid Cannonball##29436
	step //350
		goto 49.3,60.8
		.talk Rinling##14841
		..accept He Shoots, He Scores!##29438 |daily
	step //351
		goto 49.3,60.8
		.talk Rinling##14841	
		.' Tell him:
		.' <Let's shoot!> |havebuff Interface\Icons\INV_Weapon_Rifle_05
	step //352
		'Shoot at the 3 targets. 
		.' When you see a green marker appear over a target, make sure that you are aimed at it and _shoot_ |tip To aim, simply move the camera to face your current target.
		.' Shoot 25 Targets |q 29438/1
		.' Shoot your gunt and hit a target very fast
		.' Earn the Achievement Quick Shot! |achieve 6022
	step //353
		goto 49.3,60.8
		.talk Rinling##14841
		..turnin He Shoots, He Scores!##29438 |daily
	step //354
		goto Darkmoon Island,50.7,65.1
		.talk Finlay Coolshot##54605
		..accept Tonk Commander##29434 |daily
	step //355
		goto Darkmoon Island,50.7,65.1
		.talk Finlay Coolshot##54605
		.' Tell him:
		.' <Ready to Play.> |invehicle |c
	step //356
		'Use your _Cannon_ ability to shoot _Tonk Targets_.
		.from Tonk Target##33081+
		.' Destroy 30 Tonk Targets |q 29434/1
	step //357
		goto Darkmoon Island,50.7,65.1
		.talk Finlay Coolshot##54605
		..turnin Tonk Commander##29434
	step //358
		goto 51.6,77.8
		.talk Jessica Rogers##54485
		..accept Target: Turtle##29455 |daily
	step //359
		goto 51.6,77.8
		.talk Jessica Rogers##54485
		.' Tell her: 
		.' <Ready to play!> |havebuff Interface\Icons\INV_Jewelry_Ring_03
	step //360
		'Use your _Ring Toss_ ability to throw rings on the turtle.  |tip When aiming, move the marker over the middle of the turtle.
		.' Land 3 Rings on Dubenko |q 29455/1
		.' Earn the Achievement Step Right Up! |achieve 6020
		'|modelnpc 54490
	step //361
		goto 51.6,77.8
		.talk Jessica Rogers##54485
		..turnin Target: Turtle##29455
		|next "main"
	step //362
	label	"professions"
		'You have earned the Achievement Faire Favors |achieve 6032 |only if achieved(6032)
		.' You still need to earn the Achievement Faire Favors |achieve 6032 |only if not achieved(6032)
		.' You have earned the Achievement Darkmoon Dungeoneer |achieve 6027 |only if achieved(6027)
		.' You still need to earn the Achievement Darkmoon Dungeoneer |achieve 6027 |only if not achieved(6027)
		.' You have earned the Achievement Darkmoon Defender |achieve 6028 |only if achieved(6028)
		.' You still need to earn the Achievement Darkmoon Defender |achieve 6028 |only if not achieved(6028)
		.' You have earned the Achievement Darkmoon Despoiler |achieve 6029 |only if achieved(6029)
		.' You still need to earn the Achievement Darkmoon Despoiler |achieve 6029 |only if not achieved(6029)   
		|confirm always
	step //363
		|fly Thunder Bluff
	step //364
		goto Mulgore,36.8,35.8
		.click the Portal to Darkmoon Island
		.' Telport to Darkmoon Island |goto Darkmoon Island |noway |c
	step //365
		goto Darkmoon Island,56.0,52.9 |n
		.' Follow the Path to the Darkmoon Faire |goto Darkmoon Island,56.0,52.9,1 |noway |c
	step //366
		goto Darkmoon Island,51.9,60.9
		.talk Professor Thaddeus Paleo##14847
		..accept Fun for the Little Ones##29507
		|only if skill("Archaeology")>74
	step //367
		goto Darkmoon Island,49.3,60.8
		.talk Rinling##14841
		..accept Talkin' Tonks##29511
		|only if skill("Engineering")>74
	step //368
		goto Darkmoon Island,49.3,60.7
		.talk Rinling##14841
		..accept Rearm, Reuse, Recycle##29518
		|only if skill("Mining")>74
	step //369
		goto 49.3,60.9
		.talk Rinling##14841
		..accept Eyes on the Prizes##29517
		|only if skill("Leatherworking")>74
	step //370
		goto Darkmoon Island,52.9,68.0
		.talk Stamp Thunderhorn##14845
		..accept Putting the Crunch in the Frog##29509
		|only if skill("Cooking")>74
	step //371
		goto Darkmoon Island,52.9,68.0
		.talk Stamp Thunderhorn##14845		
		..accept Spoilin' for Salty Sea Dogs##29513
		|only if skill("Fishing")>74
	step //372
		goto Darkmoon Island,55.0,70.8
		.talk Chronos##14833
		..accept Putting the Carnies Back Together Again##29512
		|only if skill("First Aid")>74
	step //373
		goto Darkmoon Island,55.0,70.8
		.talk Chronos##14833
		..accept Tan My Hide##29519
		|only if skill("Skinning")>74
	step //374
		goto Darkmoon Island,55.0,70.8
		.talk Chronos##14833
		..accept Herbs for Healing##29514
		|only if skill("Herbalism")>74
	step //375
		goto 50.5,69.6
		.talk Sylannia##14844
		..accept A Fizzy Fusion##29506
		|only if skill("Alchemy")>74
	step //376
		goto 55.0,70.8
		.talk Chronos##14833
		..accept Keeping the Faire Sparkling##29516
		|only if skill("Jewelcrafting")>74
	step //377
		goto Darkmoon Island,53.2,75.8
		.talk Sayge##14822
		..accept Putting Trash to Good Use##29510
		|only if skill("Enchanting")>74
	step //378
		goto Darkmoon Island,51.1,82.0
		.talk Yebb Neblegear##14829
		..accept Baby Needs Two Pair of Shoes##29508
		|only if skill("Blacksmithing")>74
	step //379
		goto 52.5,88.7
		.buy Fishing Pole##6256
		|only if skill("Fishing")>74
	step //380
		goto Darkmoon Island,51.7,91.6
		.' Equip your Fishing Pole |equipped Fishing Pole##6256 |use Fishing Pole##6256 |q 29513
		.' Use your Fishing ability to catch _Sea Herrings_ |cast Fishing##7620
		.' Catch 5 Great Sea Herring |q 29513/1
		|only if skill("Fishing")>74
	step //381
		goto Darkmoon Island,47.9,74.5
		.' Use your Darkmoon Bandage on Injured Carnies |use Darkmoon Bandage##71978
		.' Heal 4 Injured Carnies |q 29512/1
		'|modelnpc 54518
		|only if skill("First Aid")>74
	step //382
		'All around the Island
		.click Discarded Weapon##10777+
		.collect 6 Discarded Weapon##72018 |n
		.' Disenchant the Discarded Weapons |use Discarded Weapon##72018
		.' Collect 6 Soothsayer's Dust |q 28825/1
	step //383
		'All around the Island
		.click Tonk Scrap##6314
		.' Collect 6 pieces of Tonk Scrap |q 29518/1
		|only if skill("Mining")>74
		'|model 7975
	step //384
		'All around the Island
		.click Bits of Glass##238
		.collect 5 Bits of Glass##72052 |n
		.' Click the Bits of Glass in your bags |use Bit of Glass##72052
		.' Make 5 Sparkling Gemstones |q 29516/1
		|only if skill("Jewelcrafting")>74
	step //385
		.' All around the Island
		.' Use your Battered Wrench to repair Damaged Tonk's |use Battered Wrench##72110
		.' Repair 5 Damaged Tonk's |q 29511/1
		'|modelnpc 54504
		|only if skill("Engineering")>74
	step //386
		.' All around the Island
		.click Darkblossom##209284
		.' Gather 6 Darkblossom |q 29514/1
		|only if skill("Herbalism")>74
	step //387
		.' All around the Island
		.click Staked Skins##10750
		.' Scrape 4 Staked Skins |q 29519/1
	step //388
		goto 50.5,69.6
		.talk Sylannia##14844
		.buy 5 Fizzy Faire Drink##19299 |q 29506
		|only if skill("Alchemy")>74
	step //389
		goto Darkmoon Island,50.5,90.8
		.click Portal to Mulgore##4397
		.' Teleport to Mulgore |goto Mulgore |noway |c
		|only if skill("Cooking")>74 or skill("Alchemy")>74 or skill("Archaeology")>74
	step //390
		'Open your world map, find dig sites in Kalimdor and go to them |tip They look like small shovel icons on your world map that spawn in random places.  Once you get to the zone where the dig site is located, you will see the dig site on your map as a red highlighted area.
		.' You can find _Fossil Fragments_ in these locations: 
		.' Desolace
		.' Dustwallow Marsh
		.' Stonetalon Mountains
		.' Southern Barrens
		.' Tanaris
		.' Un'Goro Crater
		.' Use your Survey ability inside the dig site area and follow the Telesope until you find a fragment |cast Survey##80451
		.earn 15 Fossil Fragments##393 |q 29507
		|only if skill("Archaeology")>74
	step //391
		goto Darkmoon Island,50.5,90.8
		.click Portal to Mulgore##4397
		.' Teleport to Mulgore |goto Mulgore |noway |c
		|only if skill("Alchemy")>74
	step //392
		goto Mulgore,46.8,60.4
		.talk Innkeeper Kauth##6747
		.buy 5 Moonberry Juice##1645 |q 29506
		|only if skill("Alchemy")>74
	step //393
		goto Mulgore,46.4,57.8
		.talk Wunna Darkmane##3081
		.buy 5 Simple Flour##30817 |q 29509
		|only if skill("Cooking")>74
	step //394
		goto Mulgore,36.8,35.8
		.click Portal to Darkmoon Island
		.' Telport to Darkmoon Island |goto Darkmoon Island |noway |c
		|only if skill("Cooking")>74 or skill("Alchemy")>74 or skill("Archaeology")>74
	step //395
		goto Darkmoon Island,56.0,52.9 |n
		.' Follow the Path to the Darkmoon Faire |goto Darkmoon Island,56.0,52.9,1 |noway |c
		|only if skill("Cooking")>74 or skill("Alchemy")>74 or skill("Archaeology")>74
	step //396
		goto Darkmoon Island,50.4,69.5
		.' Use the Cocktail Shaker in your bags to make Moonberry Fizz |use Cocktail Shaker##72043
		.' Create 5 Sevings of Moonberry Fizz |q 29506/1
		|only if skill("Alchemy")>74
	step //397
		goto Darkmoon Island,52.7,68.1
		.' Click the Plump Frogs in your bags |use Plump Frogs##72056
		.collect 5 Breaded Frog##72057 |n
		.' Throw the Breaded Frogs in the cauldron |use Breaded Frog##72057
		.' Fry 5 Crunchy Frogs |q 29509/1
		|only if skill("Cooking")>74
	step //398
		goto 55.3,71.7
		.' Use the Iron Stock in your bags to make Horseshoes |use Iron Stock##71964
		.collect 4 Horseshoes##71967 |q 29508
		|only if skill("Blacksmithing")>74
	step //399
		goto Darkmoon Island,51.9,60.9
		.talk Professor Thaddeus Paleo##14847
		..turnin Fun for the Little Ones##29507
		|only if skill("Archaeology")>74
	step //400
		goto Darkmoon Island,52.9,68.0
		.talk Stamp Thunderhorn##14845
		..turnin Putting the Crunch in the Frog##29509
		|only if skill("Cooking")>74
	step //401
		goto Darkmoon Island,52.9,68.0
		.talk Stamp Thunderhorn##14845		
		..turnin Spoilin' for Salty Sea Dogs##29513
		|only if skill("Fishing")>74
	step //402
		goto Darkmoon Island,55.0,70.8
		.talk Chronos##14833
		..turnin Putting the Carnies Back Together Again##29512
		|only if skill("First Aid")>74
	step //403
		goto Darkmoon Island,55.0,70.8
		.talk Chronos##14833
		..accept Tan My Hide##29519
		|only if skill("Skinning")>74
	step //404
		goto 55.0,70.8
		.talk Chronos##14833
		..turnin Keeping the Faire Sparkling##29516
		|only if skill("Jewelcrafting")>74
	step //405
		goto Darkmoon Island,49.3,60.8
		.talk Rinling##14841
		..turnin Talkin' Tonks##29511
		|only if skill("Engineering")>74
	step //406
		goto Darkmoon Island,55.0,70.8
		.talk Chronos##14833
		..turnin Herbs for Healing##29514
		|only if skill("Herbalism")>74
	step //407
		goto 50.5,69.6
		.talk Sylannia##14844
		..turnin A Fizzy Fusion##29506
		|only if skill("Alchemy")>74
	step //408
		goto Darkmoon Island,49.3,60.7
		.talk Rinling##14841
		..accept Rearm, Reuse, Recycle##29518
		|only if skill("Mining")>74
	step //409
		goto Darkmoon Island,53.2,75.8
		.talk Sayge##14822
		..accept Putting Trash to Good Use##29510
		|only if skill("Enchanting")>74
	step //410
		goto Darkmoon Island,51.3,81.8
		.' Use the Horshoes in your bag on Baby|use Horseshoe##71967
		.' Put New Horshoes On Baby |q 29508/1
		|only if skill("Blacksmithing")>74
		'|modelnpc 54510
	step //411
		goto Darkmoon Island,51.1,82.0
		.talk Yebb Neblegear##14829
		..turnin Baby Needs Two Pair of Shoes##29508
		|only if skill("Blacksmithing")>74
	step //412
		goto Darkmoon Island,47.9,67.1
		.talk Kerri Hicks##14832
		..accept Test Your Strength##29433
	step //413
		goto Darkmoon Island,55.6,55.0
		.talk Selina Dourman##10445
		.' Tell her:
		.' <Darkmoon Adventurer's Guide?>
		.collect Darkmoon Adventurer's Guide##71634 |q 29433
	step //414
		'These next 3 items have to be _obtained from Battlegrounds_
		.' When you kill an opponent, _loot_ their body for a chance to get _each item_.
		.collect Adventurer's Journal##71953 |n
		.accept The Captured Journal##29458 |use Adventurer's Journal##71953
		.collect Banner of the Fallen##71951 |n
		.accept A Captured Banner##29456 |use Banner of the Fallen##71951
		.collect Captured Insignia##71952 |n
		.accept The Enemy's Insignia##29457 |use Captured Insignia##71952
	step //415
		'These next 4 items have to be _obtained from Dungeons_ listed below
		.collect Mysterious Grimoire##71637 |n |tip You can get this in Zul'Farrak from Hydromancer Velratha
		..accept An Inriguing Grimoire##29445 |use Mysterious Grimoire##71637
		.collect Monstrous Egg##71636 |n |tip You can get this in Zul'Farrak from Gahz'rilla
		..accept An Exotic Egg##29444 |use Monstrous Egg##71636
		.collect A Treatise on Strategy##7175 |n |tip You can get this in Grim Batol from General Umbriss
		..accept The Master Strategist##29451 |use A Treatise on Strategy##7175
		.collect Ornate Weapon##71638 |n |tip You can get this in Scarlet Monastery from Herod
		..accept A Wondrous Weapon##29446 |use Ornate Weapon##71638
		.collect Imbued Crystal##71635 |n |tip You can get this in Scarlet Monastery from High Inquisitor Whitemane
		..accept A Curious Crystal##29443 |use Imbued Crystal##71635
	step //416
		'The next item can only be obtained from any 10 man Cataclysm Raid Boss
		.collect Soothsayer's Runes##71716 |n
		..accept Tools of Divination##29464 |use Soothsayer's Runes##71716
	step //417
		.' Kill any Creature Player or NPC that gives _experiance or honor_ to gain Grisly Trophy's |tip You need to leave Darkmoon Island to find anything to kill.
		.' Collect 250 Grisly Trophy's |q 29433/1
	step //418
		goto Darkmoon Island,47.9,67.1
		.talk Kerri Hicks##14832
		..turnin Test Your Strength##29433
	step //419
		goto Darkmoon Island,51.9,60.9
		.talk Professor Thaddeus Paleo##14847
		..turnin The Captured Journal##29458
		..turnin A Captured Banner##29456
		..turnin The Enemy's Insignia##29457
		..turnin An Inriguing Grimoire##29445
		..turnin An Exotic Egg##29444
		..turnin The Master Strategist##29451
		..turnin A Wondrous Weapon##29446
		..turnin A Curious Crystal##29443
		..turnin Tools of Divination##29464
		.' Earn the Achievement Darkmoon Dungeoneer |achieve 6027
		.' Earn the Achievement Darkmoon Defender |achieve 6028
		.' Earn the Achievement Darkmoon Despoiler |achieve 6029
		|next "main"
	step //420
	label	"no_quest"
		'You have earned the Achievement Darkmoon Duelist! |achieve 6023 |only if achieved(6023)
		.' You still need to earn the Achievement Darkmoon Duelist! |achieve 6023 |only if not achieved(6023)
		'You have earned the Achievement Fairegoer's Feast! |achieve 6026 |only if achieved(6026)
		.' You still need to earn the Achievement Fairegoer's Feast! |achieve 6026 |only if not achieved(6026)
		'You have earned the Achievement Taking the Show on the Road! |achieve 6031 |only if achieved(6031)
		.' You still need to earn the Taking the Show on the Road! |achieve 6031 |only if not achieved(6031)
		'You have earned the Achievement I Was Promised a Pony! |achieve 6025 |only if achieved(6025)
		.' You still need to earn the I Was Promised a Pony! |achieve 6025 |only if not achieved(6025)    
		|confirm always
	step //421
		goto Darkmoon Island,50.5,69.5
		.talk Sylannia##14844
		.buy Cheap Beer##19222 |n
		.' Drink Cheap Beer |achieve 6026/12 |use Cheap Beer##19222
		.buy Darkmoon Special Reserve##19221 |n
		.' Drink Darkmoon Special Reserve |achieve 6026/13 |use Special Reserve##19221
		.buy Fizzy Faire Drink##19299 |n
		.' Drink Fizzy Faire Drink |achieve 6026/14 |use Fizzy Faire Drink##19299
		.buy Bottled Winterspring Water##19300 |n
		.' Drink Bottled Winterspring Water |achieve 6026/11 |use Bottled Winterspring Water##19300
		.buy Iced Berry Slush##33234 |n
		.' Drink Iced Berry Slush |achieve 6026/17 |use Iced Berry Slush##33234
		.buy Fizzy Faire Drink "Classic"##33236 |n
		.' Drink Fizzy Faire Drink "Classic" |achieve 6026/15 |use Fizzy Faire Drink "Classic"##33236
		.buy Fresh-Squeezed Limeade##44941 |n
		.' Drink Fresh-Squeezed Limeade |achieve 6026/16 |use Fresh-Squeezed Limeade##44941
		.buy Sasparilla Sinker##74822 |n
		.' Drink Sasparilla Sinker |achieve 6026/18 |use Sasparilla Sinker##74822
	step //422
		goto Darkmoon Island,52.8,68.0
		.talk Stamp Thunderhorn##14845
		.buy Darkmoon Dog##19223 |n
		.' Eat Darkmoon Dog |achieve 6026/3 |use Darkmoon Dog##19223
		.buy Spiced Beef Jerky##19304 |n
		.' Eat Spiced Beef Jerky |achieve 6026/10 |use Spiced Beef Jerky##19304
		.buy Pickled Kodo Foot##19305 |n
		.' Eat Pickled Kodo Foot |achieve 6026/7 |use Pickled Kodo Foot##19305
		.buy Red Hot Wings##19224 |n
		.' Eat Red Hot Wings |achieve 6026/8 |use Red Hot Wings##19224
		.buy Crunchy Frog##19306 |n
		.' Eat Crunchy Frog |achieve 6026/2 |use Crunchy Frog##19306
		.buy Deep Fried Candybar##19225 |n
		.' Eat Deep Fried Candybar |achieve 6026/4 |use Deep Fried Candybar##19225
		.buy Funnel Cake##33246 |n
		.' Eat Funnel Cake |achieve 6026/6 |use Funnel Cake##33246 
		.buy Forest Strider Drumstick##33254 |n
		.' Eat Forest Strider Drumstick |achieve 6026/5 |use Forest Strider Drumstick##33254
		.buy Corn-Breaded Sausage##44940 |n
		.' Eat Corn-Breaded Sausage |achieve 6026/1 |use Corn-Breaded Sausage##44940
		.buy Salty Sea Dog##73260 |n
		.' Eat Salty Sea Dog |achieve 6026/9 |use Salty Sea Dog##73260
		.' Earn the Achievement Fairegoer's Feast |achieve 6026
	step //423
		goto Darkmoon Island,56.8,81.4
		.clicknpc Darkmoon Pony##55715
		.' Earn the Achievement I Was Promised a Pony |achieve 6025
	step //424
		goto Darkmoon Island,48.4,71.9
		.talk Boomie Sparks##55278
		.buy 6 Darkmoon Firework##74142 |future |achieve 6031
	step //425
		goto Darkmoon Island,50.5,90.8
		.click Portal to Mulgore##4397
		.' Teleport to Mulgore |goto Mulgore |noway |c
	step //426
		goto Thunder Bluff,32.2,67.0
		.' Use your Darkmoon Firework |achieve 6031/5 |use Darkmoon Firework##74142
	step //427
		|fly Orgrimmar
	step //428
		goto Orgrimmar,49.2,59.3
		.' Use your Darkmoon Firework |achieve 6031/2 |use Darkmoon Firework##74142
	step //429
		#include "rideto_tirisfal"
	step //430
		goto Undercity,66.3,2.2
		.' Use your Darkmoon Firework |achieve 6031/6 |use Darkmoon Firework##74142
	step //431
		goto Tirisfal Glades,59.5,67.5
		.click Orb of Translocation##7161
		.' Teleport to Silvermoon City |goto Silvermoon City |noway |c
	step //432
		goto Silvermoon City,50.7,16.4
		.' Use your Darkmoon Firework |achieve 6031/4 |use Darkmoon Firework##74142	
	step //433
		goto Silvermoon City,49.5,14.8
		.click Orb of Translocation##7161
		.' Teleport to Undercity |goto Tirisfal Glades |noway |c
	step //434
		goto Tirisfal Glades,59.1,59.0 |n
		.' Ride the Zeplin to Howling Fjord |goto Howling Fjord |noway |c
	step //435
		|fly Dalaran
	step //436
		goto Dalaran,72.5,45.5
		.' Use your Darkmoon Firework |achieve 6031/1 |use Darkmoon Firework##74142
	step //437
		goto Dalaran,55.4,25.5
		.click Dalaran Portal to Orgrimmar##04395
		.' Teleport to Orgrimmar |goto Orgrimmar/2 |noway |c
	step //438
		goto Orgrimmar/2,44.8,67.7
		.click Portal to Blasted Lands##08948
		.' Teleport to Blasted Lands |goto Blasted Lands |noway |c
	step //439
		 goto Blasted Lands,55.0,54.4
		 .' Go through the Green Portal
		 .' Teleport to Hellfire Peninsula |goto Hellfire Peninsula |noway |c
	step //440
		|fly Shattrath
	step //441
		goto Shattrath City,63.8,41.7
		.' Use your Darkmoon Firework |achieve 6031/3 |use Darkmoon Firework##74142
		.' Earn the Achievement Taking the Show on the Road! |achieve 6031
	step //442
		goto Shattrath City,56.8,48.9
		.click Dalaran Portal to Orgrimmar##04395
		.' Teleport to Orgrimmar |goto Orgrimmar/2 |noway |c
	step //443
		|fly Thunder Bluff
	step //444
		goto Mulgore,36.8,35.8
		.click the Portal to Darkmoon Island
		.' Telport to Darkmoon Island |goto Darkmoon Island |noway |c
	step //445
		goto Darkmoon Island,56.0,52.9 |n
		.' Follow the Path to the Darkmoon Faire |goto Darkmoon Island,56.0,52.9,1 |noway |c
	step //446
		goto Darkmoon Island,46.8,78.8
		.' Click Darkmoon Deathmatch Gate and enter the Deathmatch Arena
		.' Once inside, you will need to fight anyone inside, if you win, you will earn an achievement.
		.' Earn the Achievement Darkmoon Duelist! |achieve 6023
		.' Deafeat 12 combatants in the Deathmatch Arena
		.' Earn the Achievement Darkmoon Dominator |achieve 6024
]])

-- Lunar Festival --
ZygorGuidesViewer:RegisterInclude("H_Lunar_Festival_Quests",[[
	step //447
		goto Orgrimmar,49.9,81.2
		.talk Lunar Festival Herald##15891
		..accept The Lunar Festival##8873
	step //448
		goto 52.4,58.5
		.talk Lunar Festival Harbinger##15895
		..turnin The Lunar Festival##8873
		..accept Lunar Fireworks##8867
	step //449
		goto 52.6,59.2
		.talk Lunar Festival Vendor##47897
		.buy 8 Small Blue Rocket##21558 |q 8867
		.buy 2 Blue Rocket Cluster##21571 |q 8867
	step //450
		goto 52.4,57.5
		.' Use Small Blue Rockets|use Small Blue Rocket##21558
		.' Use Blue Rocket Clusters|use Blue Rocket Cluster##21571
		.' Fire 8 Lunar Fireworks|q 8867/1
		.' Fire 2 Lunar Fireworks Clusters|q 8867/2
	step //451
		goto 52.4,58.5
		.talk Lunar Festival Harbinger##15895
		..turnin Lunar Fireworks##8867
		..accept Valadar Starsong##8883
	step //452
		goto 52.4,57.4
		.' Use the Lunar Festival Invitation while standing in the beam of light |use Lunar Festival Invitation##21711
		.' Go to Moonglade |goto Moonglade |c |q 8883
	step //453
		goto Moonglade,53.6,35.3
		.talk Valadar Starsong##15864
		..turnin Valadar Starsong##8883
]])
ZygorGuidesViewer:RegisterInclude("H_Lunar_Festival_Elders",[[
	step //454
		goto Silverpine Forest,45.0,41.1
		.talk Elder Obsidian##15561
		..accept Obsidian the Elder##8645 |instant
	step //455
		goto Tirisfal Glades,61.9,53.9
		.talk Elder Graveborn##15568
		..accept Graveborn the Elder##8652 |instant
	step //456
		'Go south to Undercity |goto Undercity |noway |c
	step //457
		goto Undercity,66.6,38.2
		.talk Elder Darkcore##15564
		..accept Darkcore the Elder##8648 |instant
	step //458
		goto 63.3,48.6
		.talk Michael Garrett##4551
		.' Fly to Andorhal, Western Plaguelands |goto Western Plaguelands,46.6,64.7,0.5 |noway |c
	step //459
		goto Western Plaguelands,69.0,73.0
		.talk Elder Moonstrike##15594
		..accept Moonstrike the Elder##8714 |instant
	step //460
		goto 64.8,38.7 |n
		.' Enter this cave |goto 64.8,38.7,0.5 |noway |c
	step //461
		goto 63.5,36.1
		.talk Elder Meadowrun##15602
		..accept Meadowrun the Elder##8722 |instant
	step //462
		goto Eastern Plaguelands,35.6,68.8
		.talk Elder Windrun##15592
		..accept Windrun the Elder##8688 |instant
	step //463
		goto 27.7,11.7|n
		.' Enter the swirling portal to Stratholme. |goto Stratholme |noway|c
	step //464
		map Stratholme
		path follow loose;loop off;ants straight
		path 66.2,76.8		67.3,58.1	60.1,48.7
		path 59.9,31.9		68.3,22.9	78.7,22.1
		.' Follow the path to _Elder Farwhisper_.
		.talk Elder Farwhisper##15607
		..accept Farwhisper the Elder##8727
	step //465
		goto Stratholme,68.8,88.6 |n
		.' Leave Stratholme. |goto Eastern Plaguelands|noway|c
	step //466
		goto 75.7,54.6
		.talk Elder Snowcrown##15566
		..accept Snowcrown the Elder##8650 |instant
	step //467
		goto The Hinterlands,50.0,48.0
		.talk Elder Highpeak##15559
		.accept Highpeak the Elder##8643 |instant
	step //468
		goto Loch Modan,33.3,46.5
		.talk Elder Silvervein##15558
		..accept Silvervein the Elder##8642 |instant
	step //469
		goto Ironforge,28.1,17.0
		.talk Elder Bronzebeard##15871
		..accept Bronzebeard the Elder##8866 |instant |tip If you die trying to leave Ironforge, just resurrect at the spirit healer you get sent to.
	step //470
		goto Dun Morogh,53.9,49.9
		.talk Elder Goldwell##15569
		..accept Goldwell the Elder##8653 |instant
	step //471
		goto Searing Gorge,21.3,79.1
		.talk Elder Ironband##15567
		..accept Ironband the Elder##8651 |instant
	step //472
		.' Enter Blackrock Mountain. |goto Searing Gorge,34.8,85.1 |noway|c
	step //473
		map Burning Steppes
		path follow loose;loop off;ants straight
		path 19.1,22.6		19.4,23.9	20.4,24.1
		path 21.6,24.4		22.8,23.0	23.5,24.9
		path 23.7,26.2
		.' Follow the path into Blackrock Spire. |goto Blackrock Spire |noway|c
	step //474
		map Blackrock Spire/4
		path follow loose;loop off;ants straight
		path 30.0,37.9		37.3,40.9	38.9,48.5
		path 44.0,44.5
		.' Follow the path into Hordemar City. |goto Blackrock Spire/3 |noway|c
	step //475
		map Blackrock Spire/3
		path follow loose;loop off;ants straight
		path 50.3,39.2		55.2,38.3	 58.9,42.9
		path 65.3,41.9		61.8,40.0
		.' Follow the path to _Elder Stonefort_.
		.talk Elder Stonefort##15560
		..accept Stonefort the Elder##8644
	step //476
		map Blackrock Spire/3
		path follow loose;loop off;ants straight
		path 62.6,42.7		57.5,42.0	 54.6,37.5
		path 50.4,39.7
		.' Follow the ramp up to the Hall of Blackhand. |goto Blackrock Spire/4|noway|c
	step //477
		map Blackrock Spire/4
		path follow loose;loop off;ants straight
		path 40.9,45.4		37.5,48.0
		.' Jump off the ledge here. |goto Burning Steppes |noway|c
	step //478
		goto Burning Steppes,18.5,25.2
		.' Fly down to this point, or use the chains to traverse to here.
		|confirm
	step //479
		goto Searing Gorge 26.9,72.6 |n
		.' Enter Blackrock Depths here |goto Blackrock Depths |noway |c
	step //480
		map Blackrock Depths
		path follow loose;loop off;ants straight
		path 37.9,76.3		42.9,74.4	 47.8,72.4
		path 51.5,69.8		50.5,62.9
		.' Follow the path to _Elder Morndeep_.
		.talk Elder Morndeep##15549
		..accept Morndeep the Elder##8619
	step //481
		goto Burning Steppes,53.6,24.5
		.talk Elder Dawnstrider##15585
		..accept Dawnstrider the Elder##8683 |instant
	step //482
		goto 70.1,45.4
		.talk Elder Rumblerock##15557
		..accept Rumblerock the Elder##8636 |instant
	step //483
		goto Elwynn Forest,39.8,63.7
		.talk Elder Stormbrow##15565
		..accept Stormbrow the Elder##8649 |instant
	step //484
		goto 34.6,50.4
		.talk Elder Hammershout##15562
		..accept Hammershout the Elder##8646 |instant |tip If you die trying to leave Stormwind City, just resurrect at the spirit healer you get sent to.
	step //485
		goto Westfall,56.6,47.1
		.talk Elder Skychaser##15577
		..accept Skychaser the Elder##8675 |instant
	step //486
		goto Swamp of Sorrows,69.7,54.1
		.' Follow the steps down and go to the swirling portal at [76.1,45.2]
		.' Enter the Swirling Portal to The Temple of Atal'Hakkar|goto The Temple of Atal'Hakkar|noway|c
	step //487
		goto The Temple of Atal'Hakkar,62.9,34.4
		.talk Elder Starsong##15593
		..accept Starsong the Elder##8713
	step //488
		goto 50.0,14.5
		.' Leave the instance. |goto Swamp of Sorrows|noway|c
	step //489
		goto Blasted Lands,54.3,49.5
		.talk Elder Bellowrage##15563
		..accept Bellowrage the Elder##8647 |instant
	step //490
		goto Northern Stranglethorn,71.0,34.3
		.talk Elder Starglade##15596
		..accept Starglade the Elder##8716 |instant
	step //491
		goto The Cape of Stranglethorn,40.0,72.5
		.talk Elder Winterhoof##15576
		..accept Winterhoof the Elder##8674 |instant
	step //492
		goto 39.3,67.2 |n
		.' Ride the boat to Ratchet |goto Northern Barrens |noway |c
// KALIMDOR
	step //493
		goto Northern Barrens,68.4,70.0
		.talk Elder Windtotem##15582
		..accept Windtotem the Elder##8680 |instant
	step //494
		goto 48.5,59.3
		.talk Elder Moonwarden##15597
		..accept Moonwarden the Elder##8717 |instant
	step //495
		goto Southern Barrens,41.5,47.5
		.talk Elder High Mountain##15588
		..accept High Mountain the Elder##8686 |instant
	step //496
		goto Mulgore,48.5,53.2
		.talk Elder Bloodhoof##15575
		..accept Bloodhoof the Elder##8673 |instant
	step //497
		goto Thunder Bluff,73.0,23.3
		.talk Elder Ezra Wheathoof##15580
		..accept Wheathoof the Elder##8678 |instant
	step //498
		goto Desolace,29.1,62.5 |n
		.' Enter the doorway to Maraudon. |goto Desolace,29.1,62.5 |noway|c
	step //499
		map Desolace
		path follow strict; loop off; ants straight
		path	28.3,63.0	27.9,64.3	27.6,62.9
		path	29.0,62.6	30.1,62.6	29.9,60.3
		.' Follow this path |goto Maraudon/2 |noway |c
	step //500
		map Maraudon/2
		path follow strict;loop off;ants straight
		path	29.4,46.0	32.0,60.3	35.5,57.5
		path	41.0,60.5	45.6,58.5	44.8,54.1
		path	43.0,57.6	41.5,63.9	45.6,67.2
		path	44.8,76.2	44.6,83.9	45.2,89.5
		path	51.5,93.8
		.talk Elder Splitrock##15556
		..accept Splitrock the Elder##8635
	step //501
		goto Feralas,76.7,37.9
		.talk Elder Grimtotem##15581
		..accept Grimtotem the Elder##8679 |instant
	step //502
		goto 62.6,31.1
		.talk Elder Mistwalker##15587
		..accept Mistwalker the Elder##8685 |instant
	step //503
		goto Silithus,53.0,35.5
		.talk Elder Bladesing##15599
		..accept Bladesing the Elder##8719 |instant
	step //504
		goto 30.8,13.3
		.talk Elder Primestone##15570
		..accept Primestone the Elder##8654 |instant
	step //505
		goto Un'Goro Crater,50.4,76.2
		.talk Elder Thunderhorn##15583
		..accept Thunderhorn the Elder##8681 |instant
	step //506
		goto Tanaris,37.2,79.1
		.talk Elder Ragetotem##15573
		..accept Ragetotem the Elder##8671 |instant
	step //507
		goto 51.4,28.8
		.talk Elder Dreamseer##15586
		..accept Dreamseer the Elder##8684 |instant
	step //508
		goto 39.2,21.3 |n
		.' Enter Zul'Farrak. |goto Zul'Farrak |noway|c
	step //509
		goto Zul'Farrak,34.5,39.4
		.talk Elder Wildmane##15578
		..accept Wildmane the Elder##8676
	step //510
		.' Exit dungeon to Tanaris |goto Tanaris |noway |c
	step //511
		goto Thousand Needles,77.1,75.6
		.talk Elder Morningdew##15604
		..accept Morningdew the Elder##8724 |instant
	step //512
		goto 46.3,51.0
		.talk Elder Skyseer##15584
		..accept Skyseer the Elder##8682 |instant
	step //513
		goto Durotar,53.2,43.6
		.talk Elder Runetotem##15572
		..accept Runetotem the Elder##8670 |instant
	step //514
		goto Orgrimmar,52.3,60.0
		.talk Elder Darkhorn##15579
		..accept Darkhorn the Elder##8677 |instant
	step //515
		goto Azshara,64.7,79.3
		.talk Elder Skygleam##15600
		..accept Skygleam the Elder##8720 |instant
	step //516
		goto Winterspring,60.0,49.9
		.talk Elder Stonespire##15574
		..accept Stonespire the Elder##8672 |instant
	step //517
		goto 53.2,56.6
		.talk Elder Brightspear##15606
		..accept Brightspear the Elder##8726 |instant
	step //518
		goto Ashenvale,35.4,48.9
		.talk Elder Riversong##15605
		..accept Riversong the Elder##8725 |instant
	step //519
		goto Felwood,38.4,52.9
		.talk Elder Nightwind##15603
		..accept Nightwind the Elder##8723 |instant
	step //520
		goto Darkshore,49.5,18.9
		.talk Elder Starweave##15601
		..accept Starweave the Elder##8721 |instant
	step //521
		goto Teldrassil,56.9,53.1
		.talk Elder Bladeleaf##15595
		..accept Bladeleaf the Elder##8715 |instant
	step //522
		goto Darnassus,38.8,32.3
		.talk Elder Bladeswift##15598
		..accept Bladeswift the Elder##8718 |instant
	step //523
		goto Darnassus,38.0,30.5
		.' Use the Lunar Festival Invitation while standing in the beam of light |use Lunar Festival Invitation##21711
		.' Go to Moonglade |goto Moonglade |noway |c
	step //524
		|fly Orgrimmar
// NORTHREND
	step //525
		goto Orgrimmar,44.8,62.4 |n
		.' Ride the zeppelin to Borean Tundra |goto Borean Tundra |noway |c
	step //526
		goto Borean Tundra,42.9,49.6
		.talk Elder Pamuya##30371
		..accept Pamuya the Elder##13029 |instant
	step //527
		goto 33.8,34.4
		.talk Elder Northal##30360
		..accept Northal the Elder##13016 |instant
	step //528
		goto 59.1,65.6
		.talk Elder Sardis##30348
		..accept Sardis the Elder##13012 |instant
	step //529
		goto 57.4,43.7
		.talk Elder Arp##30364
		..accept Arp the Elder##13033 |instant
	step //530
		'Go north to Sholazar Basin |goto Sholazar Basin |noway |c
	step //531
		goto Sholazar Basin,49.8,63.6
		.talk Elder Sandrene##30362
		..accept Sandrene the Elder##13018 |instant
	step //532
		goto 63.8,49.0
		.talk Elder Wanikaya##30365
		..accept Wanikaya the Elder##13024 |instant
	step //533
		'Go southeast to Wintergrasp |goto Wintergrasp |noway |c
	step //534
		goto Wintergrasp,50.5,16.4
		.' Click the Defender's Portal
		.' Go to the upper level of the Wintergrasp Fortress |goto Wintergrasp,50.4,15.9,0.1 |noway |c
	step //535
		goto 49.0,13.9
		.talk Elder Bluewolf##30368
		..accept Bluewolf the Elder##13026 |instant
	step //536
		goto 49.6,15.9
		.' Click the Defender's Portal
		.' Go to outside of the Wintergrasp Fortress |goto Wintergrasp,49.6,16.3,0.1 |noway |c
	step //537
		goto Dragonblight,35.1,48.3
		.talk Elder Skywarden##30373
		..accept Skywarden the Elder##13031 |instant
	step //538
		goto 29.7,55.9
		.talk Elder Morthie##30358
		..accept Morthie the Elder##13014 |instant
	step //539
		goto 48.8,78.2
		.talk Elder Thoim##30363
		..accept Thoim the Elder##13019 |instant
	step //540
		'Go east to Grizzly Hills |goto Grizzly Hills |noway |c
	step //541
		goto Grizzly Hills,64.2,47.0
		.talk Elder Whurain##30372
		..accept Whurain the Elder##13030 |instant
	step //542
		goto 80.5,37.1
		.talk Elder Lunaro##30367
		..accept Lunaro the Elder##13025 |instant
	step //543
		goto 60.6,27.7
		.talk Elder Beldak##30357
		..accept Beldak the Elder##13013 |instant
	step //544
		'Go northwest to Zul'Drak |goto Zul'Drak |noway |c
	step //545
		goto Zul'Drak,58.9,56.0
		.talk Elder Tauros##30369
		..accept Tauros the Elder##13027 |instant
	step //546
		'Go northwest to The Storm Peaks |goto The Storm Peaks |noway |c
	step //547
		goto The Storm Peaks,41.2,84.7
		.talk Elder Graymane##30370
		..accept Graymane the Elder##13028 |instant
	step //548
		goto 28.9,73.7
		.talk Elder Fargal##30359
		..accept Fargal the Elder##13015 |instant
	step //549
		goto 31.3,37.6
		.talk Elder Stonebeard##30375
		..accept Stonebeard the Elder##13020 |instant
	step //550
		goto 64.6,51.3
		.talk Elder Muraco##30374
		..accept Muraco the Elder##13032 |instant
	step //551
		|fly Dalaran
	step //552
		goto 55.4,25.5 |n
		.click Dalaran Portal to Orgrimmar##4395
		.' Teleport to Orgrimmar |goto Orgrimmar/2 |noway |c
	step //553
		goto 22.8,70.6 |n
		.' Leave the Clef of Shadow |goto Orgrimmar |noway |c
	step //554
		#include "port_hyjal"
	step //555
		goto 62.5,22.8
		.talk Elder Evershade##55227
		..accept Evershade the Elder##29740 |instant
	step //556
		|fly Sanctuary of Malorne
	step //557
		goto 26.7,62.0
		.talk Elder Windsong##55224
		..accept Windsong the Elder##29739 |instant
	step //558
		|fly Nordrassil
	step //559
		goto 63.5,24.4 |n
		.click Portal to Orgrimmar##4395
		.' Teleport to Orgrimmar |goto Orgrimmar |noway |c
	step //560
		#include "port_deepholm"
	step //561
		goto 49.7,54.9
		.talk Elder Stonebrand##55217
		..accept Stonebrand the Elder##29735 |instant
	step //562
		goto 27.7,69.2
		.talk Elder Deepforge##55216
		..accept Deepforge the Elder##29734 |instant
	step //563
		goto 50.9,53.1 |n
		.click Portal to Orgrimmar##4395
		.' Teleport to Orgrimmar |goto Orgrimmar |noway |c
	step //564
		#include "home_ValleyofHonor"
	step //565
		#include "port_vashj'ir"
	step //566
		goto Shimmering Expanse 57.3,86.2
		.talk Elder Moonlance##55228
		..accept Moonlance the Elder##29738 |instant
	step //567
		#include "hearth_ValleyofHonor"
	step //568
		#include "port_twilight"
	step //569
		goto Twilight Highlands,50.9,70.5
		.talk Elder Firebeard##55219
		..accept Firebeard the Elder##29737 |instant
	step //570
		goto Twilight Highlands 51.9,33.1
		.talk Elder Darkfeather##55218
		..accept Darkfeather the Elder##29736 |instant
	step //571
		goto 73.5,53.6
		.' Run through the Portal to Orgrimmar
		.' Teleport to Orgrimmar |goto Orgrimmar |noway |c
		'|click Portal to Orgrimmar##4395
	step //572
		#include "port_uldum"
	step //573
		goto Uldum 31.6,63.0
		.talk Elder Sekhemi##55210
		..accept Sekhemi the Elder##29741 |instant
	step //574
		goto 65.5,18.7
		.talk Elder Menkhaf##55211
		..accept Menkhaf the Elder##29742 |instant
	step //575
		#include "hearth_ValleyofHonor"
	step //576
		#include "rideto_borean"
	step //577
		|fly Transitus Shield
	step //578
		goto 27.5,26.0 |n
		.' Enter The Nexus here |goto The Nexus |noway |c
	step //579
		map The Nexus
		path loop off
		path	 34.4,78.5	29.0,70.6	24.0,67.6
		path	 22.0,59.0	18.9,51.5	21.9,44.0
		path	 21.5,36.7	25.9,33.5	26.9,25.2
		path	 35.4,22.0	43.5,22.1	46.1,28.4
		path	 54.0,35.9	55.7,50.5	62.7,52.5
		path	 60.3,64.3	55.3,64.7
		.talk Elder Igasho##30536
		..accept Igasho the Elder##13021
	step //580
		goto Dragonblight 26.0,50.9 |n
		.' Enter Azjol-Nerub here |goto Azjol-Nerub/3 |noway |c
	step //581
		map Azjol-Nerub/3
		path loop off
		path	19.7,66.9	26.8,36.9	55.8,44.7
		path	88.3,44.8	72.6,30.9
		.' Follow this path down |goto Azjol-Nerub/2 |noway |c
	step //582
		map Azjol-Nerub/2
		path loop off
		path	39.7,30.7	43.8,20.5	61.2,19.9
		path	60.0,43.6	51.1,61.8
		.' Jump down this hole into the water below |goto Azjol-Nerub |noway |c
	step //583
		goto 21.8,43.6
		.talk Elder Nurgen##30533
		..accept Nurgen the Elder##13022
	step //584
		.' Leave Azjol-Nerub |goto Dragonblight |noway |c
	step //585
		goto The Storm Peaks 39.6,26.9 |n
		.' Enter the portal to the Halls of Stone. |goto Halls of Stone |noway|c
	step //586
		goto Halls of Stone,29.4,62.1
		.talk Elder Yurauk##30535
		..accept Yurauk the Elder##13066
	step //587
		.' Leave the Halls of Stone. |goto The Storm Peaks |noway|c
	step //588
		goto Zul'Drak,76.1,20.9 |n
		.' Enter the swirling portal to Gundrak. |goto Gundrak |noway|c
	step //589
		map Gundrak
		path loop off
		path	 59.1,49.2	58.2,68.5	50.9,73.6
		path	45.6,61.5
		.talk Elder Ohanzee##30537
		..accept Ohanzee the Elder##13065
	step //590
		map Gundrak
		path loop off
		path	45.6,61.5	50.9,73.6	 58.2,68.5
		path	59.1,49.2
		.' Follow the path, going up the ramps and out of the instance. |goto Zul'Drak |noway|c
	step //591
		'Go northwest to The Storm Peaks |goto The Storm Peaks |noway |c
	step //592
		goto Zul'Drak,28.5,86.9 |n
		.' Enter the swirling portal to Drak'Tharon Keep. |goto Drak'Tharon Keep |noway|c
	step //593
		map Drak'Tharon Keep
		path loop off
		path 31.9,80.0		39.2,86.0	46.2,84.3
		path 47.5,63.7		47.7,51.0	50.5,40.7
		path 57.0,23.0		66.6,23.8	66.7,39.0
		path 67.5,56.0		55.8,58.5	55.5,77.6
		path 65.4,76.3		68.9,79.1
		.' Follow the path to Elder Kilias.
		.talk Elder Kilias##30534
		..accept Kilias the Elder##13023 |instant
	step //594
		map Drak'Tharon Keep
		path loop off
		path	62.5,77.3	 55.5,77.7	 58.8,57.0
		path	68.0,55.8	 66.8,37.6	 66.9,25.5
		path	64.9,18.9	 57.1,19.3	 50.3,40.9
		path	47.6,50.7	 47.6,68.3	 47.3,83.3
		path	34.7,80.2	 28.5,81.0
		.' Leave the Drak'Tharon. |goto Zul'Drak |noway|c
	step //595
		goto Howling Fjord 58.0,50.0 |n
		.' Enter the Utgard Keep building here |goto Howling Fjord,58.0,50.0,0.5 |noway |c
	step //596
		goto 57.3,46.8 |n
		.' Enter Utgarde Keep here |goto Utgarde Keep |noway |c
	step //597
		map Utgarde Keep
		path loop off
		path	66.8,61.8	62.9,43.6	65.7,29.5
		path	56.4,25.1	44.8,28.0	26.3,37.3
		path	26.1,50.9	22.9,72.7	34.3,88.9
		path	49.3,77.1
		.' Follow this path to the Elder |goto 49.3,77.1,0.5 |noway |c
	step //598
		goto 47.5,69.6
		.talk Elder Jarten##30531
		..accept Jarten the Elder##13017 |instant
	step //599
		.' Leave Utgarde Keep |goto Howling Fjord |noway |c
	step //600
		goto Howling Fjord,57.3,46.7 |n
		.' Enter the swirling portal to Utgarde Pinnacle. |goto Utgarde Pinnacle/2 |noway|c
	step //601
		map Utgarde Pinnacle/2
		path loop off
		path 44.5,17.0		44.2,29.8	 38.5,35.9
		path 33.7,49.0		33.5,64.4	 35.5,69.1
		path 39.1,75.8
		.' Take the stairs down. |goto Utgarde Pinnacle |noway|c
	step //602
		map Utgarde Pinnacle
		path loop off
		path 35.9,77.9		36.2,86.9	 41.7,86.2
		path 46.1,81.9
		.' Go up the stairs. |goto Utgarde Pinnacle/2 |noway|c
	step //603
		map Utgarde Pinnacle/2
		path loop off
		path 54.0,77.0		51.8,76.2	51.8,81.4
		path 56.8,84.4		60.6,84.3	63.7,69.7
		path 68.3,68.4		 68.8,56.4	68.9,36.1
		.' Follow the path, clicking here to continue. |confirm
	step //604
		goto Utgarde Pinnacle,48.7,23.1 
		.talk Elder Chogan'gada##30538
		..accept Chogan'gada the Elder##13067
]])

ZygorGuidesViewer:RegisterInclude("H_Lunar_Festival_Achievements",[[
	step //605
		goto Orgrimmar 52.4,58.5
		.talk Lunar Festival Harbinger##15895
		.' <I'd like a new invitation to the Lunar Festival.>
		.collect Lunar Festival Invitation##21711
	step //606
		goto Orgrimmar 52.4,57.4
		.' Use the Lunar Festival Invitation while standing in the beam of light |use Lunar Festival Invitation##21711
		.' Go to Moonglade |goto Moonglade |c |q 8883
	step //607
		goto Moonglade,53.6,35.3
		.talk Valadar Starsong##15864
		..turnin Valadar Starsong##8883
	step //608
		 goto 36.6,58.1
		.talk Lunar Festival Vendor##15898
		.buy 10 Festival Firecracker##21747
		.buy 10 Red Rocket Cluster##21576
		.buy 1 Green Rocket Cluster##21574
	step //609
		goto 36.0,57.7
		.' Use the _Festival Firecrackers_ as fast as you can.
		.' You will need to use 10 in 30 seconds.
		.' You can drag the Festival Firecrackers onto your action bar. You will need to click the ground where you want to throw them.
		.use Festival Firecracker##21747
		.' Earn the _Frienzied Firecracker_ Achievement. |achieve 1552
	step //610
		goto 30.6,18.9
		.' Drag the _Red Rocket Clusters_ to you action bar.
		.' You will need to use 10 in 25 seconds.
		.' You will need to spam whatever button the Red Rocket Cluster is assigned to.
		.use Red Rocket Cluster##21576
		.' Earn _The Rockets Red Glare_ Achievement. |achieve 1281
	step //611
		goto 53.6,35.3
		.talk Valadar Starsong##15864
		..accept Elune's Blessing##8868
	step //612
		goto 63.7,62.4
		.' Use your Green Rocket Cluster |use Green Rocket Cluster##21574
		.from Omen##15467 
		.' You will need a group of 4 or 5 to beat him.
		.' Receive Elune's Blessing|q 8868/1
	step //613
		goto Moonglade 53.6,35.3
		.talk Valadar Starsong##15864
		..turnin Elune's Blessing##8868
	step //614
		goto 53.6,35.3
		.talk Valadar Starsong##15864 |tip You only need to buy one of these.
		.buy Festive Pink Dress##21538 |or
		.buy Festive Purple Dress##21539 |or
		.buy Festive Black Pant Suit##21541 |or
		.buy Festive Blue Pant Suit##21544 |or
		.buy Festive Teal Pant Suit##21543 |or
		.buy Festive Green Dress##21157 |or
		.' Earn the Achievment Lunar Festival Finery |achieve 626
	step
		Congratulations! You know how To Honor One's Elders!
]])
-- Love Is In The Air --
ZygorGuidesViewer:RegisterInclude("H_Love_Is_In_The_Air_Main_Questline",[[
	step //615
		goto Orgrimmar,50.8,75.2
		.talk Detective Snap Snagglebolt##37172
		..accept Something Stinks##24536
	step //616
		goto 51.9,76.3
		.' Use Snagglebolt's Air Analyzer on pink glowing Orgrimmar Grunts around this area |use Snagglebolt's Air Analyzer##50131
		.' Analyze 6 Perfumed Guards |q 24536/1
		'|talk Orgrimmar Grunt##3296
	step //617
		goto 50.8,75.2
		.talk Detective Snap Snagglebolt##37172
		..turnin Something Stinks##24536
		..accept Pilfering Perfume##24541
	step //618
		'Go outside Orgrimmar |goto Durotar |noway |c
	step //619
		goto Durotar,47.7,11.8
		.' Get the Crown Chemical Co. Package |havebuff INV_Crate_03 |q 24541 |tip To get the package, run outside the gates of Orgrimmar and take an immediate left.  Keep close to the wall, you will eventually get to a small camp where two Undead NPCs are standing next to a pile of boxes.  Get close to them in order to get the package.
	step //620
		'Run back inside Orgrimmar |goto Orgrimmar |noway |c
	step //621
		goto Orgrimmar,50.8,75.2
		.' Return the Crown Chemical Co. Package |tip Simply walk next to Detective Snap Snagglebolt to return the package to him. |condition ZGV.questsbyid[24541] and ZGV.questsbyid[24541].complete |q 24541
		.' If you lose your disguise, ask the Detective for another one and repeat the run.
	step //622
		goto Orgrimmar,50.8,75.2
		.' Return the Crown Chemical Co. Package |tip Simply walk next to Detective Snap Snagglebolt to return the package to him.
		.talk Detective Snap Snagglebolt##37172
		..turnin Pilfering Perfume##24541
		..accept Snivel's Sweetheart##24850
	step //623
		goto 57.6,60.8
		.talk Roka##38328
		..turnin Snivel's Sweetheart##24850
		..accept Hot On The Trail##24851
	step //624
		goto 53.8,73.5
		.' Search the Orgrimmar Auction House |q 24851/2
	step //625
		goto 48.7,83.6
		.' Search the Orgrimmar Bank |q 24851/1
	step //626
		goto 40.1,60.5
		.' Search the Orgrimmar Barber Shop |q 24851/3
	step //627
		goto 57.6,60.8
		.talk Roka##38328
		..turnin Hot On The Trail##24851
		..accept A Friendly Chat...##24576
	step //628
		goto 51.6,56.7
		.talk Snivel Rustrocket##37715
		..' Tell him you have a rocket with his mark on it.
		..get Snivel's Ledger |q 24576/1
	step //629
		goto Orgrimmar,50.8,75.2
		.talk Detective Snap Snagglebolt##37172
		..turnin A Friendly Chat...##24576
]])

ZygorGuidesViewer:RegisterInclude("H_Love_Is_In_The_Air_Dailies",[[
	daily
	step //630
		goto Orgrimmar,50.8,75.3
		.talk Detective Snap Snagglebolt##37172
		..' You have to be at least level 5 to accept a quest from him
		..accept Crushing the Crown##24638 |daily |only if level >= 5 and level < 14
		..accept Crushing the Crown##24645 |daily |only if level >= 14 and level < 23
		..accept Crushing the Crown##24647 |daily |only if level >= 23 and level < 32
		..accept Crushing the Crown##24648 |daily |only if level >= 32 and level < 41
		..accept Crushing the Crown##24649 |daily |only if level >= 41 and level < 51
		..accept Crushing the Crown##24650 |daily |only if level >= 51 and level < 61
		..accept Crushing the Crown##24651 |daily |only if level >= 61 and level < 71
		..accept Crushing the Crown##24652 |daily |only if level >= 71 and level <81
		..accept Crushing the Crown##28935 |daily |only if level >= 81
	step //631
		goto 53.1,77.2
		.talk Public Relations Agent##37675
		.' You will only be able to accept, and turn in, 1 of these 3 daily quests per day:
		..accept A Cloudlet of Classy Cologne##24635 |daily |or
		..accept A Perfect Puff of Perfume##24629 |daily |or
		..accept Bonbon Blitz##24636 |daily |or
	step //632
		goto 53.0,76.8
		.talk Kwee Q. Peddlefeet##38042
		..accept A Gift for the Warchief##24612 |daily
	step //633
		'Run around Orgrimmar and:
		.' Use your Crown Cologne Sprayer on NPCs and other players without a red heart over their head |use Crown Cologne Sprayer##49669
		.' Give 10 Cologne Samples |q 24635/1
	step //634
		'Run around Orgrimmar and:
		.' Use your Crown Perfume Sprayer on NPCs and other players without a red heart over their head |use Crown Perfume Sprayer##49668
		.' Give 10 Perfume Samples |q 24629/1
	step //635
		'Run around Orgrimmar and:
		.' Use your Crown Chocolate Sampler on NPCs and other players without a red heart over their head |use Crown Chocolate Sampler##49670
		.' Give 10 Chocolate Samples |q 24636/1
	step //636
		'Go outside Orgrimmar to Durotar |goto Durotar |noway |c
		only if level >= 5 and level < 14
	step //637
		goto Durotar,40.2,15.4
		.kill 5 Crown Lackey |q 24638/2
		.' Use Snagglebolt's Khorium Bomb next to the big shaking Chemical Wagon |use Snagglebolt's Khorium Bomb##50130
		.' Destroy the Chemical Wagon |q 24638/1
		only if level >= 5 and level < 14
	step //638
		goto Orgrimmar,43.1,64.9 |n
		.' Ride the zeppelin to Thunder Bluff |goto Thunder Bluff |noway |c
	step //639
		goto Thunder Bluff,44.0,52.6
		.talk Kwee Q. Peddlefeet##38042
		..accept A Gift for the High Chieftain##24614 |daily
	step //640
		goto 43.6,52.9
		.talk Public Relations Agent##37675
		.' You will only be able to accept, and turn in, 1 of these 3 daily quests per day:
		..turnin A Cloudlet of Classy Cologne##24635
		..turnin A Perfect Puff of Perfume##24629
		..turnin Bonbon Blitz##24636
	step //641
		|fly Ramkahen
		|only if level >= 81
	step //642
		 goto Uldum,67.8,19.8
		.kill 5 Crown Technicians |q 28935/2
		.' Use Snagglebolt's Khorium Bomb next to the big shaking Chemical Wagon |use Snagglebolt's Khorium Bomb##50130
		.' Destroy the Chemical Wagon |q 28935/1
		only if level >= 81
	step //643
		|fly Orgrimmar
	step //644
		goto Orgrimmar,50.9,55.7 |n
		.' Ride the zeppelin to Undercity |goto Tirisfal Glades |noway |c
	step //645
		Go inside Undercity |goto Undercity |noway |c
	step //646
		goto Undercity,66.5,38.6
		.talk Kwee Q. Peddlefeet##38042 |tip He is in the Ruins of Lordaeron.
		..accept A Gift for the Banshee Queen##24613 |daily
	step //647
		goto 63.3,48.5
		.talk Michael Garrett##4551
		..' Fly to The Forsaken Front, Silverpine Forest |goto Silverpine Forest,50.9,63.6,0.5 |noway |c
		only if level >= 14 and level < 23
	step //648
		goto Silverpine Forest,54.7,61.3
		.kill 5 Crown Thug |q 24645/2
		.' Use Snagglebolt's Khorium Bomb next to the big shaking Chemical Wagon |use Snagglebolt's Khorium Bomb##50130
		.' Destroy the Chemical Wagon |q 24645/1
		only if level >= 14 and level < 23
	step //649
		goto 50.9,63.6
		.talk Steven Stutzka##46552
		..' Fly to Undercity |goto Undercity |noway |c
		only if level >= 14 and level < 23
	step //650
		goto Undercity,63.3,48.5
		.talk Michael Garrett##4551
		..' Fly to Southpoint Gate, Hillsbrad |goto Hillsbrad Foothills,29.1,64.4,0.5 |noway |c
		only if level >= 23 and level < 32
	step //651
		goto Hillsbrad Foothills,34.5,58.4
		.kill 5 Crown Duster |q 24647/2
		.' Use Snagglebolt's Khorium Bomb next to the big shaking Chemical Wagon |use Snagglebolt's Khorium Bomb##50130
		.' Destroy the Chemical Wagon |q 24647/1
		only if level >= 23 and level < 32
	step //652
		goto 29.1,64.4
		.talk Pamela Stutzka##47655
		..' Fly to Undercity |goto Undercity |noway |c
		only if level >= 23 and level < 32
	step //653
		goto Undercity,63.3,48.5
		.talk Michael Garrett##4551
		..' Fly to Hiri'watha Research Station, The Hinterlands |goto The Hinterlands,32.4,58.1,0.5 |noway |c
		only if level >= 41 and level < 51
	step //654
		goto The Hinterlands,23.6,53.7
		.kill 5 Crown Agent |q 24649/2
		.' Use Snagglebolt's Khorium Bomb next to the big shaking Chemical Wagon |use Snagglebolt's Khorium Bomb##50130
		.' Destroy the Chemical Wagon |q 24649/1
		only if level >= 41 and level < 51
	step //655
		goto 32.5,58.1
		.talk Kellen Kuhn##43573
		..' Fly to Undercity |goto Undercity |noway |c
		only if level >= 41 and level < 51
	step //656
		goto Undercity,54.9,11.3 |n
		.' Click the Orb of Translocation to go to Silvermoon City |goto Silvermoon City |noway |c |tip It's a red floating ball with 3 small golden statues spinning around it, in a side room in the Ruins of Lordaeron.
	step //657
		goto Silvermoon City,64.4,66.5
		.talk Kwee Q. Peddlefeet##38042
		..accept A Gift for the Regent Lord of Quel'Thalas##24615 |daily
	step //658
		'This step depends on your character's level and what you want to do.  
		.' If you don't have a lot of money, or don't want to spend any more, do this: |tip Go to a place where the mobs are at least green to you, they cannot be grey to you, or they won't drop the items you need.  Now, just kill the mobs until you collect 40 Lovely Charms.  You won't get a Lovely Charm from every mob you kill, so be prepared to grind for a while.
		..collect 40 Lovely Charm##49655 |n
		.' If you have a lot of money, or don't care about spending money and just want to do the quests very quickly, do this: |tip Go to the Auction House and buy 4 Lovely Charm Bracelets.
		.' If you chose to kill mobs, use your Lovely Charms to create 4 Lovely Charm Bracelets |use Lovely Charm##49655
		.collect 4 Lovely Charm Bracelet##49916 |future |q 24614
	step //659
		'Go to Silvermoon City |goto Silvermoon City |noway |c
	step //660
		goto Silvermoon City,53.8,20.2
		.talk Lor'themar Theron##16802
		..turnin A Gift for the Regent Lord of Quel'Thalas##24615
	step //661
		goto 49.4,14.8 |n
		.' Click the Orb of Translocation to go to Undercity |goto Tirisfal Glades |noway |c |tip It's a red floating ball with 3 small golden statues spinning around it, in the back room of this building, up on a platform.
	step //662
		goto Undercity,58.1,91.8
		.talk Lady Sylvanas Windrunner##10181
		..turnin A Gift for the Banshee Queen##24613
	step //663
		'Go outside of Undercity to Tirisfal Glades |goto Tirisfal Glades |noway |c
	step //664
		goto Tirisfal Glades,60.7,58.8 |n
		.' Ride the zeppelin to Orgrimmar |goto Orgrimmar |noway |c
	step //665
		goto Orgrimmar,43.1,64.9 |n
		.' Ride the zeppelin to Thunder Bluff |goto Thunder Bluff |noway |c
	step //666
		goto Thunder Bluff,60.3,51.7
		.talk Baine Bloodhoof##36648
		..turnin A Gift for the High Chieftain##24614
	step //667
		goto 15.4,25.7 |n
		.' Ride the zeppelin to Orgrimmar |goto Orgrimmar |noway |c
	step //668
		#include "rideto_borean"
		only if level >= 71 and level < 81
	step //669
		|fly Dalaran
		only if level >= 71 and level < 81
	step //670
		'Go outside of Dalaran to Crystalsong Forest |goto Crystalsong Forest |noway |c
		only if level >= 71 and level < 81
	step //671
		goto Crystalsong Forest,46.3,50.8
		.kill 5 Crown Sprayer |q 24652/2
		.' Use Snagglebolt's Khorium Bomb next to the big shaking Chemical Wagon |use Snagglebolt's Khorium Bomb##50130
		.' Destroy the Chemical Wagon |q 24652/1
		only if level >= 71 and level < 81
	step //672
		|fly Dalaran
		only if level >= 71 and level < 81
	step //673
		goto Dalaran,72.2,45.8
		.talk Aludane Whitecloud##28674
		.' Fly to Warsong Hold, Borean Tundra |goto Borean Tundra,40.4,51.5,0.5 |noway |c
		only if level >= 71 and level < 81
	step //674
		goto Borean Tundra,41.4,53.7 |n
		.' Ride the zeppelin to Orgrimmar |goto Orgrimmar |noway |c 
		only if level >= 71 and level < 81
	step //675
		goto Orgrimmar,49.7,59.2
		.talk Doras##3310
		..' Fly to Brackenwall Village |goto Dustwallow Marsh,35.6,31.8,0.5 |noway |c
		only if level >= 32 and level < 41
	step //676
		goto Dustwallow Marsh,60.7,38.3
		.kill 5 Crown Hoodlum |q 24648/2
		.' Use Snagglebolt's Khorium Bomb next to the big shaking Chemical Wagon |use Snagglebolt's Khorium Bomb##50130
		.' Destroy the Chemical Wagon |q 24648/1
		only if level >= 32 and level < 41
	step //677
		goto 35.6,31.9
		.talk Shardi##11899
		..' Fly to Orgrimmar |goto Orgrimmar,49.3,59.4,0.5 |noway |c
		only if level >= 32 and level < 41
	step //678
		goto Orgrimmar,49.7,59.2
		.talk Doras##3310
		..' Fly to Everlook |goto Winterspring,58.9,48.3,0.5 |noway |c
		only if level >= 51 and level < 61
	step //679
		goto Winterspring,63.6,49.4
		.kill 5 Crown Sprinkler |q 24650/2 |tip They are on top of this big hill.
		.' Use Snagglebolt's Khorium Bomb next to the big shaking Chemical Wagon |use Snagglebolt's Khorium Bomb##50130
		.' Destroy the Chemical Wagon |q 24650/1
		only if level >= 51 and level < 61
	step //680
		goto 58.8,48.3
		.talk Yugrek##11139
		..' Fly to Orgrimmar |goto Orgrimmar,49.3,59.4,0.5 |noway |c
		only if level >= 51 and level < 61
	step //681
		goto Orgrimmar,47.1,61.9 |n
		.' Click the Portal to Blasted Lands |goto Blasted Lands |noway |c
		only if level >= 61 and level < 71
	step //682
		goto Blasted Lands,55.0,54.1 |n
		.' Go into the big green portal to Outland |goto Hellfire Peninsula |noway |c
		only if level >= 61 and level < 71
	step //683
		goto Hellfire Peninsula,87.3,48.1
		.talk Vlagga Freyfeather##18930
		..' Fly to Shattrath City |goto Shattrath City |noway |c
		only if level >= 61 and level < 71
	step //684
		'Go outside of Shattrath City to Terokkar Forest |goto Terokkar Forest |noway |c
		only if level >= 61 and level < 71
	step //685
		goto Terokkar Forest,41.4,22.4
		.kill 5 Crown Underling |q 24651/2
		.' Use Snagglebolt's Khorium Bomb next to the big shaking Chemical Wagon |use Snagglebolt's Khorium Bomb##50130
		.' Destroy the Chemical Wagon |q 24651/1
		only if level >= 61 and level < 71
	step //686
		'Go inside Shattrath City |goto Shattrath City |noway |c
		only if level >= 61 and level < 71
	step //687
		goto Shattrath City,64.1,41.1
		.talk Nutral##18940
		.' Fly to Hellfire Peninsula, The Dark Portal, Horde |goto Hellfire Peninsula,87.4,48.2,0.5 |noway |c
		only if level >= 61 and level < 71
	step //688
		'Go through the big green portal to Blasted Lands |goto Blasted Lands |noway |c
		only if level >= 61 and level < 71
	step //689
		goto Blasted Lands,50.9,72.9
		.talk Salena##43114
		.' Fly to Booty Bay, Stranglethorn |goto The Cape of Stranglethorn,40.5,73.3,0.5 |noway |c
		only if level >= 61 and level < 71
	step //690
		goto The Cape of Stranglethorn,39.3,67.2 |n
		.' Ride the boat to Ratchet |goto Northern Barrens |noway |c
		only if level >= 61 and level < 71
	step //691
		goto Northern Barrens,69.1,70.7
		.talk Bragok##16227
		.' Fly to Orgrimmar, Durotar |goto Orgrimmar,49.3,59.4,0.5 |noway |c
		only if level >= 61 and level < 71
	step //692
		goto Orgrimmar,48.1,70.5
		.talk Garrosh Hellscream##39605
		..turnin A Gift for the Warchief##24612
	step //693
		goto 50.8,75.3
		.talk Detective Snap Snagglebolt##37172
		..' You have to be at least level 5 to accept a quest from him
		..turnin Crushing the Crown##24638 |only if level >= 5 and level < 14
		..turnin Crushing the Crown##24645 |only if level >= 14 and level < 23
		..turnin Crushing the Crown##24647 |only if level >= 23 and level < 32
		..turnin Crushing the Crown##24648 |only if level >= 32 and level < 41
		..turnin Crushing the Crown##24649 |only if level >= 41 and level < 51
		..turnin Crushing the Crown##24650 |only if level >= 51 and level < 61
		..turnin Crushing the Crown##24651 |only if level >= 61 and level < 71
		..turnin Crushing the Crown##24652 |only if level >= 71 and level < 81
		..turnin Crushing the Crown##28935 |only if level >= 85
]])

ZygorGuidesViewer:RegisterInclude("H_Love_Is_In_The_Air_Achievements",[[
	step //694
		'You will need _Love Tokens_ in order to purchase items from vendors in this guide section. |tip You can get Love Tokens by completing the dailies in the Love is in the Air Dailies section. 
		.' Skip to the next step in the guide
		|confirm always
	step //695
		goto Orgrimmar,53.1,77.0
		.talk Lovely Merchant##37674
		.buy Bag of Heart Candies##21813 |n
		.' Get the 8 different types of Heart Candy:
		.' Be Mine! |collect 1 Heart Candy##21816
		.' I'll follow you all around Azeroth. |collect 1 Heart Candy##21818
		.' All yours. |collect 1 Heart Candy##21819
		.' I'm all yours! |collect 1 Heart Candy##21821
		.' Hot Lips. |collect 1 Heart Candy##21823
		.' You're Mine! |collect 1 Heart Candy##21822
		.' You're the best! |collect 1 Heart Candy##21820
		.' I LOVE YOU |collect 1 Heart Candy##21817
	step //696
		'Eat the 8 different type of Heart Candy:
		.' Be Mine! |achieve 1701/1 |use 1 Heart Candy##21816
		.' I'll follow you all around Azeroth. |achieve 1701/2 |use 1 Heart Candy##21818
		.' All yours. |achieve 1701/3 |use 1 Heart Candy##21819
		.' I'm all yours! |achieve 1701/4 |use 1 Heart Candy##21821
		.' Hot Lips. |achieve 1701/5 |use 1 Heart Candy##21823
		.' You're Mine! |achieve 1701/6 |use 1 Heart Candy##21822
		.' You're the best! |achieve 1701/7 |use 1 Heart Candy##21820
		.' I LOVE YOU |achieve 1701/8 |use 1 Heart Candy##21817
	step //697
		goto 53.1,77.0
		.talk Lovely Merchant##37674
		.buy 10 Silver Shafted Arrow##22200 |n
		.' Use your Silver Shafted Arrows on 10 players inside Orgrimmar |use Silver Shafted Arrow##22200
		.' Shoot 10 Players with the Silver Shafted Arrow |achieve 1188
	step //698
		goto 53.1,77.0
		.talk Lovely Merchant##37674
		.buy 1 Box of Chocolates##49909 |n
		.' Use your Box of Chocolates and get all the chocolate contained inside of it |use Box of Chocolates##49909
		.' Eat each type of chocolate:
		.' Sweet Surprise |achieve 1702/3 |use Sweet Surprise##22239
		.' Very Berry Cream |achieve 1702/4 |use Very Berry Cream##22238
		.' Buttermilk Delight |achieve 1702/1 |use Buttermilk Delight##22236 |tip Save the remaining Buttermilk Delights for a later achievement.
		.' Dark Desire |achieve 1702/2 |use Dark Desire##22237
	step //699
		goto 53.1,77.0
		.talk Lovely Merchant##37674
		.buy 10 Love Rocket##34258 |n
		.' Spam use your Love Rockets |use Love Rocket##34258
		.' Shoot off 10 Love Rockets in 20 seconds or less |achieve 1696
	step //700
		goto 53.1,77.0
		.talk Lovely Merchant##37674
		.buy 15 Handful of Rose Petals##22218 |achieve 1699
		.buy 1 Romantic Picnic Basket##34480 |achieve 1291
		.buy 1 "VICTORY" Perfume##49856 |achieve 1280
		.buy 5 Love Fool##22261 |achieve 1704
	step //701
		goto 54.8,78.0
		.talk Barkeep Morag##5611
		.buy 6 Cup of Frog Venom Brew##44573 |achieve 1280
	step //702
		'Go to Dalaran |goto Dalaran |noway |c
	step //703
		'All around Dalaran:
		.' Use your Handful of Rose Petals on the follow race/class combinations: |use Handful of Rose Petals##22218 |tip Save any extra Handfuls of Rose Petals you have, you'll need one later.
		.' Gnome Warlock |achieve 1699/1
		.' Orc Death Knight |achieve 1699/2
		.' Human Death Knight |achieve 1699/3
		.' Night Elf Priest |achieve 1699/4
		.' Orc Shaman |achieve 1699/5
		.' Tauren Druid |achieve 1699/6
		.' Undead Warrior |achieve 1699/7
		.' Troll Rogue |achieve 1699/8
		.' Blood Elf Mage |achieve 1699/9
		.' Draenei Paladin |achieve 1699/10
		.' Dwarf Hunter |achieve 1699/11
	step //704
		'In Dalaran:
		.' Find a player to have a picnic with you
		.' Use your Romantic Picnic Basket |use Romantic Picnic Basket##34480
		.' While having a picnic, use your Buttermilk Delight |use Buttermilk Delight##22236
		.' Enjoy a Buttermilk Delight with someone in Dalaran at a Romantic Picnic |achieve 1291
	step //705
		'Go to Wintergrasp in Northrend:
		.' Use your Love Fool anywhere inside Wintergrasp |use Love Fool##22261
		.' Target the Love Fool and Pity it |script DoEmote("PITY") |achieve 1704/1
	step //706
		'Go to Undercity |goto Undercity |noway |c
	step //707
		goto Undercity,67.6,44.1
		.' Do the following exactly in order from top to bottom in the step:
		.' Use all 6 of your Cups of Frog Venom Brew to get Completely Smashed |use Cup of Frog Venom Brew##44573
		.' Use your "VICTORY" Perfume |use "VICTORY" Perfume##49856
		.' Use your Handful of Rose Petals on Jeremiah Payson |use Handful of Rose Petals##22218 |achieve 1280/1
		.' Kiss Jeremiah Payson |script DoEmote("KISS") |achieve 1280/2
	step //708
		'Go to the Gurubashi Arena in The Cape of Stranglethorn: |tip The Cape of Stranglethorn is the southern-most zone on the Eastern Kingdoms continent.
		.' Use your Love Fool anywhere inside the Gurubashi Arena |use Love Fool##22261
		.' Target the Love Fool and Pity it |script DoEmote("PITY") |achieve 1704/2
	step //709
		'Enter the Arathi Basin PvP Battleground:
		.' Use your Love Fool inside the Blacksmith subzone inside Arathi Basin |use Love Fool##22261
		.' Target the Love Fool and Pity it |script DoEmote("PITY") |achieve 1704/3
	step //710
		'Enter the Culling of Stratholme dungeon:
		.' Use your Love Fool anywhere inside the Culling of Stratholme dungeon |use Love Fool##22261
		.' Target the Love Fool and Pity it |script DoEmote("PITY") |achieve 1704/4
	step //711
		'Enter the Naxxramas raid:
		.' Use your Love Fool anywhere inside the Naxxramas raid |use Love Fool##22261
		.' Target the Love Fool and Pity it |script DoEmote("PITY") |achieve 1704/5
	step //712
		'Go to a place where the mobs are at least green to you, they cannot be grey to you, or they won't drop the items you need.
		.' Kill the mobs until you collect 120 Lovely Charms.  |tip You won't get a Lovely Charm from every mob you kill, so be prepared to grind for a while.
		.collect 120 Lovely Charm##49655 |n
		.' Use your Lovely Charms to create 12 Lovely Charm Bracelets |use Lovely Charm##49655
		.' Create 12 Lovely Charm Bracelets |achieve 260
	step //713
		'Kill these certain bosses in any of the following dungeons: |tip You can enter either Normal or Heroic difficulty, it doesn't matter.
		.' _Drahga Shadowburner_ in Grim Batol: 
		.' _Corla, Herald of Twilight_ in Blackrock Caverns: 
		.' _High Priestess_ Azil in The Stonecore:
		.' _Admiral Ripsnarl_ in Deadmines: And
		.' _Lord Godfrey_ in Shadowfang Keep
		.' Get either of these 2 items as a random drop from these bosses:
		.collect 1 Bouquet of Red Roses##22206 |n
		.collect 1 Bouquet of Ebon Roses##44731 |n
		.' Obtain a Bouquet of Red or Ebon Roses during the Love is in the Air celebration |achieve 1703 
	step //714
		'Congratulations, you are a Fool For Love!
]])
--Noblegarden--
ZygorGuidesViewer:RegisterInclude("H_Noblegarden_Achievements",[[
	step //715
		'You may be unable to complete some of the achievements if you are lower level.  So, if you find you cannot do something in this guide, simply skip it and do what you can
		|confirm
	step //716
		goto Mulgore,47.2,59.3
		.click Brightly Colored Eggs##1407+ 
		|tip There is at least one available at all times. If Bloodhoof Village is too crowded with other players looking for eggs, you can also find them at Razor Hill, Falconwing Square, and Brill.
		.collect Brightly Colored Egg##45072+ |n
		.' Click Brightly Colored Eggs in your bags |use Brightly Colored Egg##45072
		.collect 100 Noblegarden Chocolate##44791+ |n
		.' Eat 100 Noblegarden Chocolates |achieve 2418 |use Noblegarden Chocolate##44791
		.' Discover a White Tuxedo Shirt by opening Brightly Colored Eggs |achieve 248/1
		.' Discover Black Tuxedo Pants by opening Brightly Colored Eggs |achieve 248/2
		.' Discover an Elegant Dress by opening Brightly Colored Eggs |achieve 249                                              
		.' If you've eaten 100 chocolates and want to buy these items to continue, click here to continue |confirm
	step //717
		'If you don't already have these items, collect Noblegarden Chocolates and purchase them from the Noblegarden Merchant at [47.1,59.9]:
		.collect Noblegarden Egg##44818 |achieve 2420 |tip It costs 5 Noblegarden Chocolates.
		.collect Blossoming Branch##44792 |achieve 2416 |tip It costs 10 Noblegarden Chocolates.
		.collect Spring Flowers##45073 |achieve 2422 |tip It costs 50 Noblegarden Chocolates.
		.collect Spring Robes##44800 |achieve 2436 |tip It costs 50 Noblegarden Chocolates.
		.collect Spring Rabbit's Foot##44794 |achieve 2497 |tip It costs 100 Noblegarden Chocolates.
	step //718
		goto 47.2,59.3
		.' Use your Spring Rabbit's Foot in your bags to get a Spring Rabbit companion |use Spring Rabbit's Foot##44794
		.' Bring out your Spring Rabbit companion |tip Press P to bring up your Spellbook and click on the Companions ribbon, then click the Spring Rabbit icon.
		.' Find a player with a Spring Rabbit next to them around Bloodhoof Village  
		.' Find your Spring Rabbit another one to love in Bloodhoof Village |achieve 2497/1
		|modelnpc Spring Rabbit##32791
	step //719
		goto 47.4,58.6
		.talk Tak##40809
		.' Fly to Thunk's Abode, Desolace |goto Desolace,70.7,32.9,0.5 |noway |c
	step //720
		'Equip your Spring Robes in your bags |equipped Spring Robes##44800 |use Spring Robes##44800
		.' Use your Spring Robes' ability to plant a flower |use Spring Robes##44800
		.' Plant a flower in Desolace |achieve 2436/2
	step //721
		goto Desolace,70.7,32.9
		.talk Thunk's Wyvern##35556
		.' Fly to Cenarion Hold, Silithus |goto Silithus,52.9,34.7,0.5 |noway |c
	step //722
		'Equip your Spring Robes in your bags |equipped Spring Robes##44800 |use Spring Robes##44800
		.' Use your Spring Robes' ability to plant a flower |use Spring Robes##44800
		.' Plant a flower in Silithus |achieve 2436/3
	step //723
		goto Silithus,52.8,34.6
		.talk Runk Windtamer##15178
		.' Fly to Mossy Pile, Un'Goro Crater |goto Un'Goro Crater,44.0,40.2,0.5 |noway |c
	step //724
		goto Un'Goro Crater,35.8,50.7
		.' Change into a bunny |tip You will need a friend to do this, or at least another player.  There should be plenty of players trying to do this achievement at the same time, so it should be easy to find help.  Have your friend, or other player, use their Blossoming Branch on you to turn you into a rabbit.
		.' Stand still until you lay an egg
		.' Lay a Noblegarden Egg in the Golakka Hot Springs |achieve 2416
	step //725
		goto 44.1,40.3
		.talk Flizzy Coilspanner##39175
		.' Fly to Gadgetzan, Tanaris |goto Tanaris,52.0,27.5,0.5 |noway |c
	step //726
		'Equip your Spring Robes in your bags |equipped Spring Robes##44800 |use Spring Robes##44800
		.' Use your Spring Robes' ability to plant a flower |use Spring Robes##44800
		.' Plant a flower in Tanaris |achieve 2436/4
	step //727
		goto Tanaris,52.0,27.6
		.talk Bulkrek Ragefist##7824
		.' Fly to Fizzle and Pozzik's Speedbarge, Thousand Needles |goto Thousand Needles,79.1,71.9,0.5 |noway |c
	step //728
		goto Thousand Needles,90.3,72.8
		'Equip your Spring Robes in your bags |equipped Spring Robes##44800 |use Spring Robes##44800
		.' Use your Spring Robes' ability to plant a flower |use Spring Robes##44800
		.' Plant a flower in Thousand Needles |achieve 2436/5
	step //729
		goto 79.2,72.0
		.talk Tilly Topspin##40768
		.' Fly to Razor Hill, Durotar |goto Durotar,53.0,43.6,0.5 |noway |c
	step //730
		goto Durotar,52.5,42.7
		.' Bring out your Spring Rabbit companion |tip Press P to bring up your Spellbook and click on the Companions ribbon, then click the Spring Rabbit icon.
		.' Find a player with a Spring Rabbit next to them around Razor Hill 
		.' Find your Spring Rabbit another one to love in Razor Hill |achieve 2497/4
		|modelnpc Spring Rabbit##32791
	step //731
		goto 53.1,43.6
		.talk Burok##41140
		.' Fly to Orgrimmar, Durotar |goto Orgrimmar,49.3,59.4,0.5 |noway |c
	step //732
		goto Orgrimmar,50.8,55.8 |n
		.' Ride the zeppelin to Tirisfal Glades |goto Tirisfal Glades |noway |c
	step //733
		goto Tirisfal Glades,61.0,52.7
		.' Bring out your Spring Rabbit companion |tip Press P to bring up your Spellbook and click on the Companions ribbon, then click the Spring Rabbit icon.
		.' Find a player with a Spring Rabbit next to them around Brill 
		.' Find your Spring Rabbit another one to love in Brill |achieve 2497/2
		|modelnpc Spring Rabbit##32791
	step //734
		'Go south to Undercity |goto Undercity |noway |c
	step //735
		goto Undercity,54.9,11.2 |n
		.' Click the Orb of Translocation to go to Silvermoon City |goto Silvermoon City |noway |c |tip It's a glowing red crystal ball in a side room of the Ruins of Lordaeron.
		|modelnpc Orb of Translocation##7186
	step //736
		'Use your Noblegarden Egg anywhere in Silvermoon City |use Noblegarden Egg##44818
		.' Hide a Brightly Colored Egg in Silvermoon City |achieve 2420
	step //737
		'Go outside to Eversong Woods |goto Eversong Woods |noway |c
	step //738
		goto Eversong Woods,47.5,46.5
		.' Bring out your Spring Rabbit companion |tip Press P to bring up your Spellbook and click on the Companions ribbon, then click the Spring Rabbit icon.
		.' Find a player with a Spring Rabbit next to them around Falconwing Square 
		.' Find your Spring Rabbit another one to love in Falconwing Square |achieve 2497/3
		|modelnpc Spring Rabbit##32791
	step //739
		'Go to Silvermoon City |goto Silvermoon City |noway |c
	step //740
		goto Silvermoon City,49.5,14.8 |n
		.' Click the Orb of Translocation to go to Undercity |goto Undercity |noway |c |tip It's a glowing red crystal ball in the back room of this building, up a big ramp.
		|modelnpc Orb of Translocation##7186
	step //741
		goto Undercity,63.3,48.5
		.talk Michael Garrett##4551
		.' Fly to New Kargath, Badlands |goto Badlands,17.3,40.2,0.5 |noway |c
	step //742
		'Equip your Spring Robes in your bags |equipped Spring Robes##44800 |use Spring Robes##44800
		.' Use your Spring Robes' ability to plant a flower |use Spring Robes##44800
		.' Plant a flower in The Badlands |achieve 2436/1
	step //743
		'Equip your Black Tuxedo Pants |equipped Black Tuxedo Pants##6835 |use Black Tuxedo Pants##6835
		'Equip your White Tuxedo Shirt |equipped White Tuxedo Shirt##6833 |use White Tuxedo Shirt##6833
		.' Find another player who is wearing the Elegant Dress and perform the Kiss emote on them |script DoEmote("KISS") |tip The Elegant Dress looks like a long pink dress when worn.
		.' Kiss someone wearing an Elegant Dress while wearing a White Tuxedo Shirt and Black Tuxedo Pants |achieve 2576
	step //744
		'Find a female character of every race that are at least level 18 and do the following: |tip The best places to try and find them would be Dalaran, Shattrath, Stormwind, and Orgrimmar
		.' Use your Spring Flowers on them |equipped Spring Flowers##45073 |use Spring Flowers##45073
		.' Place bunny ears on a Blood Elf |achieve 2422/1
		.' Place bunny ears on a Human |achieve 2422/6
		.' Place bunny ears on a Troll |achieve 2422/10
		.' Place bunny ears on a Draenei |achieve 2422/2
		.' Place bunny ears on a Night Elf |achieve 2422/7
		.' Place bunny ears on an Undead |achieve 2422/11
		.' Place bunny ears on a Dwarf |achieve 2422/3
		.' Place bunny ears on a Orc |achieve 2422/8
		.' Place bunny ears on a Gnome |achieve 2422/4
		.' Place bunny ears on a Tauren |achieve 2422/9
		.' Place bunny ears on a Goblin |achieve 2422/5
		.' Place bunny ears on a Worgen |achieve 2422/12
	step //745
		'Congratulations, you are now a Noble Gardener!
]])

ZygorGuidesViewer:RegisterInclude("H_Noblegarden_Quests_Dailies",[[
	step //746
		goto Thunder Bluff,40.8,56.1
		.talk Tauren Commoner##19176
		..accept Spring Gatherers##13483
	step //747
		goto 47.0,49.6
		.talk Tal##2995
		.' Fly to Bloodhoof Village, Mulgore |goto Mulgore,47.4,58.7,0.5 |noway |c
	step //748
		goto Mulgore,46.9,59.5
		.talk Spring Gatherer##32798
		..turnin Spring Gatherers##13483
		..accept The Great Egg Hunt##13479 |daily
	step //749
		goto 47.1,59.9
		.talk Noblegarden Merchant##32837
		..accept A Tisket, a Tasket, a Noblegarden Basket##13503
	step //750
		'Search around Bloodhoof Village for Brightly Colored Eggs and click them:
		.click Brightly Colored Egg##1407+ 
		|tip There is at least one available at all times. If Bloodhoof Village is too crowded with other players looking for eggs, you can also find them at Razor Hill, Falconwing Square, and Brill.
		.collect Brightly Colored Egg##45072+ |n
		.' Click Brightly Colored Eggs in your bags |use Brightly Colored Egg##45072
		.get 20 Brightly Colored Shell Fragment |q 13479/1
		.get 10 Noblegarden Chocolate |q 13503/1
	step //751
		goto 47.1,59.9
		.talk Noblegarden Merchant##32837
		..turnin A Tisket, a Tasket, a Noblegarden Basket##13503
	step //752
		goto 46.9,59.5
		.talk Spring Gatherer##32798
		..turnin The Great Egg Hunt##13479
]])

--CHILDREN'S VEIL--

ZygorGuidesViewer:RegisterInclude("H_Children's_Week_Ogrimmar_Quests",[[
	step //753
		goto Orgrimmar,58.0,57.6
		.talk Orphan Matron Battlewail##51989 |tip This npc may walk around, so some searching may be required.
		..accept Children's Week##172
	step //754
		'Use your Orcish Orphan Whistle to summon your Orcish Orphan |use Orcish Orphan Whistle##18597
		.talk Orcish Orphan##14444
		..turnin Children's Week##172
		..accept Ridin' the Rocketway##29146
		..accept The Fallen Chieftain##29176
		..accept The Banshee Queen##29167
	step //755
		|fly Southern Rocketway Terminus
	step //756
		goto 50.7,73.9
		.clicknpc Redhound Two-Seater##52583
		.' Take Your Orphan to Ride the Rocketway |q 29146/1
	step //757
		'Use your Orcish Orphan Whistle to summon your Orcish Orphan |use Orcish Orphan Whistle##18597
		.talk Orcish Orphan##14444
		..turnin Ridin' the Rocketway##29146
	step //758
		goto 25.9,49.6
		.talk Bilgewater Rocket-jockey##43217
		..' Tell him Southern Rocketway Terminus, please
		.' Ride the rocket to Southern Rocketway Terminus |goto 50.7,74.1,1.0 |noway |c
	step //759
		|fly Thunder Bluff
	step //760
		'Go outside to Mulgore |goto Mulgore |noway |c
	step //761
		goto Mulgore,60.7,23.1
		.' Use your Human Orphan Whistle to summon your Human Orphan |use Human Orphan Whistle##18597
		.' Take Your Orphan to Visit Red Rocks |q 29176/1
	step //762
		'Use your Orcish Orphan Whistle to summon your Orcish Orphan |use Orcish Orphan Whistle##18597
		.talk Orcish Orphan##14444
		..turnin The Fallen Chieftain##29176
	step //763
		'Go west to Thunder Bluff |goto Thunder Bluff |noway |c
	step //764
		|fly Orgrimmar
	step //765
		goto Orgrimmar,50.8,55.8 |n
		.' Ride the zeppelin to Tirisfal Glades |goto Tirisfal Glades |noway |c
	step //766
		'Go south to Undercity |goto Undercity |noway |c
	step //767
		goto Undercity,52.4,64.2 |n
		.' Follow the path down |goto Undercity,52.4,64.2,0.5 |noway |c
	step //768
		goto 58.1,91.8
		.' Use your Human Orphan Whistle to summon your Human Orphan |use Human Orphan Whistle##18597
		.' Take Your Orphan to a Meeting with Lady Sylvanas Windrunner |q 29167/1
	step //769
		'Use your Orcish Orphan Whistle to summon your Orcish Orphan |use Orcish Orphan Whistle##18597
		.talk Orcish Orphan##14444
		..turnin The Banshee Queen##29167
		..accept Let's Go Fly a Kite##29190
		..accept You Scream, I Scream...##29191
	step //770
		'Go outside to Tirisfal Glades |goto Tirisfal Glades |noway |c
	step //771
		goto Tirisfal Glades,60.7,58.8 |n
		.' Ride the zeppelin to Orgrimmar |goto Orgrimmar |noway |c
	step //772
		goto Orgrimmar,58.3,55.0
		.talk Blax Bottlerocket##52809
		.buy 1 Dragon Kite 2-Pack##69231 |q 29190
	step //773
		'Use your Orcish Orphan Whistle to summon your Orcish Orphan |use Orcish Orphan Whistle##18597
		.' When your orphan is next to you:
		.' Use your Dragon Kite 2-Pack |use Dragon Kite 2-Pack##69231
		.' Fly Dragon Kites with Your Orphan |q 29190/1
	step //774
		'Use your Orcish Orphan Whistle to summon your Orcish Orphan |use Orcish Orphan Whistle##18597
		.talk Orcish Orphan##14444
		..turnin Let's Go Fly a Kite##29190
	step //775
		goto 38.8,87.0
		.talk Snixx Quickfreeze##52818
		.buy 1 Cone of Cold##69233 |q 29191
	step //776
		'Use your Orcish Orphan Whistle to summon your Orcish Orphan |use Orcish Orphan Whistle##18597
		.' When your orphan is next to you:
		.' Use your Cone of Cold |use Cone of Cold##69233
		.' Take Your Orphan Out for Ice Cream |q 29191/1
	step //777
		'Use your Orcish Orphan Whistle to summon your Orcish Orphan |use Orcish Orphan Whistle##18597
		.talk Orcish Orphan##14444
		..turnin You Scream, I Scream...##29191
		..accept A Warden of the Horde##5502
	step //778
		goto 58.3,55.0
		.talk Blax Bottlerocket##52809
		.buy 1 Foam Sword Rack |q 5502/1
	step //779
		goto 58.0,57.6
		.talk Orphan Matron Battlewail##51989
		..turnin A Warden of the Horde##5502 |tip You will be able to choose from 3 pet companions or a 5 gold reward.  If you already have all 3 pets, choose the gold.  You will be able to do this quest each year, so you will be able to collect all 3 pets, eventually.
]])
ZygorGuidesViewer:RegisterInclude("H_Children's_Week_Shattrath_Quests",[[
	step //780
		goto Shattrath City,74.9,47.9
		.talk Orphan Matron Mercy##22819
		..accept Children's Week##10942
	step //781
		'Use your Blood Elf Orphan Whistle to summon your Blood Elf Orphan |use Blood Elf Orphan Whistle##31880
		.talk Blood Elf Orphan##22817
		..turnin Children's Week##10942
		..accept Hch'uu and the Mushroom People##10945
		..accept A Trip to the Dark Portal##10951
		..accept Visit the Throne of the Elements##10953 
	step //782
		goto Nagrand,60.7,22.3
		.' Use your Blood Elf Orphan Whistle to summon your Blood Elf Orphan |use Blood Elf Orphan Whistle##31880
		.' Take Salandria to the Throne of the Elements |q 10953/1
	step //783
		goto Nagrand,60.7,22.1
		.talk Elementalist Sharvak##18072
		..turnin Visit the Throne of the Elements##10953
	step //784
		goto Zangarmarsh,19.3,51.3
		.' Use your Blood Elf Orphan Whistle to summon your Blood Elf Orphan |use Blood Elf Orphan Whistle##31880
		.' Take Salandria to Sporeggar |q 10945/1
	step //785
		goto Zangarmarsh,19.3,51.3
		.talk Hch'uu##22823
		..turnin Hch'uu and the Mushroom People##10945
	step //786
		goto Hellfire Peninsula,89.6,50.2
		.' Use your Blood Elf Orphan Whistle to summon your Blood Elf Orphan |use Blood Elf Orphan Whistle##31880
		.' Take Salandria to the Dark Portal |q 10951/1
	step //787
		'Use your Blood Elf Orphan Whistle to summon your Blood Elf Orphan |use Blood Elf Orphan Whistle##31880
		.talk Blood Elf Orphan##22817
		..turnin A Trip to the Dark Portal##10951
		..accept Now, When I Grow Up...##11975
		..accept Time to Visit the Caverns##10963
	step //788
		'Go through the Dark Portal to the Blasted Lands |goto Blasted Lands |noway |c
	step //789
		'Go north to Swamp of Sorrows |goto Swamp of Sorrows |noway |c
	step //790
		|fly Booty Bay
	step //791
		goto The Cape of Stranglethorn,39.2,67.2 |n
		.' Ride the boat to Ratchet |goto Northern Barrens |noway |c
	step //792
		|fly Gadgetzan
	step //793
		goto Tanaris,61.5,50.6 |n
		.' The path to Zaladormu starts here |goto Tanaris,61.5,50.6,1 |noway |c
	step //794
		goto Tanaris,64.9,50.0 |n
		.' Enter the Caverns of Time here |goto Tanaris,64.9,50.0,0.5 |noway |c
	step //795
		'Follow the path down to 60.0,57.0 |goto Tanaris,60.0,57.0 |tip You will end up underground, in the Caverns of Time, next to a big dragon named Zaladormu, who is laying on a big platform.
		.' Use your Blood Elf Orphan Whistle to summon your Blood Elf Orphan |use Blood Elf Orphan Whistle##31880
		.' Take Salandria to the Caverns of Time |q 10963/1
	step //796
		goto Tanaris,63.0,57.3
		.talk Alurmi##21643
		.buy 1 Toy Dragon##31951 |q 10963/2
	step //797
		'Use your Blood Elf Orphan Whistle to summon your Blood Elf Orphan |use Blood Elf Orphan Whistle##31880
		.talk Blood Elf Orphan##22817
		..turnin Time to Visit the Caverns##10963
	step //798
		'Go outside to 52.0,27.6 |goto Tanaris,52.0,27.6
		|fly Orgrimmar
	step //799
		goto Orgrimmar,50.9,55.8 |n
		.' Go up the tower and ride the zeppelin to Tirisfal Glades |goto Tirisfal Glades |noway |c
	step //800
		'Go south to Undercity |goto Undercity |noway |c
	step //801
		goto 54.9,11.3 |n
		.' Click the Orb of Translocation to go to Silvermoon City |goto Silvermoon City |noway |c |tip It's a red floating ball with 3 small golden statues spinning around it, in a side room in the Ruins of Lordaeron.
	step //802
		goto Silvermoon City,76.7,80.7
		.' Use your Blood Elf Orphan Whistle to summon your Blood Elf Orphan |use Blood Elf Orphan Whistle##31880
		.' Take Salandria to see the Elite Tauren Chieftain in Silvermoon City's Walk of Elders
		.talk Blood Elf Orphan##22817
		..turnin Now, When I Grow Up...##11975
		..accept Back to the Orphanage##10967
	step //803
		goto Silvermoon City,58.4,21.0 |n
		.' Click the Portal to Blasted Lands to go to the Blasted Lands |goto Blasted Lands |noway |c
	step //804
		'Go south through the Dark Portal to Hellfire Peninsula |goto Hellfire Peninsula |noway |c
	step //805
		|fly Shattrath
	step //806
		goto Shattrath City,74.9,47.9
		.talk Orphan Matron Mercy##22819
		..turnin Back to the Orphanage##10967 |tip You will be able to choose from 4 pet companions. Only Egbert's Egg, Elekk Training Collar, and Sleepy Willy count toward an achievement.
]])
ZygorGuidesViewer:RegisterInclude("H_Children's_Week_Oracle_Quests",[[
	step //807
		goto Dalaran,49.4,63.2
		.talk Orphan Matron Aria##34365
		..accept Little Orphan Roo Of The Oracles##13926
		..' Ask about the orphans
		..' Speak to Orphan Matron Aria and accept to care for the Oracle Orphan |q 13926/1
	step //808
		'Use your Oracle Orphan Whistle to summon your Oracle Orphan |use Oracle Orphan Whistle##46397
		.talk Oracle Orphan##33533
		..turnin Little Orphan Roo Of The Oracles##13926
		..accept The Biggest Tree Ever!##13929
		..accept The Bronze Dragonshrine##13933
		..accept Playmates!##13950 
	step //809
		goto Grizzly Hills,50.8,42.8
		.' Use your Oracle Orphan Whistle to summon your Oracle Orphan |use Oracle Orphan Whistle##46397
		.' Take Roo to visit Grizzlemaw |q 13929/1
	step //810
		'Use your Oracle Orphan Whistle to summon your Oracle Orphan |use Oracle Orphan Whistle##46397
		.talk Oracle Orphan##33533
		..turnin The Biggest Tree Ever!##13929
	step //811
		goto Dragonblight,72.5,36.9
		.' Use your Oracle Orphan Whistle to summon your Oracle Orphan |use Oracle Orphan Whistle##46397
		.' Take Roo to visit the Bronze Dragonshrine |q 13933/1
	step //812
		'Use your Oracle Orphan Whistle to summon your Oracle Orphan |use Oracle Orphan Whistle##46397
		.talk Oracle Orphan##33533
		..turnin The Bronze Dragonshrine##13933
	step //813
		goto Borean Tundra,43.5,13.7
		.' Use your Oracle Orphan Whistle to summon your Oracle Orphan |use Oracle Orphan Whistle##46397
		.' Take Roo to visit Winterfin Retreat |q 13950/1
	step //814
		'Use your Oracle Orphan Whistle to summon your Oracle Orphan |use Oracle Orphan Whistle##46397
		.talk Oracle Orphan##33533
		..turnin Playmates!##13950
		..accept The Dragon Queen##13954
		..accept Meeting a Great One##13956
	step //815
		goto Sholazar Basin,40.3,83.0 |n
		.' Walk into the light to teleport to Un'Goro Crater |goto Un'Goro Crater |noway |c
	step //816
		goto Un'Goro Crater,47.5,9.2
		.' Use your Oracle Orphan Whistle to summon your Oracle Orphan |use Oracle Orphan Whistle##46397
		.' Take Roo to visit The Etymidian |q 13956/1
	step //817
		'Use your Oracle Orphan Whistle to summon your Oracle Orphan |use Oracle Orphan Whistle##46397
		.talk Oracle Orphan##33533
		..turnin Meeting a Great One##13956
	step //818
		goto Un'Goro Crater,50.5,7.8 |n
		.' Walk into the light to teleport to Sholazar Basin |goto Sholazar Basin |noway |c
	step //819
		goto Dragonblight,59.8,54.7
		.' Use your Oracle Orphan Whistle to summon your Oracle Orphan |use Oracle Orphan Whistle##46397
		.' Take Roo to visit Alexstrasza the Life-Binder |q 13954/1 |tip Alexstrasza the Life-Binder is at the top of Wyrmrest Temple.
	step //820
		'Use your Oracle Orphan Whistle to summon your Oracle Orphan |use Oracle Orphan Whistle##46397
		.talk Oracle Orphan##33533
		..turnin The Dragon Queen##13954
		..accept A Trip To The Wonderworks##13937
	step //821
		|fly Dalaran
	step //822
		goto Dalaran,44.9,45.6
		.talk Jepetto Joybuzz##29478
		.buy 1 Small Paper Zeppelin##46693
	step //823
		'Use your Oracle Orphan Whistle to summon your Oracle Orphan |use Oracle Orphan Whistle##46397
		.' Use your Small Paper Zeppelin on your Oracle Orphan |use Small Paper Zeppelin##46693
		.' Throw the Small Paper Zeppelin to Roo |q 13937/1
	step //824
		'Use your Oracle Orphan Whistle to summon your Oracle Orphan |use Oracle Orphan Whistle##46397
		.talk Oracle Orphan##33533
		..turnin A Trip To The Wonderworks##13937
		..accept Back To The Orphanage##13959
	step //825
		goto Dalaran,49.4,63.2
		.talk Orphan Matron Aria##34365
		..turnin Back To The Orphanage##13959 |tip You will receive a Curious Oracle Hatchling pet companion in the mail.
]])
ZygorGuidesViewer:RegisterInclude("H_Children's_Week_Wolvar_Quests",[[
	step //826
		goto Dalaran,49.4,63.2
		.talk Orphan Matron Aria##34365
		..accept Little Orphan Kekek Of The Wolvar##13927
		..' Ask about the orphans
		..' Speak to Orphan Matron Aria and accept to care for the Wolvar Orphan |q 13927/1
	step //827
		'Use your Wolvar Orphan Whistle to summon your Wolvar Orphan |use Wolvar Orphan Whistle##46396
		.talk Wolvar Orphan##33532
		..turnin Little Orphan Kekek Of The Wolvar##13927
		..accept Home Of The Bear-Men##13930
		..accept The Bronze Dragonshrine##13934
		..accept Playmates!##13951 
	step //828
		goto Grizzly Hills,50.8,42.8
		.' Use your Wolvar Orphan Whistle to summon your Wolvar Orphan |use Wolvar Orphan Whistle##46396
		.' Take Kekek to visit Grizzlemaw |q 13930/1
	step //829
		'Use your Wolvar Orphan Whistle to summon your Wolvar Orphan |use Wolvar Orphan Whistle##46396
		.talk Wolvar Orphan##33532
		..turnin Home Of The Bear-Men##13930
	step //830
		goto Dragonblight,72.5,36.9
		.' Use your Wolvar Orphan Whistle to summon your Wolvar Orphan |use Wolvar Orphan Whistle##46396
		.' Take Kekek to visit the Bronze Dragonshrine |q 13934/1
	step //831
		'Use your Wolvar Orphan Whistle to summon your Wolvar Orphan |use Wolvar Orphan Whistle##46396
		.talk Wolvar Orphan##33532
		..turnin The Bronze Dragonshrine##13934
	step //832
		goto Dragonblight,45.3,63.3
		.' Use your Wolvar Orphan Whistle to summon your Wolvar Orphan |use Wolvar Orphan Whistle##46396
		.' Take Kekek to visit Snowfall Glade |q 13951/1
	step //833
		'Use your Wolvar Orphan Whistle to summon your Wolvar Orphan |use Wolvar Orphan Whistle##46396
		.talk Wolvar Orphan##33532
		..turnin Playmates!##13951
		..accept The Dragon Queen##13955
		..accept The Mighty Hemet Nesingwary##13957
	step //834
		goto Dragonblight,59.8,54.7
		.' Use your Wolvar Orphan Whistle to summon your Wolvar Orphan |use Wolvar Orphan Whistle##46396
		.' Take Kekek to visit Alexstrasza the Life-Binder |q 13955/1 |tip Alexstrasza the Life-Binder is at the top of Wyrmrest Temple.
	step //835
		'Use your Wolvar Orphan Whistle to summon your Wolvar Orphan |use Wolvar Orphan Whistle##46396
		.talk Wolvar Orphan##33532
		..turnin The Dragon Queen##13955
	step //836
		goto Sholazar Basin,27.1,58.7
		.' Use your Wolvar Orphan Whistle to summon your Wolvar Orphan |use Wolvar Orphan Whistle##46396
		.' Take Kekek to visit Hemet Nesingwary |q 13957/1
	step //837
		'Use your Wolvar Orphan Whistle to summon your Wolvar Orphan |use Wolvar Orphan Whistle##46396
		.talk Wolvar Orphan##33532
		..turnin The Mighty Hemet Nesingwary##13957	
		..accept A Trip To The Wonderworks##13938
	step //838
		|fly Dalaran
	step //839
		goto Dalaran,44.9,45.6
		.talk Jepetto Joybuzz##29478
		.buy 1 Small Paper Zeppelin##46693
	step //840
		'Use your Wolvar Orphan Whistle to summon your Wolvar Orphan |use Wolvar Orphan Whistle##46396
		.' Use your Small Paper Zeppelin on your Wolvar Orphan |use Small Paper Zeppelin##46693
		.' Throw the Small Paper Zeppelin to Kekek |q 13938/1
	step //841
		'Use your Wolvar Orphan Whistle to summon your Wolvar Orphan |use Wolvar Orphan Whistle##46396
		.talk Wolvar Orphan##33532
		..turnin A Trip To The Wonderworks##13938
		..accept Back To The Orphanage##13960
	step //842
		goto Dalaran,49.4,63.2
		.talk Orphan Matron Aria##34365
		..turnin Back To The Orphanage##13960 |tip You will receive a Curious Wolvar Pup pet companion in the mail.
]])
ZygorGuidesViewer:RegisterInclude("H_Children's_Week_Achievements",[[
	step //843
		goto Orgrimmar,70.9,25.6
		.talk Orphan Matron Battlewail##14451
		..' Ask her for another Orphan Whistle |collect 1 Orcish Orphan Whistle##18597
	step //844
		'Complete any 5 daily quests of your choice: |tip Make sure your orphan is standing next to you when turning in the daily quests, or you won't get credit for this achievement.
		.' Get the Daily Chores Achievement |achieve 1789
	step //845
		goto Orgrimmar,52.2,69.0
		.talk Alowicious Czervik##14480
		..buy 1 Tigule and Foror's Strawberry Ice Cream##7228 |achieve 1788
	step //846
		'Purchase the follow items from the Auction House, or use your Cooking ability to create them, if you'd like:
		.collect 1 Tasty Cupcake##43490 |achieve 1788
		.collect 1 Delicious Chocolate Cake##33924 |achieve 1788
	step //847
		goto Dalaran,51.2,29.1
		.talk Aimee##29548
		..buy 1 Red Velvet Cupcake##42429 |achieve 1788
		..buy 1 Lovely Cake##42438 |achieve 1788
		..buy 1 Dalaran Doughnut##42430 |achieve 1788
		..buy 1 Dalaran Brownie##42431 |achieve 1788
	step //848
		'Use your Lovely Cake in your bags to place a cake on the ground |use Lovely Cake##42438
		.' Click the Lovely Cake
		.collect 1 Lovely Cake Slice##42434 |achieve 1788
	step //849
		'Use whichever Orphan Whistle you currently have to summon your Orphan, so that the Orphan is standing next to you:
		.' Eat Tigule and Foror's Strawberry Ice Cream |achieve 1788/1 |use Tigule and Foror's Strawberry Ice Cream##7228
		.' Eat Tasty Cupcake |achieve 1788/2 |use Tasty Cupcake##43490
		.' Eat Red Velvet Cupcake |achieve 1788/3 |use Red Velvet Cupcake##42429
		.' Eat Delicious Chocolate Cake |achieve 1788/4 |use Delicious Chocolate Cake##33924
		.' Eat Lovely Cake Slice |achieve 1788/5 |use Lovely Cake Slice##42434
		.' Eat Dalaran Brownie |achieve 1788/6 |use Dalaran Brownie##42431
		.' Eat Dalaran Doughnut |achieve 1788/7 |use Dalaran Doughnut##42430
	step //850
		'Use your Hearthstone while your Orphan is standing next to you |use Hearthstone##6948
		.' Get the Home Alone Achievement |achieve 1791
	step //851
		'The following achievements are a little more dynamic, so we cannot walk you step-by-step through getting them. 
		|confirm
	step //852
		'Find a group, run the Utgarde Pinnacle dungeon, and defeat King Ymiron |tip Make sure your Orphan is standing next to you when you defeat King Ymiron, or else you won't get credit for the achievement.
		.' Get the Hail To The King, Baby Achievement |achieve 1790
	step //853
		'Enter the Eye of the Storm battleground and capture the flag |tip Make sure your Orphan is standing next to you when you capture the flag, or else you won't get credit for the achievement.
		.' Capture the flag in Eye of the Storm |achieve 1786/1
	step //854
		'Enter the Alterac Valley battleground and assault a tower |tip Make sure your Orphan is standing next to you when you assault the tower, or else you won't get credit for the achievement.
		.' Assault a tower in Alterac Valley |achieve 1786/2
	step //855
		'Enter the Arathi Basin battleground and assault a flag |tip Make sure your Orphan is standing next to you when you assault the flag, or else you won't get credit for the achievement.
		.' Assault a flag in Arathi Basin |achieve 1786/3
	step //856
		'Enter the Warsong Gulch battleground and return a fallen flag |tip Make sure your Orphan is standing next to you when you return the fallen flag, or else you won't get credit for the achievement.
		.' Return a fallen flag in Warsong Gulch |achieve 1786/4
	step //857
		'Congratulations, you do it For The Children! |achieve 1793/1 
]])
-- WINTERS VEIL --

ZygorGuidesViewer:RegisterInclude("H_Winterveil_Quests",[[
	step //858
		goto Orgrimmar,52.7,77.3
		.talk Kaymard Copperpinch##13418
		..accept Great-father Winter is Here!##6961
		..accept You're a Mean One...##6983 |daily
	step //859
		goto 49.6,78.0
		.talk Great-father Winter##13445
		..turnin Great-father Winter is Here!##6961
		..accept Treats for Great-father Winter##6962
	step //860
		goto 51.0,71.0
		.talk Furmund##9550
		..accept The Reason for the Season##6964
	step //861
		goto 56.1,61.7
		.talk Arugi##46709
		.' Learn the Apprentice Cooking skill.
		|only if skill("Cooking")<=1
	step //862
		goto 39.5,47.3
		.talk Sagorne Creststrider##13417
		..turnin The Reason for the Season##6964
		..accept The Feast of Winter Veil##7061
	step //863
		goto 52.5,76.8
		.talk Penney Copperpinch##13420
		.buy 1 Recipe: Gingerbread Cookie##17200 |n
		.learn Gingerbread Cookie##21143
		.' Click the Recipe: Gingerbread Cookie recipe in your bags |use Recipe: Gingerbread Cookie##17200
		.' Learn the Gingerbread Cookie recipe
		.buy 5 Holiday Spices##17194 |q 6962
	step //864
		'Buy 5 Small Eggs from the Auction House: |tip You can also farm these from mobs.
		.collect 5 Small Egg##6889 |q 6962
	step //865
		goto 53.8,84.7
		.create Gingerbread Cookie##21143,Cooking,5 total |q 6962/1
	step //866
		goto 53.6,78.8
		.talk Innkeeper Gryshka##6929
		.buy Ice Cold Milk##1179 |future |q 6962
	step //867
		goto 53.6,78.8
		.talk Innkeeper Gryshka##6929
		.home Orgrimmar
	step //868
		goto 49.6,78.0
		.talk Great-father Winter##13445
		..turnin Treats for Great-father Winter##6962
	step //869
		#include "rideto_tirisfal"
	step //870
		|fly Tarren Mill
	step //871
		goto Hillsbrad Foothills,42.3,41.1
		.talk Strange Snowman##13636
		..accept You're a Mean One...##6983
	step //872
		goto Hillsbrad Foothills,43.6,39.0
		.from The Abominable Greench##13602 |tip This will require a group to kill, but you do not have to be in a party.
		.' Free Metzen the Reindeer |q 6983/1
		.get Stolen Treats |q 6983/2 |tip You can pick this up if someone has killed The Abominable Grinch recently.
	step //873
		|fly Brill
	step //874
		#include "rideto_org"
	step //875
		|fly Thunder Bluff
	step //876
		goto Thunder Bluff,60.3,51.7
		.talk Baine Bloodhoof##36648
		..turnin The Feast of Winter Veil##7061
	step //877
		'Hearth to Orgrimmar |goto Orgrimmar |use Hearthstone##6948 |noway |c
	step //878
		goto Orgrimmar,52.6,77.4
		.talk Kaymard Copperpinch##13418
		..turnin You're a Mean One...##6983
		..accept A Smokywood Pastures' Thank You!##6984
	step //879
		goto 49.6,78.0
		.talk Great-father Winter##13445
		..turnin A Smokywood Pastures' Thank You!##6984	
]])

ZygorGuidesViewer:RegisterInclude("H_Winterveil_Achievements",[[
	step //880
		goto Orgrimmar,54.5,77.8
		.' Kiss a Winter Reveler every hour |script DoEmote("KISS") |tip You can only use this once per hour. The items you get are random.
		.collect 10 Handful of Snowflakes##34191 |n
		.collect 3 Mistletoe##21519 |n
		.collect 1 Preserved Holly##21213 |n
		|confirm always
	step //881
		'Use a Handful of Snowflakes on the following race/class combinations |use Handful of Snowflakes##34191 |tip The best place to complete this is in major cities, but it can be done anywhere in the world.
		.' You can get more snowflakes by using /kiss on Winter Revelers at [54.5,77.8]
		.' Orc Death Knight |achieve 1687/1
		.' Human Warrior |achieve 1687/2
		.' Tauren Shaman |achieve 1687/3
		.' Night Elf Druid |achieve 1687/4
		.' Undead Rogue |achieve 1687/5
		.' Troll Hunter |achieve 1687/6
		.' Gnome Mage |achieve 1687/7
		.' Dwarf Paladin |achieve 1687/8
		.' Blood Elf Warlock |achieve 1687/9
		.' Draenei Priest |achieve 1687/10
	step //882
		'Use the Cooking profession to create Egg Nog and Hot Apple Cider
		.' You can get the recipes for these items from Penney Copperpinch at [52.5,76.8]
		.create Egg Nog##21144,Cooking,1 total |achieve 1688/2
		.create 1 Hot Apple Cider##45022,Cooking,1 total |achieve 1688/3 |tip Requires a cooking skill of 325
	step //883
		'Use the Tailoring profession or pay a tailor to create Green Winter Clothes
		.' You can buy the pattern from Penney Copperpinch at [52.5,76.8]
		.collect Green Winter Clothes##34087 |future |achieve 277 |or
		.' or
		.collect Red Winter Clothes##34085 |future |achieve 277 |or
	step //884
		'Use the Leatherworking profession or pay a leatherworker to create Winter Boots
		.' You can buy the pattern from Penney Copperpinch at [52.5,76.8]
		.collect Winter Boots##34086 |future |achieve 277
	step //885
		.' The Winter Hat will drop from any of these dungeons
		.' _Deadmines (Heroic)_ - Admiral Ripsnarl
		.' _The Stone Core (Normal + Heroic)_ - High Priestess Azil
		.' -Blackrock Caverns (Normal + Heroic)_ - Corla, Herald of Twilight
		.' _Shadowfang Keep (Heroic)_ - Lord Godfrey
		.' _Grim Batol (Normal + Heroic)_ - Drahga Shadowburner
		.collect 1 Green Winter Hat##21525 |future |achieve 277 |or
		.' or
		.collect 1 Red Winter Hat##21524 |future |achieve 277 |or
	step //886
		'Get the Smokywood Pastures Sampler from your mailbox |tip It should arrive within 24 hours after completing the Feast of Winter Veil quest section of this guide.
		.' Click the Smokywood Pastures Sampler in your bag |use Smokywood Pastures Sampler##17685
		.collect 1 Graccu's Mince Meat Fruitcake##21215 |future |achieve 277
		.' Equip the Green Winter Clothes |equipped Green Winter Clothes##34087 |use Green Winter Clothes##34087 |future |achieve 277
		.' or
		.' Equip the Red Winter Clothes |equipped Red Winter Clothes##34085 |use Red Winter Clothes##34085 |future |achieve 277
		.' Equip the Winter Boots |equipped  Winter Boots##34086 |use Winter Boots##34086 |future |achieve 277
		.' Equip the Green Winter Hat |equipped Winter Hat##21525 |use Winter Hat##21525 |future |achieve 277
		.' or
		.' Equip the Red Winter Hat |equipped Red Winter Hat##21524 |use Red Winter Hat##21524 |future |achieve 277
		.' During the Feast of Winter Veil, wear 3 pieces of winter clothing and eat Graccu's Mince Meat Fruitcake. |achieve 277 |use Graccu's Mince Meat Fruitcake##21215
	step //887
		goto Orgrimmar,50.2,62.1
		.' Use the Winter Wondervolt machine to turn into a Little Helper. If you don't have the buff active while killing players, you won't get credit.
		.' Do any type of PvP of your choice |tip You must be killing players that give you honor.
		.' Earn 50 honorable kills as a Little Helper from the Winter Wondervolt machine |achieve 252
	step //888
		'Make sure you have the following in your bags:
		.collect 3 Mistletoe##21519 |future |achieve 1282
		.collect 1 Preserved Holly##21213 |future |achieve 1282
	step //889
		goto 52.5,76.8
		.talk Penney Copperpinch##13420
		.buy 1 Snowball##17202 |future |achieve 259
	step //890
		goto 53.6,78.8
		.talk Innkeeper Gryshka##6929
		.home Orgrimmar
	step //891
		|fly Thunder Bluff
	step //892
		goto Thunder Bluff,60.3,51.7
		.' Use a snowball on Baine Bloodhoof |use Snowball##17202 |n
		.' Throw a snowball at Baine Bloodhoof during the Feast of Winter Veil |achieve 259
	step //893
		goto 47.0,49.8
		.talk Tal##2995
		.' Fly to Orgrimmar |goto Orgrimmar |noway |c
	step //894
		#include "rideto_tirisfal"
	step //895
		'Go south into Undercity |goto Undercity |noway |c
	step //896
		goto Undercity,50.8,21.7
		.' Use your Mistletoe on Brother Malach |use Mistletoe##21519 |modelnpc 5661
		.' Use Mistletoe on Brother Malach in the Undercity |achieve 1685/1
	step //897
		.' The following achievements require a level 70 or higher character.
		|confirm
	step //898
		goto 85.3,17.1 |n
		.' Click the portal to the Blasted Lands |goto Blasted Lands |noway |c
	step //899
		'Go into the huge green portal to Hellfire Peninsula |goto Hellfire Peninsula |noway |c
	//UNLOCK DAILIES
	step //900
		goto Blade's Edge Mountains,28.7,57.4
		.talk Chu'a'lor##23233
		..accept The Trouble Below##11057
		..accept The Crystals##11025
	step //901
		goto 29.2,53.7
		.from Apexis Flayer##22175+
		.get 5 Apexis Shard |q 11025/1
	step //902
		goto 28.8,57.4
		.talk Chu'a'lor##23233
		..turnin The Crystals##11025
		..accept An Apexis Relic##11058
	step //903
		goto 28.4,57.6
		.talk Torkus##23316
		..accept Our Boy Wants To Be A Skyguard Ranger##11030
	step //904
		goto 33.1,52.3
		.from Gan'arg Analyzer##23386+
		.collect Apexis Shard##32569 |n
		.' Click an Apexis Relic |tip It looks like a small multi-colored crystal floating in the air.
		..' Insert an Apexis Shard to begin.
		.' Stand on the white globe and watch as the crystal floating above you casts a beam on the surrounding clusters
		.' Click the clusters in the same color pattern as the crystal |tip You must do this eight times. If you mess up you will be given a few chances to correct yourself before you have to start the process over.
		.' Attain the Apexis Emanations |q 11058/1
	step //905
		goto 51.1,15.6
		.from Bash'ir Arcanist##22243+, Bash'ir Spell-Thief##22242+, Bash'ir Raider##22241+
		.collect 10 Apexis Shard##32569 
	step //906
		goto 32.8,40.5
		.' Click the Fel Crystalforge |tip It looks like a big metal machine with green smoke coming out of it.
		.' Purchase 1 Unstable Flask of the Beast
		.get Unstable Flask of the Beast |q 11030/1
	step //907
		goto 28.8,57.4
		.talk Chu'a'lor##23233
		..turnin An Apexis Relic##11058
		..accept The Relic's Emanation##11080 |daily
	step //908
		goto 28.4,57.7
		.talk Torkus##23316
		..turnin Our Boy Wants To Be A Skyguard Ranger##11030
	step //909
		goto 27.7,68.1
		.from Gan'arg Analyzer##23386+
		.collect Apexis Shard##32569 |n
		.' Click an Apexis Relic |tip It looks like a small multi-colored crystal floating in the air.
		.' Insert an Apexis Shard to begin.
		.' Stand on the white globe and watch as the crystal floating above you casts a beam on the surrounding clusters
		.' Click the clusters in the same color pattern as the crystal |tip You must do this six times. If you mess up you will be given a few chances to correct yourself before you have to start the process over.
		.' Attain the Apexis Vibrations |q 11080/1
	step //910
		goto 28.8,57.4
		.talk Chu'a'lor##23233
		..turnin The Relic's Emanation##11080
		..accept The Skyguard Outpost##11062
	step //911
		goto 27.4,52.7
		.talk Sky Commander Keller##23334
		..turnin The Skyguard Outpost##11062
	//END UNLOCKING DAILIES
	step //912
		goto 27.6,52.9
		.talk Sky Sergeant Vanderlip##23120
		..accept Bombing Run##11010
	step //913
		goto 36.8,39.4
		.' While on your flying mount, use the Skyguard Bombs on Fel Cannonball Stacks |use Skyguard Bombs##32456
		.' Destroy 15 Fel Cannonball Stacks |q 11010/1
	step //914
		goto 27.6,52.9
		.talk Sky Sergeant Vanderlip##23120
		..turnin Bombing Run##11010
		..accept Bomb Them Again!##11023 |daily
	step //915
		'Use Preserved Holly while riding your flying mount |havebuff Interface\Icons\INV_Misc_Plant_03 |use Preserved Holly##21213
	step //916
		goto 36.8,39.4
		.' While on riding the Reindeer Mount, use the Skyguard Bombs on Fel Cannonball Stacks |use Skyguard Bombs##32456
		.' Destroy 15 Fel Cannonball Stacks |q 11023/1
	step //917
		goto 27.6,52.9
		.talk Sky Sergeant Vanderlip##23120
		..turnin Bomb Them Again!##11023 |daily |tip You have to be on your mount when turning in the quest.
		.' Complete the Bomb Them Again! quest while mounted on a flying reindeer during the Feast of Winter Veil |achieve 1282
	step //918
		'Hearth to Orgrimmar |goto Orgrimmar |use Hearthstone##6948 |noway |c
	//DALARAN
	step //919
		#include "rideto_borean"
	step //920
		goto 40.2,55.0
		.' Use your Mistletoe on Durkot Wolfbrother |use Mistletoe##21519
		.' Use Mistletoe on Durkot Wolfbrother in Warsong Hold |achieve 1685/2
		'|modelnpc 26044
	step //921
		|fly Argent Tournament Grounds
	step //922
		'Orgrim's Hammer flies in a triangular pattern using these points:
		.' Point 1: [60.6,34.9]
		.' Point 2: [68.0,52.5]
		.' Point 3: [68.9,27.0]
		.'Find Orgrim's Hammer flying around in the sky |tip On you world map, it looks like a ship icon with 2 long red-ish ballons on either side of it.
		.' Use your Mistletoe on Brother Keltan |use Mistletoe##21519 |tip He is a blood elf with gray hair and walks all around the Orgrim's Hammer airship.
		.' Use Mistletoe on Brother Keltan in Icecrown |achieve 1685/3
		'|modelnpc 31261
	 step //923
		|fly Dalaran
	step //924
		goto Dalaran,50.3,63.2
		.' Get the Winter Veil Disguise Kit from your mailbox |tip It should arrive within 24 hours after completing the Feast of Winter Veil quest section of this guide.
		.' Equip the Winter Veil Disguise Kit in your bag |use Winter Veil Disguise Kit##17712
		.' Dance with another player wearing their snowman costume |script DoEmote("DANCE")
		.' During the Feast of Winter Veil, use your Winter Veil Disguise kit to become a snowman and then dance with another snowman in Dalaran |achieve 1690
	step //925
		goto Orgrimmar,49.6,78.1
		.' This step can only be completed by logging into the server on December 25th.
		.' Click a present underneath the tree.
		.' Open one of the presents underneath the Winter Veil tree once they are available. |achieve 1689
		.' Earn the Achievement and Title Merrymaker! |achieve 1691
	step //926
		.' Click the presents under the tree on _December 25th_ and receive 
		.collect Gaudy Winter Veil Sweater##70923 |future |achieve 5854
		.' Go to Stormwind, use your Sweater to sing carol's |achieve 5854/4
		.' Go to Ironforge, use your Sweater to sing carol's |achieve 5854/3
		.' Go to The Exodar, use your Sweater to sing carol's |achieve 5854/2
		.' Go to Darnassus, use your Sweater to sing carol's |achieve 5854/1
	step //927
		.' Click the presents under the tree on _December 25th_ and receive 
		.' Crashin' Thrashin' Racer. 
		.' Gain 25 crashes with your racer |achieve 1295
]])


-- HALLOWS END --
ZygorGuidesViewer:RegisterInclude("Hallows_End_Quests_Horde",[[
	step //928
		#include "rideto_tirisfal"
	step //929
		goto Undercity,63.3,47.6
		.talk Forsaken Commoner##19178
		..accept A Season for Celebration##29400
		..accept Masked Orphan Matron##11357 |tip You may not be able to accept this quest.
	step //930
		goto Undercity,67.4,6.6
		.talk Spoops##15309
		..accept Hallow's End Treats for Spoops!##8312
	step //931
		goto Undercity,67.4,13.1
		.talk Darkcaller Yanka##15197
		..turnin A Season for Celebration##29400
	step //932
		goto 68.8,7.9
		.talk Candace Fenlow##53763
		..accept A Friend in Need##29431
	step //933
		goto Undercity,67.7,37.9
		.talk Innkeeper Norman##6741
		..accept Chicken Clucking for a Mint##8354
	step //934
		goto 67.7,37.9
		.' While targeting Innkeeper Norman:
		.' Cluck like a Chicken for Innkeeper Norman |script DoEmote("CHICKEN") |q 8354/1
	step //935
		goto 67.7,37.9
		.talk Innkeeper Norman##6741
		..turnin Chicken Clucking for a Mint##8354
	step //936
		#include "rideto_org"
	step //937
		goto Orgrimmar,32.9,65.1
		.talk Kali Remik##11814
		..accept Incoming Gumdrop##8358
	step //938
		goto 32.9,65.1
		.' While targeting Kali Remik:
		.' Make Train sounds for Kali Remik |script DoEmote("TRAIN") |q 8358/1
	step //939
		goto 32.9,65.1
		.talk Kali Remik##11814
		..turnin Incoming Gumdrop##8358
	step //940
		goto 53.6,78.8
		.talk Innkeeper Gryshka##6929
		..accept Flexing for Nougat##8359
	step //941
		goto 53.6,78.8
		.' While targeting Innkeeper Gryshka:
		.' Flex for Innkeeper Gryshka |script DoEmote("FLEX") |q 8359/1
	step //942
		goto 53.6,78.8
		.talk Innkeeper Gryshka##6929
		..turnin Flexing for Nougat##8359
	step //943
		goto Orgrimmar,54.4,77.6
		.talk Edgar Goodwin##54141
		..turnin A Friend in Need##29431
		..accept Missing Heirlooms##29415
	step //944
		goto Durotar,57.4,9.0
		.talk Hired Courier##54142
		..turnin Missing Heirlooms##29415
		..accept Fencing the Goods##29416
	step //945
		goto Orgrimmar,54.1,73.4
		.talk Auctioneer Drezmit##44866
		.' Follow the Thief's Trail and Question Auctioneer Drezmit |q 29416/1
	step //946
		goto 54.1,73.4
		.talk Auctioneer Drezmit##44866
		..turnin Fencing the Goods##29416
		..accept Shopping Around##29425
	step //947
		  goto 58.0,48.0
		.' Listen to the Dialogue
		.' Investigate Droffers and Son |q 29425/1
	step //948
		goto 58.0,48.4
		.talk Delian Sunshade##54146
		..turnin Shopping Around##29425
		..accept Taking Precautions##29426
	step //949
		goto 46.0,49.3
		.click Blood Nettle##10249
		.get 5 Blood Nettle |q 29426/3
		.' You can find more Blood Nettle's here: [43.6,48.8]
	step //950
		goto 55.2,45.9
		.talk Kor'geld##3348
		.buy 5 Crystal Vial |q 29426/1
	step //951
		goto 57.2,46.5
		.talk Magenius##3351
		.buy 5 Arcane Powder |q 29426/2
	step //952
		goto 58.0,48.4
		.talk Delian Sunshade##54146
		..turnin Taking Precautions##29426
		..accept The Collector's Agent##29427
	step //953
		|fly Thunder Bluff
	step //954
		goto 45.8,64.7
		.talk Innkeeper Pala##6746
		..accept Dancing for Marzipan##8360
	step //955
		goto 45.8,64.7
		.' While targeting Innkeeper Pala:
		.' Dance for Innkeeper Pala |script DoEmote("DANCE") |q 8360/1
	step //956
		goto 45.8,64.7
		.talk Innkeeper Pala##6746
		..turnin Dancing for Marzipan##8360
	step //957
		|fly Orgrimmar
	step //958
		'Go outside to Durotar |goto Durotar |noway |c
	step //959
		goto Durotar,52.6,41.2
		.talk Masked Orphan Matron##23973
		..turnin Masked Orphan Matron##11357
		..accept Fire Training##11361
	step //960
		goto 52.5,41.3
		.' Click the Water Barrel |tip It looks like a huge bucket of water.
		.collect Water Bucket##32971 |q 11361
	step //961
		goto 49.3,43.5
		.' Use your Water Bucket on the burning scarecrows |use Water Bucket##32971
		.' Fight 5 Fires |q 11361/1
		.' Collect more Water Buckets from the Water Barrel at [49.2,44.5]
	step //962
		goto 52.6,41.2
		.talk Masked Orphan Matron##23973
		..' You will only be able to accept 1 of the 2 daily quests
		..turnin Fire Training##11361
		..accept Stop the Fires!##11219 |or
		..accept "Let the Fires Come!"##12139|or
	step //963
		goto 52.5,41.3
		.' Click the Water Barrel |tip It looks like a huge bucket of water.
		.collect Water Bucket##32971 |q 11219
	step //964
		goto 52.5,41.3
		.' Click the Water Barrel |tip It looks like a huge bucket of water.
		.collect Water Bucket##32971 |q 12139
	step //965
		goto 52.2,42.6
		.' Use your Water Bucket on the fires all around this area |use Water Bucket##32971
		.' Put Out the Fires |q 11219/1 |tip You will need a group of people to complete this quest.  It is best to do this quest at peak hours.
		.' Collect more Water Buckets from the Water Barrel at [52.5,41.3]
	step //966
		goto 52.2,42.6
		.' Wait until the fires appear on the buildings in Razor Hill
		.' Use your Water Bucket on the fires all around this area |use Water Bucket##32971
		.' Put Out the Fires |q 12139/1 |tip You will need a group of people to complete this quest.  It is best to do this quest at peak hours.
		.' Collect more Water Buckets from the Water Barrel at [52.5,41.3]
	step //967
		goto 52.6,42.4
		.' Click the Large Jack-o'-Lantern |tip It's a burning pumpkin laying in the road.
		..accept Smash the Pumpkin##12155
	step //968
		goto 52.6,41.2
		.talk Masked Orphan Matron##23973
		..' You will only be able to accept 1 of the 2 daily quests
		..turnin Stop the Fires!##11219 |or
		..turnin "Let the Fires Come!"##12139 |or
		..turnin Smash the Pumpkin##12155
	step //969
		#include "rideto_tirisfal"
	step //970
		goto Undercity,67.4,6.6
		.talk Spoops##15309
		..turnin Hallow's End Treats for Spoops!##8312
	step //971
		goto Tirisfal Glades,65.5,75.1
		.' This is in the Ruins, not below in Undercity
		.' Disrupt the Meeting |q 29427/1 |tip You will have to fight a Void Walkers here.
	step //972
		goto 65.8,74.8
		.click Stolen Crate##335
		..turnin The Collector's Agent##29427
		..accept What Now?##29428
	step //973
		#include "rideto_org"
	step //974
		goto Orgrimmar,54.4,77.6
		.talk Edgar Goodwin##54141
		..turnin What Now?##29428
	step //975
		goto 54.5,77.5
		.click Edgar's Crate##335
		..turnin The Creepy Crate##29429
		.' You will receive _Creepy Crate_ companion
		.collect 1 Creepy Crate##71076 |use Creepy Crate##71076 |n
		.learnpet Creepy Crate##54128
]])

ZygorGuidesViewer:RegisterInclude("Hallows_End_Dailies_Horde",[[
	step //976
		goto Durotar,52.6,41.2
		.talk Masked Orphan Matron##23973
		..' You will only be able to accept 1 of the 2 daily quests
		..accept Stop the Fires!##11219 |daily |or
		..accept "Let the Fires Come!"##12139 |daily |or
	step //977
		goto 52.5,41.3
		.' Click the Water Barrel |tip It looks like a huge bucket of water.
		.collect Water Bucket##32971 |q 11219
	step //978
		goto 52.2,42.6
		.' Use your Water Bucket on the fires all around this area |use Water Bucket##32971
		.' Put Out the Fires |q 11219/1 |tip You will need a group of people to complete this quest.  It is best to do this quest at peak hours.
		.' Collect more Water Buckets from the Water Barrel at [52.5,41.3]
	step //979
		goto 52.5,41.3
		.' Click the Water Barrel |tip It looks like a huge bucket of water.
		.collect Water Bucket##32971 |q 12139
	step //980
		goto 52.2,42.6
		.' Wait until the fires appear on the buildings in Razor Hill
		.' Use your Water Bucket on the fires all around this area |use Water Bucket##32971
		.' Put Out the Fires |q 12139/1 |tip You will need a group of people to complete this quest.  It is best to do this quest at peak hours.
		.' Collect more Water Buckets from the Water Barrel at [52.5,41.3]
	step //981
		goto 52.6,42.4
		.' Click the Large Jack-o'-Lantern |tip It's a burning pumpkin laying in the road.
		..accept Smash the Pumpkin##12155 |daily
	step //982
		goto 52.6,41.2
		.talk Masked Orphan Matron##23973
		..' You will only be able to accept 1 of the 2 daily quests
		..turnin Stop the Fires!##11219
		..turnin "Let the Fires Come!"##12139
		..turnin Smash the Pumpkin##12155
	step //983
		#include "rideto_tirisfal"
	step //984
		goto Undercity,67.4,13.0
		.talk Darkcaller Yanka##15197
		..accept A Time to Build Up##29376 |daily
		..accept A Time to Break Down##29377 |daily
	step //985
		goto 67.7,14.5
		.click Bonfire##200
		.' Use the Bonfire |q 29376/1
		.click Wickerman Ashes##06421
		.' Use the Wickerman Ashes |q 29376/2
	step //986
		goto 67.3,13.1
		.talk Darkcaller Yanka##15197
		..turnin A Time to Build Up##29376
	step //987
		goto 68.8,7.8
		.talk Candace Fenlow##53763
		..accept Clean Up in Undercity##29375 |daily
		..accept Stink Bombs Away!##29374 |daily  
	step //988
		'All around Undercity
		Run to the Orange Smoke and clean up the stink bombs |use Arcane Cleanser##70727
		.' Remove 10 Stink Bombs |q 29375/1
	step //989
		goto 68.8,7.9
		.talk Candace Fenlow##53763
		..turnin Clean Up in Undercity##29375
	step //990
		goto 67.5,9.2
		.talk Crina Fenlow##53764
		.' I'm ready to attack Stormwind! |invehicle
	step //991
		.' Use the _Toss Stink Bomb_ ability on your action bar all around _Stormwind_
		.' Drop 25 Stink Bombs |q 29374/1
		.' Click the _Return Home_ button on your action bar |outvehicle
	step //992
		goto 68.8,7.8
		.talk Candace Fenlow##53763
		..turnin Stink Bombs Away!##29374
	step //993
		#include "rideto_stranglethorn"
	step //994
		goto Elwynn Forest,33.6,48.2
		.' Use the Dousing Agent in your Bags on the _Wickerman_ when you fly in front of _Stormwind_ |use Dousing Agent##68647
		.' Douse the Alliance's Wickerman |q 29377/1
	step //995
		#include "rideto_stranglethorn"
	step //996
		goto Undercity,67.4,13.0
		.talk Darkcaller Yanka##15197
		..turnin A Time to Break Down##29377
	step //997
		'Congratulations,  you have earned the Achievement _Rotten Hollow_ |achieve 1041
]])

ZygorGuidesViewer:RegisterInclude("Hallows_End_Achievements_Horde",[[
	step //998
		goto Durotar,51.5,41.6
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Durotar, Razor Hill |achieve 965/8
	step //999
		'Go north to Orgrimmar |goto Orgrimmar |noway |c
	step //1000
		goto Orgrimmar,53.9,79.0
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Orgrimmar, Valley of Strength |achieve 965/20
	step //1001
		|fly Bilgewater Harbor
	step //1002
		goto Azshara,57.1,50.2
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Azshara, Bilgewater Harbor |achieve 965/5
	step //1003
		|fly Everlook
	step //1004
		goto Winterspring,59.8,51.2
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Winterspring, Everlook |achieve 965/30
	step //1005
		|fly Whisperwind Grove
	step //1006
		goto Felwood,44.7,29.0
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Felwood, Whisperwind Grove |achieve 965/11
	step //1007
		|fly Splintertree Post
	step //1008
		goto Ashenvale,74.0,60.6
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Ashenvale, Splintertree Post |achieve 965/3
	step //1009
		|fly Silverwind Refuge
	step //1010
		 goto Ashenvale,50.2,67.3
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Ashenvale, Silverwind Refuge |achieve 965/2
	step //1011
		|fly Hellscream's Watch
	step //1012
		goto Ashenvale,38.6,42.3
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Ashenvale, Hellscream's Watch |achieve 965/1
	step //1013
		|fly Zoram'gar Outpost
	step //1014
		 goto Ashenvale,13.0,34.1
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Ashenvale, Zoram'gar Outpost |achieve 965/4
	step //1015
		|fly Sun Rock Retreat
	step //1016
		goto Stonetalon Mountains,50.4,63.8
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Stonetalon Mountains, Sun Rock Retreat |achieve 965/25
	step //1017
		|fly Krom'gar Fortress
	step //1018
		goto Stonetalon Mountains,66.5,64.2
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Stonetalon Mountains, Krom'gar Fortress |achieve 965/24
	step //1019
		|fly Nozzlepot's Outpost
	step //1020
		goto Northern Barrens,62.5,16.6
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Stonetalon Mountains, Nozzlepot's Outpost |achieve 965/18
	step //1021
		goto Northern Barrens,56.2,40.0
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Stonetalon Mountains, Grol'dom Farm |achieve 965/17 |use Handful of Treats##37586
	step //1022
		|fly The Crossroads
	step //1023
		goto Northern Barrens,49.5,57.9 
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Barrens, The Crossroads |achieve 965/16
	step //1024
		|fly Ratchet
	step //1025
		  goto Northern Barrens,67.4,74.7
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Barrens, Ratchet |achieve 965/19
	step //1026
		|fly Thunder Bluff
	step //1027
		goto Thunder Bluff,45.6,65.0
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Thunder Bluff, Lower Rise |achieve 965/28
	step //1028
		goto Mulgore,46.6,61.0
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Mulgore, Bloodhoof Village |achieve 965/15
	step //1029
		|fly Desolation Hold
	step //1030
		goto Southern Barrens,40.7,69.3
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Southern Barrens, Desolation Hold |achieve 965/22
	step //1031
		|fly Hunter's Hill
	step //1032
		goto Southern Barrens,39.2,20.0
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Southern Barrens, Hunter's Hill |achieve 965/23
	step //1033
		|fly Karnum's Glade
	step //1034
		goto Desolace,56.7,50.1
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Desolace, Karnum's Glade |achieve 965/6
	step //1035
		|fly Shadowprey Village
	step //1036
		goto Desolace,24.1,68.3
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Desolace, Shadowprey Village |achieve 965/7
	step //1037
		|fly Camp Ataya
	step //1038
		goto Feralas,41.5,15.7
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Feralas, Camp Ataya |achieve 965/12
	step //1039
		|fly Stonemaul Hold
	step //1040
		goto Feralas,52.0,47.6
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Feralas, Stonemaul Hold |achieve 965/14
	step //1041
		|fly Camp Mojache
	step //1042
		goto Feralas,74.8,45.1
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Desolace, Camp Mojache |achieve 965/13
	step //1043
		|fly Cenarion Hold
	step //1044
		goto Silithus,55.5,36.8
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Silithus, Cenarion Hold |achieve 965/21
	step //1045
		|fly Marshal's Stand
	step //1046
		goto Un'Goro Crater,55.3,62.1
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Un'Goro Crater, Marshal's Stand |achieve 965/29
	step //1047
		|fly Gadgetzan
	step //1048
		goto Tanaris,52.6,27.1
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Tanaris, Gadgetzan |achieve 965/27
	step //1049
		|fly Bootlegger Outpost
	step //1050
		 goto Tanaris,55.8,60.9
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Tanaris, Bootlegger Outpost |achieve 965/26
	step //1051
		|fly Brackenwall Village
	step //1052
		goto Dustwallow Marsh,36.8,32.4
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Dustwallow Marsh, Brackenwall Village |achieve 965/9
	step //1053
		|fly Mudsprocket
	step //1054
		goto 41.9,74.1
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Dustwallow Marsh, Mudsprocket |achieve 965/10
	step //1055
		|fly Ratchet
	step //1056
		goto Northern Barrens,63.6,38.6 |n
		.' Ride the boat to Booty Bay |goto The Cape of Stranglethorn |noway |c
	step //1057
		goto The Cape of Stranglethorn,40.9,74.0
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in The Cape of Stranglethorn, Booty Bay |achieve 967/5
	step //1058
		|fly Hardwrench Hideaway
	step //1059
		goto The Cape of Stranglethorn,35.0,27.2
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in The Cape of Stranglethorn, Hardwrench Hideaway |achieve 967/6
	step //1060
		|fly Grom'gol Base Camp
	step //1061
		goto Northern Stranglethorn,37.4,51.8
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Stranglethorn Vale, Grom'gol Base Camp |achieve 967/15
	step //1062
		|fly Stonard
	step //1063
		goto Swamp of Sorrows,46.9,56.9
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Swamp of Sorrows, Stonard |achieve 967/22
	step //1064
		|fly Bogpaddle
	step //1065
		goto Swamp of Sorrows,71.6,13.8
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Swamp of Sorrows, Bogpaddle |achieve 967/21
	step //1066
		|fly New Kargath
	step //1067
		goto Badlands,18.4,42.7
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Badlands, New Kargath |achieve 967/3
	step //1068
		|fly Fuselight
	step //1069
		goto Badlands,65.8,35.6
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Badlands, Fuselight |achieve 967/2
	step //1070
		|fly Hammerfall
	step //1071
		goto Arathi Highlands,69.0,33.3
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Arathi Highlands, Hammerfall |achieve 967/1
	step //1072
		|fly Iron Summit
	step //1073
		goto Searing Gorge,39.4,66.1
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Searing Gorge, Iron Summit |achieve 967/16
	step //1074
		|fly Revantusk Village
	step //1075
		goto The Hinterlands,78.2,81.5
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in The Hinterlands, Revantusk Village |achieve 967/14
	step //1076
		|fly Hiri'watha Research Station
	step //1077
		goto The Hinterlands,31.8,57.9
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Hinterlands, Hiri'watha Research Station |achieve 967/13
	step //1078
		|fly Light's Hope Chapel
	step //1079
		goto Eastern Plaguelands,75.6,52.3
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Eastern Plaguelands, Light's Hope Chapel |achieve 967/7
	step //1080
		|fly Andorhal
	step //1081
		goto Western Plaguelands,48.3,63.8
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Western Plaguelands, Andorhal |achieve 967/7
	step //1082
		|fly Tranquillien
	step //1083
		goto Ghostlands,48.7,31.9
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Ghostlands, Tranquillien |achieve 967/10
	step //1084
		'Go north to Eversong Woods |goto Eversong Woods |noway |c
	step //1085
		goto Eversong Woods,43.7,71.0
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Eversong Woods, Fairbreeze Village |achieve 967/8
	step //1086
		goto 48.2,47.9
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Eversong Woods, Falconwing Square |achieve 967/9
	step //1087
		'Go west to Silvermoon City |goto Silvermoon City |noway |c
	step //1088
		goto Silvermoon City,67.6,72.9
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Silvermoon, The Bazaar |achieve 967/17
	step //1089
		goto 79.4,57.7
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Silvermoon, The Royal Exchange |achieve 967/18
	step //1090
		goto 49.5,14.8
		.click Orb of Translocation##7161
		.' Teleport to Undercity |goto Undercity |noway |c
	step //1091
		goto Undercity,67.8,37.4
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Undercity, The Trade Quarter |achieve 967/25
	step //1092
		'Go outside to Tirisfal Glades |goto Tirisfal Glades |noway |c
	step //1093
		goto Tirisfal Glades,61.0,51.4
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Tirisfal Glades, Brill |achieve 967/23
	step //1094
		goto Tirisfal Glades,83.0,72.1
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Tirisfal Glades, The Bulwark |achieve 967/24
	step //1095
		|fly Forsaken Rear Guard
	step //1096
		goto Silverpine Forest,44.3,20.3
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Silverpine Forest, The Forsaken Rear Guard |achieve 967/19
	step //1097
		|fly The Sepulcher
	step //1098
		goto Silverpine Forest,46.5,42.9
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Silverpine Forest, The Sepulcher |achieve 967/20
	step //1099
		|fly Tarren Mill
	step //1100
		goto Hillsbrad Foothills,57.9,47.3
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Hillsbrad Foothills, Tarren Mill |achieve 967/12
	step //1101
		|fly Eastpoint Tower
	step //1102
		goto Hillsbrad Foothills,60.3,63.7
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Hillsbrad Foothills, Eastpoint Tower |achieve 967/11
	step //1103
		|fly Trade Quarter
	step //1104
		goto Undercity,85.3,17.1
		.' Click the Portal to Blasted Lands 
		.' Teleport to the Blasted Lands |goto Blasted Lands |noway |c
	step //1105
		goto Blasted Lands,40.4,11.3
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Blasted Lands, Dreadmaul Hold |achieve 967/4
	step //1106
		goto Blasted Lands,55.0,54.3 |n
		.' Go into the huge green portal to Hellfire Peninsula |goto Hellfire Peninsula |noway |c
	step //1107
		goto Hellfire Peninsula,56.8,37.4
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Hellfire Peninsula, Thrallmar |achieve 968/5
	step //1108
		goto 26.9,59.5
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Hellfire Peninsula, Falcon Watch |achieve 968/4
	step //1109
		goto Shattrath City,56.3,81.9
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Shattrath City, Scryer's Tier |achieve 968/11
		only if rep ('The Scryers') >= Friendly
	step //1110
		goto Shattrath City,28.2,49.1
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Shattrath City, Aldor Rise |achieve 968/11
		only if rep ('The Aldor') >= Friendly
	step //1111
		goto Terokkar Forest,48.7,45.2
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Terokkar Forest, Stonebreaker Hold |achieve 968/12
	step //1112
		goto Shadowmoon Valley,30.3,27.7
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Shadowmoon Valley, Shadowmoon Village |achieve 968/10
	step //1113
		goto 56.4,59.8
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Shadowmoon Valley, Sanctum of the Stars |achieve 968/9
		only if rep ('The Scryers') >= Friendly
	step //1114
		goto 61.0,28.2
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Shadowmoon Valley, Altar of Sha'tar |achieve 968/9
		only if rep ('The Aldor') >= Friendly
	step //1115
		goto Nagrand,56.7,34.5
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Nagrand, Garadar |achieve 968/6
	step //1116
		goto Zangarmarsh,30.6,50.9
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Zangarmarsh, Zabra'jin |achieve 968/13
	step //1117
		goto 78.5,62.9
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Zangarmarsh, Cenarion Refuge |achieve 968/14
	step //1118
		goto Blade's Edge Mountains,76.2,60.4
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Blade's Edge Mountains, Mok'Nathal Village |achieve 968/2
	step //1119
		goto 53.4,55.5
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Blade's Edge Mountains, Thunderlord Stronghold |achieve 968/3
	step //1120
		goto 62.9,38.3
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Blade's Edge Mountains, Evergrove |achieve 968/1
	step //1121
		goto Netherstorm,32.0,64.4
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Netherstorm, Area 52 |achieve 968/7
	step //1122
		goto 43.3,36.1
		.click Candy Bucket##6404
		..' Complete the Candy Bucket quest |tip If you cannot complete this quest because of a "Duplicate item found" message, open the Handful of Candy item in your bags and take out the contents. |use Handful of Treats##37586
		.' Visit the Candy Bucket in Netherstorm, The Stormspire |achieve 968/8
	step //1123
		'You must be at least level 75 to complete this step:
		.' Use the Dungeon Finder to queue for The Headless Horseman
		.from Headless Horseman##23682
		.' Complete the Bring Me The Head of... Oh Wait achievement |achieve 255
	step //1124
		'Use your Tricky Treats 5 times in a row quickly |use Tricky Treat##33226 |tip You can only get these by killing The Headless Horseman in the previous guide step.
		.' You will start puking :-)
		.' Complete the Out With It achievement |achieve 288
	step //1125
		goto 67.7,6.5
		.talk Chub##53757
		.buy Tooth Pick##37604 |n
		.' Use your Tooth Pick |use Tooth Pick##37604
		.' Show off your sparkling smile by using a Tooth Pick |achieve 981
	step //1126
		'Use your Weighted Jack-o'-Lanterns on the following races: |use Weighted Jack-o'-Lantern##34068 |tip You receive Weighted Jack-o'-Lanterns by doing the Hallow's End daily quests.  Make sure the player doesn't already have a jack-o-lantern on their head or you won't get credit.  The best place to complete this is in Dalaran, but it can be done anywhere in the world.
		.' Gnome |achieve 291/1
		.' Blood Elf |achieve 291/2
		.' Draenei |achieve 291/3
		.' Dwarf |achieve 291/4
		.' Human |achieve 291/5
		.' Night Elf |achieve 291/6
		.' Orc |achieve 291/7
		.' Tauren |achieve 291/8
		.' Troll |achieve 291/9
		.' Undead |achieve 291/10
	step //1127
		'Have other players use Hallowed Wands on you while in a party to transform into the following:
		.' Transform into a Bat |achieve 283/1
		.' Transform into a Ghost |achieve 283/2
		.' Transform into a Leper Gnome |achieve 283/3
		.' Transform into a Ninja |achieve 283/4
		.' Transform into a Pirate |achieve 283/5
		.' Transform into a Skeleton |achieve 283/6
		.' Transform into a Wisp |achieve 283/7
	step //1128
		goto 67.7,6.5
		.talk Chub##53757
		.buy Sinister Squashling##33154 |n
		.buy Hallowed Helm##33292 |n
		.' Use the Sinister Squashling |use Sinister Squashling##33154
		.' Obtain a Sinister Squashling pet |achieve 292/1
		.' Obtain a Hallowed Helm |achieve 292/2
	step //1129
		'Use your G.N.E.R.D.S. |use G.N.E.R.D.S.##37583 |tip Use them every 30 minutes while PvPing to keep the buff on.  If you don't have the buff active while killing players, you won't get credit.
		.' Do any type of PvP of your choice |tip You must be killing players that give you honor.
		.' Earn 10 honorable kills while under the influence of the G.N.E.R.D. buff |achieve 1261
	step //1130
		'Congratulations, you are now one of The Hallowed!
]])

-- PILGRIM'S BOUNTY --
ZygorGuidesViewer:RegisterInclude("Pilgrims_Bounty_Quests_Horde",[[
	step //1131
		goto Undercity,65.6,8.1
		.talk Bountiful Feast Hostess##34654
		..accept Sharing a Bountiful Feast##14065
	step //1132
		goto 64.7,7.9
		.clicknpc The Turkey Chair##34812
		.' Use the first ability on your hotbar to Pass the food to other players who are sitting at the table |tip You must target the other players and use the Pass the Food ability.  Do this repeatedly until you get an achievement.
		.' Start a Food Fight! |achieve 3579
		.' Use the other abilities on your hotbar to eat the food |tip You will only be able to eat certain foods at each place on the table.  Once you eat the foods available to your spot 5 times, click the red arrow above your action bar to get out of the Turkey Chair.  Then, go sit in another Turkey Chair that has a type of food you haven't eaten yet.
		.' Eat each type of food 5 times in a row |tip You can see how many times you've eaten the food by looking at it's buff that it gives you next to your mini map.
		.' Gain the Spirit of Sharing |q 14065/1
	step //1133
		goto 65.6,8.1
		.talk Bountiful Feast Hostess##34654
		..turnin Sharing a Bountiful Feast##14065
	step //1134
		goto 63.2,8.9
		.talk Roberta Carter##34712
		.' Learn the Apprentice Cooking skill, if you don't have it already
		.' Learn the Spice Bread recipe
		|confirm
	step //1135
		goto 63.9,11.1
		.talk Rose Standish##34683
		.buy Bountiful Cookbook##46810
	step //1136
		'Use your Bountiful Cookbook |use Bountiful Cookbook##46810
		.collect Recipe: Spice Bread Stuffing##46803
		.collect Recipe: Pumpkin Pie##46804
		.collect Recipe: Cranberry Chutney##46805
		.collect Recipe: Candied Sweet Potato##46806
		.collect Recipe: Slow-Roasted Turkey##46807
	step //1137
		'Use your Recipe: Spice Bread Stuffing to learn the recipe |use Recipe: Spice Bread Stuffing##46803
		|confirm
	step //1138
		goto 63.9,11.5
		.talk Miles Standish##34677
		..accept Spice Bread Stuffing##14037
	step //1139
		goto 63.9,11.1
		.talk Rose Standish##34683
		.buy 5 Simple Flour##30817 |n
		.buy 5 Mild Spices##2678 |n
		.buy 5 Autumnal Herbs##44835 |n
		.' Cook next to the Pilgrim's Bounty Cooking Fire at [63.2,8.3]
		.create 5 Spice Bread##37836,Cooking,5 total |n
		.create 5 Spice Bread Stuffing##66038,Cooking,5 total |q 14037/1
		.get 5 Spice Bread Stuffing |q 14037/2
		|skill Cooking,100
		.' If you need to train your Cooking skill to allow a higher max level, talk to Roberta Carter at [63.2,8.9]
	step //1140
		'Use your Recipe: Pumpkin Pie to learn the recipe |use Recipe: Pumpkin Pie##46804
		|confirm
	step //1141
		goto 65.3,14.3
		.talk William Mullins##34768
		..turnin Spice Bread Stuffing##14037
		..accept Pumpkin Pie##14040
	step //1142
		goto 63.9,11.1
		.talk Rose Standish##34683
		.buy 5 Ripe Tirisfal Pumpkin##46796+ |n
		.buy 5 Honey##44853 |n
		.' Cook next to the Pilgrim's Bounty Cooking Fire at [63.2,8.3]
		.create 5 Pumpkin Pie##66036,Cooking,5 total |q 14040/1
		.get 5 Pumpkin Pie |q 14040/2
		|skill Cooking,160
		.' If you need to train your Cooking skill to allow a higher max level, talk to Roberta Carter at [63.2,8.9]
	step //1143
		'Use your Recipe: Cranberry Chutney to learn the recipe |use Recipe: Cranberry Chutney##46805
		|confirm
	step //1144
		'Go outside to Tirisfal Glades |goto Tirisfal Glades |noway |c
	step //1145
		goto Tirisfal Glades,60.7,58.8 |n
		.' Ride the zeppelin to Orgrimmar. |goto Orgrimmar |noway |c
	step //1146
		'Go South to Durotar. |goto Durotar |noway|c
	step //1147
		goto Durotar 46.6,13.8
		.talk Francis Eaton##34679
		..turnin Pumpkin Pie##14040
		..accept Cranberry Chutney##14041
	step //1148
		goto 46.6,13.8
		.talk Dalni Tallgrass##34685
		.buy 5 Tangy Southfury Cranberries##46793+ |n
		.buy 5 Honey##44853 |n
		.' Cook next to the Pilgrim's Bounty Cooking Fire at [46.4,13.8]
		.create 5 Cranberry Chutney##66035,Cooking,5 total |q 14041/1
		.get 5 Cranberry Chutney |q 14041/2
		|skill Cooking,220
		.' If you need to train your Cooking skill to allow a higher max level, talk to Ondani Greatmill at [46.4,13.9]
	step //1149 //Needs Coords
		.clicknpc The Turkey Chair##34812
		.' Eat each type of food 5 times in a row |tip You can see how many times you've eaten the food by looking at it's buff that it gives you next to your mini map.
		.' Gain the Spirit of Sharing |achieve 3557/1
	step //1150
		'Go inside Orgrimmar |goto Orgrimmar |noway |c
	step //1151
		|fly Thunder Bluff
	step //1152
		goto Thunder Bluff,30.9,63.7
		.talk Dokin Farplain##34678
		..turnin Cranberry Chutney##14041
		..accept Candied Sweet Potatoes##14043
	step //1153
		goto 31.1,63.4
		.talk Laha Farplain##34684
		.buy Mulgore Sweet Potato##46797 |n
		.buy Honey##44853 |n
		.buy Autumnal Herbs##44835 |n
		.' Cook next to the Pilgrim's Bounty Cooking Fire at [30.5,70.1]
		.create 5 Candied Sweet Potatoes##66034,Cooking,5 total |q 14043/1
		.get 5 Candied Sweet Potatoes |q 14043/2
		|skill Cooking,280
		.' If you need to train your Cooking skill to allow a higher max level, talk to Mahara Goldwheat at [31.0,69.8]
	step //1154
		goto 29.9,62.7
		.clicknpc The Turkey Chair##34812
		.' Eat each type of food 5 times in a row |tip You can see how many times you've eaten the food by looking at it's buff that it gives you next to your mini map.
		.' Gain the Spirit of Sharing |achieve 3557/3
	step //1155
		|fly Orgrimmar
	step //1156
		'Go outside to Durotar |goto Durotar |noway |c
	step //1157
		goto Durotar,46.6,13.8
		.talk Francis Eaton##34679
		..turnin Candied Sweet Potatoes##14043
		..accept Undersupplied in the Undercity##14044
	step //1158
		'Go into Orgrimmar. |goto Orgrimmar |noway|c
	step //1159
		goto Orgrimmar,50.8,55.8 |n
		.' Ride the zeppelin to Tirisfal Glades |goto Tirisfal Glades |noway |c
	step //1160
		'Go into Undercity |goto Undercity |noway |c
	step //1161
		goto Undercity,63.9,11.5
		.talk Miles Standish##34677
		..turnin Undersupplied in the Undercity##14044
		..accept Slow-roasted Turkey##14047
	step //1162
		'Go outside to Tirisfal Glades |goto Tirisfal Glades |noway |c
	step //1163
		goto Tirisfal Glades,62.2,56.4
		.from Wild Turkey##32820+ |tip You can find these all around Tirisfal Glades, so you are not limited to staying in this area.  Ride around Tirisfal Glades and look for Wild Turkeys, you should be able to find them easily if you ride around.
		.collect 20 Wild Turkey##44834 |q 14047
	step //1164
		'Go into Undercity |goto Undercity |noway |c
	step //1165
		goto Undercity,63.9,11.1
		.talk Rose Standish##34683
		.buy Honey##44853 |n
		.buy Autumnal Herbs##44835 |n
		.' Cook next to the Pilgrim's Bounty Cooking Fire at [63.1,8.3]
		.create 5 Slow-Roasted Turkey##66037,Cooking,5 total |q 14047/1
		.get 5 Slow-Roasted Turkey |q 14047/2
		|skill Cooking,300
		.' If you need to train your Cooking skill to allow a higher max level, talk to Roberta Carter at [63.2,8.9]
	step //1166
		'Go outside to Tirisfal Glades |goto Tirisfal Glades |noway |c
	step //1167
		goto Tirisfal Glades,60.7,58.8 |n
		.' Ride the zeppelin to Orgrimmar. |goto Orgrimmar |noway|c
	step //1168
		'Go south to Durotar. |goto Durotar |noway|c
	step //1169
		goto Durotar,46.6,13.8
		.talk Francis Eaton##34679
		..turnin Slow-roasted Turkey##14047
]])

ZygorGuidesViewer:RegisterInclude("Pilgrims_Bounty_Achievements_Horde",[[
	step //1170
	label start
		goto Orgrimmar,50.9,55.7 |n
		'Ride the Zeppelin to Tirisfal Glades. |goto Tirisfal Glades |noway|c
	step //1171
		'Go south to Undercity. |goto Undercity |noway|c
	step //1172
		goto Undercity,54.9,11.3
		.click Orb of Translocation##7161
		' Go to Silvermoon City |goto Silvermoon City |noway|c
	step //1173
		' Go south to Eversong Woods. |goto Eversong Woods |noway|c
	step //1174
		goto Eversong Woods,55.7,53.2
		.clicknpc The Turkey Chair##34812
		.' Eat each type of food 5 times in a row |tip You can see how many times you've eaten the food by looking at it's buff that it gives you next to your mini map.
		.' Gain the Spirit of Sharing |achieve 3557/2
		.' Earn the Pilgrim's Paunch Achievement. |achieve 3557/2
	step //1175
		'While still at the table, go to each of the chairs.
		.' While in each of the chairs, press 1.
		.' Pass the Candied Sweet Potatoes. |achieve 3558/1
		.' Pass the Cranberry Chutney. |achieve 3558/2
		.' Pass the Pumpkin Pie. Pumpkin Pie. |achieve 3558/3
		.' Pass the Slow-Roasted Turkey. |achieve 3558/4
		.' Pass the Spice Bread Stuffing. |achieve 3558/5
		.' Earn the Sharing is Caring Achievement. |achieve 3558
	step //1176
		'Go North to Silvermoon City. |goto Silvermoon City|noway|c
	step //1177
		goto Silvermoon City,49.4,14.8 
		.click Orb of Translocation##7161
		'Go to the Undercity |goto Undercity |noway|c
	step //1178
		goto Undercity,65.2,14.2
		.talk William Mullins##34768
		.accept She Says Potato##14058 |daily
	step //1179
		goto Undercity,63.2,9.0
		.talk Roberta Carter##34712
		.accept We're Out of Cranberry Chutney Again?##14059 |daily
	step //1180
		goto 63.9,11.1
		.talk Rose Standish##34683
		.buy 20 Ripe Tirisfal Pumpkin##46796 |n
		.buy 20 Simple Flour##30817 |n
		.buy 20 Mild Spices##2678 |n
		.buy 20 Autumnal Herbs##44835 |n
		|confirm always
	step //1181
		'Go south to Tirisfal Glades. |goto Tirisfal Glades |noway|c
	step //1182
		goto Tirisfal Glades,62.2,56.4
		.from Wild Turkey##32820+ |tip You can find these all around Tirisfal Glades, so you are not limited to staying in this area.  Ride around Tirisfal Glades and look for Wild Turkeys, you should be able to find them easily if you ride around.
		.collect 20 Wild Turkey##44834 |n
		|confirm always
	step //1183
		goto Tirisfal Glades,60.7,58.8 |n
		'Ride the Zeppelin to Orgrimmar. |goto Orgrimmar |noway|c
	step //1184
		'Go South to Durotar. |goto Durotar |noway|c
	step //1185
		goto Durotar,46.4,13.9
		.talk Ondani Greatmill##34713
		.accept Can't Get Enough Turkey##14061
		..accept Don't Forget The Stuffing!##14062
	step //1186
		goto Durotar,46.6,13.8
		.talk Dalni Tallgrass##34685
		.buy 20 Tangy Southfury Cranberries##46793
	step //1187
		'Go into Orgrimmar. |goto Orgrimmar|noway|c
	step //1188
		|fly Thunder Bluff
	step //1189
		goto Thunder Bluff,31.0,63.3
		.talk Laha Farplain##34684
		.buy 20 Mulgore Sweet Potato##46797
		.buy 20 Honey##44853
	step //1190
		goto Thunder Bluff,30.9,69.7
		.talk Mahara Goldwheat##34714
		.accept Easy As Pie##14060
	step //1191
		.create 20 Pumpkin Pie##66036,Cooking,20 total |q 14060/1
	step //1192
		goto Thunder Bluff,30.9,69.7
		.talk Mahara Goldwheat##34714
		.turnin Easy As Pie##14060 |achieve 3597/3
		..collect Pilgrim's Hat##46723
		..' You need the hat for a later achievement.
	step //1193
		|fly Orgrimmar
	step //1194
		'Go South to Durotar. |goto Durotar |noway|c
	step //1195
		goto Durotar,46.4,13.9
		.create 20 Spice Bread##37836,Cooking,20 total |n
		.create 20 Spice Bread Stuffing##66038,Cooking,20 total |q 14062/1
	step //1196
		goto Durotar,46.6,13.8
		.talk Dalni Tallgrass##34685
		.buy 40 Honey##44853
		.buy 20 Autumnal Herbs##44835
	step //1197
		goto 46.4,13.9
		.create 20 Slow-Roasted Turkey##66037+,Cooking,20 total |q 14061/1
	step //1198
		goto Durotar,46.4,13.9
		.talk Ondani Greatmill##34713
		.turnin Can't Get Enough Turkey##14061 |achieve 3597/1
		..collect Pilgrim's Attire##46800 |tip You only need this, the Dress or the Robes, not all 3. |or
		..collect Pilgrim's Dress##44785 |tip You only need this, the Attire or the Robes, not all 3. |or
		..collect Pilgrim's Robe##46824 |tip You only need this, the Attire or the Dress, not all 3. |or
	step //1199
		goto Durotar,46.4,13.9
		.talk Ondani Greatmill##34713
		.turnin Don't Forget The Stuffing!##14062 |achieve 3597/2
		..collect Turkey Shooter##44812 |tip Collect Turkey Shooters.  You will need at least 8 for an Achievement.
	step //1200
		'Go into Orgrimmar. |goto Orgrimmar|noway|c
	step //1201
		goto Orgrimmar,50.8,55.8 |n
		.' Ride the zeppelin to Tirisfal Glades |goto Tirisfal Glades |noway |c
	step //1202
		'Go South to Undercity. |goto Undercity |noway|c
	step //1203
		goto Undercity,63.9,11.1
		.talk Rose Standish##34683
		.buy 40 Honey##44853
		.buy 20 Autumnal Herbs##44835
	step //1204
		goto Undercity,63.2,8.4
		.create 20 Candied Sweet Potato##66034,Cooking,20 total |q 14058/1
	step //1205
		.create 20 Cranberry Chutney##66035,Cooking,20 total |q 14059/1
	step //1206
		goto Undercity,63.2,8.9
		.talk Roberta Carter##34712
		.turnin We're Out of Cranberry Chutney Again?##14059 |achieve 3597/5
		..collect Turkey Shooter##44812 |tip Collect Turkey Shooters.  You will need at least 8 for an Achievement.
	step //1207
		goto 65.2,14.2
		.talk William Mullins##34768
		.turnin She Says Potato##14058 |achieve 3597/4
		..collect Turkey Shooter##44812 |tip Collect Turkey Shooters.  You will need at least 8 for an Achievement.
	step //1208
		.' Earn the Pilgrim's Progress Achievement. |achieve 3597
	step //1209
		'Go out to Tirisfal Glades. |goto Tirisfal Glades |noway|c
	step //1210
		goto Tirisfal Glades,62.5,57.8
		'You will need to fly around Tirisfal Glades.  You have to kill 40 Turkey's without letting you Turkey Tracker Buff fall off.  You will be given 30 seconds for each kill to find a new turkey.
		.kill Wild Turkey##32820+ |n
		.' Earn the Turkinator Achievement. |achieve 3578
	step //1211
		goto Tirisfal Glades,60.7,58.7 |n
		'Ride the Zeppelin to Orgrimmar |goto Orgrimmar |noway|c
	step //1212
		goto Orgrimmar,35.5,69.1 |n
		.' Click the Portal to Blasted Lands. |goto Blasted Lands |noway|c
	step //1213
		goto Blasted Lands,55.0,54.0 |n
		.' Go through the Portal. |goto Hellfire Peninsula |noway|c
	step //1214
		|fly Stonebreaker Hold
	step //1215
		goto Terokkar Forest,44.9,65.6 |n
		.' Go through the swirling portal. |goto Sethekk Halls|noway|c
	step //1216
		'Fight to the end of the Instance.
		.' Before Engaging Talon King Ikiss, equip
		.' Equip Pilgrim's Attire |equipped Pilgrim's Attire##46800 |use Pilgrim's Attire##46800 |or 
		.' Equip Pilgrim's Dress |equipped Pilgrim's Dress##44785 |use Pilgrim's Dress##44785 |or
		.' Equip Pilgrim's Robe |equipped Pilgrim's Robe##46824 |use Pilgrim's Robe##46824  |or
		.' Equip Pilgrim's Hat |equipped Pilgrim's Hat##46723 |use Pilgrim's Hat##46723
		.' Kill Talon King Ikiss while wearing these items.
		.' Earn the Terokkar Turkey Time Achievement. |achieve 3582
	step //1217
		.' Leave the instance. |goto Terokkar Forest |noway|c
	step //1218
		|fly Shattrath 
	step //1219
		goto Shattrath City,56.8,48.9 |n
		.' Click the Portal to Orgrimmar. |goto Orgrimmar |noway|c
	step //1220
		goto Orgrimmar,53.6,78.8
		.talk Innkeeper Gryshka##6929
		.home Valley of Strength
	step //1221
		|fly Hellscream's Watch
	step //1222
		.' Go Northwest to Darkshore. |goto Darkshore |noway|c
	step //1223
		goto Darkshore,41.0,15.0 |n
		.' Fly across the water to Teldrassil |goto Teldrassil,57.1,92.0,1 |noway|c
	step //1224
		goto Darnassus,64.1,46.7 |tip You will be flagged, so if there are alliance players you will most likely be attacked.
		.' Equip Pilgrim's Attire |equipped Pilgrim's Attire##46800 |use Pilgrim's Attire##46800 |or 
		.' Equip Pilgrim's Dress |equipped Pilgrim's Dress##44785 |use Pilgrim's Dress##44785 |or
		.' Equip Pilgrim's Robe |equipped Pilgrim's Robe##46824 |use Pilgrim's Robe##46824  |or
		.clicknpc The Turkey Chair##34812
		.' Take a seat at a Darnassus Bountiful Table. |achieve 3581/1
	step //1225
		goto Teldrassil,52.5,89.4 |n
		.' Ride the boat to Azuremyst Isle. |goto Azuremyst Isle |noway|c
	step //1226
		goto The Exodar,77.1,52.2
		.' Equip Pilgrim's Attire |equipped Pilgrim's Attire##46800 |use Pilgrim's Attire##46800 |or 
		.' Equip Pilgrim's Dress |equipped Pilgrim's Dress##44785 |use Pilgrim's Dress##44785 |or
		.' Equip Pilgrim's Robe |equipped Pilgrim's Robe##46824 |use Pilgrim's Robe##46824  |or
		.clicknpc The Turkey Chair##34812
		.' Take a seat at the Exodar Bountiful Table. |achieve 3581/2
	step //1227
		goto Azuremyst Isle,21.4,54.1 |n
		'Ride the boat to Teldrassil. |goto Teldrassil |noway|c
	step //1228
		goto Teldrassil,55.0,93.7 |n
		.' Ride the boat to Stormwind |goto Stormwind City |noway|c
	step //1229
		goto Elwynn Forest,34.7,50.6
		.' Equip Pilgrim's Attire |equipped Pilgrim's Attire##46800 |use Pilgrim's Attire##46800 |or 
		.' Equip Pilgrim's Dress |equipped Pilgrim's Dress##44785 |use Pilgrim's Dress##44785 |or
		.' Equip Pilgrim's Robe |equipped Pilgrim's Robe##46824 |use Pilgrim's Robe##46824  |or
		.clicknpc The Turkey Chair##34812
		.' Take a seat at the Stormwind Bountiful Table. |achieve 3581/4
	step //1230
		goto Dun Morogh,59.7,35.3
		.' Equip Pilgrim's Attire |equipped Pilgrim's Attire##46800 |use Pilgrim's Attire##46800 |or 
		.' Equip Pilgrim's Dress |equipped Pilgrim's Dress##44785 |use Pilgrim's Dress##44785 |or
		.' Equip Pilgrim's Robe |equipped Pilgrim's Robe##46824 |use Pilgrim's Robe##46824  |or
		.clicknpc The Turkey Chair##34812
		.' Take a seat at the Ironforge Bountiful Table. |achieve 3581/3
	step //1231
		.' Earn the Pilgrim's Peril Achievement. |achieve 3581
	step
		'You should have a few _Turkey Shooters_ from your daily quests, if you don't, you will need to do more daily's when possible for more.
		.' While in Dun Morogh, shoot Alliance Rogues with your Turkey Shooter. |use Turkey Shooter##44812
		.' Shoot a Dwarf Rogue |achieve 3559/2
		.' Shoot a Gnome Rogue |achieve 3559/3
		.' Shoot a Human Rogue |achieve 3559/5
		.' Shoot a Night Elf Rogue |achieve 3559/6
		.' Shoot a Worgen Rogue |achieve 3559/10
	step
		#include "hearth_hub"
	step
		goto Durotar,46.2,15.1
		'You should have a few _Turkey Shooters_ from your daily quests, if you don't, you will need to do more daily's when possible for more.
		.' While in Durotar, shoot Horde Rogues with your Turkey Shooter. |use Turkey Shooter##44812
		.' Shoot a Blood Elf Rogue |achieve 3559/1
		.' Shoot a Orc Rogue |achieve 3559/7
		.' Shoot a Troll Rogue |achieve 3559/8
		.' Shoot a Undead Rogue |achieve 3559/9
		.' Shoot a Goblin Rogue |achieve 3559/4
	step
		.' You have reached the End of this guide, you can only do the Dailys Once per day. 
		Click here to continue. |confirm always
		|next "end" |only if achieved(3656)
		|next "start" |only if not achieved(3656)
	step
	label	"end"
		.' Congratualtions, you have earned the Pilgrim Achievement!
]])

ZygorGuidesViewer:RegisterInclude("Pilgrims_Bounty_Dailies",[[
	step //1233
	label daily
		goto Orgrimmar,50.9,55.7 |n
		.' Ride the Zeppelin to Tirisfal Glades. |goto Tirisfal Glades |noway|c
	step //1234
		goto Undercity,65.2,14.2
		.talk William Mullins##34768
		.accept She Says Potato##14058 |daily
	step //1235
		goto Undercity,63.2,9.0
		.talk Roberta Carter##34712
		.accept We're Out of Cranberry Chutney Again?##14059 |daily
	step //1236
		goto 63.9,11.1
		.talk Rose Standish##34683
		.buy 20 Ripe Tirisfal Pumpkin##46796 |n
		.buy 20 Simple Flour##30817 |n
		.buy 20 Mild Spices##2678 |n
		.buy 20 Autumnal Herbs##44835 |n
		|confirm always
	step //1237
		'Go south to Tirisfal Glades. |goto Tirisfal Glades |noway|c
	step //1238
		goto Tirisfal Glades,62.2,56.4
		.from Wild Turkey##32820+ |tip You can find these all around Tirisfal Glades, so you are not limited to staying in this area.  Ride around Tirisfal Glades and look for Wild Turkeys, you should be able to find them easily if you ride around.
		.collect 20 Wild Turkey##44834 |n
		|confirm always
	step //1239
		goto Tirisfal Glades,60.7,58.8 |n
		'Ride the Zeppelin to Orgrimmar. |goto Orgrimmar |noway|c
	step //1240
		'Go South to Durotar. |goto Durotar |noway|c
	step //1241
		goto Durotar,46.4,13.9
		.talk Ondani Greatmill##34713
		.accept Can't Get Enough Turkey##14061 |daily
		..accept Don't Forget The Stuffing!##14062 |daily
	step //1242
		goto Durotar,46.6,13.8
		.talk Dalni Tallgrass##34685
		.buy 20 Tangy Southfury Cranberries##46793
	step //1243
		'Go into Orgrimmar. |goto Orgrimmar|noway|c
	step //1244
		|fly Thunder Bluff
	step //1245
		goto Thunder Bluff,31.0,63.3
		.talk Laha Farplain##34684
		.buy 20 Mulgore Sweet Potato##46797
		.buy 20 Honey##44853
	step //1246
		goto Thunder Bluff,30.9,69.7
		.talk Mahara Goldwheat##34714
		.accept Easy As Pie##14060 |daily
	step //1247
		.create 20 Pumpkin Pie##66036,Cooking,20 total |q 14060/1
	step //1248
		goto Thunder Bluff,30.9,69.7
		.talk Mahara Goldwheat##34714
		.turnin Easy As Pie##14060
		..collect Turkey Shooter##44812 |tip Collect Turkey Shooters.  You will need at least 8 for an Achievement.
	step //1249
		|fly Orgrimmar
	step //1250
		'Go South to Durotar. |goto Durotar |noway|c
	step //1251
		goto Durotar,46.4,13.9
		.create 20 Spice Bread##37836,Cooking,20 total |n
		.create 20 Spice Bread Stuffing##66038,Cooking,20 total |q 14062/1
	step //1252
		goto Durotar,46.6,13.8
		.talk Dalni Tallgrass##34685
		.buy 40 Honey##44853
		.buy 20 Autumnal Herbs##44835
	step //1253
		goto 46.4,13.9
		.create 20 Slow-Roasted Turkey##66037+,Cooking,20 total |q 14061/1
	step //1254
		goto Durotar,46.4,13.9
		.talk Ondani Greatmill##34713
		.turnin Can't Get Enough Turkey##14061 |achieve 3597/1
		..collect Turkey Shooter##44812 |tip Collect Turkey Shooters.  You will need at least 8 for an Achievement.
	step //1255
		goto Durotar,46.4,13.9
		.talk Ondani Greatmill##34713
		.turnin Don't Forget The Stuffing!##14062 |achieve 3597/2
		..collect Turkey Shooter##44812 |tip Collect Turkey Shooters.  You will need at least 8 for an Achievement.
	step //1256
		'Go into Orgrimmar. |goto Orgrimmar|noway|c
	step //1257
		goto Orgrimmar,50.8,55.8 |n
		.' Ride the zeppelin to Tirisfal Glades |goto Tirisfal Glades |noway |c
	step //1258
		'Go South to Undercity. |goto Undercity |noway|c
	step //1259
		goto Undercity,63.9,11.1
		.talk Rose Standish##34683
		.buy 40 Honey##44853
		.buy 20 Autumnal Herbs##44835
	step //1260
		goto Undercity,63.2,8.4
		.create 20 Candied Sweet Potato##66034,Cooking,20 total |q 14058/1
	step //1261
		.create 20 Cranberry Chutney##66035,Cooking,20 total |q 14059/1
	step //1262
		goto Undercity,63.2,8.9
		.talk Roberta Carter##34712
		.turnin We're Out of Cranberry Chutney Again?##14059 |achieve 3597/5
		..collect Turkey Shooter##44812 |tip Collect Turkey Shooters.  You will need at least 8 for an Achievement.
	step //1263
		goto 65.2,14.2
		.talk William Mullins##34768
		.turnin She Says Potato##14058 |achieve 3597/4
		..collect Turkey Shooter##44812 |tip Collect Turkey Shooters.  You will need at least 8 for an Achievement.
	step //1264
		goto Elwynn Forest,34.7,50.6
		.' For the achievement Turkey Lurkey, you have to hit 8 difference races of rogues with the Turkey shooter.
		.use Turkey Shooter##44812
		.' Shoot a Dwarf Rogue |achieve 3559/2
		.' Shoot a Gnome Rogue |achieve 3559/3
		.' Shoot a Human Rogue |achieve 3559/4
		.' Shoot a Night Elf Rogue |achieve 3559/5
		.' You can look for the get a maximum of 5 Turkey Shooters per day, so it will take 2 days to do this if you don't have any already.
	step //1265
		.' Hearth to Orgrimmar. |goto Orgrimmar,53.6,78.8,0.5 |noway|c |use Hearthstone##6948
	step //1266
		goto Durotar,46.5,14.6
		.' For the achievement Turkey Lurkey, you have to hit 8 difference races of rogues with the Turkey shooter.
		.' Shoot a Blood Elf Rogue |achieve 3559/1
		.' Shoot a Orc Rogue |achieve 3559/6
		.' Shoot a Troll Rogue |achieve 3559/7
		.' Shoot an Undead Rogue |achieve 3559/8
		.' You can look for the get a maximum of 5 Turkey Shooters per day, so it will take 2 days to do this if you don't have any already.
		.' Click here to go to the start of the Daily quests. |next "daily" |confirm |only if not achieved(3559)
		|next "finish" |only if achieved(3656)
	step //1267
	label finish
		'Congratulations, you have completed the Pilgrim achievement!
]])

-- MIDSUMMER --
ZygorGuidesViewer:RegisterInclude("Midsummer_Quests",[[
	step
		goto Orgrimmar 53.6,78.8
		.talk Innkeeper Gryshka##6929
		.home Orgrimmar
	step
		goto Mulgore 51.8,59.3
		.talk Mulgore Flame Keeper##25936
		..accept Honor the Flame##11852 |instant
	step
		goto 51.7,59.5
		.talk Flame Eater##25994
		..accept Playing with Fire##11915
	step
		|fly Thunder Bluff
	step
		goto Thunder Bluff 40.8,56.1
		.talk Tauren Commoner##19176
		..accept The Spinner of Summer Tales##11971
	step
		goto 21.6,27.7
		.talk Festival Talespinner##16818
		..turnin The Spinner of Summer Tales##11971
		..accept Incense for the Festival Scorchlings##11966
	step
		goto 21.0,26.4
		.talk Master Flame Eater##26113
		..turnin Playing with Fire##11915
		..accept Torch Tossing##11922
	step
		'Use your Practice Torches in your bags and throw them at the Torch Target Braziers nearby |use Practice Torches##34862 |tip You must throw the torches at the correct braziers.  Throw the torches at the Torch Target Braziers when they have a floating red arrow point down above them.
		.' Hit 8 braziers |q 11922/1
	step
		goto 21.0,26.4
		.talk Master Flame Eater##26113
		..turnin Torch Tossing##11922
		..accept Torch Catching##11923
	step
		goto 21.8,27.3
		.' Use your Unlit Torches in your bags next to the bonfire |use Unlit Torches##34833
		.' As soon as you light torch, it will fly in the air.  There will be a small round shadow on the ground indicating where the torch is flying.  Follow that shadow and catch the torch.  When you catch the torch, it will be thrown in the air again.  Follow the shadow again and catch the torch.  Do this until you've caught the torch 4 times in a row without it hitting the ground.
		.' Catch 4 torches in a row. |q 11923/1
	step
		goto 21.0,26.4
		.talk Master Flame Eater##26113
		..turnin Torch Catching##11923
	step
		goto 21.2,24.0
		.talk Earthen Ring Elder##26221
		..accept Unusual Activity##11886
	step
		|fly Brackenwall Village, Dustwallow Marsh
	step
		goto Dustwallow Marsh 33.5,30.9
		.talk Festival Scorchling##26520
		..turnin Incense for the Festival Scorchlings##11966
	step
		goto 33.4,30.9
		.talk Dustwallow Marsh Flame Keeper##25930
		..accept Honor the Flame##11847 |instant
	step
		goto 62.1,40.3
		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11744 |instant
	step
		|fly Gadgetzan
	step
		goto Tanaris 49.8,27.9
		.talk Tanaris Flame Keeper##25921
		..accept Honor the Flame##11838 |instant
	step
		goto 52.7,30.1
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11762 |instant
	step
		|fly Cenarion Hold
	step
		goto Silithus,50.9,41.3
		.talk Silithus Flame Keeper##25919
		..accept Honor the Flame##11836 |instant
	step
		goto 60.6,33.2
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11760 |instant
	step
		|fly Camp Mojache
	step
		goto Feralas 72.4,47.8
		.talk Feralas Flame Keeper##25932
		..accept Honor the Flame##11849 |instant
	step
		goto 46.6,43.8
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11746 |instant
	step
		'Go north to Desolace. |goto Desolace |noway |c
	step
		goto Desolace,26.2,76.9
		.talk Desolace Flame Keeper##25928
		..accept Honor the Flame##11845 |instant
	step
		goto 65.8,16.9
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11741 |instant
	step
		goto Stonetalon Mountains,38.2,68.3 |n
		.' The path up to Sun Rock Retreat starts here |goto Stonetalon Mountains,42.5,68.6,0.5 |noway |c
	step
		goto 52.9,62.5
		.talk Stonetalon Flame Keeper##25940
		..accept Honor the Flame##11856 |instant
	step
		|fly Desolation Hold
	step
		goto Southern Barrens,40.9,67.8
		.talk Southern Barrens Flame Keeper##25943
		..accept Honor the Flame##28927 |instant
	step
		goto 48.3,72.4
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##28913 |instant
	step
		|fly The Crossroads
	step
		goto Northern Barrens 50.0,54.6
		.talk The Northern Barrens Flame Keeper##25943
		..accept Honor the Flame##11859 |instant
	step
		'Go northeast to Durotar |goto Durotar |noway |c
	step
		goto Durotar 52.2,47.3
		.talk Durotar Flame Keeper##25929
		..accept Honor the Flame##11846 |instant
	step
		|fly Everlook
	step
		goto Winterspring 58.1,47.5
		.talk Winterspring Flame Keeper##25922
		..accept Honor the Flame##11839 |instant
	step
		goto 61.3,47.1
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11763 |instant
	step
		|fly Silverwind Refuge
	step
		 goto Ashenvale 51.4,66.2
		.talk Ashenvale Flame Keeper##25884
		..accept Honor the Flame##11841 |instant
	step
		goto 86.8,41.4
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11734 |instant
	step
		|fly Zoram'gar Outpost
	step
		goto 15.3,20.1
		.from Twilight Firesworn##25863+, Twilight Flameguard##25866+
		.get Twilight Correspondence |q 11886/1
	step
		goto 15.7,20.3
		.' Use your Totemic Beacon next to the blue bonfire |use Totemic Beacon##35828
		.talk Earthen Ring Guide##25324
		..turnin Unusual Activity##11886
		..accept An Innocent Disguise##11891
	step
		goto 9.6,13.2
		.' Use your Orb of the Crawler in this spot |use Orb of the Crawler##35237
		.' Get the Crab Disguise |havebuff Interface\Icons\Ability_Hunter_Pet_Crab
	step
		goto 9.2,12.6
		'While in the crab disguise follow this path.
		.' Listen to the plan of the Twilight Cultists |q 11891/1
	step
		goto 9.7,13.3
		.' Use your Totemic Beacon next to the blue bonfire |use Totemic Beacon##35828
		.talk Earthen Ring Guide##25324
		..turnin An Innocent Disguise##11891
		..accept Inform the Elder##12012
	step
		'Go east to Darkshore |goto Darkshore |noway |c
	step
		goto Darkshore 48.9,22.6
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11740 |instant
	step
		goto 40.0,12.7 |noway
		.' You'll need to fly across the ocean here, you will get fatigued.
		goto Teldrassil,57.6,89.6 |c
	step
		goto Teldrassil 54.7,52.9
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11753 |instant
	step
		.' Go West to Darnassus. |goto Darnassus
	step
		goto Darnassus 64,47.1
		.click Flame of Darnassus##6756
		.collect Flame of Darnassus##23184 |n
		.' Click the Flame of Darnassus in your bags |use Flame of Darnassus##23184
		..accept Stealing Darnassus's Flame##9332 |tip It is recommended that you be level 80 when attempting to complete this guide step.
	step
		goto 35.8,50.3 |n
		.' Go inside the pink portal to Rut'theran Village |goto Teldrassil |noway |c
	step
		goto Teldrassil 52.3,89.5 |n
		.' Ride the boat to Azuremyst Isle |goto Azuremyst Isle |noway |c
	step
		'Go inside the Exodar |goto The Exodar |noway |c
	step
		goto The Exodar 41.6,26.9
		.click Flame of the Exodar##6756
		.collect Flame of the Exodar##35569 |n
		.' Click the Flame of the Exodar in your bags |use Flame of the Exodar##35569
		..accept Stealing the Exodar's Flame##11933 |tip It is recommended that you be level 80 when attempting to complete this guide step.
	step
		'Go outside to Azuremyst Isle |goto Azuremyst Isle |noway |c
	step
		goto Azuremyst Isle 44.7,52.7
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11735 |instant
	step
		'Go north to Bloodmyst Isle |goto Bloodmyst Isle |noway |c
	step
		goto Bloodmyst Isle 55.9,68.6
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11738 |instant
	step
		'Hearth to Orgrimmar |goto Orgrimmar |use Hearthstone##6948 |noway |c
	step
		|fly Ratchet
	step
		goto Northern Barrens 70.1,73.3 |n
		.' Ride the boat to Booty Bay |goto The Cape of Stranglethorn |noway |c
	step
		goto The Cape of Stranglethorn 50.4,70.4
		.talk Stranglethorn Vale Flame Keeper##25920
		..accept Honor the Flame##11837 |instant
	step
		goto 51.8,67.4
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11761 |instant
	step
		|fly Grom'gol Base Camp
	step
		goto Northern Stranglethorn 40.6,50.9
		.talk Northern Stranglethorn Vale Flame Keeper##25944
		..accept Honor the Flame##28924 |instant
	step
		goto 51.7,63.3
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##28910 |instant
	step
		|fly Dreadmaul Hold
	step
		goto Blasted Lands 55.3,15.2
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11737 |instant
	step
		|fly Bogpaddle
	step
		goto Swamp of Sorrows 76.3,13.8
		.talk Swamp of Sorrows Flame Keeper##25941
		..accept Honor the Flame##11857 |instant
	step
		goto 70.3,14.4
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##28916 |instant
	step
		'Go west to Duskwood |goto Duskwood |noway |c
	step
		goto Duskwood 73.4,55.0
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11743 |instant
	step
		'Go west to Westfall |goto Westfall |noway |c
	step
		goto Westfall 45.1,62.3
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11581 |instant
	step
		'Go northeast to Elwynn Forest |goto Elwynn Forest |noway |c
	step
		goto Elwynn Forest 43.1,63.0
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11745 |instant
	step
		'Go northwest to Stormwind City |goto Stormwind City |noway |c
	step
		goto Stormwind City 50.0,72.6
		.click Flame of Stormwind##6756
		.collect Flame of Stormwind##23182 |n
		.' Click the Flame of Stormwind in your bags |use Flame of Stormwind##23182
		..accept Stealing Stormwind's Flame##9330 |tip It is recommended that you be level 80 when attempting to complete this guide step.
	step
		'Go outside to Elwynn Forest |goto Elwynn Forest |noway |c
	step
		'Go east to Redridge Mountains |goto Redridge Mountains |noway |c
	step
		goto Redridge Mountains 24.5,53.8
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11751 |instant
	step
		'Go northeast to Burning Steppes |goto Burning Steppes |noway |c
	step
		goto Burning Steppes 68.7,60.1
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11739 |instant
	step
		goto 51.1,29.2
		.talk Burning Steppes Flame Keeper##25927
		..accept Honor the Flame##11844 |instant
	step
		|fly New Kargath, Badlands
	step
		goto Badlands 18.7,56.0
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##28912 |instant
	step
		goto 23.1,37.4
		.talk Badlands Flame Keeper##25925
		..accept Honor the Flame##11842 |instant
	step
		'Go northeast to Loch Modan |goto Loch Modan |noway |c
	step
		goto Loch Modan 32.4,40.2
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11749 |instant
	step
		'Go southwest to Dun Morogh |goto Dun Morogh |noway |c
	step
		goto Dun Morogh 53.6,44.8
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11742 |instant
	step
		'Go northeast to Ironforge |goto Ironforge |noway |c
	step
		goto Ironforge 64.3,26.0
		.click Flame of Ironforge##6756
		.collect Flame of Ironforge##23183 |n
		.' Click the Flame of Ironforge in your bags |use Flame of Ironforge##23183
		..accept Stealing Ironforge's Flame##9331 |tip It is recommended that you be level 80 when attempting to complete this guide step.
	step
		'Go outside to Dun Morogh |goto Dun Morogh |noway |c
	step
		'Go east to Loch Modan |goto Loch Modan |noway |c
	step
		'Go north to Wetlands |goto Wetlands |noway |c
	step
		goto Wetlands 13.2,47.1
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11757 |instant
	step
		'Go northeast to Arathi Highlands |goto Arathi Highlands |noway |c
	step
		goto Arathi Highlands 44.6,46.1
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11732 |instant
	step
		goto 69.3,42.6
		.talk Arathi Flame Keeper##25923
		..accept Honor the Flame##11840 |instant
	step
		|fly Tarren Mill
	step
		goto Hillsbrad Foothills 54.7,50.1
		.talk Hillsbrad Flame Keeper##25935
		..accept Honor the Flame##11853 |instant
	step
		|fly The Sepulcher
	step
		goto Silverpine Forest 49.6,38.2
		.talk Silverpine Forest Flame Keeper##25939
		..accept Honor the Flame##11584 |instant
	step
		|fly Trade Quarter
	step
		goto Undercity 66.9,13.5
		.talk Earthen Ring Elder##26221
		..turnin Inform the Elder##12012
	step
		goto 67.7,8.3
		.talk Festival Talespinner##16818
		..turnin Stealing Darnassus's Flame##9332
		..turnin Stealing the Exodar's Flame##11933
		..turnin Stealing Stormwind's Flame##9330
		..turnin Stealing Ironforge's Flame##9331
		..accept A Thief's Reward##9339 |instant
	step
		goto 54.9,11.3
		.click Orb of Translocation##7161 
		.' Go to Silvermoon City |goto Silvermoon City |noway |c
	step
		'Go outside to Eversong Woods |goto Eversong Woods |noway |c
	step
		goto Eversong Woods 46.4,50.6
		.talk Eversong Woods Flame Keeper##25931
		..accept Honor the Flame##11848 |instant
	step
		'Go south to Ghostlands |goto Ghostlands |noway |c
	step
		goto Ghostlands 46.9,26.3
		.talk Ghostlands Flame Keeper##25933
		..accept Honor the Flame##11850 |instant
	step
		|fly Revantusk Village
	step
		goto The Hinterlands 76.7,75.0
		.talk The Hinterlands Flame Keeper##25944
		..accept Honor the Flame##11860 |instant
	step
		goto 14.5,49.9
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11755 |instant
	step
		'Go southwest to Hillsbrad Foothills |goto Hillsbrad Foothills |noway |c
	step
		|fly The Bulwark
	step
		'Go east to Western Plaguelands |goto Western Plaguelands |noway |c
	step
		goto Western Plaguelands 43.6,82.5
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11756 |instant
	step
		'Go northwest to Tirisfal Glades |goto Tirisfal Glades |noway |c
	step
		goto Tirisfal Glades 57.2,51.7
		.talk Tirisfal Glades Flame Keeper##25946
		..accept Honor the Flame##11862 |instant
	step
		'Go southeast to Undercity |goto Undercity |noway |c
	step
		goto Undercity 85.3,17.1 |n
		.' Click the Portal to Blasted Lands |goto Blasted Lands |noway |c
	step
		'Go inside the huge green portal to Hellfire Peninsula |goto Hellfire Peninsula |noway |c
	step
		goto Hellfire Peninsula 61.9,58.5
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11747 |instant
	step
		goto Hellfire Peninsula 57.1,42.0
		.talk Hellfire Peninsula Flame Keeper##25934
		..accept Honor the Flame##11851 |instant
	step
		goto Netherstorm 32.1,68.3
		.talk Netherstorm Flame Keeper##25918
		..accept Honor the Flame##11835 |instant
	step
		goto Netherstorm 31.1,62.9
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11759 |instant
	step
		goto Blade's Edge Mountains 49.9,58.7
		.talk Blade's Edge Flame Keeper##25926
		..accept Honor the Flame##11843 |instant
	step
		goto Blade's Edge Mountains 41.8,66.0
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11736 |instant
	step
		goto Zangarmarsh 35.4,51.6
		.talk Zangarmarsh Flame Keeper##25947
		..accept Honor the Flame##11863 |instant
	step
		goto Zangarmarsh 68.6,52.1
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11758 |instant
	step
		goto Nagrand 50.9,34.1
		.talk Nagrand Flame Keeper##25937
		..accept Honor the Flame##11854 |instant
	step
		goto Nagrand 49.7,69.7
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11750 |instant
	step
		goto Terokkar Forest 52.0,42.9
		.talk Terokkar Forest Flame Keeper##25942
		..accept Honor the Flame##11858 |instant
	step
		goto Terokkar Forest 54.2,55.5
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11754 |instant
	step
		goto Shadowmoon Valley 33.4,30.5
		.talk Shadowmoon Valley Flame Keeper##25938
		..accept Honor the Flame##11855 |instant
	step
		goto Shadowmoon Valley 39.5,54.4
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##11752 |instant
	step
		goto Shattrath City 56.9,48.9 |n
		.' Click the Shattrath Portal to Orgrimmar |goto Orgrimmar |noway |c
	step
		goto Orgrimmar 44.6,62.4 |n
		.' Ride the zeppelin to Borean Tundra |goto Borean Tundra |noway |c
	step
		goto Borean Tundra 55.2,20.2
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##13440 |instant
	step
		goto Borean Tundra 51.1,11.5
		.talk Borean Tundra Flame Keeper##32809
		..accept Honor the Flame##13493 |instant
	step
		goto Sholazar Basin 47.9,66.2
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##13442 |instant
	step
		goto Sholazar Basin 47.1,61.5
		.talk Sholazar Basin Flame Keeper##32810
		..accept Honor the Flame##13494 |instant
	step
		goto Dragonblight 38.3,48.5
		.talk Dragonblight Flame Keeper##32811
		..accept Honor the Flame##13495 |instant
	step
		goto Dragonblight 75.1,43.8
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##13443 |instant
	step
		goto Crystalsong Forest 77.6,75.2
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##13447 |instant
	step
		goto Crystalsong Forest 80.0,53.2
		.talk Crystalsong Forest Flame Keeper##32815
		..accept Honor the Flame##13499 |instant
	step
		goto The Storm Peaks 40.3,85.3
		.talk Storm Peaks Flame Keeper##32814
		..accept Honor the Flame##13498 |instant
	step
		goto The Storm Peaks 41.4,87.0
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##13446 |instant
	step
		goto Zul'Drak 40.5,61.0
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##13449 |instant
	step
		goto Zul'Drak 43.4,71.7
		.talk Zul'Drak Flame Keeper##32816
		..accept Honor the Flame##13500 |instant
	step
		goto Grizzly Hills 19.3,61.2
		.talk Grizzly Hills Flame Keeper##32813
		..accept Honor the Flame##13497 |instant
	step
		goto Grizzly Hills 34.2,60.6
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##13445 |instant
	step
		goto Howling Fjord 48.6,13.1
		.talk Howling Fjord Flame Keeper##32812
		..accept Honor the Flame##13496 |instant
	step
		goto Howling Fjord 57.8,15.8
 		.click Alliance Bonfire##7734 
		..accept Desecrate this Fire!##13444 |instant
]])

ZygorGuidesViewer:RegisterInclude("Midsummer_Achievements",[[
	step
		'Complete the Midsummer Fire Festival Quests guide section before doing this guide section.
		.' Skip to the next step in the guide
	step
		goto Undercity,66.9,13.6
		.talk Earthen Ring Elder##26221
		..' Queue for The Frost Lord Ahune battle.
		..' Click Find Group
		..from Lord Ahune##25740
		.' Complete the Ice the Frost Lord Achievement |achieve 263
	step
		goto Undercity,68.1,11.2
		.talk Midsummer Merchant##26124
		.buy 15 Juggling Torch##34599
		.buy 1 Mantle of the Fire Festival##23324
		.buy 1 Vestment of Summer##34685
		.buy 1 Sandals of Summer##34683
	step
		goto Undercity,68.0,14.4
		.' Equip your Mantle of the Fire Festival |use Mantle of the Fire Festival##23324
		'
		'
		.' Equip your Vestment of Summer |use Vestment of Summer##34685
		'
		'
		.' Equip your Sandals of Summer |use Sandals of Summer##34683
		.' Click the Ribbon Pole |tip It looks like a tall metal pole with a small fire on top of it.
		.' Let your character spin around for 1 minute
		.' Complete the Burning Hot Pole Dance Achievement |achieve 271
	step
		'Don't forget to put your regular gear back on
		.' Skip to the next step in the guide
	step
		'Go outside to Tirisfal Glades |goto Tirisfal Glades |noway |c
	step
		goto Tirisfal Glades,59.1,59.0 |n
		.' Ride the zeppelin to Howling Fjord |goto Howling Fjord |noway |c
	step
		goto Howling Fjord,79.0,29.7
		.talk Bat Handler Adeline##27344
		.' Fly to Dalaran |goto Dalaran,72.7,45.7,0.5 |noway |c
	step
		goto Dalaran,36.8,44.1
		.' Use your 40 Juggling Torches as fast as you can |tip You must juggle them all in under 15 seconds.  The best way to do this is to place your Juggling Torches on your hotbar.  Press the hotbar key and click the ground at the same time.  Keep spamming the hotbar key and clicking the ground at the same time as fast as possible and dont stop until you get the achievement.
		.' Complete the Torch Juggler Achievement |achieve 272
	step
		'Hearth to Orgrimmar |goto Orgrimmar 53.4,78.8 |noway |c
	step
		goto Orgrimmar 49.4,36.7 |n
		. 'Click the Portal to Vashj'ir |goto Abyssal Depths |noway |c
	step
		|fly Silver Tide Hollow
	step
		goto Shimmering Expanse 49.4,42.0
		.talk Vashj'ir Flame Guardian##51697
		..accept Honor the Flame##29031
	step
		goto Shimmering Expanse 49.4,41.9
		.click Earthen Ring Bonfire##7734
		..turnin Honor the Flame##29031
		|confirm
	step
		|fly Smuggler's Scar
	step
		'Fly east to Twilight Highlands |goto Twilight Highlands |noway |c
	step
		goto Twilight Highlands 53.1,46.2
		.talk Twilight Highlands Flame Keeper##51651
		..accept Honor the Flame##28946 |instant
	step
		goto 47.3,28.3
		.click Alliance Bonfire##7734
		..accept Desecrate this Fire!##28943 |instant
	step
		'Hearth to Orgrimmar |goto Orgrimmar 53.4,78.8 |noway |c
	step
		goto Orgrimmar 50.8,36.5 |n
		.' Click the portal to Deepholm |goto Deepholm |noway |c
	step
		goto Deepholm 49.3,51.4
		.talk Deepholm Flame Guardian##51698
		..accept Honor the Flame##29036
	step
		goto Deepholm 49.3,51.4
		.click Earthen Ring Bonfire##7734
		..turnin Honor the Flame##29036
		|confirm
	step
		goto Deepholm 50.9,53.1 |n
		.' Click the Portal to Orgrimmar |goto Orgrimmar |noway |c
	step
		goto Orgrimmar 51.0,38.2 |n
		.' Click the Portal to Hyjal |goto Mount Hyjal |noway |c
	step	
		goto Mount Hyjal 62.8,22.7
		.talk Hyjal Flame Guardian##51682
		..accept Honor the Flame##29030
	step
		goto 62.8,22.8
		.click Earthen Ring Bonfire##7734
		..turnin Honor the Flame##29030
		|confirm
	step
		goto 63.5,24.4 |n
		.' Click the portal to Orgrimmar |goto Orgrimmar |noway |c
	step
		  goto 49.0,38.4 |n
		.' Click the Portal to Uldum |goto Uldum |noway |c
	step
		goto Uldum 53.1,34.5
		.talk Uldum Flame Keeper##51652
		..accept Honor the Flame##28949 |instant
	step
		goto 53.5,32.0
		.click Alliance Bonfire##7734
		..accept Desecrate this Fire!##28947 |instant
	step
		'Congratulations, you are now The Flame Warden!
]])

--------------------------------------------------------------------------------------------------------------------------------------
-- Professions Cooking
--------------------------------------------------------------------------------------------------------------------------------------
ZygorGuidesViewer:RegisterInclude("H_The_Northrend_Gourmet",[[
	step //1268
	title +Wrath of the Lich King Recipes
		#include trainCooking
		.learn Dalaran Clam Chowder##58065 
		.learn Grilled Sculpin##45563 
		.learn Mammoth Meal##45549 
		.learn Pickled Fangtooth##45566 
		.learn Poached Nettlefish##45565 
		.learn Rhino Dogs##45553 
		.learn Roasted Worg##45552 
	step //1269
		#include trainCooking
		.learn Shoveltusk Steak##45550 
		.learn Smoked Salmon##45564 
		.learn Worm Delight##45551 
		.learn Fisherman's Feast##42302 
		.learn Hot Buttered Trout##42305 
		.learn Great Feast##45554 
		.learn Black Jelly##64358 
		.learn Darkbrew Lager##88015 
		.learn Blackened Surprise##88006
	step //1270
		#include rideto_borean
	step //1271
		//alliance
		//goto 57.8,71.4
		//.talk Rollick MacKreel##26989
		//..accept Northern Cooking##13088
		//horde
		goto 42,54.2
		.talk Orn Tenderhoof##26972
		..accept Northern Cooking##13090
	step //1272
		goto 45,47.4
		.from Wooly Rhino Matriarch##25487+,Wooly Rhino Calf##25488+
		.get 4 Chilled Meat##43013 |q 13090
		//alliance
		//.get 4 Chilled Meat##43013 |q 13088
	step //1273
		//alliance
		//goto 57.8,71.4
		//.talk Rollick MacKreel##26989
		//..turnin Northern Cooking##13088
		//horde
		goto 42,54.2
		.talk Orn Tenderhoof##26972
		..turnin Northern Cooking##13090
		.learn Northern Stew##57421
	//Emotions food
	step //1274
		goto 54.6,70.0
		.from Crypt Crawler##25227 |tip You can also farm any Northrend Dungeon for a higher drop percentage.
		.collect 1 Recipe: Bad Clams##43509
		.collect 1 Recipe: Last Week's Mammoth##43508
		.collect 1 Recipe: Haunted Herring##43510
		.collect 1 Recipe: Tasty Cupcake##43507
	step //1275
		.learn Bad Clams##58523 |use Recipe: Bad Clams##43509
		.learn Haunted Herring##58525 |use Recipe: Haunted Herring##43510
		.learn Last Week's Mammoth##58521 |use Recipe: Last Week's Mammoth##43508
		.learn Tasty Cupcake##58512 |use Recipe: Tasty Cupcake##43507
	step //1276
		fly Nesingwary Base Camp
	step //1277
		goto 26.8,60.1
		.talk Grimbooze Thunderbrew##29157
		..accept Some Make Lemonade, Some Make Liquor##12634
	step //1278
		goto 37.6,61.8
		.click Sturdy Vine##8129
		.' Click the fruit that falls to the ground or talk to the dwarf that falls
		.get Orange |q 12634/1
		.get 2 Banana Bunch|q 12634/2
		.get Papaya |q 12634/3
	step //1279
		goto 26.8,60.1
		.talk Grimbooze Thunderbrew##29157
		..turnin Some Make Lemonade, Some Make Liquor##12634
		..accept Still At It##12644
	step //1280
		goto 26.7,60
		.talk "Tipsy" McManus##28566
		..'Tell him you are ready to start the distillation process
		.' Click the items on the ground or on the machine that he yells at you during the process, it's random
		.' Click the barrel on the ground when the process is done
		.get Thunderbrew's Jungle Punch|q 12644/1
	step //1281
		goto 26.8,60.1
		.talk Grimbooze Thunderbrew##29157
		..turnin Still At It##12644
		..accept The Taste Test##12645
	step //1282
		goto 27.4,59.4
		.' Use your Jungle Punch Sample on Hadrius Harlowe|use Jungle Punch Sample##38697|tip Standing next to a tiki torch.
		.' Complete Hadrius' taste test |q 12645/2
	step //1283
		goto 27.1,58.6
		.' Use your Jungle Punch Sample on Hemet Nesingwary|use Jungle Punch Sample##38697|tip Standing in front of a tent.
		.' Complete Hemet's taste test |q 12645/1
	step //1284
		goto 26.8,60.1
		.talk Grimbooze Thunderbrew##29157
		..turnin The Taste Test##12645
	step //1285
		goto Sholazar Basin,25.3,58.5
		.talk The Spirit of Gnomeregan##28037
		.' Fly to Dalaran |goto Dalaran |noway |c
	step //1286
		goto Dalaran,43.2,24.4
		.talk Washed-Up Mage##32516
		..accept Fletcher's Lost and Found##13571 |instant
	step //1287
		'You can use the Professions section of this guide to get to 450 cooking |only if skill("Cooking")<450
		'You can use the Dalaran Cooking Dailies section of this guide to earn Dalaran Cooking Awards to buy the following recipes: |tip You will need a total of 74 Dalaran Cooking Awards to get all of the recipes
		goto Dalaran,70.1,38.2 
		.talk Misensi##31031 
		.buy 1 Recipe: Mega Mammoth Meal##43018 
		.buy 1 Recipe: Tender Shoveltusk Steak##43019 
		.buy 1 Recipe: Spiced Worm Burger##43020 
		.buy 1 Recipe: Very Burnt Worg##43021 
		.buy 1 Recipe: Worg Tartare##44954 
		.buy 1 Recipe: Mighty Rhino Dogs##43022 
		.buy 1 Recipe: Poached Northern Sculpin##43023 //50
		.buy 1 Recipe: Firecracker Salmon##43024 
		.buy 1 Recipe: Spicy Blue Nettlefish##43025 
		.buy 1 Recipe: Imperial Manta Steak##43026 
		.buy 1 Recipe: Spicy Fried Herring##43027 
		.buy 1 Recipe: Rhinolicious Wormsteak##43028
	step //1288
		'Use the Professions section of this guide to get to 450 cooking |only if skill("Cooking")<450
		.learn Mega Mammoth Meal##45555 |use Recipe: Mega Mammoth Meal##43018 
		.learn Tender Shoveltusk Steak##45556 |use Recipe: Tender Shoveltusk Steak##43019
		.learn Spiced Worm Burger##45557 |use Recipe: Spiced Worm Burger##43020
		.learn Very Burnt Worg##45558 |use Recipe: Very Burnt Worg##43021
		.learn Worg Tartare##62350 |use Recipe: Worg Tartare##44954
		.learn Mighty Rhino Dogs##45559 |use Recipe: Mighty Rhino Dogs##43022
		.learn Poached Northern Sculpin##45567 |use Recipe: Poached Northern Sculpin##43023
		.learn Firecracker Salmon##45568 |use Recipe: Firecracker Salmon##43024
		.learn Spicy Blue Nettlefish##45571 |use Recipe: Spicy Blue Nettlefish##43025
		.learn Imperial Manta Steak##45570 |use Recipe: Imperial Manta Steak##43026
		.learn Spicy Fried Herring##57433 |use Recipe: Spicy Fried Herring##43027
		.learn Rhinolicious Wormsteak##57434 |use  Recipe: Rhinolicious Wormsteak##43028
	step //1289
		'Use the Professions section of this guide to get to 450 cooking |only if skill("Cooking")<450
		'Use the Dalaran Cooking Dailies section of this guide to earn Dalaran Cooking Awards to buy the following recipes: |tip You will need a total of 74 Dalaran Cooking Awards to get all of the recipes
		goto Dalaran,70.1,38.2 
		.talk Misensi##31031 
		.buy 1 Recipe: Critter Bites##43029 
		.buy 1 Recipe: Hearty Rhino##43030 
		.buy 1 Recipe: Snapper Extreme##43031 
		.buy 1 Recipe: Blackened Worg Steak##43032 
		.buy 1 Recipe: Cuttlesteak##43033 
		.buy 1 Recipe: Spiced Mammoth Treats##43034 
		.buy 1 Recipe: Blackened Dragonfin##43035 
		.buy 1 Recipe: Dragonfin Fillet##43036 
		.buy 1 Recipe: Tracker Snacks##43037 
		.buy 1 Recipe: Gigantic Feast##43505 
		.buy 1 Recipe: Small Feast##43506 
		.buy 1 Recipe: Fish Feast##43017 
	step //1290
		'Use the Professions section of this guide to get to 450 cooking |only if skill("Cooking")<450
		.learn Critter Bites##57435 |use Recipe: Critter Bites##43029
		.learn Hearty Rhino##57436 |use Recipe: Hearty Rhino##43030
		.learn Snapper Extreme##57437 |use Recipe: Snapper Extreme##43031
		.learn Blackened Worg Steak##57438 |use Recipe: Blackened Worg Steak##43032
		.learn Cuttlesteak##57439 |use Recipe: Cuttlesteak##43033
		.learn Spiced Mammoth Treats##57440 |use Recipe: Spiced Mammoth Treats##43034
		.learn Blackened Dragonfin##57441 |use Recipe: Blackened Dragonfin##43035
		.learn Dragonfin Fillet##57442 |use Recipe: Dragonfin Fillet##43036
		.learn Tracker Snacks##57443 |use Recipe: Tracker Snacks##43037
		.learn Gigantic Feast##58527 |use Recipe: Gigantic Feast##43505
		.learn Small Feast##58528 |use Recipe: Small Feast##43506 
		.learn Fish Feast##57423 |use Recipe: Fish Feast##43017
	step //1291
		'You can either buy these from the Auction House or farm them
		.collect 1 Barrelhead Goby##41812
		.collect 4 Bonescale Snapper##41808
		.collect 5 Chilled Meat##43013
		.collect 8 Chunk o' Mammoth##34736
		.collect 2 Deep Sea Monsterbelly##41800
		.collect 2 Dragonfin Angelfish##41807
		.collect 1 Essence of Undeath##12808
		.collect 3 Fangtooth Herring##41810
		.collect 6 Glacial Salmon##41809
		.collect 2 Imperial Manta Ray##41809
		.collect 1 Moonglow Cuttlefish##41801
		.collect 1 Mote of Shadow##22577
		.collect 4 Musselback Sculpin##41806
		.collect 6 Nettlefish##51813
		.collect 1 Northern Egg##43501
		.collect 24 Northern Spices##43007
		.collect 7 Rhino Meat##43012
		.collect 3 Rockfin Grouper##41803
		.collect 1 Savory Snowplum##35948
		.collect 5 Shoveltusk Flank##43009
		.collect 3 Succulent Clam Meat##36782
		.collect 2 Tundra Berries##35949
		.collect 5 Worg Haunch##43011
	step //1292
		goto Orgrimmar,56.5,61.2
		.talk Suja##46708
		.buy 2 Simple Flour##30817
	step //1293
		goto Orgrimmar,50.8,74.6
		.talk Shan'ti##3342
		.collect 2 Tundra Berries##35949
	step //1294
		'Build a Basic Campfire |cast Basic Campfire##818
		.create Bad Clams##58523,Cooking,1 total
		.' Cook Bad Clams |achieve 1777/1
		.' Eat Bad Clams |achieve 1780/1 |use Bad Clams##43491
	step //1295
		.create Baked Manta Ray##45569,Cooking,1 total
		.' Cook Baked Manta Ray |achieve 1777/2
	step //1296
		.create Blackened Dragonfin##57441,Cooking,1 total
		.' Cook Blackened Dragonfin |achieve 1777/3
	step //1297
		.create Blackened Worg Steak##57438,Cooking,1 total
		.' Cook Blackened Worg Steak |achieve 1777/4
	step //1298
		.create Critter Bites##57435,Cooking,1 total
		.' Cook Critter Bites |achieve 1777/5
	step //1299
		.create Cuttlesteak##57439,Cooking,1 total
		.' Cook Cuttlesteak |achieve 1777/6
	step //1300
		.create Dalaran Clam Chowder##58065,Cooking,1 total
		.' Cook Dalaran Clam Chowder |achieve 1777/7
	step //1301
		.create Dragonfin Filet##57442,Cooking,1 total
		.' Cook Dragonfin Filet |achieve 1777/8
	step //1302
		.create Firecracker Salmon##45568,Cooking,1 total
		.' Cook Firecracker Salmon |achieve 1777/9
	step //1303
		.create Fish Feast##57423,Cooking,1 total
		.' Cook Fish Feast |achieve 1777/10
	step //1304
		.create Gigantic Feast##58527,Cooking,1 total
		.' Cook Gigantic Feast |achieve 1777/11
	step //1305
		.create Great Feast##45554,Cooking,1 total
		.' Cook Great Feast |achieve 1777/12
	step //1306
		.create Grilled Bonescale##45561,Cooking,1 total
		.' Cook Grilled Bonescale |achieve 1777/13
	step //1307
		.create Grilled Sculpin##45563,Cooking,1 total
		.' Cook Grilled Sculpin |achieve 1777/14
	step //1308
		.create Haunted Herring##58525,Cooking,1 total
		.' Cook Haunted Herring |achieve 1777/15
		.' Eat Haunted Herring |achieve 1780/2|use Haunted Herring##43492
	step //1309
		.create Hearty Rhino##57436,Cooking,1 total
		.' Cook Hearty Rhino |achieve 1778/16
	step //1310
		.create Imperial Manta Steak##45570,Cooking,1 total
		.' Cook Imperial Manta Steak |achieve 1778/17
	step //1311
		.create Kungaloosh##53056,Cooking,1 total
		.' Cook Kungaloosh |achieve 1778/18
	step //1312
		.create Last Week's Mammoth##58521,Cooking,1 total
		.' Cook Last Week's Mammoth |achieve 1778/19
		.' Eat Last Week's Mammoth |achieve 1780/3 |use Last Week's Mammoth##43488
	step //1313
		.create Mammoth Meal##45549,Cooking,1 total
		.' Cook Mammoth Meal |achieve 1778/20
	step //1314
		.create Mega Mammoth Meal##45555,Cooking,1 total
		.' Cook Mega Mammoth Meal |achieve 1778/21
	step //1315
		.create Mighty Rhino Dogs##45559,Cooking,1 total
		.' Cook Mighty Rhino Dogs |achieve 1778/22
	step //1316
		.create Northern Stew##57421,Cooking,1 total
		.' Cook Northern Stew |achieve 1778/23
	step //1317
		.create Pickeled Fangtooth##45566,Cooking,1 total
		.' Cook Pickeled Fangtooth |achieve 1778/24
	step //1318
		.create Poached Nettlefish##45565,Cooking,1 total
		.' Cook Poached Nettlefish |achieve 1778/25
	step //1319
		.create Poached Northern Sculpin##45567,Cooking,1 total
		.' Cook Poached Northern Sculpin |achieve 1778/26
	step //1320
		.create Rhino Dogs##45553,Cooking,1 total
		.' Cook Rhino Dogs |achieve 1778/27
	step //1321
		.create Rhinolicious Wormsteak##57434,Cooking,1 total
		.' Cook Rhinolicious Wormsteak |achieve 1778/28
	step //1322
		.create Roasted Worg##45552,Cooking,1 total
		.' Cook Roasted Worg |achieve 1778/29
	step //1323
		.create Sauteed Goby##45562,Cooking,1 total
		.' Cook Sauteed Goby |achieve 1778/30
	step //1324
		.create Shoveltusk Steak##45550,Cooking,1 total
		.' Cook Shoveltusk Steak |achieve 1779/31
	step //1325
		.create Small Feast##58528,Cooking,1 total
		.' Cook Small Feast |achieve 1779/32
	step //1326
		.create Smoked Rockfin##45560,Cooking,1 total
		.' Cook Smoked Rockfin |achieve 1779/33
	step //1327
		.create Smoked Salmon##45564,Cooking,1 total
		.' Cook Smoked Salmon |achieve 1779/34
	step //1328
		.create Snapper Extreme##57437,Cooking,1 total
		.' Cook Snapper Extreme |achieve 1779/35
	step //1329
		.create Spiced Mammoth Treats##57440,Cooking,1 total
		.' Cook Spiced Mammoth |achieve 1779/36
	step //1330
		.create Spiced Worm Burger##45557,Cooking,1 total
		.' Cook Spiced Worm Burger |achieve 1779/37
	step //1331
		.create Spicy Blue Nettlefish##45571,Cooking,1 total
		.' Cook Spicy Blue Nettlefish |achieve 1779/38
	step //1332
		.create Spicy Fried Herring##57433,Cooking,1 total
		.' Cook Spicy Fried Herring |achieve 1779/39
	step //1333
		.create Tasty Cupcake##58512,Cooking,1 total
		.' Cook Tasty Cupcake |achieve 1779/40
		.' Eat Tasty Cupcake |achieve 1780/4 |use Tasty Cupcake##43490
	step //1334
		.create Tender Shoveltusk Steak##45556,Cooking,1 total
		.' Cook Tender Shoveltusk Steak |achieve 1779/41
	step //1335
		.create Tracker Snacks##57443,Cooking,1 total
		.' Cook Tracker Snacks |achieve 1779/42
	step //1336
		.create Very Burnt Worg##45558,Cooking,1 total
		.' Cook Very Burnt Worg |achieve 1779/43
	step //1337
		.create Worg Tartare##62350,Cooking,1 total
		.' Cook Worg Tartare |achieve 1779/44
	step //1338
		.create Worm Delight##45551,Cooking,1 total
		.' Cook Worm Delight |achieve 1779/45
		.' Cook 45 of the Northrend recipes |achieve 1779
	step //1339
		'Congratulations! You've earned the Northrend Gourment achievement!
]])

ZygorGuidesViewer:RegisterInclude("H_The_Outland_Gourmet",[[
	step //1340
	title +The Burning Crusade Recipes
		#include trainCooking
		.learn Stewed Trout##42296 		
		.learn Fisherman's Feast##42302 
		.learn Hot Buttered Trout##42305 
	//300 Buzzard Bites TBC
	step //1341
		goto Hellfire Peninsula,49.2,74.8
		.talk Lagassi##19344
		..accept Ravager Egg Roundup##9349
	step //1342
		goto 39.0,88.4
		.from Razorfang Hatchling##16932+,Razorfang Ravager##16933+
		.get 12 Ravager Egg##23217 |q 9349/1
	step //1343
		goto Hellfire Peninsula,49.2,74.8
		.talk Lagassi##19344
		..turnin Ravager Egg Roundup##9349
	step //1344
		goto Hellfire Peninsula,49.2,74.8
		.talk Lagassi##19344
		..accept Helboar, the Other White Meat##9361
	step //1345
		goto 51.2,69.8
		.from Deranged Helboar##16863
		.collect 8 Tainted Helboar Meat##23270
	step //1346
		'Use the Purification Mixture on the Tainted Meat |use Purification Mixture##23268
		.get 8 Purified Helboar Meat##23248 |q 9361/1
	step //1347
		goto Hellfire Peninsula,49.2,74.8
		.talk Lagassi##19344
		..turnin Helboar, the Other White Meat##9361
	step //1348
		goto Hellfire Peninsula,49.2,74.8
		.talk Lagassi##19344
		..accept Smooth as Butter##9356
	step //1349
		goto 61.0,66.6
		.from Bonestripper Buzzard##16972
		.get 12 Plump Buzzard Wing |q 9356/1
	step //1350
		goto Hellfire Peninsula,49.2,74.8
		.talk Lagassi##19344
		..accept Smooth as Butter##9356
		.collect 1 Recipe: Buzzard Bites##27684 |n
		.learn Buzzard Bites##33279 |use Recipe: Buzzard Bites##27684
		//300 Ravager Dog TBC
	step //1351
		//alliance: 
		//goto Hellfire Peninsula,54.2,63.6
		//.talk Sid Limbardi##16826
		//horde:
		goto Hellfire Peninsula,54.6,41.0
		.talk Cookie One-Eye##16585
		.buy 1 Recipe: Ravager Dog##27688 |n
		.learn Ravager Dog##33284 |use Recipe: Ravager Dog##27688
	//300 Feltail Delight TBC blackened trout
	step //1352
		//alliance:
		//goto Zangarmarsh,42.2,27.8
		//.talk Doba##20028
		//horde:
		goto Zangarmarsh,85.2,54.6
		.talk Zurai##18011
		.buy 1 Recipe Feltail Delight##27695 |n
		.learn Feltail Delight##33291 |use Recipe Feltail Delight##27695
	step //1353
		|fly Zabra'jin
	step //1354
		goto 31.6,49.2
		.talk Gambarinka##18015
		.buy Recipe: Blackened Trout##27694 |n
		.learn Blackened Trout##33290 |use Recipe: Blackened Trout##27694 
	//300 Clam Bar TBC
	step //1355
		goto Zangarmarsh,17.8,51.2
		.talk Mycah##18382
		.buy 1 Recipe: Clam Bar##30156 |n
		.learn Clam Bar##36210 |use Recipe: Clam Bar##30156
	//310 Blackened Sporefish TBC
	step //1356
		//both
		goto Zangarmarsh,78.0,66.0
		.talk Juno Dufrain##18911
		.buy 1 Recipe: Blackened Sporefish##27696 |n
		.learn Blackened Sporefish##33292 |use Recipe: Blackened Sporefish##27696
	//310 Sporeling Snack TBC --help
	//320 Grilled Mudfish TBC, poached bluefish, talbuk steak. roasted clefthoof
	step //1357
		//alliance
		//goto Nagrand,56.2,73.2
		//.talk Uriku##20096
		//horde
		goto Nagrand,58.0,35.6 
		.talk Nula the Butcher##20097
		.buy 1 Recipe: Grilled Mudfish##27697
		.buy 1 Recipe: Talbuk Steak##27693
		.buy 1 Recipe: Poached Bluefish##27698
		.buy 1 Recipe: Roasted Clefthoof##27691
	step //1358
		.learn Talbuk Steak##33289 |use Recipe: Talbuk Steak##27693
		.learn Grilled Mudfish##33293 |use Recipe: Grilled Mudfish##27697
		.learn Poached Bluefish##33294 |use Recipe: Poached Bluefish##27698
		.learn Roasted Clefthoof##33287 |use Recipe: Roasted Clefthoof##27691
	//325 Golden Fish Sticks TBC + Spicy Crawdad TBC
	step //1359
		//alliance
		//goto Terokkar Forest,56.6,53.2
		//.talk Biribi##19296
		//horde
		goto Terokkar Forest,48.8,46.0
		.talk Rungor##18960
		.buy 1 Recipe: Golden Fish Sticks##27699 |n
		.buy 1 Recipe: Spicy Crawdad##27700 |n
		.learn Golden Fish Sticks##33295 |use Recipe: Golden Fish Sticks##27699
		.learn Spicy Crawdad##33296 |use Recipe: Spicy Crawdad##27700 
	//315 Blackened Basilisk TBC + warp burger
	step //1360
		//allaince
		//goto Terokkar Forest,55.8,53.0
		//.talk Supply Officer Mills##19038
		//horde
		goto Terokkar Forest,48.8,45.0
		.talk Inkeeper Grilka##18957
		.buy 1 Recipe Blackened Basilisk##27690 |n
		.buy 1 Recipe: Warp Burger##27692 |n
		.learn Blackened Basilisk##33286 |use Recipe Blackened Basilisk##27690
		.learn Warp Burger##33288 |use Recipe: Warp Burger##27692
	//325 Warp Burger TBC
	//335 Crunchy Serpent TBC + Mok'Nathal Shortribs TBC
	step //1361
		|fly Evergrove
	step //1362
		goto Blade's Edge Mountains,62.4,40.2
		.talk Xerintha Ravenoak##20916
		.buy 1 Recipe: Mok'Nathal Shortribs##31675 |n
		.buy 1 Recipe: Crunchy Serpent##31674 |n
		.learn Mok'Nathal Shortribs##38867 |use Recipe: Mok'Nathal Shortribs##31675
		.learn Crunchy Serpent##38868 |use Recipe: Crunchy Serpent##31674
	step //1363
		|fly Shattrath
	step //1364
		'Use the Shattrath Cooking Dailies section of this guide to get these recipes: |tip It's not always guarenteed to come from these daily prizes so be patient
		'Make sure to choose the Crate of Meat
		.collect 1 Recipe: Spicy Hot Talbuk##33873
	step //1365
		.learn Spicy Hot Talbuk##43765 |use Recipe: Spicy Hot Talbuk##33873
	//300 Broiled Bloodfin TBC + Skullfish Soup TBC
	step //1366
		//Barrel of fish 
		'Use the Shattrath Cooking Dailies section of this guide to get these recipes: |tip It's not always guarenteed to come from these daily prizes so be patient
		'Make sure to choose the Barrel of Fish
		.collect 1 Recipe: Broiled Bloodfin##33869
		.collect 1 Recipe: Skullfish Soup##33870
	step //1367
		.learn Broiled Bloodfin##43761 |use Recipe: Broiled Bloodfin##33869
		.learn Skullfish Soup##43707 |use Recipe: Skullfish Soup##33870
	//300 Kibler's Bits TBC
	step //1368
		'Use the Shattrath Cooking Dailies section of this guide to get this recipe: |tip It's not always guarenteed to come from these daily prizes so be patient
		'You can choose either the Crate of Meat of Barrel of Fish 
		.collect 1 Recipe: Kibler's Bits##33875
	step //1369
		.learn Kibler's Bits##43772 |use Recipe: Kibler's Bits##33875
	//300 Stormchops TBC
	step //1370
		'Use the Shattrath Cooking Dailies or Dalaran Cooking Dailies section of this guide to get these recipes: |tip It's not always guarenteed to come from these daily prizes so be patient
		'You can choose either Crate of Meat, Barrel of Fish, or Small Spice Bag
		.collect 1 Recipe: Stormchops##33871
		.collect 1 Recipe: Delicious Chocolate Cake##33925
	step //1371
		.learn Stormchops##43758 |use Recipe: Stormchops##33871
		.learn Delicious Chocolate Cake##43779 |use Recipe: Delicious Chocolate Cake##33925
	step //1372
		'You can either purchase these items from the Acution House or farm them
		.collect 8 Small Eggs##6889
		.collect 2 Buzzard Meat##27671
		.collect 2 Clefthoof Meat##27678
		.collect 2 Jaggal Clam Meat##24477
		.collect 2 Talbuk Venison##27682
		.collect 1 Chunk o' Basilisk##27677
		.collect 1 Raptor Ribs##31670
		.collect 1 Ravager Flesh##27674
		.collect 1 Serpent Flesh##31671
		.collect 1 Strange Spores##27676
		.collect 1 Warped Flesh##27681
		.collect 3 Mageroyal##785
	step //1373
		'You can either purchase these items from the Auction House or fish for them
		.collect 2 Barbed Gill Trout##27422
		.collect 1 Bloodfin Catfish##33823
		.collect 1 Crescent-Tail Skullfish##33824
		.collect 1 Enormous Barbed Gill Trout##27516
		.collect 1 Figluster's Mudfish##27435
		.collect 1 Golden Darter##27438
		.collect 1 Huge Spotted Feltail##27515
		.collect 1 Icefin Bluefish##27437
		.collect 1 Lightning Eel##13757
		.collect 1 Spotted Feltail##27425
		.collect 1 Zangarian Sporefish##27429
	step //1374
		goto Orgrimmar,50.8,74.6
		.talk Shan'ti##3342
		.buy 5 Goldenbark Apple##4539
	step //1375
		goto Orgrimmar,53.6,78.8
		.talk Innkeeper Gryshka##6929
		.buy 4 Ice Cold Milk##1179
	step //1376
		goto Orgrimmar,56.5,61.2
		.talk Suja##46708
		.buy 8 Simple Flour##30817
		.buy 4 Mild Spices##2678 
	step //1377
		fly Fizzle & Pozzik's Speedbarge
	step //1378
		goto 76.5,74.8
		.talk Daisy##40832
		.buy 1 Flask of Port##2593
	step //1379
		'Build a Basic Campfire |cast Basic Campfire##818
		.create Delicious Chocolate Cake##43779,Cooking,1 total
		.' Cook Delicious Chocolate Cake |achieve 1800/1
	step //1380
		.create Blackened Trout##33290,Cooking,1 total
		.' Cook Blackened Trout |achieve 1800/2
	step //1381
		.create Buzzard Bites##33279,Cooking,1 total
		.' Cook Buzzard Bites |achieve 1800/3
	step //1382
		.create Clam Bar##36210,Cooking,1 total
		.' Cook Clam Bar |achieve 1800/4
	step //1383
		.create Feltail Delight##33291,Cooking,1 total
		.' Cook Feltail Delight |achieve 1800/5
	step //1384
		.create Ravager Dog##33284,Cooking,1 total
		.' Cook Ravager Dog |achieve 1800/6
	step //1385
		.create Stormchops##43758,Cooking,1 total
		.' Cook Stormchops |achieve 1800/7
	step //1386
		.create Blackened Sporefish##33292,Cooking,1 total
		.' Cook Blackened Sporefish |achieve 1800/8
	step //1387
		.create Blackened Basilisk##33286,Cooking,1 total
		.' Cook Blackened Basilisk |achieve 1800/9
	step //1388
		.create Grilled Mudfish##33293,Cooking,1 total
		.' Cook Grilled Mudfish |achieve 1800/10
	step //1389
		.create Poached Bluefish##33294,Cooking,1 total
		.' Cook Poached Bluefish |achieve 1800/11
	step //1390
		.create Broiled Bloodfin##43761,Cooking,1 total
		.' Cook Broiled Bloodfin |achieve 1800/12
	step //1391
		.create Golden Fish Sticks##33295,Cooking,1 total
		.' Cook Golden Fish Sticks |achieve 1800/13
	step //1392
		.create Kibler's Bits##43772,Cooking,1 total
		.' Cook Kibler's Bits |achieve 1800/14
	step //1393
		.create Roasted Clefthoof##33287,Cooking,1 total
		.' Cook Roasted Clefthoof |achieve 1800/15
	step //1394
		.create Talbuk Steak##33289,Cooking,1 total
		.' Cook Talbuk Steak |achieve 1800/16
	step //1395
		.create Warp Burger##33288,Cooking,1 total
		.' Cook Warp Burger |achieve 1800/17
	step //1396
		.create Crunchy Serpent##38868,Cooking,1 total
		.' Cook Crunchy Serpent |achieve 1800/18
	step //1397
		.create Mok'Nathal Shortribs##38867,Cooking,1 total
		.' Cook Mok'Nathal |achieve 1800/19
	step //1398
		.create Fisherman's Feast##42302,Cooking,1 total
		.' Cook Fisherman's Feast |achieve 1800/20
	step //1399
		.create Hot Buttered Trout##42305,Cooking,1 total
		.' Cook Hot Buttered Trout |achieve 1800/21
	step //1400
		.create Skullfish Soup##43707,Cooking,1 total
		.' Cook Skullfish Soup |achieve 1800/22
	step //1401
		.create Spicy Crawdad##33296,Cooking,1 total
		.' Cook Spicy Crawdad |achieve 1800/23
	step //1402
		.create Spicy Hot Talbuk##43765,Cooking,1 total
		.' Cook Spicy Hot Talbuk |achieve 1800/24
	step //1403
		.create Stewed Trout##42296,Cooking,1 total
		.' Cook Stewed Trout |achieve 1800/25
	step //1404
		.' Cook each of the Outland cooking recipes |achieve 1800
	step //1405
		Congratulations! You're earned The Outland Gourmet achievement!
]])

ZygorGuidesViewer:RegisterInclude("H_The_Cake_is_not_a_lie",[[ 
	description Bake a Delicious Chocolate Cake. 
	author support@zygorguides.com
	condition end achieved(877)
	step //1406
		'Complete Cooking dailies in Shattrath City:
		.collect Recipe: Delicious Chocolate Cake##33925 |n |tip You are not guaranteed to get this recipe - it is random, so try to have patience.
		.' Click the Recipe: Delicious Chocolate Cake |use Recipe: Delicious Chocolate Cake##33925
		.learn Delicious Chocolate Cake##43779
	step //1407
		goto Orgrimmar,54.9,78.2
		.talk Barkeep Morag##5611
		.buy 4 Ice Cold Milk##1179
	step //1408
		goto 56.4,61.3
		.talk Suja##46708
		.buy 8 Simple Flour##30817
		.buy 4 Mild Spices##2678
	step //1409
		fly Fizzle & Pozzik's Speedbarge
	step //1410
		goto 76.5,74.8
		.talk Daisy##40832
		.buy 1 Flask of Port##2593
	step //1411
		'From the Auction House:
		.buy 3 Mageroyal##785
		.buy 8 Small Egg##6889 |next "HaveEggs"
		.' Or...
		.' Click this line if you would rather farm the Small Eggs |script ZGV:GotoStep("farm")
	step //1412
		|fly Northern Rocketway Terminus
	step //1413
		goto Azshara,49.8,15.6
		.from Thunderhead Hippogryph##6375+
		.collect 8 Small Egg##6889
	step //1414
	label "HaveEggs"
		'Build a Basic Campfire |cast Basic Campfire##818
		.create Delicious Chocolate Cake##43779,Cooking,1 total |n
		.' Earn The Cake Is Not A Lie Achievement |achieve 877
	step //1415
		'Congratulations!  You've earned The Cake Is Not A Lie Achievement.
]])

ZygorGuidesViewer:RegisterInclude("H_Kickin'_It_Up_a_Notch",[[ 
	step //1416
		#include "darkportal"
	step //1417
		|fly Shattrath
	step //1418
	label "warning"
		.' The following quests are random and you can only do one per day. Click to proceed. |confirm always
	step //1419
	label "hub"
		goto Shattrath City,61.8,15.6
		.talk The Rokk##24393
		.' You will only be able to accept one of these daily quests per day
		..accept Soup for the Soul##11381 |daily |or
		..accept Super Hot Stew##11379 |daily |or
		..accept Manalicious##11380 |daily |or
		..accept Revenge is Tasty##11377 |daily |or
	step //1420
		|fly Garadar |q 11381
	step //1421
		goto Nagrand,58.0,35.6
		.talk Nula the Butcher##20097
		.buy Recipe: Roasted Clefthoof##27691 |n
		.' Click the Recipe: Roasted Clefthoof in your bags |use Recipe: Roasted Clefthoof##27691
		.learn Roasted Clefthoof##33287 |q 11381
	step //1422
		goto Nagrand,47.0,64.7
		.from Clefthoof##18205+, Clefthoof Calf##19183+
		.collect 4 Clefthoof Meat##27678 |q 11381
		.' You can find more Clefthooves at [45.5,72.7]
	step //1423
		.' Build a Basic Campfire |cast Basic Campfire##818
		.create Roasted Clefthoof##33287,Cooking,4 total |q 11381
	step //1424
		goto 25.9,59.5
		.' Use your Cooking Pot to Cook up some Spiritual Soup |use Cooking Pot##33851
		.' Cook a Spiritual Soup |q 11381/1
	step //1425
		|fly Thunderlord Stronghold |q 11379
	step //1426
		goto Blade's Edge Mountains,62.5,40.3
		.talk Xerintha Ravenoak##20916
		.buy Recipe: Mok'Nathal Shortribs##31675 |n
		.' Click the Recipe: Mok'Nathal Shortribs in your bags |use Recipe: Mok'Nathal Shortribs##31675
		.learn Mok'Nathal Shortribs##38867 |q 11379
		.buy Recipe: Crunchy Serpent##31674 |n
		.' Click the Recipe: Crunchy Serpent in your bags |use Recipe: Mok'Nathal Shortribs##31674
		.learn Crunchy Serpent##38868 |q 11379
	step //1427
		goto Blade's Edge Mountains,49.6,46.2
		.from Daggermaw Blackhide##22052+, Bladespire Raptor##20728+
		.collect 4 Raptor Ribs##31670+ |q 11379
	step //1428
		goto 68.2,63.2
		.from Scalewing Serpent##20749+, Felsworn Scalewing##21123+
		.collect 1 Serpent Flesh##31671 |q 11379
	step //1429
		.' Build a Basic Campfire |cast Basic Campfire##818
		.create 2 Mok'Nathal Shortribs##38867,Cooking,2 total |q 11379
	step //1430
		.' Build a Basic Campfire |cast Basic Campfire##818
		.create 1 Crunchy Serpent##38868,Cooking,1 total |q 11379
	step //1431
		goto 29.0,84.5
		.from Abyssal Flamebringer##19973+
		.' Use your Cooking Pot next to the Abyssal Flamebringer corpse to Cook up some Demon Broiled Surprise |use Cooking Pot##33852
		.get Demon Broiled Surprise |q 11379/1
	step //1432
		|fly Area 52 |q 11380
	step //1433
		goto Netherstorm,45.6,54.2
		.click Mana Berry Bush##28+
		.get 15 Mana Berry##33849+ |q 11380/1
	step //1434
		'Go outside to Terokkar Forest |goto Terokkar Forest |q 11377
	step //1435
		goto Terokkar Forest,48.8,45.0
		.talk Innkeeper Grilka##18957
		.buy Recipe: Warp Burger##27692 |n
		.' Click the Recipe: Warp Burger in your bags |use Recipe: Warp Burger##27692
		.learn Warp Burger##33288 |q 11377
	step //1436
		goto 64.0,83.5
		.from Blackwind Warp Chaser##23219+
		.collect 3 Warped Flesh##27681 |q 11377
	step //1437
		goto 67.6,74.7
		.from Monstrous Kaliri##23051+ |tip They fly around in the sky close to the tree outposts and bridges.
		.collect Giant Kaliri Wing##33838 |q 11377
	step //1438
		goto 25.9,59.5
		.' Build a Basic Campfire |cast Basic Campfire##818
		.create Warp Burger##33288,Cooking,3 total |q 11377
		.' Use your Cooking Pot to Cook up some Kaliri Stew |use Cooking Pot##33837
		.create Kaliri Stew##43718,Cooking,1 total |q 11377/1
	step //1439
		|fly Shattrath
	step //1440
		goto Shattrath City,61.8,15.6
		.talk The Rokk##24393
		..turnin Soup for the Soul##11381
		..turnin Super Hot Stew##11379
		..turnin Manalicious##11380 
		..turnin Revenge is Tasty##11377
	step //1441
		'You've completed all the dailies you can do today. Click to go back to the dailies hub. |confirm |next "-warning" |only if not step:Find("+check"):IsComplete()
		'Checking achievements |next |only if default

	step //1442
	label "check"
		.' Daily Completed "Revenge is Tasty" |achieve 906/1
		.' Daily Completed "Super Hot Stew" |achieve 906/2
		.' Daily Completed "Manalicious" |achieve 906/3
		.' Daily Completed "Soup for the Soul" |achieve 906/4
		.' Earn the Kickin' It Up a Notch Achievement |achieve 906
	step //1443
		'Congratulations!  You've earned "Kickin' It Up a Notch" Achievement.
]])

ZygorGuidesViewer:RegisterInclude("H_Our_Daily_Bread",[[
	step //1444
	title +Dalaran Cooking Dailies
		goto Dalaran,70.0,39.0
		.talk Awilo Long'gomba##29631
		.' You will only be able to accept, and turn in, 1 of these 5 daily quests per day, and they all require you have 350+ Cooking skill:
		..accept Cheese for Glowergold##13115 |or
		..accept Convention at the Legerdemain##13113 |or
		..accept Infused Mushroom Meatloaf##13112 |or
		..accept Mustard Dogs!##13116 |or
		..accept Sewer Stew##13114 |or
	step //1445
		goto 54.7,31.5
		.' Click the Aged Dalaran Limburger |tip They look like piles and pieces of yellow cheese on the tables inside this building.
		.collect 1 Aged Dalaran Limburger##43137 |q 13115
		.' Click the Half Full Glasses of Wine |tip They look like small blue-ish wine glasses sitting on tables, and on the ground, inside this building.  They spawn in random locations.
		.collect 6 Half Full Dalaran Wine Glass##43138 |q 13115
		.' You can find more Half Full Glasses of Wine inside the building at [49.4,39.3]
	step //1446
		'Use your Empty Cheese Serving Platter in your bags |use Empty Cheese Serving Platter##43139
		.get 1 Wine and Cheese Platter |q 13115/1
	step //1447
		goto 55.0,30.8
		.' Click a Full Jug of Wine |tip They look like small blue-ish green jugs sitting on the ground inside this building.  They spawn in random locations.
		.get 1 Jug of Wine |q 13113/2
	step //1448
		goto Dragonblight,30.0,49.8
		.from Rabid Grizzly##26643+, Blighted Elk##26616+
		.collect 10 Chilled Meat##43013 |q 13113
	step //1449
		'Create a basic campfire |cast Basic Campfire##818
		.create 4 Northern Stew##57421,Cooking,4 total
		.get 4 Northern Stew |q 13113/1
	step //1450
		'The entrance to the Dalaran sewers starts here |goto Dalaran,60.2,47.7,0.3 |c |q 13112
	step //1451
		goto 59.5,43.6
		.from Underbelly Rat##32428+
		.collect 4 Infused Mushroom##43100 |q 13112
	step //1452
		'Leave the Dalaran sewers |goto Dalaran,60.2,47.7,0.3|c|q 13112
	step //1453
		goto Dragonblight,30.0,49.8
		.from Rabid Grizzly##26643+, Blighted Elk##26616+
		.collect 2 Chilled Meat##43013 |q 13112
	step //1454
		'Create a basic campfire |cast Basic Campfire##818
		'Use your Meatloaf Pan in your bags |use Meatloaf Pan##43101 |tip You will need a cooking fire to do this.
		.get 1 Infused Mushroom Meatloaf |q 13112/1
	step //1455
		goto Dalaran,67.7,40.0
		.click the Wild Mustard##8340
		.collect 4 Wild Mustard##43143 |q 13116
		.' You can find more Wild Mustard flowers:
		..' at [50.3,48.3]
		..' at [37.2,43.9]
	step //1456
		goto Borean Tundra,46.7,43.6
		.from Wooly Rhino Calf##25488+, Wooly Rhino Matriarch##25487+, Wooly Rhino Bull##25489+
		.collect 4 Rhino Meat##43012 |q 13116
	step //1457
		'Create a basic campfire |cast Basic Campfire##818
		.create Rhino Dog##45553,Cooking,4 total |q 13116
		.collect 4 Rhino Dogs##34752 |q 13116
	step //1458
		'Use your Empty Picnic Basket in your bags|use Empty Picnic Basket##43142
		.get 1 Mustard Dog Basket! |q 13116/1
	step //1459
		goto Crystalsong Forest,26.7,44.1
		.click Crystalsong Carrot##4652+ 
		.collect 4 Crystalsong Carrot##43148 |q 13114
	step //1460
		'Create a basic campfire |cast Basic Campfire##818
		'Use your Stew Cookpot in your bags |use Stew Cookpot##43147
		.get 1 Vegetable Stew |q 13114/1
	step //1461
		goto Dalaran,36.6,27.8
		.talk Ranid Glowergold##28718
		..turnin Cheese for Glowergold##13115
		.' Completed Daily "Cheese for Glowergold" |achieve 1783/4
	step //1462
		goto Dalaran,48.6,37.5
		.talk Arille Azuregaze##29049
		..turnin Convention at the Legerdemain##13113 
		.' Completed Daily "Conventrion at the Legermain" |achieve 1783/2
	step //1463
		goto Dalaran,52.3,55.6
		.talk Orton Bennet##29527
		..turnin Infused Mushroom Meatloaf##13112
		.' Completed Daily "Infused Mushroom Meatloaf" |achieve 1783/1
	step //1464
		goto Dalaran,68.6,42.0
		.talk Archmage Pentarus##28160
		..turnin Mustard Dogs!##13116
		.' Completed Daily "Mustard Dogs!" |achieve 1783/5
	step //1465
		'The entrance to the Dalaran sewers starts here |goto Dalaran,60.2,47.7,0.3 |c |q 13114
	step //1466
		goto Dalaran,35.5,57.6
		.talk Ajay Green##29532
		..turnin Sewer Stew##13114
		.' Completed Daily "Sewer Stew" |achieve 1783/3
	step //1467
		'Congratulations! You've earned the Our Daily Bread achievement! |achieve 1783
]])

ZygorGuidesViewer:RegisterInclude("H_Captain_Rumsey's_Lager",[[
	step //1468
		'Use the Shattrath or Dalaran Cooking Dailies, or the Fishing Dailies of this guide to get this recipe: |tip It's not always guarenteed to come from these daily prizes so be patient
		.collect 1 Recipe: Captain Rumsey's Lager##34834
	step //1469
		.learn Captain Rumsey's Lager##45695 |use Recipe: Captain Rumsey's Lager##34834
	step //1470
		'Congratulation, you have earned the achievement Captain Rumsey's Lager! |achieve 1801
]])

ZygorGuidesViewer:RegisterInclude("H_Critter_Gitter",[[
	step //1471
		'You can either buy these from the Auction House or farm them
		.collect 10 Critter Bites##43004
		.' Click here to go farm for these |confirm |next "farm1"
		|next "gitter"
	step //1472
	label farm1
		'You can either buy these from the Auction House or farm them
		.collect 20 Chilled Meat##43013
		.collect 10 Northern Spices##43007
		.' Click here to go farm for these |confirm |next "farm2"
		|next "recipe"
	step //1473
	label farm2
		#include "rideto_borean"
	step //1474
	title +Chilled Meat
		goto Borean Tundra,78.2,24.0
		.from Scourged Mammoth##25452+
		.collect 20 Chilled Meat##43013
	step //1475
	title +Northern Spices
		'Use the Dalaran Cooking Dailies section of this guide to get Small Spice Bags
		.collect Spice Bag##44113 |n
		.collect 10 Northern Spices##43007
	step //1476
	label make
	title +Critter Gitter
		'Get someone to make your 10 Critter Bites |tip Ask in your guild or in trade for someone to make these. Be sure to tip well! 
		.' Or... |only if skill("Cooking")>=400
		'Build a Basic Campfire |cast Basic Campfire##818 |only if skill("Cooking")>=400
		.create Critter Bites##57435,Cooking,10 total |only if skill("Cooking")>=400
		.collect 10 Critter Bites##43004
		.' Click here if you don't have the recipe |script ZGV:GotoStep("recipe") |only if skill("Cooking")>=400
		|next "gitter"
	step //1477
	label recipe
		'Use the Dalaran Cooking Dailies section of this guide to earn 3 Dalaran Cooking Awards
		.earn 3 Dalaran Cooking Award##81 
	step //1478
		goto Dalaran,70.2,37.2
		.talk Misensi##31031
		.buy 1 Recipe: Critter Bites##43029
	step //1479
		.learn Critter Bites##57435
	step //1480
		'Build a Basic Campfire |cast Basic Campfire##818 
		.create Critter Bites##57435,Cooking,10 total 
		.collect 10 Critter Bites##43004
	step //1481
	label gitter
		#include "rideto_tirisfal"
	step //1482
		|fly Thondroril River
	step //1483
		goto Eastern Plaguelands,4.7,35.5
		'Target the Beetles, Scorpions, and Cockroaches and use the Critter Bites on them |use Critter Bites##43004
		|tip Use all 10 Critter Bites as quick as possible. These critters are scattered all throughout the tunnel.
		.' Coerce 10 critters to be your pet within 3 minutes or less |achieve 1781
	step //1484
		'Congratulations! You've earned the Critter Gitter achievement!
]])

ZygorGuidesViewer:RegisterInclude("H_Dinner_Impossible",[[
	step //1485
		'You can either buy these items from the auction house or use the Cooking professions guide to reach level 375 Cooking, otherwise you cannot complete this achievement. |only if skill("Cooking")<375
		'You can either buy these items from the auction house or farm them |only if skill("Cooking")>=375
		.collect 5 Great Feast##34753
		.' Click here to go farm these materials |script ZGV:GotoStep("farm1")
		|next usefeast
	step //1486
		#include trainCooking |only if skill("Cooking")>=375
		.learn Great Feast##45554 |only if skill("Cooking")>=375
	step //1487
	label farm1
		'You can either buy these items from the auction house or farm them 
		.collect 5 Chunk o'Mammoth##34736 
		.collect 5 Shoveltusk Flank##43009 
		.collect 5 Worm Meat##43010 
		.collect 10 Chilled Meat##43013 
		.' Click here to go farm these materials |script ZGV:GotoStep("farm2")
		|next makefeast
	step //1488
	label farm2
		#include "rideto_borean"
	step //1489
		goto 78.2,24.0
		.from Scourged Mammoth##25452+
		.collect 5 Chunk o'Mammoth##34736 
		.collect 10 Chilled Meat##43013 
	step //1490
		goto 76.2,23.0
		.from Tundra Crawler##25454+
		.collect 5 Worm Meat##43010 
	step //1491
		fly Vengeance Landing
	step //1492
		goto 73.6,40.0
		.from Shoveltusk##23690+
		.collect 5 Shoveltusk Flank##43009 
	step //1493
		#include hearth_hub
	step //1494
	label makefeast
		'Have someone make the Great Feasts for you |tip Ask in your guild or in trade for someone to make these |only if skill("Cooking")<375
		'Create a basic campfire |cast Basic Campfire##818 |only if skill("Cooking")>=375
		.create 5 Great Feast##45554,Cooking,4 total |only if skill("Cooking")>=375
		.collect 5 Great Feast##34753
	step //1495
	label usefeast
		'Push [H] on your keyboard to open your Player vs. Player interface 
		.' Click on Alterac Valley and then click on the Join Battle button on the lower left-hand corner of the Player vs. Player interface
		..' Wait for the que to pop-up in the middle of your screen and click on accept	
		..' Go to Alterac Valley |goto Alterac Valley |noway |c
	step //1496
		'Use one of your Great Feasts |use Great Feast##34753 
		.' Present a Great Feast in Alterac Valley |achieve 1784/1 |tip You can leave the battleground now, but you will have to wait 15 minutes to complete the next step
	step //1497
		'Push [H] on your keyboard to open your Player vs. Player interface 
		.' Click on Arathi Basin and then click on the Join Battle button on the lower left-hand corner of the Player vs. Player interface
		..' Wait for the que to pop-up in the middle of your screen and click on accept	
		..' Go to Arathi Basin |goto Arathi Basin |noway |c
	step //1498
		'Use one of your Great Feasts |use Great Feast##34753 
		.' Present a Great Feast in Arathi Basin |achieve 1784/2 |tip You can leave the battleground now, but you will have to wait 15 minutes to complete the next step
	step //1499
		'Push the [H] key on your keyboard to open your Player vs. Player interface 
		.' Click on Warsong Gulch and then click on the Join Battle button on the lower left-hand corner of the Player vs. Player interface
		..' Wait for the que to pop-up in the middle of your screen and click on accept	
		..' Go to Warsong Gulch |goto Warsong Gulch |noway |c
	step //1500
		'Use one of your Great Feasts |use Great Feast##34753 
		.' Present a Great Feast in Warsong Gulch |achieve 1784/3 |tip You can leave the battleground now, but you will have to wait 15 minutes to complete the next step
	step //1501
		'Push [H] on your keyboard to open your Player vs. Player interface 
		.' Click on Strand of the Ancients and then click on the Join Battle button on the lower left-hand corner of the Player vs. Player interface
		..' Wait for the que to pop-up in the middle of your screen and click on accept	
		..' Go to Strand of the Ancients |goto Strand of the Ancients |noway |c
	step //1502
		'Use one of your Great Feasts |use Great Feast##34753 
		.' Present a Great Feast in Strand of the Ancients |achieve 1784/4 |tip You can leave the battleground now, but you will have to wait 15 minutes to complete the next step
	step //1503
		'Push [H] on your keyboard to open your Player vs. Player interface 
		.' Click on Arathi Basin and then click on the Join Battle button on the lower left-hand corner of the Player vs. Player interface
		..' Wait for the que to pop-up in the middle of your screen and click on accept	
		..' Go to Eye of the Storm |goto Arathi Basin |noway |c
	step //1504
		'Use one of your Great Feasts |use Great Feast##34753 
		.' Present a Great Feast in Eye of the Storm |achieve 1784/5 
	step //1505
		Congratulations! You've earned the Dinner Impossible achievement!
]])


--------------------------------------------------------------------------------------------------------------------------------------
-- Professions Fishing
--------------------------------------------------------------------------------------------------------------------------------------

ZygorGuidesViewer:RegisterInclude("H_Old_Gnome_and_the_Sea",[[
	step //1506
		|fly Splintertree Post
	step //1507
		 goto Ashenvale,78.0,51.7
		.' Look for Sagefish Schools in the water.  Walk along the rivers until you find one if you're unable to see one at this spot.
		.' It looks like a swarm of fish.
		.' Use you fishing skill until your lure is inside of the school of fish, then catch one. |cast Fishing##7620
		.' Earn The Old Gnome and the Sea Achievement. |achieve 153
	step //1508
		'Congratulations! You've earned The Old Gnome and the Sea achievement!
]])
ZygorGuidesViewer:RegisterInclude("H_The_Scavenger",[[
	step //1509
		#include darkportal
	step //1510
		|fly Zabra'jin
	step //1511
		goto 57.0,56.0
		.' Look for Steam Pump Flotsam in the water around this area and fish from it |cast Fishing##7620
		.' Fish from Steam Pump Flotsam |achieve 1257/1
	step //1512
		#include "shatport_org"
	step //1513
		|fly Gadgetzan 
	step //1514
		goto 67.4,38.2
		.' Look for Floating Wreckage around this area |tip You may have to fish from other pools to get this to show up |cast Fishing##7620
		.' Fish from Floating Wreckage |achieve 1257/5
	step //1515
		|fly Camp Mojache
	step //1516
		goto Feralas,63.1,51.5 
		.' Look for Waterlogged Wreckage around this area |tip You may have to fish from other pools to get this to show up |cast Fishing##7620
		.' Fish from Waterlogged Wreckage |achieve 1257/4
	step //1517
		#include hearth_hub
	step //1518
		#include "rideto_stranglethorn"
	step //1519
		goto 55.0,64.0
		.' Look for Schooner Wreckage around this area |tip You may need to fish from other pools to get this to show up |cast Fishing##7620
		.' Fish from Schooner Wreckage |achieve 1257/3
	step //1520
		'Go to The Cape of Stranglethorn |goto The Cape of Stranglethorn |noway |c
	step //1521
		goto 30.9,81.5
		.' Look for Bloodsail Wreckage around this area |tip You may need to fish from other pools to get this to show up |cast Fishing##7620
		.' Fish from Bloodsail Wreckage |achieve 1257/2
	step //1522
		.' Successfully fish in each of the junk nodes |achieve 1257
	step //1523
		'Congratulations! You've earned The Scavenger achievement!
]])
ZygorGuidesViewer:RegisterInclude("H_The_Fishing_Diplomat",[[
	step //1524
		goto Orgrimmar,24.8,62.8
		.' Use your fishing skill in the pond |cast Fishing##7620
		.' Fish in Orgrimmar |achieve 150/1
	step //1525
		#include "rideto_stranglethorn"
	step //1526
		.' Go to Stormwind City |goto Stormwind City |noway |c
	step //1527
		goto 69.0,92.2
		.' Use your fishing skill in the moat in front of Stormwind City |cast Fishing##7620
		.' Fish in Stormwind City |achieve 150/2
	step //1528
		.' Earn The Fishing Diplomat. |achieve 150
	step //1529
		'Congratulations! You've earned The Fishing Diplomat achievement!
]])
ZygorGuidesViewer:RegisterInclude("H_Mr._Pinchy's_Magical_Crawdad_Box",[[
	step //1530
		.' You can track fishing in horder to help you find Highland Mixed Schools.
		.learn Find Fish##43308  |next "HaveFishTracking"
		|confirm
		.' or
		.' Click here if you are already in Oultand |confirm |next "outland"
	step //1531
		#include darkportal
	step //1532
	label	"outland"
		|fly Stonebreaker Hold
	step //1533
		.' Go east to Terokkar Forest |goto Terokkar Forest
	step //1534
		goto Terokkar Forest,65.0,76.8
		.' Use your Find Fish ability to locate Highland Mixed Schools
		|confirm

	step //1535
		goto Terokkar Forest,66.5,84.3
		.' Here [Terokkar Forest,66.5,84.3]
		.' Here [Terokkar Forest,65.9,73.1]
		.' Here [Terokkar Forest,60.6,59.9]
		.' Here [Terokkar Forest,45.0,40.5]
		.' Use your fishing skill to fish in the pond |cast Fishing##7620
		.collect 1 Magical Crawdad Box##27445 |n
		'|modeldisplay 3215
		.learnpet Magical Crawdad##18839 |use Magical Crawdad Box##27445
]])
ZygorGuidesViewer:RegisterInclude("H_Fishing_25_Fish",[[
	step //1536
		goto Orgrimmar,66.6,41.6
		.talk Shankys##3333
		.buy 1 Fishing Pole##6256
		.buy 10 Shiny Bauble##6529
	step //1537
		.' Equip your Fishing Pole |use Fishing Pole##6256
		.' Use the Shiny Bauble to temporarily increase your Fishing skill, to make it easier to catch fish |use Shiny Bauble##6529 |tip If your Shiny Bauble Fishing skill boost expires, you can buy more Shiny Baubles to help you fish.
		.' Stand on the end of this wooden dock
		.' Use your Fishing skill to fish in the water all around the wooden dock |cast Fishing##7620
		.' Catch 25 Fish. |achieve 1556
	step //1538
		'Congratulations! You've earned the 25 Fish achievement!
]])
ZygorGuidesViewer:RegisterInclude("H_Fishing_50_Fish",[[
	step //1539
		goto Orgrimmar,66.6,41.6
		.talk Shankys##3333
		.buy 1 Fishing Pole##6256
		.buy 10 Shiny Bauble##6529
	step //1540
		.' Equip your Fishing Pole |use Fishing Pole##6256
		.' Use the Shiny Bauble to temporarily increase your Fishing skill, to make it easier to catch fish |use Shiny Bauble##6529 |tip If your Shiny Bauble Fishing skill boost expires, you can buy more Shiny Baubles to help you fish.
		.' Stand on the end of this wooden dock
		.' Use your Fishing skill to fish in the water all around the wooden dock |cast Fishing##7620
		.' Catch 50 Fish. |achieve 1557
	step //1541
		'Congratulations! You've earned the 50 Fish achievement!
]])
ZygorGuidesViewer:RegisterInclude("H_Fishing_100_Fish",[[
	step //1542
		goto Orgrimmar,66.6,41.6
		.talk Shankys##3333
		.buy 1 Fishing Pole##6256
		.buy 10 Shiny Bauble##6529
	step //1543
		.' Equip your Fishing Pole |use Fishing Pole##6256
		.' Use the Shiny Bauble to temporarily increase your Fishing skill, to make it easier to catch fish |use Shiny Bauble##6529 |tip If your Shiny Bauble Fishing skill boost expires, you can buy more Shiny Baubles to help you fish.
		.' Stand on the end of this wooden dock
		.' Use your Fishing skill to fish in the water all around the wooden dock |cast Fishing##7620
		.' Catch 100 Fish. |achieve 1558
	step //1544
		'Congratulations! You've earned the 100 Fish achievement!
]])
ZygorGuidesViewer:RegisterInclude("H_Fishing_250_Fish",[[
	step //1545
		goto Orgrimmar,66.6,41.6
		.talk Shankys##3333
		.buy 1 Fishing Pole##6256
		.buy 10 Shiny Bauble##6529
	step //1546
		.' Equip your Fishing Pole |use Fishing Pole##6256
		.' Use the Shiny Bauble to temporarily increase your Fishing skill, to make it easier to catch fish |use Shiny Bauble##6529 |tip If your Shiny Bauble Fishing skill boost expires, you can buy more Shiny Baubles to help you fish.
		.' Stand on the end of this wooden dock
		.' Use your Fishing skill to fish in the water all around the wooden dock |cast Fishing##7620
		.' Catch 250 Fish. |achieve 1559
	step //1547
		'Congratulations! You've earned the 250 Fish achievement!
]])
ZygorGuidesViewer:RegisterInclude("H_Fishing_500_Fish",[[
	step //1548
		goto Orgrimmar,66.6,41.6
		.talk Shankys##3333
		.buy 1 Fishing Pole##6256
		.buy 10 Shiny Bauble##6529
	step //1549
		.' Equip your Fishing Pole |use Fishing Pole##6256
		.' Use the Shiny Bauble to temporarily increase your Fishing skill, to make it easier to catch fish |use Shiny Bauble##6529 |tip If your Shiny Bauble Fishing skill boost expires, you can buy more Shiny Baubles to help you fish.
		.' Stand on the end of this wooden dock
		.' Use your Fishing skill to fish in the water all around the wooden dock |cast Fishing##7620
		.' Catch 500 Fish. |achieve 1560
	step //1550
		'Congratulations! You've earned the 500 Fish achievement!
]])
ZygorGuidesViewer:RegisterInclude("H_Fishing_1000_Fish",[[
	step //1551
		goto Orgrimmar,66.6,41.6
		.talk Shankys##3333
		.buy 1 Fishing Pole##6256
		.buy 10 Shiny Bauble##6529
	step //1552
		.' Equip your Fishing Pole |use Fishing Pole##6256
		.' Use the Shiny Bauble to temporarily increase your Fishing skill, to make it easier to catch fish |use Shiny Bauble##6529 |tip If your Shiny Bauble Fishing skill boost expires, you can buy more Shiny Baubles to help you fish.
		.' Stand on the end of this wooden dock
		.' Use your Fishing skill to fish in the water all around the wooden dock |cast Fishing##7620
		.' Catch 1000 Fish. |achieve 1561
	step //1553
		'Congratulations! You've earned the 1000 Fish achievement!
]])
ZygorGuidesViewer:RegisterInclude("H_Fishing_1-1000_Fish",[[
	step //1554
		goto Orgrimmar,66.6,41.6
		.talk Shankys##3333
		.buy 1 Fishing Pole##6256
		.buy 10 Shiny Bauble##6529
	step //1555
		.' Equip your Fishing Pole |use Fishing Pole##6256
		.' Use the Shiny Bauble to temporarily increase your Fishing skill, to make it easier to catch fish |use Shiny Bauble##6529 |tip If your Shiny Bauble Fishing skill boost expires, you can buy more Shiny Baubles to help you fish.
		.' Stand on the end of this wooden dock
		.' Use your Fishing skill to fish in the water all around the wooden dock |cast Fishing##7620
		.' Catch 25 Fish. |achieve 1556
		.' Catch 50 Fish. |achieve 1557
		.' Catch 100 Fish. |achieve 1558
		.' Catch 250 Fish. |achieve 1559
		.' Catch 500 Fish. |achieve 1560
		.' Catch 1000 Fish. |achieve 1561
	step //1556
		'Congratulations! You've earned the 1000 Fish achievement!
]])
ZygorGuidesViewer:RegisterInclude("H_Old_Crafty_and_Ironjaw",[[
	step //1557
		.' In order to Earn this achievement, you will need to fish from any pool of water in Orgrimmar.
		.' The higher level your fishing skill, the better.  You will catch less junk the higher you are, which gives you a higher chance to catch Old Crafty.
		.' Click here when you're ready to proceed to the next step in the guide |confirm
	step //1558
		goto Orgrimmar,59.3,39.9
		.' Use your fishing ability in the stream of water. |cast Fishing##7620
		.collect Old Crafty##34486
	step //1559
		.' Earn the Old Crafty Achievement. |achieve 1836
	step //1560
		.' In order to Earn this achievement, you will need to fish from any pool of water (or lava) in Ironforge.
		.' The higher level your fishing skill, the better. You will catch less junk the higher you are, which gives you a higher chance to catch Old Ironjaw.
		.' Click here when you're ready to proceed to the next step in the guide |confirm
	step //1561
		#include portal_twilight
	step //1562
		'Go to Ironforge |goto Ironforge |noway |c 
	step //1563
		goto Ironforge,47.6,14.2
		.' Use your fishing ability in the pond. |cast Fishing##7620
		.collect Old Ironjaw##34484
	step //1564
		.' Earn the Old Ironjaw Achievement. |achieve 1837
	step //1565
		'Congratulations! You've earned the Old Ironjaw achievement!
		'Congratulations! You've earned the Old Crafty achievement!
]])
ZygorGuidesViewer:RegisterInclude("H_The_Lurker_Above",[[
	step //1566
		.' In order to earn the _Lurker Above_ achievement, you will need to be in a raid group.
		.' You will also need to be at least Level 70.
		.' It would be best if you picked up Elixirs of Water Walking 
		.' You won't need a certain level of fishing, but the high level you are, the higher change you have of fishing up 'The Lurker Below'.
		.' Click here after you have read the requirements for this achievement. |confirm
		.' or 
		.' Click here if you are in Outland already |confirm |next "outland"
	step //1567
		#include darkportal
	step //1568
	label	"outland"
		|fly Zabra'jin
	step //1569
		goto Zangarmarsh,50.4,41.0 |n
		.' Swim down underwater through the tube to the Coilfang Reservoir |goto 51.9,38.0 |c
	step //1570
		.' Go North into Serpent Shrine Cavern |goto Serpentshrine Cavern
	step //1571
		 goto Serpentshrine Cavern,13.5,59.6
		 .' Ride the elevator down
		.' Click here once you're at the bottom and off of the elevator |confirm
	step //1572
		goto Serpentshrine Cavern,19.6,68.5
		.' Walk up the ramp and ride the elevator up.
		.' Click here once you ride the elevator up. |confirm
	step //1573
		goto Serpentshrine Cavern,22.7,72.8 |n
		.' Use your water walking potion and jump into the water. |use Elixir of Water Walking##8827
		.' If you jump into the water without water walking, fish will attack you and you will have to kill them before using your Elixir.
		.' Walk over to the wooden circle with the Strange pool in the center |goto Serpentshrine Cavern,38.6,59.5 |c
	step //1574
		.' Once you're there, use your fishing ability and make sure that your lure lands in the Strange Pool. |cast Fishing##7620
		.' Earn The Lurker Above Achievement. |achieve 144
	step //1575
		'Congratulations! You've earned The Lurker Above achievement!
]])
ZygorGuidesViewer:RegisterInclude("H_Old_Man_Barlowned",[[
	step //1576
		.' In order the earn this achievement, you will need to have completed these 5 daily quests:
		.' Crcolisks in the City |achieve 905/1
		.' Bait Bandits |achieve 905/2
		.' Felblood Fillet |achieve 905/3
		.' The One That Got Away |achieve 905/4
		.' Shrimpin' Ain't Easy |achieve 905/5
		.' Click here to proceed |confirm
	step //1577
		goto Terokkar Forest,38.7,12.8
		.talk Old Man Barlo##25580
		.' You will only be able to pick up 1 of 5 dailies per day.
		.accept Crocolisks in the City##11665 |or |daily
		.accept Bait Bandits##11666 |or |daily
		.accept Felblood Fillet##11669 |or |daily
		.accept The One That Got Away##11667 |or |daily
		.accept Shrimpin' Ain't Easy##11668 |or |daily
	step //1578
		.' Go West to Shattrath City |goto Shattrath City
		only if havequest(11665)
	step //1579
		goto Shattrath City,57.2,48.2
		.' Click the Shattrath Portal to Stormwind |goto Stormwind City
		only if havequest(11665)
	step //1580
		goto Stormwind City,54.9,69.7
		.' Use your Fishing skill to fish in the water all around the wooden dock |cast Fishing##7620
		..get Baby Crocolisk##34864 |q 11665/1
		only if havequest(11665)
	step //1581
		goto Stormwind City,49.0,87.4 |n
		.' Click the Swirling Portal to Blasted Lands |goto Blasted Lands
		only if havequest(11665)
	step //1582
		goto Blasted Lands,55.0,53.9
		.' Go through the Dark Portal |goto Hellfire Peninsula |noway|c
		only if havequest(11665)
	step //1583
		|fly Shattrath
		only if havequest(11665)
	step //1584
		.' Go Northeast to Terokkar Forest |goto Terokkar Forest |noway|c
		only if havequest(11665)
	step //1585
		goto Terokkar Forest,51.8,37.2
		.' Fish in the river here |cast Fishing##7620
		..get Blackfin Darter##34865 |q 11666/1
		only if havequest(11666)
	step //1586
		|fly Zabra'jin
		only if havequest(11667)
	step //1587
		goto Nagrand,37.4,47.1
		.' Use your fishing ability to fish in the lake. |cast Fishing##7620
		..get World's Largest Mudfish##34868 |q 11667/1
		only if havequest(11667)
	step //1588
		.' Go North to Zangarmarsh |goto Zangarmarsh
		only if havequest(11668)
	step //1589
		goto Zangarmarsh,77.9,79.7
		.' Fish from the Lake here |cast Fishing##7620
		.'Click the Bloated Barbed Gill Trout in your bags|use Bloated Barbed Gill Trout##35313
		..get Giant Freshwater Shrimp##34866 |q 11668/1
		only if havequest(11668)
	step //1590
		goto Shadowmoon Valley,29.9,38.8
		.' Use your fishing ability in the green lava. |cast Fishing##7620
		..get Monstrous Felblood Snapper |q 11669/1
		only if havequest(11669)
	step //1591
		goto Terokkar Forest,38.7,12.8
		.talk Old Man Barlo##25580
		.' You will only be able to pick up 1 of 5 dailies per day.
		.turnin Crocolisks in the City##11665 |or |daily
		.turnin Bait Bandits##11666 |or |daily
		.turnin Felblood Fillet##11669 |or |daily
		.turnin The One That Got Away##11667 |or |daily
		.turnin Shrimpin' Ain't Easy##11668 |or |daily	
	step //1592
		.' Crcolisks in the City |achieve 905/1
		.' Bait Bandits |achieve 905/2
		.' Felblood Fillet |achieve 905/3
		.' The One That Got Away |achieve 905/4
		.' Shrimpin' Ain't Easy |achieve 905/5
	step //1593
		.' Earn the Old Man Barlowned Achievement. |achieve 905
	step //1594
		'Congratulations! You've earned the Old Man Barlowned achievement!
]])
ZygorGuidesViewer:RegisterInclude("H_Outland_Angler",[[
	step //1595
		.' In order to earn the Outland Angler achievement, you will need to fish from 6 different pools of fish in the Outlands.
		|confirm
	step //1596
		#include darkportal
	step //1597
		|fly Swamprat Post
	step //1598
		goto Zangarmarsh,72.5,59.9
		.' Use your fishing skill on Sporefish School's around Umberfen Lake |cast Fishing##7620
		.' Fish from a Sporefish School |achieve 1225/6
	step //1599
		|fly Stonebreaker Hold
	step //1600
		goto Terokkar Forest,60.8,59.0 |n
		.' You will need to fly to reach the Highland Mixed Schools.  There are two more spots you can check for them below:
		.' The large Skettis Lake |goto 66.4,80.0 |n
		.' Lake Jorune |goto 45.9,39.5 |n
		.' Fish from a Highland Mixed School |achieve 1225/5
	step //1601
		map Terokkar Forest
		path follow loose;loop off;ants straight // this stays until the end of the guide.
		path	 60.5,51.9	62.9,48.1	63.6,45.0
		path	 60.0,36.5
		.' Follow the stream until you find a School of Darters or Brackish Mixed School in the river.
		.' Use your fishing skill to fish from either Brackish Mixed or School of Darters
		.' Fish from a School of Darters |achieve 1225/4
		.' Fish from a Brackish Mixed School |achieve 1225/1
	step //1602
		|fly Garadar
	step //1603
		map Nagrand
		path follow loose;loop off;ants straight // this stays until the end of the guide.
		path	 47.2,44.4	48.7,45.3	51.1,43.2
		path	 50.9,47.6	48.8,48.1	47.4,48.6
		path	 46.5,47.6
		.' Follow the stream until you find a Bluefish and a Mudfish School.
		.' Use your fishing skill to fish from either Bluefish and a Mudfish School |cast Fishing##7620
		.' Fish from a Bluefish School |achieve 1225/2
		.' Fish from a Mudfish School |achieve 1225/3
	step //1604
		.' Earn the Outland Angler Achievement. |achieve 1225
	step //1605
		'Congratulations! You've earned the Outland Angler achievement!
]])
ZygorGuidesViewer:RegisterInclude("H_Northrend_Angler_Angler",[[
	step //1606
		.' In order to earn this achievement, you will have to fish from 10 different schools of fish in Northrend.
		.' Click here to proceed. |confirm
	step //1607
		.' Borean Man O'War School |achieve 1517/1
		.' Dragonfin Angelfish School |achieve 1517/2
		.' Glacial Salmon School |achieve 1517/3
		.' Imperial Manta Ray School |achieve 1517/4
		.' Musselback Sculpin School |achieve 1517/5
		.' Deep Sea Monsterbelly School |achieve 1517/6
		.' Fangtooth Herring School |achieve 1517/7
		.' Glassfin Minnow School |achieve 1517/8
		.' Moonglow Cuttlefish School |achieve 1517/9
		.' Neettlefish School |achieve 1517/10
		.' Click here to proceed. |confirm
	step //1608
		#include "rideto_borean"
	step //1609
		map Borean Tundra
		path follow loose;loop off;ants straight // this stays until the end of the guide.
		path	54.3,75.2	49.5,79.0	45.8,80.9
		path	43.4,78.5	40.3,77.0
		.' Follow the coast until you find and Imperial Manta Ray and a Borean Man O' War School.  You mayb need to fish out other schools in order to force new ones to spawn.
		.' Fish from an Imperial Manta Ray School |achieve 1517/4 |cast Fishing##7620
		.' Fish from a Borean Man O' War School |achieve 1517/1 |cast Fishing##7620
	step //1610
		goto Borean Tundra,51.2,42.4
		.' You will be able to find Musselback Sculpin Schools around Lake Kum'uya.
		.' Fish from a Musselback Scuplin School |achieve 1517/5
	step //1611
		goto Borean Tundra,82.7,59.5
		.' Around the Glacier, you will find Schools of Moonglow Cuttlefish and Deep Sea Monsterbelly.
		.' Fish from a Deep Sea Monsterbelly School |achieve 1517/6 |cast Fishing##7620
		.' Fish from a Moonglow Cuttlefish School |achieve 1517/9 |cast Fishing##7620
	step //1612
		|fly River's Heart
	step //1613
		goto Sholazar Basin,46.8,64.7
		.' All around River's Heart, you will find schools of Nettlefish.
		.' Fish from a Nettlefish School |achieve 1517/10 |cast Fishing##7620
	step //1614
		|fly Moa'ki Harbor
	step //1615
		goto Dragonblight,42.3,67.8
		.' You can find Dragonfin Angelfish School all along Lake Indu'le.
		.' Fish from a Dragonfin Angelfish School |achieve 1517/2 |cast Fishing##7620
	step //1616
		|fly Sunreaver's Command
	step //1617
		goto Crystalsong Forest,49.0,54.1
		.' Along the Twilight Rivulet you will find schools of Glassfin Minnow.
		.' Fish from a Glassfin Minnow School |achieve 1517/8 |cast Fishing##7620
	step //1618
		|fly Conquest Hold
	step //1619
		map Grizzly Hills
		path follow loose;loop off;ants straight // this stays until the end of the guide.
		path	26.4,64.9	28.6,60.8	29.5,55.8
		.' You can find Schools of Glacial Salmon along this river.
		.' Fish from a Glacial Salmon School |achieve 1517/3 |cast Fishing##7620
	step //1620
		map Howling Fjord
		path follow loose;loop off;ants straight // this stays until the end of the guide.
		path	59.5,58.8	60.8,60.3	60.6,64.5
		.' You can find Fangtooth Herring Schools along Daggercap Bay.
		.' Fish from a Fangtooth Herring School |achieve 1517/7 |cast Fishing##7620
	step //1621
		.' Earn the Northrend Angler Achievement. |achieve 1517 |cast Fishing##7620
	step //1622
		'Congratulations! You've earned the Northrend Angler achievement!
]])
ZygorGuidesViewer:RegisterInclude("Turtles_All_the_Way_Down",[[
	step //1623
		.' In order to earn this achievement, you will need to fish from any school of fish within a Northrend or Cataclysm Zone.
		.' Click here to proceed. |confirm
	step //1624
		#include rideto_borean
	step //1625
		|fly Sunreaver's Command
	step //1626
		goto Crystalsong Forest,48.7,54.0
		.' Fish from school of fish along the river here. |cast Fishing##7620
		.' You will only be able to catch the sea turtle from fish schools.
		.collect Sea Turtle##46109
		.' Use the Sea Turtle. |use Sea Turtle##46109
		.' Earn the Turtles All the Way Down achievement. |achieve 3218
	step //1627
		.' Congratulations, you have earned the Turtles All the Way Down achievement.
]])
ZygorGuidesViewer:RegisterInclude("H_Chasing_Marcia",[[
	step //1628
		.' In order to earn this Achievement, you will have to complete 5 daily quests.
		.' You will only be able to accept one per day, so this may take longer than 5 days to achieve.
		.' Click here to proceed |confirm
	step //1629
		'Below is a list of the 5 daily quests you will need to complete.
		.' The Ghostfish |achieve 3217/1
		.' Jewel Of The Sewers |achieve 3217/2
		.' Dangerously Delicious |achieve 3217/3
		.' Blood is Thicker |achieve 3217/4
		.' Disarmed! |achieve 3217/5
		.' Click to proceed |confirm
	step //1630
		goto Dalaran,53.1,64.9
		.talk Marcia Chase##28742
		.' You will only be able to accept, and turn in, 1 of these 5 daily quests per day:
		..accept Blood Is Thicker##13833 |daily |or
		..accept Dangerously Delicious##13834 |daily |or
		..accept Jewel Of The Sewers##13832 |daily |or
		..accept Disarmed!##13836 |daily |or
		..accept The Ghostfish##13830 |daily |or
	step //1631
		goto Borean Tundra,54.6,41.8
		.from Wooly Mammoth##24614, Mammoth Calf##24613, Wooly Mammoth Bull##25743
		.' Get the Animal Blood buff|havebuff Ability_Seal|q 13833
		only if havequest (13833)
	step //1632
		goto 53.7,42.9
		.' Walk into the water here to create a pool of blood
		.' Fish in the pool of blood
		.get 5 Bloodtooth Frenzy |q 13833/1
		only if havequest (13833)
	step //1633
		goto Wintergrasp,79.9,41.8
		.' Fish in this big lake
		.get 10 Terrorfish |q 13834/1
		only if havequest (13834)
	step //1634
		'The entrance to the Dalaran sewers starts here|goto Dalaran,60.2,47.7,0.3|c|q 13832
		only if havequest (13832)
	step //1635
		goto 44.4,66.2
		.' Fish in the water in the Dalaran sewers
		.get 1 Corroded Jewelry |q 13832/1
		only if havequest (13832)
	step //1636
		'Leave the Dalaran sewers|goto Dalaran,60.2,47.7,0.3|c|q 13832
		only if havequest (13832)
	step //1637
		goto Dalaran,64.8,60.8
		.' Stand on the this circular platform and fish in the water here
		.collect Bloated Slippery Eel##45328|n
		.' Click the Bloated Slippery Eel in your bags|use Bloated Slippery Eel##45328
		.get 1 Severed Arm |q 13836/1
		only if havequest (13836)
	step //1638
		goto Sholazar Basin,49.3,61.8
		.' Fish in the water here
		.collect 1 Phantom Ghostfish##45902|n
		.' Click the Phantom Ghostfish in your bags to eat it|use Phantom Ghostfish##45902
		.' Discover the Ghostfish mystery |q 13830/1
		only if havequest (13830)
	step //1639
		goto Dalaran,53.1,64.9
		.talk Marcia Chase##28742
		.' You will only be able to accept, and turn in, 1 of these 5 daily quests per day:
		..turnin Blood Is Thicker##13833
		..turnin Dangerously Delicious##13834
		..turnin Jewel Of The Sewers##13832
		..turnin The Ghostfish##13830
	step //1640
		goto Dalaran,36.6,37.3
		.talk Olisarra the Kind##28706
		..turnin Disarmed!##13836
	step //1641
		.' Earn the Chasing Marcia Achievement. |achieve 3217
	step //1642
		'Congratulations! You've earned the Chasing Marcia achievement!
]])
ZygorGuidesViewer:RegisterInclude("H_Fish_Don't_Leave_Footprints",[[
	step //1643
		#include "rideto_stranglethorn"
	step //1644
		goto Northern Stranglethorn,31.0,37.7
		.' Use your fishing skill fish from Schooner Wreckage along The Savage Coast.  You may need to fish out the other schools of fish to get them to spawn. |cast Fishing##7620
		.collect Weather-Beaten Journal##34109
		.' Use the Weather-Beaten Journal. |use Weather-Beaten Jounral##34109
		.' Earn the Fish Don't Leave Footprints achievement. |achieve 1243
	step //1645
		.' Congratulations, you have earned the Fish Don't Leave Footprints achievement!
]])
ZygorGuidesViewer:RegisterInclude("H_The_Coin_Master",[[
	step //1646
		.' This guide will help you earn the achievements A Penny For Your Thoughts, Silver in the City, There's Gold In That There Fountain, and finally, The Coin Master.
		.' Click here to proceed. |confirm
	step //1647
		.' Here is your current progression on The Coin Master.
		.' A Penny For Your Thoughts. |achieve 2096/1
		.' Silver in the City. |achieve 2096/2
		.' There's a Gold In That There Fountain. |achieve 2096/3
		.' Click here to proceed. |confirm
	step //1648
		#include "rideto_borean"
	step //1649
		|fly Dalaran
	step //1650
		goto Dalaran,52.6,66.5
		.' This fountain is where you will be fishing from to earn these achievements. Use your fishing skills to fish up Copper, Silver and Gold Coins. |cast Fishing##7620
		.' Earn the A Penny For Your Thoughts achievement. |achieve 2096/1
		.' Earn the Silver in the City achievement. |achieve 2096/2
		.' Earn the There's Gold In That There Fountain achievement. |achieve 2096/3
		.' This achievement takes a lot of time, so try to be patient.
	step //1651
		.' Earn the A Penny For Your Thoughts Achiement. |achieve 2094
		.' Earn the Silver in the City achievement. |achieve 2095
		.' Earn the There's Gold In That There Fountain achievement. |achieve 1957
		.' Earn The Coin Master achievement. |achieve 2096
	step //1652
		.' Congratulation, you have earned The Coin Master achievement!
]])
ZygorGuidesViewer:RegisterInclude("H_Master_Angler_of_Azeroth",[[
	step //1653
		'To earn this Achievement, you need to go to Booty Bay, accept this quest and be the first to complete it.
		.' You can start this quest every _Sunday_ from _2pm to 4pm SERVER TIME_. 
		|confirm
	step //1654
		goto Orgrimmar,66.6,41.6
		.talk Shankys##3333
		.buy 1 Fishing Pole##6256
		.buy 10 Shiny Bauble##6529
		.' Or
		|confirm
	step //1655
		#include "rideto_bootybay"
	step //1656
		goto The Cape of Stranglethorn,41.7,73.0
		.talk Riggle Bassbait##15077
		..accept Master Angler##8193
	step //1657
		goto The Cape of Stranglethorn,39.1,57.9
		.' Make sure you have you're fishing pole equipped and fish in these area's for Tasty Fish |use Fishing Pole##6256
		.' Attach your Shiny Bauble to your fishing pole to increase your fishing skill slightly |use Shiny Bauble##6529
		.get 40 Speckled Tastyfish##19807 |q 8193
		.' You can find more schools of fish here: [37.9,55.6]
		.' Here [36.3,53.8]
		.' Here [36.1,50.9]
		.' And here [36.2,47.7]
	step //1658
		goto The Cape of Stranglethorn,41.7,73.0
		.talk Riggle Bassbait##15077
		..turnin Master Angler##8193
		.' Be the first to turn in this quest to earn achievement
		.' Earn Master Angler Achievement |achieve 306
]])
ZygorGuidesViewer:RegisterInclude("H_Master_Angler_of_Northrend",[[
	step //1659
		'To earn this Achievement, you need to go to Northrend, catch a _Blacktip Shark_ and be the first to turn it in.
		.' You can start fishing every _Saturday_ at _2pm SERVER TIME_, you will hear the NPC yell out that the 
		.' contest has started, make sure you are next to a school of fish, and start fishing!
		|confirm
	step //1660
		goto Orgrimmar,66.6,41.6
		.talk Shankys##3333
		.buy 1 Fishing Pole##6256
		.buy 10 Shiny Bauble##6529
		.' Or
		|confirm
	step //1661
		#include "rideto_borean"
	step //1662
		|fly Dalaran
	step //1663
		goto Dalaran,65.7,32.2
		.talk Uda the Beast##31557
		.home
	step //1664
		goto Dalaran,52.4,65.2
		.talk Elder Clearwater##38294
		.turnin Kalu'ak Fishing Derby##24803
	step //1665
		goto Dalaran,56.0,46.8
		.click Teleport to Violet Stand Crystal##8070
		.' Teleport to the Violet Stand |goto Crystalsong Forest |noway |c
	step //1666
		map Crystalsong Forest
		path follow loose;loop off;ants straight
		path	22.5,35.4
		path	25.2,43.4	29.6,45.2	34.0,47.9
		path	38.7,54.4	44.8,56.7	50.3,56.4
		.' Follow this path and turn your _Track Fishing_ on.
		.' Fish up a _Blacktip Shark_ from any school of fish.|use Fishing Pole##6256
		.' Attach your Shiny Bauble to your fishing pole to increase your fishing skill slightly |use Shiny Bauble##6529
		.collect Blacktip Shark##50289
	step //1667
		.' Hearth to Dalaran |goto Dalaran |use Hearthstone##6948 |noway |c 
		.' Or
		goto Crystalsong Forest,15.7,42.4
		.click Teleport to Dalaran Crystal##8070
		.' Teleport to Dalaran |goto Dalaran |noway |c 
	step //1668
		goto Dalaran,52.4,65.2
		.talk Elder Clearwater##38294
		.turnin Kalu'ak Fishing Derby##24803
		.' If you are the first to turn in this quest you will get an achievement
		.' Earn the Achievement Master Angler of Azeroth |achieve 306
]])

---------------------------------------------------------------------------------------
--Dailies
---------------------------------------------------------------------------------------
-- Outland

ZygorGuidesViewer:RegisterInclude("H_SSO_PreQuest_with_Dailies", [[
	step //1669
		|fly Shattrath
	step //1670
		goto Shattrath City,49.1,42.5
		.talk Exarch Nasuun##24932
		..accept Maintaining the Sunwell Portal##11514 |daily
	step //1671
		goto 62.8,36.0
		.talk Lord Torvos##25140
		..accept Sunfury Attack Plans##11877 |daily
	step //1672
		goto 62.8,35.6
		.talk Emissary Mordin##19202
		..accept Gaining the Advantage##11875 |daily
		only if skill("Skinning")>300 or skill("Mining")>300 or skill("Herbalism")>300
	step //1673
		goto Shattrath City,61.7,52.1
		.talk Harbinger Haronem##19475
		..accept The Multiphase Survey##11880 |daily
	step //1674
		|fly Garadar
	step //1675
		goto Nagrand,50.3,40.4
		.from Clefthoof Bull##17132+,Talbuk Thorngrazer##17131+,Wild Elekk##18334+
		.' Skin their corpses in order to collect the Nether Residue.
		.get 8 Nether Residue##35229 |q 11875/1
		only if skill("Skinning")>=300
	step //1676
		goto 40.8,31.6
		.' Mine inside the cave and collect Nether Residue.
		.collect 8 Nether Residue##35229 |q 11875/1
		.' You can check [Nagrand,50.0,56.6] for more Mining Nodes.
		only if skill("Mining")>=300
	step //1677
		goto Nagrand,38.3,65.3
		.' Fly around the Spirit Fields looking for Fiery Red Orbs on the ground.
		.' Use your Multiphase Spectrographic Goggles on the Orbs. |use Multiphase Spectrographic Goggles##35233
		.' 6 Multiphase Readings Taken |q 11880/1
	step //1678
		|fly Evergrove
	step //1679
		goto Blade's Edge Mountains,54.0,18.1
		.from Unbound Ethereal##22244+,Bash'ir Raider##22241+,Bash'ir Arcanist##22243+,Bash'ir Spell-Thief##22242+
		.get 1 Bash'ir Phasing Device |q 11514
		'Use the Bash'ir Phasing Device. |use Bash'ir Phasing Device##34248
		.' Collect 10 Smuggled Mana Cell |q 11514/1
	step //1680
		|fly Area 52
	step //1681
		goto Netherstorm,25.9,66.8
		.from Sunfury Bloodwarder##18853+,Sunfury Captain##19453+,Sunfury Magister##18855+,Sunfury Geologist##19779+,Sunfury Astromancer##19643
		.get Sunfury Attack Plans |q 11877/1
	step //1682
		|fly Shattrath
	step //1683
		goto Shattrath City,62.8,36.0
		.talk Lord Torvos##25140
		.turnin Sunfury Attack Plans##11877 |daily
	step //1684
		goto 62.8,35.6
		.talk Emissary Mordin##19202 
		.turnin Gaining the Advantage##11875 |daily
	step //1685
		goto 61.6,52.2
		.talk Harbinger Haronem##19475
		.turnin The Multiphas Survey##11880 |daily
	step //1686
		goto 49.1,42.5
		.talk Exarch Nasuun##24932 |daily
		.turnin Maintaining the Sunwell Portal##11514 |daily
	step //1687
		goto Shattrath City,48.6,42.0 |n
		.' Click the Shattrath Portal to Isle of Quel'Danas. |goto Isle of Quel'Danas
	step //1688
		goto Isle of Quel'Danas,47.5,35.4
		.talk Astromancer Darnarian##25133
		..accept Know Your Ley Lines##11547 |daily
	step //1689
		goto 47.5,35.1
		.talk Battlemage Arynna##25057
		..accept The Air Strikes Must Continue##11533 |daily
	step //1690
		goto 47.6,35.1
		.talk Harbinger Inuuro##25061
		..accept The Battle Must Go On##11537 |daily
	step //1691
		goto 48.8,37.2
		.talk Anchorite Ayuri##25112
		..accept Your Continued Support##11548 |daily
		.' This quest requires that you give 10 Gold in trade of reputation with the Shattered Sun Offensive, you should be able to turn it in immidiately.
		..turnin Your Continued Support##11548 |daily
	step //1692
		goto 50.6,39.0
		.talk Vindicator Kaalan##25108
		..accept Keeping the Enemy at Bay##11543 |daily
	step //1693
		goto 49.3,40.4
		.talk Magister Ilastar##25069
		..accept Crush the Dawnblade##11540 |daily
	step //1694
		goto 50.6,40.8
		.talk Smith Hauthaa##25046
		..accept Don't Stop Now....##11536 |daily
		..accept Ata'mal Armaments##11544 |daily
	step //1695
		goto 51.5,32.5
		.talk Mar'nah##24975
		..accept Rediscovering Your Roots##11521 |daily
		..accept Open for Business##11546 |daily
	step //1696
		goto 53.8,34.3
		.talk Captain Valindria##25088
		..accept Disrupt the Greengill Coast##11541 |daily
	step //1697
		goto 47.5,30.5
		.talk Captain Theris Dawnhearth##24967
		..accept Arm the Wards!##11523 |daily
		..accept The Missing Magistrix##11526
	step //1698
		goto 47.1,30.7
		.talk Vindicator Xayann##24965
		..accept Further Conversions##11525 |daily
	step //1699
		goto Isle of Quel'Danas,44.3,28.5
		.from Wretched Fiend##24966+
		.collect 4 Mana Remnants##34338 |q 11523 |c
		.from Erratic Sentry##24972+
		.' Use Attuned Crystal Cores on the Erratic Sentries corpse. |use Attuned Crystal Cores##34368
		.' 5 Converted Sentry Deployed |q 11525/1
		.click Bloodberry Bush##28
		.get 5 Bloodberry |q 11546/1 |tip They can be found all around this area on the ground.
	step //1700
		goto Isle of Quel'Danas,42.1,35.7
		.kill 6 Dawnblade Summoner##24978+ |q 11540/1
		.kill 6 Dawnblade Blood Knight##24976+ |q 11540/2
		.kill 3 Dawnblade Marksman##24979+ |q 11540/3
		.' Use your Astromancer's Crystal to sample the Bloodcrystal's density. |use Astromancer's Crystal##34533
		.' Bloodcrystal Reading Taken |q 11547/3
	step //1701
		goto Isle of Quel'Danas,46.5,35.5
		.' Use the Mana Remnants to Energize the Crystal Ward. |use Mana Remnants##34338
		.' Energize a Crystal Ward |q 11523/1
	step //1702
		goto 48.5,25.2
		.talk Ayren Cloudbreaker##25059
		.' Tell him you Need to Intercept the Dawnblade Reinforcements.
		.' Use your Flaming Oil to set fire to the ships sails as you fly around. |use Flaming Oil##34489
		.' Sin'loren sails burned |q 11543/1
		.' Bloodoath sails burned |q 11543/2
		.' Dawnchaser sails burned |q 11543/3
	step //1703
		.kill 6 Dawnblade Reservist##25087+ |q 11543/4
		.' You can find more at [Isle of Quel'Danas,51.1,9.7]
		.' Another spot for them is at [Isle of Quel'Danas,55.2,11.8]
	step //1704
		goto Isle of Quel'Danas,52.4,17.4
		.talk Unrestrained Dragonhawk##25236
		.' Ride the dragonhawk to Sun's Reach. |goto Isle of Quel'Danas,48.4,25.3 |noway|c
	step //1705
		goto Isle of Quel'Danas,48.5,25.2
		.talk Ayren Cloudbreaker##25059
		.' Tell him you've been ordered to undertake an airstrike.
		.' Use your Arcane Charges on mobs once you get to the Dead Scar. |use Arcane Charges##34475
		.kill 2 Pit Overlord##25031+ |q 11533/1
		.kill 3 Eredar Sorcerer##25033+ |q 11533/2
		.kill 12 Wrath Enforcer##25030+ |q 11533/3
	step //1706
		goto Isle of Quel'Danas,48.5,43.7
		.kill Emissary of Hate##25003 |n
		.' Use your Shattered Sun Banner on his corpse. |use Shattered Sun Banner##34414
		.' Impale the Emissary of Hate |q 11537/1
		.kill 6 Burning Legion Demon |q 11537/2
		.' Use your Astromancer's Crystal to sample the Portal's density. |use Astromancer's Crystal##34533
		.' Portal Reading Taken |q 11547/1
	step //1707
		.' Take this path back to the shoreside. |goto Isle of Quel'Danas,57.3,38.6 |c
	step //1708
		goto Isle of Quel'Danas,64.1,49.9
		.from Darkspine Myrmidon##25060+
		..collect Darkspine Chest Key##34477 |n
		.from Darkspine Siren##25073+
		..collect Orb of Murloc Control##34483 |n
		.' Use your Orbs of Murloc Control on Greengill Slaves along the shore. |use Orb of Murloc Control##34483
		.' Free 10 Greengill Slaves |q 11541/1
		.' Use your Darkspine Chest Keys on the Darkspine Ore Chest.
		.get 3 Darkspine Iron Ore |q 11536/1
	step //1709
		goto Isle of Quel'Danas,61.1,62.0
		.' Use your Astromancer's Crystal to sample the Shrine's density. |use Astromancer's Crystal##34533
		.' Shrine Reading Taken |q 11547/2
	step //1710
		goto Isle of Quel'Danas,53.8,34.3
		.talk Captain Valindria##25088
		..turnin Disrupt the Greengill Coast##11541 |daily
	step //1711
		goto 50.6,40.7
		.talk Smith Hauthaa##25046
		..turnin Don't Stop Now....##11536 |daily
	step //1712
		goto 50.6,39.0
		.talk Vindicator Kaalan##25108
		..turnin Keeping the Enemy at Bay##11543 |daily
	step //1713
		goto 49.3,40.4
		.talk Magister Ilastar##25069
		..turnin Crush the Dawnblade##11540 |daily
	step //1714
		goto 51.5,32.5
		.talk Mar'nah##24975
		..turnin Open for Business##11546 |daily
	step //1715
		goto 47.5,35.3
		.talk Astromancer Darnarian##25133
		.turnin Know Your Ley Lines##11547 |daily
	step //1716
		goto 47.5,35.1
		.talk Battlemage Arynna##25057
		.turnin The Air Strikes Must Continue##11533 |daily
	step //1717
		goto 47.6,35.1
		.talk Harbinger Inuuro##25061
		.turnin The Battle Must Go On##11537 |daily
	step //1718
		goto 47.5,30.5
		.talk Captain Theris Dawnhearth##24967
		.turnin Arm the Wards!##11523 |daily
	step //1719
		goto 47.1,30.7
		.talk Vindicator Xayann##24965
		.turnin Further Conversions##11525 |daily
	step //1720
		goto Isle of Quel'Danas,48.5,44.7
		|use Captured Legion Scroll##34420
		.' Teleport to Hellfire Peninsula |goto Hellfire Peninsula,58.6,18.7,0.5 |noway|c
	step //1721
		goto Hellfire Peninsula,58.2,17.6
		.talk Magistrix Seyla##24937
		.turnin The Missing Magistrix##11526
		..accept Blood for Blood##11515 |daily
		..accept Blast the Gateway##11516 |daily
	step //1722
		goto Hellfire Peninsula,66.4,20.1
		.from Wrath Herald##24919+
		.collect 4 Demonic Blood##34259 
		.' use the Sizzling Embers to summon a Living Flare. |use Sizzling Embers##34253
		.kill Incandescent Fel Spark##22323+ |n
		.' Once you see a message that says "Living Flare becomes unstable with brimming energy!" take it to [Hellfire Peninsula,58.6,18.7].
		.' Legion Gateway Destroyed |q 11516/1
	step //1723
		goto 59.9,21.0
		.' Use your Fel Siphon on Felblood Initiates. |use Fel Siphon##34257
		.kill 4 Emaciated Felblood##24918 |q 11515/1
	step //1724
		goto Hellfire Peninsula,58.2,17.6
		.talk Magistrix Seyla##24937
		.turnin Blast the Gateway##11516 |daily
		.turnin Blood for Blood##11515 |daily
	step //1725
		goto Terokkar Forest,59.7,10.3
		.from Razorthorn Flayer##24920+
		..collect Razorthorn Flayer Gland##34255 |q 11521 |n
		.' Use your Razorthorn Flayer Gland on Razorthorn Ravagers. |use Razorthorn Flayer Gland##34255
		.' Use your pets Expose Razorthorn Root ability on mounds of dirt around the area. |cast Expose Razorthorn Root##44935
		.collect 5 Razorthorn Root##34254 |q 11521/1
	step //1726
		|fly Altar of Sha'tar
		only if rep ("The Aldor")>=Neutral
	step //1727
		|fly Sanctum of the Stars
		only if rep ("The Scryers")>=Neutral
	step //1728
		 goto Shadowmoon Valley,68.5,37.5
		.from Shadowmoon Chosen##22084+,Shadowmoon Slayer##22082+,Shadowmoon Darkweaver##22081+
		.collect 5 Ata'mal Armament##34500 |q 11544
	step //1729
		|fly Shattrath
	step //1730
		goto Shattrath City,48.6,42.0 |n
		.' Click the Shattrath Portal to Isle of Quel'Danas. |goto Isle of Quel'Danas |noway|c
	step //1731
		goto Isle of Quel'Danas,51.5,32.5
		.talk Mar'nah##24975
		.turnin Rediscovering Your Roots##11521 |daily
	step //1732
		goto 50.6,40.7
		.' Click the Ata'mal Armaments and cleanse them at Hauthaa's Anvil. |use Ata'mal Armament##34500
		.' Cleanse 5 Ata'mal Metals |q 11544/1
	step //1733
		goto 50.6,40.7
		.talk Smith Hauthaa##25046
		..turnin Ata'mal Armaments##11544 |daily
	step //1734
		' Move to our Shattered Sun Offensive Dailies guide.
]])
ZygorGuidesViewer:RegisterInclude("H_SSO_Dailies", [[
	daily
	step //1735
		|fly Shattrath
	step //1736
		goto Shattrath City,56.3,81.5
		.talk Innkeeper Haelthol##19232
		.home Shattrath City
		only if rep ("The Scryers")>=Neutral
	step //1737
		goto Shattrath City,28.2,49.4
		.talk Minalei##19046
		.home Shattrath City
		only if rep ("The Aldor")>=Neutral
	step //1738
		goto Shattrath City,49.1,42.5
		.talk Exarch Nasuun##24932
		..accept Maintaining the Sunwell Portal##11514 |daily
	step //1739
		goto 62.8,36.0
		.talk Lord Torvos##25140
		..accept Sunfury Attack Plans##11877 |daily
	step //1740
		goto 62.8,35.6
		.talk Emissary Mordin##19202
		..accept Gaining the Advantage##11875 |daily
		only if skill("Skinning")>300 or skill("Mining")>300 or skill("Herbalism")>300
	step //1741
		goto Shattrath City,61.7,52.1
		.talk Harbinger Haronem##19475
		..accept The Multiphase Survey##11880 |daily
	step //1742
		goto Shattrath City,48.6,42.0 |n
		.' Click the Shattrath Portal to Isle of Quel'Danas. |goto Isle of Quel'Danas
	step //1743
		goto Isle of Quel'Danas,47.5,35.4
		.talk Astromancer Darnarian##25133
		..accept Know Your Ley Lines##11547 |daily
	step //1744
		goto 47.5,35.1
		.talk Battlemage Arynna##25057
		..accept The Air Strikes Must Continue##11533 |daily
	step //1745
		goto 47.6,35.1
		.talk Harbinger Inuuro##25061
		..accept The Battle Must Go On##11537 |daily
	step //1746
		goto 48.8,37.2
		.talk Anchorite Ayuri##25112
		..accept Your Continued Support##11548 |daily
		.' This quest requires that you give 10 Gold in trade of reputation with the Shattered Sun Offensive, you should be able to turn it in immidiately.
		..turnin Your Continued Support##11548 |daily
	step //1747
		goto 50.6,39.0
		.talk Vindicator Kaalan##25108
		..accept Keeping the Enemy at Bay##11543 |daily
	step //1748
		oto 49.3,40.4
		.talk Magister Ilastar##25069
		..accept Crush the Dawnblade##11540 |daily
	step //1749
		goto 50.6,40.8
		.talk Smith Hauthaa##25046
		..accept Don't Stop Now....##11536 |daily
		..accept Ata'mal Armaments##11544 |daily
	step //1750
		goto 51.5,32.5
		.talk Mar'nah##24975
		..accept Rediscovering Your Roots##11521 |daily
		..accept Open for Business##11546 |daily
	step //1751
		goto 53.8,34.3
		.talk Captain Valindria##25088
		..accept Disrupt the Greengill Coast##11541 |daily
	step //1752
		goto 47.5,30.5
		.talk Captain Theris Dawnhearth##24967
		..accept Arm the Wards!##11523 |daily
		..accept The Missing Magistrix##11526
	step //1753
		goto 47.1,30.7
		.talk Vindicator Xayann##24965
		..accept Further Conversions##11525 |daily
	step //1754
		goto Isle of Quel'Danas,44.3,28.5
		.from Wretched Fiend##24966+
		.collect 4 Mana Remnants##34338 |q 11523 |c
		.from Erratic Sentry##24972+
		.' Use Attuned Crystal Cores on the Erratic Sentries corpse. |use Attuned Crystal Cores##34368
		.' 5 Converted Sentry Deployed |q 11525/1
		.click Bloodberry Bush##28
		.get 5 Bloodberry |q 11546/1 |tip They can be found all around this area on the ground.
	step //1755
		goto Isle of Quel'Danas,42.1,35.7
		.kill 6 Dawnblade Summoner##24978+ |q 11540/1
		.kill 6 Dawnblade Blood Knight##24976+ |q 11540/2
		.kill 3 Dawnblade Marksman##24979+ |q 11540/3
		.' Use your Astromancer's Crystal to sample the Bloodcrystal's density. |use Astromancer's Crystal##34533
		.' Bloodcrystal Reading Taken |q 11547/3
	step //1756
		goto Isle of Quel'Danas,46.5,35.5
		.' Use the Mana Remnants to Energize the Crystal Ward. |use Mana Remnants##34338
		.' Energize a Crystal Ward |q 11523/1
	step //1757
		goto 48.5,25.2
		.talk Ayren Cloudbreaker##25059
		.' Tell him you Need to Intercept the Dawnblade Reinforcements.
		.' Use your Flaming Oil to set fire to the ships in the water. |use Flaming Oil##34489
		.' Sin'loren sails burned |q 11543/1
		.' Bloodoath sails burned |q 11543/2
		.' Dawnchaser sails burned |q 11543/3
	step //1758
		.kill 6 Dawnblade Reservist##25087+ |q 11543/4
		.' You can find more at [Isle of Quel'Danas,51.1,9.7]
		.' Another spot for them is at [Isle of Quel'Danas,55.2,11.8]
	step //1759
		goto Isle of Quel'Danas,52.4,17.4
		.talk Unrestrained Dragonhawk##25236
		.' Ride the dragonhawk to Sun's Reach. |goto Isle of Quel'Danas,48.4,25.3 |noway|c
	step //1760
		goto Isle of Quel'Danas,48.5,25.2
		.talk Ayren Cloudbreaker##25059
		.' Tell him you've been ordered to undertake an airstrike.
		.' Use your Arcane Charges on mobs once you get to the Dead Scar. |use Arcane Charges##34475
		.kill 2 Pit Overlord##25031+ |q 11533/1
		.kill 3 Eredar Sorcerer##25033+ |q 11533/2
		.kill 12 Wrath Enforcer##25030+ |q 11533/3
	step //1761
		goto Isle of Quel'Danas,48.5,43.7
		.kill Emissary of Hate##25003 |n
		.' Use your Shattered Sun Banner on his corpse. |use Shattered Sun Banner##34414
		.' Impale the Emissary of Hate |q 11537/1
		.kill 6 Burning Legion Demon |q 11537/2
		.' Use your Astromancer's Crystal to sample the Portal's density. |use Astromancer's Crystal##34533
		.' Portal Reading Taken |q 11547/1
	step //1762
		.' Take this path back to the shoreside. |goto Isle of Quel'Danas,57.3,38.6 |c
	step //1763
		goto Isle of Quel'Danas,64.1,49.9
		.from Darkspine Myrmidon##25060+
		..collect Darkspine Chest Key##34477 |n
		.from Darkspine Siren##25073+
		..collect Orb of Murloc Control##34483 |n
		.' Use your Orbs of Murloc Control on Greengill Slaves along the shore. |use Orb of Murloc Control##34483
		.' Free 10 Greengill Slaves |q 11541/1
		.' Use your Darkspine Chest Keys on the Darkspine Ore Chest.
		.get 3 Darkspine Iron Ore |q 11536/1
	step //1764
		goto Isle of Quel'Danas,61.1,62.0
		.' Use your Astromancer's Crystal to sample the Shrine's density. |use Astromancer's Crystal##34533
		.' Shrine Reading Taken |q 11547/2
	step //1765
		'Hearth to the Scryer's Tier Inn |goto Shattrath City,56.3,81.5,0.5 |use Hearthstone##6948 |noway|c
		only if rep("The Scryers")>=Neutral
	step //1766
		'Hearth to the Aldor Rise Inn |goto Shattrath City,28.2,49.4,0.5 |use Hearthstone##6948 |noway|c
		only if rep ("The Aldor")>=Neutral
	step //1767
		|fly Altar of Sha'tar
		only if rep ("The Aldor")>=Neutral
	step //1768
		|fly Sanctum of the Stars
		only if rep ("The Scryers")>=Neutral
	step //1769
		 goto Shadowmoon Valley,68.5,37.5
		.from Shadowmoon Chosen##22084+,Shadowmoon Slayer##22082+,Shadowmoon Darkweaver##22081+
		.collect 5 Ata'mal Armament##34500 |q 11544
	step //1770
		|fly Stonebreaker Hold
	step //1771
		goto Terokkar Forest,59.7,10.3
		.from Razorthorn Flayer##24920+
		..collect Razorthorn Flayer Gland##34255 |q 11521
		.' Use your Razorthorn Flayer Gland on Razorthorn Ravagers. |use Razorthorn Flayer Gland##34255
		.' Use your pets Expose Razorthorn Root ability on mounds of dirt around the area. |cast Expose Razorthorn Root##44935
		.collect 5 Razorthorn Root##34254 |q 11521/1
	step //1772
		|fly Garadar
	step //1773
		goto Nagrand,58.8,75.1
		.from Clefthoof Bull##17132+,Talbuk Thorngrazer##17131+,Wild Elekk##18334+
		.' Skin their corpses in order to collect the Nether Residue.
		.get 8 Nether Residue##35229 |q 11875/1
		only if skill("Skinning")>=300
	step //1774
		goto 40.8,31.6
		.' Mine inside the cave and collect Nether Residue.
		.collect 8 Nether Residue##35229 |q 11875/1
		.' You can check [Nagrand,50.0,56.6] for more Mining Nodes.
		only if skill("Mining")>=300
	step //1775
		goto Nagrand,38.3,65.3
		.' Fly around the Spirit Fields looking for Fiery Red Orbs on the ground.
		.' Use your Multiphase Spectrographic Goggles on the Orbs. |use Multiphase Spectrographic Goggles##35233
		.' 6 Multiphase Readings Taken |q 11880/1
	step //1776
		|fly Evergrove
	step //1777
		goto Blade's Edge Mountains,54.0,18.1
		.from Unbound Ethereal##22244+,Bash'ir Raider##22241+,Bash'ir Arcanist##22243+,Bash'ir Spell-Thief##22242+
		.get 1 Bash'ir Phasing Device |q 11514
		'Use the Bash'ir Phasing Device. |use Bash'ir Phasing Device##34248
		.' Collect 10 Smuggled Mana Cell |q 11514/1
	step //1778
		|fly Area 52
	step //1779
		goto Netherstorm,25.9,66.8
		.from Sunfury Bloodwarder##18853+,Sunfury Captain##19453+,Sunfury Magister##18855+,Sunfury Geologist##19779+,Sunfury Astromancer##19643
		.get Sunfury Attack Plans |q 11877/1
	step //1780
		|fly Thrallmar
		.' You can fly through the Twisting Nether to [Hellfire Peninsula,58.2,17.6], but you risk a possible death in doing so.
		.' If you choose to fly on your own, click here to proceed. |confirm
	step //1781
		goto Hellfire Peninsula,58.2,17.6
		.talk Magistrix Seyla##24937
		..accept Blood for Blood##11515 |daily
		..accept Blast the Gateway##11516 |daily
	step //1782
		goto Hellfire Peninsula,66.4,20.1
		.from Wrath Herald##24919+
		.collect 4 Demonic Blood##34259 
		.' use the Sizzling Embers to summon a Living Flare. |use Sizzling Embers##34253
		.kill Incandescent Fel Spark##22323+ |n
		.' Once you see a message that says "Living Flare becomes unstable with brimming energy!" take it to [Hellfire Peninsula,58.6,18.7].
		.' Legion Gateway Destroyed |q 11516/1
	step //1783
		goto 59.9,21.0
		.' Use your Fel Siphon on Felblood Initiates. |use Fel Siphon##34257
		.kill 4 Emaciated Felblood##24918 |q 11515/1
	step //1784
		goto Hellfire Peninsula,58.2,17.6
		.talk Magistrix Seyla##24937
		.turnin Blast the Gateway##11516 |daily
		.turnin Blood for Blood##11515 |daily
	step //1785
		|fly Shattrath
	step //1786
		goto Shattrath City,62.8,36.0
		.talk Lord Torvos##25140
		.turnin Sunfury Attack Plans##11877 |daily
	step //1787
		goto 62.8,35.6
		.talk Emissary Mordin##19202 
		.turnin Gaining the Advantage##11875 |daily
	step //1788
		goto 61.6,52.2
		.talk Harbinger Haronem##19475
		.turnin The Multiphas Survey##11880 |daily
	step //1789
		goto 49.1,42.5
		.talk Exarch Nasuun##24932 |daily
		.turnin Maintaining the Sunwell Portal##11514 |daily
	step //1790
		goto Shattrath City,48.6,42.0 |n
		.' Click the Shattrath Portal to Isle of Qual'Danas. |goto Isle of Quel'Danas |noway|c
	step //1791
		goto Isle of Quel'Danas,53.8,34.3
		.talk Captain Valindria##25088
		..turnin Disrupt the Greengill Coast##11541 |daily
	step //1792
		goto 50.6,40.7
		.' Click the Ata'mal Armaments and cleanse them at Hauthaa's Anvil. |use Ata'mal Armament##34500
		.' Cleanse 5 Ata'mal Metals |q 11544/1
	step //1793
		goto 50.6,40.7
		.talk Smith Hauthaa##25046
		..turnin Don't Stop Now....##11536 |daily
		..turnin Ata'mal Armaments##11544 |daily
	step //1794
		goto 50.6,39.0
		.talk Vindicator Kaalan##25108
		..turnin Keeping the Enemy at Bay##11543 |daily
	step //1795
		goto 49.3,40.4
		.talk Magister Ilastar##25069
		..turnin Crush the Dawnblade##11540 |daily
	step //1796
		goto 51.5,32.5
		.talk Mar'nah##24975
		..turnin Open for Business##11546 |daily
		.turnin Rediscovering Your Roots##11521 |daily
	step //1797
		goto 47.5,35.3
		.talk Astromancer Darnarian##25133
		.turnin Know Your Ley Lines##11547 |daily
	step //1798
		goto 47.5,35.1
		.talk Battlemage Arynna##25057
		.turnin The Air Strikes Must Continue##11533 |daily
	step //1799
		goto 47.6,35.1
		.talk Harbinger Inuuro##25061
		.turnin The Battle Must Go On##11537 |daily
	step //1800
		goto 47.5,30.5
		.talk Captain Theris Dawnhearth##24967
		.turnin Arm the Wards!##11523 |daily
	step //1801
		goto 47.1,30.7
		.talk Vindicator Xayann##24965
		.turnin Further Conversions##11525 |daily
	step //1802
		goto Isle of Quel'Danas,47.3,30.7
		.talk Eldara Dawnrunner##25032
		..accept A Friend in the Frontlines##11554 |instant
		only if rep ("Shattered Sun Offensive")==Friendly
	step //1803
		goto Isle of Quel'Danas,47.3,30.7
		.talk Eldara Dawnrunner##25032
		..accept Honored By Your Allies##11555 |instant
		only if rep ("Shattered Sun Offensive")==Honored
	step //1804
		goto Isle of Quel'Danas,47.3,30.7
		.talk Eldara Dawnrunner##25032
		..accept Revered in the Field of Battle##11556 |instant
		only if rep ("Shattered Sun Offensive")==Revered
	step //1805
		goto Isle of Quel'Danas,47.3,30.7
		.talk Eldara Dawnrunner##25032
		..accept Exalted Among All Combatants##11557 |instant
		only if rep ("Shattered Sun Offensive")==Exalted
	step //1806
		goto Isle of Quel'Danas,51.2,33.1
		.talk Anchorite Kairthos##25163
		..accept A Magnanimous Benefactor##11549 |tip This quest will cost you 1,000 Gold, but give you the title "Of the Shattered Sun".
		only if rep ("Shattered Sun Offensive")==Exalted
	step //1807
		goto Isle of Quel'Danas,51.2,33.1
		.talk Anchorite Kairthos##25163
		.' _WARNING_, by turning in this quest, you will spend _1000 gold!_
		..turnin A Magnanimous Benefactor##11549
		only if rep ("Shattered Sun Offensive")==Exalted
	step //1808
		'Congratulations, you have earned the title _of the Shattered Sun_!
		only if rep ("Shattered Sun Offensive")==Exalted
]])
ZygorGuidesViewer:RegisterInclude("H_Maghar_Faction",[[
	step //1809
		goto Hellfire Peninsula,55,36
		.talk Nazgrel##3230
		.accept The Assassin##9400
	step //1810
		goto 33.6,43.5
		.' Go to this spot
		.' Find Krun Spinebreaker |q 9400/1
	step //1811
		goto 33.6,43.5
		.clicknpc Fel Orc Corpse##17062
		..turnin The Assassin##9400
		..accept A Strange Weapon##9401
	step //1812
		goto 55,36
		.talk Nazgrel##3230
		..turnin A Strange Weapon##9401
		..accept The Warchief's Mandate##9405
	step //1813
		goto 54.2,37.9
		.talk Far Seer Regulkut##16574
		..turnin The Warchief's Mandate##9405
		..accept A Spirit Guide##9410
	step //1814
		goto 33.6,43.5
		.' Use your Ancestral Spirit Wolf Totem next to the Fel Orc Corpse |use Ancestral Spirit Wolf Totem##23669 |modelnpc Fel Orc Corpse##17062
		.' Follow the spirit wolf |tip Stay close to the wolf and follow it until it stops, or you will not be able to turn in the quest.
		.' Follow the wolf to this spot|goto 32,27.8,0.5|c
	step //1815
		goto 32,27.8
		.talk Gorkan Bloodfist##16845
		..turnin A Spirit Guide##9410
		..accept The Mag'har##9406
	step //1816
		goto 55,36
		.talk Nazgrel##3230
		..turnin The Mag'har##9406
	step //1817
		goto Nagrand,71.6,40.5
		.talk Shado "Fitz" Farstrider##18200
		..accept Windroc Mastery (1)##9854
		.talk Hemet Nesingwary##18180
		..accept Clefthoof Mastery (1)##9789
		.talk Harold Lane##18218
		..accept Talbuk Mastery (1)##9857
	step //1818
		goto 72.2,38.4
		.kill 12 Talbuk Stag##17130+ |q 9857/1
		.' You can find more Talbuk Stags at [70.8,46.4]
	step //1819
		goto 66.5,39.5
		.kill 12 Windroc##17128+ |q 9854/1
	step //1820
		goto 64,45.1
		.kill 12 Clefthoof##18205+ |q 9789/1
		.from Wild Elekk##18334
		.collect 3 Pair of Ivory Tusks##25463 |q 9914 |future
		.from Dust Howlers##17158
		.collect Howling Wind##24504 |n
		.' Use the Howling Wind in your bags |use Howling Wind##24504
		..accept The Howling Wind##9861
		.' You can find more Clefthoofs, Elekks, and Dust Howlers at [70.8,46.4]
	step //1821
		goto 71.6,40.5
		.talk Shado "Fitz" Farstrider##18200
		..turnin Windroc Mastery (1)##9854
		..accept Windroc Mastery (2)##9855
		.talk Hemet Nesingwary##18180
		..turnin Clefthoof Mastery (1)##9789
		..accept Clefthoof Mastery (2)##9850
		.talk Harold Lane##18218
		..turnin Talbuk Mastery (1)##9857
		..accept Talbuk Mastery (2)##9858
	step //1822
		goto 57.2,35.2
		.talk Gursha##18808
		.fpath Garadar
	step //1823
		goto 57.1,34.9
		.talk Matron Drakia##18302
		..accept Missing Mag'hari Procession##9944
	step //1824
		goto 56.6,34.6
		.talk Matron Tikkit##18913
		.home Garadar
	step //1825
		goto 55.4,37.4
		.talk Captain Kroghan##18090
		..turnin Reinforcements for Garadar##9797
	step //1826
		goto 55.5,37.6
		.talk Jorin Deadeye##18106
		..accept The Impotent Leader##9888
	step //1827
		goto 55.8,38
		.talk Warden Bullrok##18407
		..accept Proving Your Strength##10479
		.click the Garadar Bulletin Board
		..accept Wanted: Giselda the Crone##9935
		..accept Wanted: Zorbo the Advisor##9939
	step //1828
		goto 55,39
		.talk Elementalist Yal'hah##18234
		..accept The Throne of the Elements##9870
	step //1829
		goto 54.7,39.7
		.talk Farseer Kurkush##18066
		..accept Vile Idolatry##9863
		.talk Farseer Corhuk##18067
		..accept The Missing War Party##9864
		.talk Farseer Margadesh##18068
		..accept Murkblood Leaders...##9867
	step //1830
		goto 51.9,34.8
		.talk the Consortium Recruiter##18335
		..accept The Consortium Needs You!##9913
	step //1831
		goto 60.5,22.4
		.talk Elementalist Morgh##18074
		..turnin The Howling Wind##9861
		..accept Murkblood Corrupters##9862
		.talk Elementalist Sharvak##18072
		..turnin The Throne of the Elements##9870
		.talk Elementalist Lo'ap##18073
		..accept A Rare Bean##9800
		..accept Muck Diving##9815
		.talk Elementalist Untrag##18071
		..accept The Underneath##9818
	step //1832
		goto 61.8,24.4
		.talk Gordawg##18099 |tip He may not be in this spot, he wanders around the Throne of Elements area.
		..turnin The Underneath##9818
		..accept The Tortured Earth##9819
	step //1833
		goto 52.1,25.6
		.kill 12 Talbuk Thorngrazer##17131+ |q 9858/1
		.click Dung##3675
		.get 8 Digested Caracoli |q 9800/1
	step //1834
		goto 51.6,30.8
		.kill 12 Clefthoof Bull##17132+ |q 9850/1
		.' You can find more Clefthoof Bulls at [49.7,35.6]
	step //1835
		goto 46.5,18.2
		.kill Zorbo the Advisor##18413 |q 9939/1 |tip Inside the cave at the top of the hill.
	step //1836
		goto 48.3,21.5
		.from 5 Warmaul Shaman##18064+ |q 9939/2
		.from 5 Warmaul Reaver##17138+ |q 9939/3
		.get 10 Obsidian Warbeads |q 10479/1
	step //1837
		goto 32.4,36.1
		.talk Saurfang the Younger##18229
		..turnin The Missing War Party##9864
		..accept Once Were Warriors##9865
		.talk Elder Yorley##18414
		..turnin Missing Mag'hari Procession##9944
		..accept War on the Warmaul##9945
		.talk Elder Ungriz##18415
		..accept Finding the Survivors##9948
	step //1838
		goto 29.2,31.6 |n
		.' The path up to 'War on the Warmaul' and 'Finding the Survivors' starts here |goto 29.2,31.6,0.5 |noway |c
	step //1839
		goto 23.4,29.2
		.kill 8 Warmaul Brute##18065+ |q 9945/1
		.kill 8 Warmaul Warlock##18037+ |q 9945/2
		.collect Warmaul Prison Key##25604 |n
		.click the yellow cages around this area
		.' Free 5 Mag'har Prisoners |q 9948/1
	step //1840
		goto 32.4,36.1
		.talk Elder Yorley##18414
		..turnin War on the Warmaul##9945
		.talk Elder Ungriz##18415
		..turnin Finding the Survivors##9948
	step //1841
		goto 41.5,40.9
		.from Muck Spawn##17154+
		.get 5 Muck-ridden Core |q 9815/1
	step //1842
		goto 32,39.1
		.kill 20 Murkblood Scavenger##18207+ |q 9865/1
		.kill 10 Murkblood Raider##18203+ |q 9865/2
		.kill 5 Murkblood Putrifier##18202+ |q 9862/1
		.get 10 Murkblood Idol |q 9863/1
	step //1843
		goto 30.9,42.3
		.from Ortor of Murkblood##18204 |tip He's standing inside the big building here.
		.get Head of Ortor of Murkblood |q 9867/1
	step //1844
		goto 32.4,36.1
		.talk Saurfang the Younger##18229
		..turnin Once Were Warriors##9865
		..accept He Will Walk The Earth...##9866
	step //1845
		goto 30.8,58.1
		.talk Zerid##18276
		..accept Gava'xi##9900
		..accept Matters of Security##9925
	step //1846
		goto 31.4,57.8
		.talk Gezhe##18265
		..turnin The Consortium Needs You!##9913
		..accept Stealing from Thieves##9882
	step //1847
		goto 31.8,56.8
		.talk Shadrek##18333
		..accept A Head Full of Ivory##9914
		..turnin A Head Full of Ivory##9914
	step //1848
		goto 33.4,62.4
		.click Oshu'gun Crystal Fragment##6415
		.from Vir'aani Raider##17149
		.get 10 Oshu'gun Crystal Fragment |q 9882/1
	step //1849
		goto 30.6,67.5
		.kill 8 Voidspawn##17981+ |q 9925/1
	step //1850
		goto 42.4,73.5
		.kill Gava'xi##18298 |q 9900/1 |tip He spawns at the peak of a small hill at this location, sometimes he spawns at the base of the hill though, so keep an eye out.  He walks around all around this area, near this hill, so you may need to search for him.
	step //1851
		goto 48.4,61.5
		.kill 12 Ravenous Windroc##18220+ |q 9855/1
	step //1852
		goto 30.8,58.1
		.talk Zerid##18276
		..turnin Gava'xi##9900
		..turnin Matters of Security##9925
	step //1853
		goto 31.4,57.8
		.talk Gezhe##18265
		..turnin Stealing from Thieves##9882
	step //1854
		goto 61.7,67.1
		.talk Wazat##19035
		..accept I Must Have Them!##10109
	step //1855
		goto 65.4,70.8
		.kill 10 Tortured Earth Spirit##17156+ |q 9819/1
	step //1856
		goto 69.4,56.9
		.from Dust Howler##17158+
		.get 3 Air Elemental Gas |q 10109/1
		.' You can find more Dust Howlers at [65.5,46.9]
	step //1857
		goto 61.7,67.1
		.talk Wazat##19035
		..turnin I Must Have Them!##10109
	step //1858
		'Go southeast to Terokkar Forest |goto Terokkar Forest |noway |c
	step //1859
		goto Terokkar Forest,19.8,60.9
		.talk Kilrath##18273
		..turnin The Impotent Leader##9888
		..accept Don't Kill the Fat One##9889
	step //1860
		goto 20,63.1
		.kill 10 Boulderfist Invader##18260+ |q 9889/1
	step //1861
		goto 20,63.1
		.' Fight Unkor the Ruthless until he submits |q 9889/2
		.talk Unkor the Ruthless##18262
		..turnin Don't Kill the Fat One##9889
		..accept Success!##9890
	step //1862
		goto 19.8,60.9
		.talk Kilrath##18273
		..turnin Success!##9890
		..accept Because Kilrath is a Coward##9891
	step //1863
		'Hearth to Garadar |goto Nagrand,56.7,34.6,0.5 |use Hearthstone##6948 |noway |c
	step //1864
		goto Nagrand,55.5,37.6
		.talk Jorin Deadeye##18106
		..turnin Because Kilrath is a Coward##9891
		..accept Message in a Battle##9906
	step //1865
		goto 55.8,38
		.talk Warden Bullrok##18407
		..turnin Proving Your Strength##10479
		..turnin Wanted: Zorbo the Advisor##9939
	step //1866
		goto 55.5,37.6
		.talk Elkay'gan the Mystic##18300
		..accept Standards and Practices##9910
	step //1867
		goto 54.7,39.7
		.talk Farseer Kurkush##18066
		..turnin Vile Idolatry##9863
		.talk Farseer Corhuk##18067
		..turnin He Will Walk The Earth...##9866
		.talk Farseer Margadesh##18068
		..turnin Murkblood Leaders...##9867
	step //1868
		goto 61.8,24.4
		.talk Gordawg##18099
		..turnin The Tortured Earth##9819
		..accept Eating Damnation##9821 |tip He may not be in this spot, he wanders around the Throne of Elements area.
	step //1869
		goto 60.5,22.4
		.talk Elementalist Lo'ap##18073
		..turnin A Rare Bean##9800
		..accept Agitated Spirits of Skysong##9804
		..turnin Muck Diving##9815
		.talk Elementalist Morgh##18074
		..turnin Murkblood Corrupters##9862
	step //1870
		goto 59.7,27.3
		.kill 8 Lake Spirit##17153+ |q 9804/1
	step //1871
		goto 60.5,22.4
		.talk Elementalist Lo'ap##18073
		..turnin Agitated Spirits of Skysong##9804
		..accept Blessing of Incineratus##9805
	step //1872
		goto 52,20.2
		.from Enraged Crusher##18062+ |tip You can find them all along this cliffside.
		.get 10 Enraged Crusher Core |q 9821/1
	step //1873
		goto 61.8,24.4
		.talk Gordawg##18099 |tip He may not be in this spot, he wanders around the Throne of Elements area.
		..turnin Eating Damnation##9821
		..accept Shattering the Veil##9849
	step //1874
		goto 71.6,40.5
		.talk Harold Lane##18218
		..turnin Talbuk Mastery (2)##9858
		.talk Hemet Nesingwary##18180
		..turnin Clefthoof Mastery (2)##9850
		.talk Shado "Fitz" Farstrider##18200
		..turnin Windroc Mastery (2)##9855
	step //1875
		goto 70.8,51.2
		.' Go inside the hut
		.' Use the Living Fire in your bags |use Living Fire##24467
		.' Destroy the Western Hut |q 9805/2
	step //1876
		goto 72.4,50.3
		.' Go inside the hut
		.' Use the Living Fire in your bags |use Living Fire##24467
		.' Destroy the Large Hut |q 9805/1
	step //1877
		goto 72.8,54.7
		.' Go inside the hut
		.' Use the Living Fire in your bags |use Living Fire##24467
		.' Destroy the Eastern Hut |q 9805/4
	step //1878
		goto 71.2,53.2
		.' Go inside the hut
		.' Use the Living Fire in your bags |use Living Fire##24467
		.' Destroy the Southern Hut |q 9805/3
	step //1879
		goto 60.5,22.4
		.talk Elementalist Lo'ap##18073
		..turnin Blessing of Incineratus##9805
		..accept The Spirit Polluted##9810
	step //1880
		goto 72.1,69.9
		.' Use your Mag'har Battle Standard next to the bonfire |use Mag'har Battle Standard##25458
		.' Place the First Battle Standard |q 9910/1
	step //1881
		goto 74.7,69.8
		.' Use your Mag'har Battle Standard next to the bonfire |use Mag'har Battle Standard##25458 |tip Up the hill on the middle ledge, overlooking the camp.
		.' Place the Second Battle Standard |q 9910/2
	step //1882
		goto 75.8,68.4
		.' Use your Mag'har Battle Standard next to the bonfire |use Mag'har Battle Standard##25458 |tip All the way up the hill.
		.' Place the Third Battle Standard |q 9910/3
	step //1883
		goto 72.9,69.8
		.kill 8 Boulderfist Mystic##17135+ |q 9906/1
		.kill 8 Boulderfist Crusher##17134+ |q 9906/2
	step //1884
		goto 55.5,37.6
		.talk Jorin Deadeye##18106
		..turnin Message in a Battle##9906
		..accept An Audacious Advance##9907
	step //1885
		goto 55.5,37.6
		.talk Elkay'gan the Mystic##18300
		..turnin Standards and Practices##9910
		..accept Bleeding Hollow Supply Crates##9916
	step //1886
		goto 40.8,31.5
		.kill 10 Boulderfist Warrior##17136+ |q 9907/1
		.kill 10 Boulderfist Mage##17137+ |q 9907/2
		.click Bleeding Hollow Supply Crate##5531
		.get 10 Bleeding Hollow Supply Crate |q 9916/1 |tip They look like wooden boxes with a red symbol on the side of them.  There are a lot of them inside the cave.
	step //1887
		goto 33.8,48.9
		.kill 8 Lake Surger##17155+ |q 9810/2
	step //1888
		goto 33.1,50.8
		.kill Watoosun's Polluted Essence##18145 |q 9810/1 |tip He's underwater.
	step //1889
		goto 27.9,77.6
		.' Use Gordawg's Boulder on Shattered Rumblers |use Gordawg's Boulder##24501
		.' Kill the Minions of Gurok that spawn from their corpses
		.kill 30 Minion of Gurok##18181+ |q 9849/1
	step //1890
		'Hearth to Garadar |goto Nagrand,56.7,34.6,0.5 |use Hearthstone##6948 |noway |c
	step //1891
		goto 55.5,37.6
		.talk Elkay'gan the Mystic##18300
		..turnin Bleeding Hollow Supply Crates##9916
	step //1892
		goto 55.5,37.6
		.talk Jorin Deadeye##18106
		..turnin An Audacious Advance##9907
		..accept Diplomatic Measures##10107
	step //1893
		goto 73.8,68.1 |n
		.' The path up to Lantressor of the Blade starts here |goto 73.8,68.1,0.5 |noway |c
	step //1894
		goto 73.8,62.6
		.talk Lantresor of the Blade##18261
		.' Listen to his story
		.' Hear the story of the Blademaster |q 10107/1
		..turnin Diplomatic Measures##10107
		..accept Armaments for Deception##9928
		..accept Ruthless Cunning##9927
	step //1895
		goto 71.1,82.4
		.kill Giselda the Crone##18391 |q 9935/1 |tip Inside the big circle building, in the middle.
	step //1896
		goto 71.4,79.4
		.click the Kil'sorrow Armaments##6959 |tip They look like skinny, square, tan boxes on the ground with a red axe logo on them.
		.click Kil'sorrow Armaments##6959
		.get 10 Kil'sorrow Armaments |q 9928/1
		.from Kil'sorrow Deathsworn##17148, Kil'sorrow Cultist##17147, Kil'sorrow Spellbinder##17146
		.' Kill 10 Kil'sorrow Agents |q 9935/2
		.' Use your Warmaul Ogre Banner on their corpses |use Warmaul Ogre Banner##25552
		.' Plant 10 Warmaul Ogre Banners |q 9927/1
	step //1897
		goto 73.8,62.6
		.talk Lantresor of the Blade##18261
		..turnin Armaments for Deception##9928
		..turnin Ruthless Cunning##9927
		..accept Returning the Favor##9931
		..accept Body of Evidence##9932
	step //1898
		goto 55.8,38
		.talk Warden Bullrok##18407
		..turnin Wanted: Giselda the Crone##9935
	step //1899
		goto 61.8,24.4
		.talk Gordawg##18099
		..turnin Shattering the Veil##9849
	step //1900
		goto 60.5,22.4
		.talk Elementalist Lo'ap##18073
		..turnin The Spirit Polluted##9810
	step //1901
		goto 46.5,24.3
		.from Warmaul Shaman##18064+, Warmaul Reaver##17138+
		.' Use your Kil'sorrow Banner on their copses |use Kil'sorrow Banner##25555
		.' Plant 10 Kil'sorrow Banners |q 9931/1
		.' Use the Damp Woolen Blanket on the Blazing Warmaul Pyre |use Damp Woolen Blanket##25658 |tip It looks like a big burning bonfire.
		.' Defend the 2 ogres that spawn until they finish placing corpses around
		.' Plant the Kil'sorrow Bodies |q 9932/1
	step //1902
		goto 73.8,62.6
		.talk Lantressor of the Blade##18261
		..turnin Returning the Favor##9931
		..turnin Body of Evidence##9932
		..accept Message to Garadar##9934
	step //1903
		'Hearth to Garadar |goto Nagrand,56.7,34.6,0.5 |use Hearthstone##6948 |noway |c
	step //1904
		goto 55.5,37.6
		.talk Garrosh##18063
		..turnin Message to Garadar##9934
	step //1905
		goto Nagrand,55.8,38.0
		.talk Warden Bullrok##18407
		..accept Wanted: Durn the Hungerer##9937
	step //1906
		goto 55.2,36.1
		.talk Matron Celestine##18301
		..accept He Called Himself Altruis...##9983
	step //1907
		.' The next few quests are meant to be _group quests_. If you are not high level, you may need at least _3 people_ for these quests.
		.' Click here to proceed |confirm always
	step //1908
		map Nagrand
		path follow loose;loop;ants curved
		path	46.7,63.7	40.8,63.5	37.4,62.1
		path	34.0,62.7	31.7,65.4	30.5,71.3
		path	32.0,75.9	35.5,78.5	39.8,78.7
		path	42.4,75.5	46.0,70.2
		.' Follow the path around this are to look for _Durn the Hungerer_
		.kill Durn the Hungerer##18411 |q 9937/1
	step //1909
		goto 27.3,43.1
		.talk Altruis the Sufferer##18417
		..turnin He Called Himself Altruis...##9983 
		..accept Survey the Land##9991 |tip You will fly around on a drake to view The Twilight Ridge.
		..turnin Survey the Land##9991
		..accept Buying Time##9999
	step //1910
		goto 25.2,38.3
		.kill 2 Felguard Legionnaire##17152+ |q 9999/1
		.kill 3 Mo'arg Engineer##16945+ |q 9999/2
		.kill 8 Gan'arg Tinkerer##17151+ |q 9999/3
	step //1911
		goto 27.3,43.1
		.talk Altruis the Sufferer##18417
		..turnin Buying Time##9999
		..accept The Master Planner##10001
	step //1912
		goto Nagrand,17.5,50.3
		.from Mo'arg Master Planner##18567
		.get The Master Planner's Blueprints |q 10001/1
		.' You can also find the Mater Planner around [23.3,35.4]
	step //1913
		goto 27.3,43.1
		.talk Altruis the Sufferer##18417
		..turnin The Master Planner##10001
		..accept Patience and Understanding##10004
	step //1914
		goto 32.3,36.2
		.talk Elder Yorley##18414
		..accept Cho'war the Pillager##9946
	step //1915
		goto Nagrand,25.8,13.8
		.' Follow the path up and around 
		.from Cho'war the Pillager##18423
		.get Head of Cho'war |q 9946/1
	step //1916
		goto 27.2,18.7 |n
		.' Leave the Cave here |goto 27.2,18.7,0.5 |noway |c
	step //1917
		goto 32.3,36.2
		.talk Elder Yorley##18414
		..turnin Cho'war the Pillager##9946
	step //1918
		goto Nagrand,55.8,38.0
		.talk Warden Bullrok##18407
		..turnin Wanted: Durn the Hungerer##9937
	step //1919
		|fly Shattrath
	step //1920
		goto Shattrath City,77.3,34.9
		.talk Sal'salabim##18584
		.' Tell him "Altruis sent me. He said that you could help me." |tip He will immediately start attacking you!
		.' Persuad Sal'salabim |q 10004/1
	step //1921
		goto Shattrath City,77.3,34.9
		.talk Sal'salabim##18584
		..turnin Patience and Understanding##10004
		..accept Crackin' Some Skulls##10009
	step //1922
		goto 75.0,31.5
		.talk Raliq the Drunk##18585
		.' Tell him you are here to collect a dept, pay up or you're going to have to hurt him. |tip He will immediately start attacking you!
		.' Collect Raliq's Debt |q 10009/1
	step //1923
		goto Zangarmarsh,80.9,91.1
		.talk Coosh'coosh##18586
		.' Tell him you are here to collect a dept, pay up or you're going to have to hurt him. |tip He will immediately start attacking you!
		.' Collect Coosh'coosh's Debt |q 10009/2
	step //1924
		goto Terokkar Forest,27.2,58.1
		.talk Floon##18588
		.' Tell him you are here to collect a dept, pay up or you're going to have to hurt him. |tip He will immediately start attacking you!
		.' Collect Floon's Debt |q 10009/3
	step //1925
		goto 77.3,34.9
		.talk Sal'salabim##18584
		..turnin Crackin' Some Skulls##10009
		..accept It's Just That Easy?##10010
	step //1926
		|fly Garadar
	step //1927
		goto Nagrand,27.3,43.1
		.talk Altruis the Sufferer##18417
		..turnin It's Just That Easy?##10010
		..accept Forge Camp: Annihilated##10011
	step //1928
		goto Nagrand,25.0,36.1
		.from "Demos\,\ Overseer of Hate##18535"
		.collect Fel Cannon Activator##25770 |n
		.' Use the Fel Cannon Activator in your bags |use Fel Cannon Activator##25770
		.' Destroy Forge Camp: Hate |q 10011/1
	step //1929
		goto 19.6,51.1
		.from "Xirkos\,\ Overseer of Fear##18536"
		.collect Fel Cannon Activator##25771 |n
		.' Use the Fel Cannon Activator in your bags |use Fel Cannon Activator##25771
		.' Destoy Forge Camp: Fear |q 10011/2
	step //1930
		goto 27.3,43.1
		.talk Altruis the Sufferer##18417
		..turnin Forge Camp: Annihilated##10011
	step //1931
		.' Once you have completed the above quests, you will have to grind your way to exalted.
		.' Click to proceed. |confirm always
	step //1932
	label	"bead_grind"
		goto Nagrand,48.9,22.7
		.from Warmaul Reaver##17138+, Warmaul Shaman##18064+
		..collect Obsidian Warbeads##25433 |n
		.' If you are fresh into revered, you will need 420 beads to get 21,000 reputation points.
		.' Collect beads in sets of 10.
		.' Click here when you're ready to turn in. |confirm always
	step //1933
	label	"turn_in"
		goto Nagrand,55.8,37.9
		.talk Warden Bullrok##18407
		..accept More Warbeads##10478 |n     
		.' Click here to go back to farming. |next "bead_grind" |confirm |only if rep("The Mag'har")<=Revered
		.' Earn Exalted status with The Mag'har |condition rep("The Mag'har")==Exalted |next "exalted"
	step //1934
	label exalted
		.' Congratulations, you are now Exalted with The Mag'har! |condition rep("The Mag'har")==Exalted
]])
ZygorGuidesViewer:RegisterInclude("H_Therazane_PreQuest", [[
		goto Orgrimmar,49.7,76.5
		.' Click the Warchief's Command Board |tip It looks like a wooden board hanging between 2 wooden posts, with papers pinned on it.
		..accept Warchief's Command: Deepholm!##27722
	step //1935
		goto 50.5,38.4
		.talk Farseer Krogar##45244
		..turnin The War Has Many Fronts##27442
		..turnin Warchief's Command: Deepholm!##27722
		..accept The Maelstrom##27203
	step //1936
		goto 50.1,37.8
		.' Click the Portal to the Maelstrom |tip It looks like a swirling green portal.
		.' Teleport to The Maelstrom |goto The Maelstrom |noway |c
	step //1937
		goto The Maelstrom,33.4,50.2
		.talk Thrall##45042
		..turnin The Maelstrom##27203
		..accept Deepholm, Realm of Earth##27123
	step //1938
		goto 32.5,52.0
		.' Click the Wyvern |tip It looks like a wind rider flying in place.
		.' You will fly into Deepholm |goto Deepholm,49.9,54.7,0.5 |noway |c
	step //1939
		goto Deepholm,49.6,53.0
		.talk Maruut Stonebinder##43065
		..turnin Deepholm, Realm of Earth##27123
		..accept Gunship Down##26245
	step //1940
		goto 49.7,52.9
		.talk Seer Kormo##43397
		..accept Elemental Energy##27136
		..accept The Earth Claims All##26244
	step //1941
		goto 49.5,53.3
		.talk Earthcaller Yevaa##42573
		..accept Where's Goldmine?##26409
	step //1942
		goto 49.2,51.9
		.talk Caretaker Nuunwa##45300
		.home Temple of Earth
	step //1943
		goto 46.5,57.3
		.talk Initiate Goldmine##42574
		..turnin Where's Goldmine?##26409
		..accept Explosive Bonding Compound##26410
		..accept Something that Burns##27135
	step //1944
		goto 45.5,57.9
		.from Rockslice Flayer##42606+
		.get 5 Quartzite Resin |q 26410/1
	step //1945
		goto 46.5,57.3
		.talk Initiate Goldmine##42574
		..turnin Explosive Bonding Compound##26410
	step //1946
		goto 51.1,61.6
		.' Use your Depleted Totem |use Depleted Totem##60835
		.from Lodestone Elemental##43258+, Energized Geode##43254+ |tip Kill them next to your Depleted Totems.
		.' Energize the Totem 8 Times |q 27136/1
	step //1947
		goto 52.0,58.9
		.' Use Goldmine's Fire Totem in the red lava spot |use Goldmines's Fire Totem##60834
		.from Magmatooth##45099
		.get The Burning Heart |q 27135/1
	step //1948
		goto 49.7,52.9
		.talk Seer Kormo##43397
		..turnin Elemental Energy##27136
	step //1949
		goto 46.5,57.3
		.talk Initiate Goldmine##42574
		..turnin Something that Burns##27135
		..accept Apply and Flash Dry##26411
	step //1950
		goto 46.6,57.2
		.' Use your Explosive Bonding Compound on Flint Oremantle |use Explosive Bonding Compound##58502 |tip He's laying on the ground next to Initiate Goldmine.
		.' Apply the Explosive Bonding Compound |q 26411/1
	step //1951
		goto 46.5,57.3
		.talk Initiate Goldmine##42574
		..turnin Apply and Flash Dry##26411
		..accept Take Him to the Earthcaller##26413
	step //1952
		goto 49.5,53.3
		.' Introduce Flint Oremantle to Earthcaller Yevaa |q 26413/1
	step //1953
		goto 49.5,53.3
		.talk Earthcaller Yevaa##42573
		..turnin Take Him to the Earthcaller##26413
		..accept To Stonehearth's Aid##26484
	step //1954
		goto 56.1,74.2
		.' Click the Slain Cannoneer |tip It looks like a dead orc on the deck of the crashed zeppelin, laying next to a pile of cannon balls and a cannon.
		.' Receive the Second Clue |q 26245/2
	step //1955
		goto 53.5,73.8
		.' Click Captain Skullshatter |tip He's a dead orc laying on the ground next to a small round table in a side room on the deck of the crashed zeppelin.
		.' Receive the First Clue |q 26245/1
	step //1956
		goto 53.6,73.8
		.' Click the Captain's Log |tip It's a gray book laying on the small round table next to Captain Skullshatter.
		..accept Captain's Log##26246
	step //1957
		goto 56.7,76.4
		.' Click the Unexploded Artillery Shell |tip It looks like a metal casing, or bullet type of object laying on the ground underneath the crashed zeppelin.  You can get to it by flying in the 3 open side doors on the north side of the crashed zeppelin.
		.' Receive the Third Clue |q 26245/3
	step //1958
		goto 55.9,74.9
		.kill 5 Deepstone Elemental |q 26244/1
	step //1959
		goto 49.6,52.9
		.talk Maruut Stonebinder##43065
		..turnin Gunship Down##26245
		..turnin Captain's Log##26246
	step //1960
		goto 49.7,52.9
		.talk Seer Kormo##43397
		..turnin The Earth Claims All##26244
	step //1961
		goto 49.6,53.0
		.talk Maruut Stonebinder##43065
		..accept Diplomacy First##26247
	step //1962
		goto 62.4,52.6
		.talk Stormcaller Mylra##42684
		..turnin Diplomacy First##26247
		..accept All Our Friends Are Dead##26248
		..accept The Admiral's Cabin##26249
	step //1963
		'All around on this airship:
		.' Use your Spirit Totem on Slain Crew Members |use Spirit Totem##58167 |tip They look like dead Alliance soldiers all over this airship.
		.' Receive 6 Slain Crew Member Information |q 26248/1
	step //1964
		'Enter the doorway on the main deck of the airship:
		.talk First Mate Moody##43082
		..turnin The Admiral's Cabin##26249
		..accept Without a Captain or Crew##26427
	step //1965
		'Leave through the doorway and immediately turn right:
		.' Click the Bottle of Whiskey |tip It's a yellow bottle sitting on the edge of a small life boat on the side of the airship.
		.get Bottle of Whiskey |q 26427/1
	step //1966
		'All around on the deck of the airship:
		.' Click a Spool of Rope |tip They are coiled up ropes laying all around on the deck of the airship.
		.get Spool of Rope |q 26427/2
	step //1967
		'Enter the doorway on the main deck of the airship:
		.talk First Mate Moody##43082
		..turnin Without a Captain or Crew##26427
	step //1968
		'Go to the very top of the airship:
		.talk Stormcaller Mylra##42684
		..turnin All Our Friends Are Dead##26248
		..accept Take No Prisoners##26251
		..accept On Second Thought, Take One Prisoner##26250
	step //1969
		'Go onto the main deck of the ship and go down the stairs to the deck below:
		.' Fight Mor'norokk the Hateful until he surrenders |tip He's downstairs in the airship, in the very back of the first level you come to.
		.talk Mor'norokk the Hateful##42801
		.' Subdue Mor'norokk the Hateful |q 26250/1
	step //1970
		'All around on this lower deck of the airship:
		.kill 6 Twilight Saboteur |q 26251/1
	step //1971
		'Go to the very top of the airship:
		.talk Stormcaller Mylra##42684
		..turnin Take No Prisoners##26251
		..turnin On Second Thought, Take One Prisoner##26250
		..accept Some Spraining to Do##26254
	step //1972
		Next to Stormcaller Mylra:
		.' Click Stormbeak |tip It's a gryphon flying in place next to the airship.
		.' Interrogate Mok'norrok |q 26254/1
	step //1973
		'When you land on the airship again:
		.talk Stormcaller Mylra##42684
		..turnin Some Spraining to Do##26254
		..accept Return to the Temple of Earth##26255
	step //1974
		'Hearth to Temple of Earth |goto 49.2,51.9,0.5 |use Hearthstone##6948 |noway |c
	step //1975
		goto 49.6,53.0
		.talk Maruut Stonebinder##43065
		..turnin Return to the Temple of Earth##26255
		..accept Deathwing's Fall##26258
	step //1976
		goto 49.7,52.9
		.talk Seer Kormo##43397
		..accept Blood of the Earthwarder##26259
	step //1977
		goto 59.4,58.2
		.' Go to this spot
		.' Reach Deathwing's Fall |q 26258/1
		.' Click the Quest Complete box that displays on the right side of the screen under your minimap
		..turnin Deathwing's Fall##26258
		..accept Bleed the Bloodshaper##26256
	step //1978
		goto 61.5,60.6
		.from Twilight Bloodshaper##43218+
		.get Twilight Orders |q 26256/1
		.' Click the Quest Complete box that displays on the right side of the screen under your minimap
		..turnin Bleed the Bloodshaper##26256
		..accept Question the Slaves##26261
	step //1979
		goto 62.8,59.5
		.' Click the Slavemaster's Coffer |tip It looks like a small wooden chest on the ground inside a red tent.
		.collect Twilight Slaver's Key##60739 |q 26261
	step //1980
		goto 61.2,60.1
		.from Living Blood##43123+
		.get 5 Blood of Neltharion |q 26259/1
	step //1981
		goto 64.5,65.5
		.' Click Ball and Chains |tip They are attached to the feet of the Enslaved Miners around this area.
		.' Free 6 Enslaved Miners |q 26261/1
		.' Click the Quest Complete box that displays on the right side of the screen under your minimap
		..turnin Question the Slaves##26261
		..accept The Forgemaster's Log##26260
	step //1982
		goto 63.7,55.4
		.' Click the Forgemaster's Log |tip It's a blue-ish book laying on the floor at the very top of this tower.
		..turnin The Forgemaster's Log##26260
		..accept Silvermarsh Rendezvous##27007
	step //1983
		goto 70.6,61.2
		.' Go to this spot
		.' Reach Upper Silvermarsh |q 27007/1
		.' Click the Quest Complete box that displays on the right side of the screen under your minimap
		..turnin Silvermarsh Rendezvous##27007
		..accept Quicksilver Submersion##27010
	step //1984
		goto 71.8,64.3
		.' Click the Trogg Crate |tip It's a brown box sitting next to the water.
		.collect Trogg Crate##60809 |q 27010
		.from Murkstone Trogg##44936
		.collect Maziel's Research##60816 |n
		.' Click Maziel's Research in your bags |use Maziel's Research##60816
		..accept Twilight Research##27100
	step //1985
		goto 74.9,64.8
		.' Use your Trogg Crate in the water and swim to this spot |use Trogg Crate##60809
		.' Watch the dialogue
		.' Uncover the World Pillar Fragment Clue |q 27010/1
		.' Click the Quest Complete box that displays on the right side of the screen under your minimap
		..turnin Quicksilver Submersion##27010
		..accept The Twilight Overlook##27061
	step //1986
		goto 72.5,65.2
		.from Mercurial Ooze##43158+
		.get 4 Twilight Research Notes |q 27100/1
		.' Click the Quest Complete box that displays on the right side of the screen under your minimap
		..turnin Twilight Research##27100
		..accept Maziel's Revelation##27101
	step //1987
		goto 67.2,70.2
		.' Click Maziel's Journal |tip It looks like a small black book laying on the ground on this tiny island in a pond, next to a big rock.
		..turnin Maziel's Revelation##27101
		..accept Maziel's Ascendancy##27102
	step //1988
		goto 69.5,68.0 |n
		.' Enter the cave |goto 69.5,68.0,0.5 |noway |c
	step //1989
		goto 72.8,62.0
		.kill Maziel |q 27102/1
		.' Click the Quest Complete box that displays on the right side of the screen under your minimap
		..turnin Maziel's Ascendancy##27102
	step //1990
		goto 69.5,68.0 |n
		.' Leave the cave |goto 69.5,68.0,0.5 |noway |c	
	step //1991
		goto 64.5,82.1
		.talk Stormcaller Mylra##44010
		..turnin The Twilight Overlook##27061
		..accept Big Game, Big Bait##26766
		..accept To Catch a Dragon##26768
	step //1992
		goto 68.2,77.9
		.from Scalesworn Cultist##44221+
		.get Twilight Snare |q 26768/1
	step //1993
		goto 64.5,82.1
		.talk Stormcaller Mylra##44010
		..turnin To Catch a Dragon##26768
	step //1994
		goto 59.9,83.6
		.from Jadecrest Basilisk##43981+
		.' Use Mylra's Knife on Jadefire Basilisk corpses |use Mylra's Knife##60382
		.get 5 Side of Basilisk Meat |q 26766/1 
	step //1995
		goto 64.5,82.1
		.talk Stormcaller Mylra##44010
		..turnin Big Game, Big Bait##26766
		..accept Testing the Trap##26771
	step //1996
		goto 50.9,85.3
		.' Use your Trapped Basilisk Meat |use Trapped Basilisk Meat##60773
		.kill Stonescale Matriarch |q 26771/1
	step //1997
		goto 64.5,82.1
		.talk Stormcaller Mylra##44010
		..turnin Testing the Trap##26771
		..accept Abyssion's Minions##26857
	step //1998
		goto 64.6,82.2
		.talk Seer Galekk##44222
		..accept Block the Gates##26861
	step //1999
		goto 68.7,75.0
		.' Use your Stormstone next to the swirling blue portal |use Stormstone##60501
		.' Disrupt the Twilight Gate |q 26861/1
	step //2000
		goto 71.2,75.1
		.' Use your Stormstone next to the structure with the floating yellow crystal |use Stormstone##60501
		.' Disrupt the Elemental Gate |q 26861/2
	step //2001
		goto 69.9,76.7
		.from Scalesworn Cultist##44221+, Twilight Scalesister##43967+, Twilight Dragonspawn##43966+
		.' Defeat 8 Abyssion's Underlings |q 26857/1
	step //2002
		goto 64.6,82.2
		.talk Seer Galekk##44222
		..turnin Block the Gates##26861
	step //2003
		goto 64.5,82.2
		.talk Stormcaller Mylra##44010
		..turnin Abyssion's Minions##26857
		..accept The World Pillar Fragment##26876
	step //2004
		goto 69.9,76.9
		.' Use your Earthen Ring Banner |use Earthen Ring Banner##60810
		.from Abyssion##
		.' Click The First Fragment of the World Pillar |tip It's a floating green rock that appears after you kill Abyssion.
		.get The Upper World Pillar Fragment |q 26876/1
	step //2005
		'Hearth to Temple of Earth |goto 49.2,51.9,0.5 |use Hearthstone##6948 |noway |c
	step //2006
		goto 49.6,53.0
		.talk Maruut Stonebinder##43065
		..turnin The World Pillar Fragment##26876
	step //2007
		goto 49.7,52.9
		.talk Seer Kormo##43397
		..turnin Blood of the Earthwarder##26259
	step //2008
		goto 27.9,68.7
		.talk Crag Rockcrusher##43071
		..turnin To Stonehearth's Aid##26484
		..accept The Quaking Fields##27931
	step //2009
		goto 30.6,77.7
		.talk Slate Quicksand##47195
		..turnin The Quaking Fields##27931
		..accept The Axe of Earthly Sundering##27932
		..accept Elemental Ore##27933
	step //2010
		goto 32.2,79.1
		.' Use The Axe of Earthly Sundering on Emerald Colossi |use The Ace of Earthly Sundering##60490 |tip They look like glowing giants that walk around this area.
		.kill 5 Sundered Emerald Colossus |q 27932/1 
		.from Jade Rager##44220+
		.get 6 Elemental Ore |q 27933/1
	step //2011
		goto 30.6,77.7
		.talk Slate Quicksand##47195
		..turnin The Axe of Earthly Sundering##27932
		..turnin Elemental Ore##27933
		..accept One With the Ground##27934
	step //2012
		goto 30.6,77.7
		.talk Slate Quicksand##47195
		..' Tell him you are ready for the ritual
		.' Complete the One With the Ground Ritual |q 27934/1
		.' Click the Quest Complete box that displays on the right side of the screen under your minimap
		..turnin One With the Ground##27934
		..accept Bring Down the Avalanche##27935
	step //2013
		goto 46.9,89.1
		.kill Avalanchion |q 27935/1
	step //2014
		goto 43.4,82.0 |n
		.' Leave the cave |goto 43.4,82.0,0.5 |noway |c
	step //2015
		goto 27.9,68.7
		.talk Crag Rockcrusher##43071
		..turnin Bring Down the Avalanche##27935
		..accept Stonefather's Boon##26499
	step //2016
		goto 28.2,69.6
		.talk Earthbreaker Dolomite##43160
		..accept We're Surrounded##26500
	step //2017
		goto 29.7,68.8
		kill 12 Stone Trogg Ambusher |q 26500/1
		.' Use Stonefather's Banner next to Stone Hearth Defenders |use Stonefather's Banner##58884 |tip They look like dwarves.  Stonefather's Banner won't work on the Stone Hearth Defenders if they already have the Stonefather's Boon buff.
		.' Grant the Stonefather's Boon 12 times |q 26499/1
	step //2018
		goto 28.2,69.6
		.talk Earthbreaker Dolomite##43160
		..turnin We're Surrounded##26500
		..accept Thunder Stones##26502
	step //2019
		goto 27.9,68.7
		.talk Crag Rockcrusher##43071
		..turnin Stonefather's Boon##26499
		..accept Sealing the Way##26501
	step //2020
		goto 27.3,67.8
		.' Use your Rockslide Reagent on the Earthen Geomancer |use Rockslide Reagent##58885 |tip They must be out of combat for it to work, so kill any troggs attacking the Earthen Geomancer.
		.' Seal the Shrine |q 26501/4
	step //2021
		goto 26.0,68.8
		.' Use your Rockslide Reagent on the Earthen Geomancer |use Rockslide Reagent##58885 |tip They must be out of combat for it to work, so kill any troggs attacking the Earthen Geomancer.
		.' Seal the Barracks |q 26501/3
	step //2022
		goto 26.2,69.8
		.' Use your Rockslide Reagent on the Earthen Geomancer |use Rockslide Reagent##58885 |tip They must be out of combat for it to work, so kill any troggs attacking the Earthen Geomancer.
		.' Seal the Inn |q 26501/2
	step //2023
		goto 27.3,70.1
		.' Use your Rockslide Reagent on the Earthen Geomancer |use Rockslide Reagent##58885 |tip They must be out of combat for it to work, so kill any troggs attacking the Earthen Geomancer.
		.' Seal the Armory |q 26501/1
		.' Click Thunder Stones |tip They looks like blue round spiked cannonballs on the ground and in wagons around this area.
		.get 12 Thunder Stone |q 26502/1 
	step //2024
		goto 24.5,62.4
		.talk Gravel Longslab##43168
		..turnin Sealing the Way##26501
		..accept Shatter Them!##26537
	step //2025
		goto 24.8,62.2
		.talk Clay Mudaxle##43169
		..turnin Thunder Stones##26502
		..accept Fixer Upper##26564
	step //2026
		goto 24.6,62.2
		.talk Earthmender Deepvein##43319
		..accept Battlefront Triage##26591
	step //2027
		goto 23.9,60.3
		.' Use Deepvein's Patch Kit on Injured Earthens |use Deepvein's Patch Kit##58965 |tip They look like dwarves laying on the ground around this area.
		.' Patch up 10 Injured Earthen |q 26591/1
		.' Click Catapult Parts |tip They look kind of like big metal parts laying on the ground around this area.
		.get 6 Catapult Part |q 26564/1 
		.from Stone Trogg Berserker##43228+, Stone Trogg Geomancer##43234+, Needlerock Rider##43250+
		.kill 12 Fractured Battlefront stone troggs |q 26537/1
	step //2028
		goto 24.5,62.4
		.talk Gravel Longslab##43168
		..turnin Shatter Them!##26537
	step //2029
		goto 24.6,62.2
		.talk Earthmender Deepvein##43319
		..turnin Battlefront Triage##26591
	step //2030
		goto 24.8,62.2
		.talk Clay Mudaxle##43169
		..turnin Fixer Upper##26564
	step //2031
		goto 24.5,62.4
		.talk Gravel Longslab##43168
		..accept Troggzor the Earthinator##26625
	step //2032
		goto 22.6,56.9
		.from Troggzor the Earthinator##43456
		.get The Earthinator's Cudgel |q 26625/1 
	step //2033
		goto 24.5,62.4
		.talk Gravel Longslab##43168
		..turnin Troggzor the Earthinator##26625
	step //2034
		goto 24.8,62.2
		.talk Clay Mudaxle##43169
		..accept Rush Delivery##27126
	step //2035
		goto 20.7,61.6
		.talk Peak Grindstone##45043
		..turnin Rush Delivery##27126
		..accept Close Escort##26632
	step //2036
		goto 20.7,61.6
		.talk Peak Grindstone##45043
		..' Tell him you're ready to escort the catapult
		.' Safely Escort the Earthen Catapult |q 26632/1
	step //2037
		goto 22.7,52.0
		.talk Pyrium Lodestone##43897
		..turnin Close Escort##26632
		..accept Keep Them off the Front##26755
	step //2038
		goto 22.4,52.0
		.' Click an Earthen Catapult |tip They look like wooden launchers with stone wheels.
		.' Use your Fire Catapult ability on your hotbar on the Stone Trogg and Fungal mobs
		.' Bombarb 30 Reinforcements |q 26755/1
	step //2039
		goto 22.7,52.0
		.talk Pyrium Lodestone##43897
		..turnin Keep Them off the Front##26755
		..accept Reactivate the Constructs##26762
	step //2040
		goto 22.8,52.1
		.talk Flint Oremantle##43898
		..accept Mystic Masters##26770
	step //2041
		goto 22.6,47.6
		.' Click Deactivated War Construct |tip They look like metal golems around this area.
		.' Reactivate 5 Deactivated War Constructs |q 26762/1
		.kill 5 Needlerock Mystic |q 26770/1
	step //2042
		goto 22.8,52.1
		.talk Flint Oremantle##43898
		..turnin Mystic Masters##26770
	step //2043
		goto 22.7,52.0
		.talk Pyrium Lodestone##43897
		..turnin Reactivate the Constructs##26762
		..accept Down Into the Chasm##26834
	step //2044
		goto 27.6,44.8
		.talk Slate Quicksand##44143
		..turnin Down Into the Chasm##26834
		..accept Sprout No More##26791
		..accept Fungal Monstrosities##26792
	step //2045
		goto 27.6,44.7
		.' Click the War Guardian |tip It looks like a metal golem.
		.' Obtain a War Guardian for the Sprout No More quest |q 26791/1
		.' Obtain a War Guardian for the Fungal Monstrosities quest |q 26792/1
	step //2046
		goto 26.8,41.8
		.kill 5 Fungal Monstronsity |q 26792/2
		.' Click Giant Mushrooms |tip They look like huge mushrooms with orange caps around this area.
		.' Destroy 5 Giant Mushrooms |q 26791/2
	step //2047
		goto 27.6,44.8
		.talk Slate Quicksand##44143
		..turnin Sprout No More##26791
		..turnin Fungal Monstrosities##26792
		..accept A Slight Problem##26835
	step //2048
		goto 22.7,52.0
		.talk Pyrium Lodestone##43897
		..turnin A Slight Problem##26835
		..accept Rescue the Stonefather... and Flint##26836
	step //2049
		goto 24.5,31.1
		.from Bouldergut##44151
		.' Rescue Stonefather Oremantle |q 26836/1
	step //2050
		goto 22.7,52.0
		.talk Pyrium Lodestone##43897
		..turnin Rescue the Stonefather... and Flint##26836
		..accept The Hero Returns##27937
	step //2051
		goto 28.0,68.6
		.talk Stonefather Oremantle##44204
		..turnin The Hero Returns##27937
		..accept The Middle Fragment##27938
	step //2052
		goto 28.0,68.7
		.' Click The Stonefather's Safe |tip It looks like a metal vault door with gold circles and symbols on it.
		.get The Middle Fragment of the World Pillar |q 27938/1
	step //2053
		'Hearth to Temple of Earth |goto 49.2,51.9,0.5 |use Hearthstone##6948 |noway |c
	step //2054
		goto 49.5,53.3
		.talk Earthcaller Yevaa##42573
		..turnin The Middle Fragment##27938
	step //2055
		goto 49.6,53.0
		.talk Maruut Stonebinder##43065
		..accept The Very Earth Beneath Our Feet##26326
	step //2056
		goto 46.1,45.6
		.talk Earthcaller Torunscar##42730
		..turnin The Very Earth Beneath Our Feet##26326
		..accept Crumbling Defenses##26312
		..accept On Even Ground##26314
	step //2057
		goto 46.2,45.7
		.talk Earthmender Norsala##42731
		..accept Core of Our Troubles##26313
	step //2058
		goto 44.3,43.7
		.from Irestone Rumbler##42780+
		.' Use your Elementium Grapple Line on Servants of Therazane |use Elementium Grapple Line##58169 |tip Run away from the Servants of Therazane to bring them down.
		.' Relieve Stormcaller Mylra |q 26312/2
	step //2059
		goto 44.5,41.3
		.from Irestone Rumbler##42780+
		.' Use your Elementium Grapple Line on Servants of Therazane |use Elementium Grapple Line##58169 |tip Run away from the Servants of Therazane to bring them down.
		.' Relieve Tawn Winterbluff |q 26312/1
	step //2060
		goto 47.6,42.8
		.from Irestone Rumbler##42780+
		.' Use your Elementium Grapple Line on Servants of Therazane |use Elementium Grapple Line##58169 |tip Run away from the Servants of Therazane to bring them down.
		.' Relieve Hargoth Dimblaze |q 26312/3
	step //2061
		goto 46.2,42.2
		.from Irestone Rumbler##42780+
		.get 6 Irestone Core |q 26313/1
		.' Use your Elementium Grapple Line on Servants of Therazane |use Elementium Grapple Line##58169 |tip Run away from the Servants of Therazane to bring them down.
		.' Bring down 3 Servants of Therazane |q 26314/1
	step //2062
		goto 46.2,45.7
		.talk Earthmender Norsala##42731
		..turnin Core of Our Troubles##26313
	step //2063
		goto 46.1,45.6
		.talk Earthcaller Torunscar##42730
		..turnin Crumbling Defenses##26312
		..turnin On Even Ground##26314
	step //2064
		goto 46.2,45.7
		.talk Earthmender Norsala##42731
		..accept Imposing Confrontation##26315
	step //2065
		goto 49.2,40.1
		.' Use your Earthen Ring Proclamation on Boden the Imposing |use Earthen Ring Proclamation##58177 |tip He's a huge rock giant that walks around this area.
		.' Seek Peace with Boden the Imposing |q 26315/1
	step //2066
		goto 46.2,45.7
		.talk Earthmender Norsala##42731
		..turnin Imposing Confrontation##26315
		..accept Rocky Relations##26328
	step //2067
		goto 56.5,42.7
		.talk Diamant the Patient##42467
		..turnin Rocky Relations##26328
		..accept Hatred Runs Deep##26376
		..accept Unsolid Ground##26377
	step //2068
		goto 56.5,41.0
		.talk Quartz Stonetender##42899
		..accept Loose Stones##26375
	step //2069
		goto 60.2,39.4
		.kill Dragul Giantbutcher |q 26376/1
	step //2070
		goto 59.5,41.5
		.' Click Jade Crystal Clusters |tip They look like green glowing rocks sitting on the ground all around this area.
		.collect 6 Jade Crystal Cluster##58500 |q 26377
		.' Use your Delicate Chain Smasher next to Quartz Rocklings |use Delicate Chain Smasher##58254 |tip They look like small rock giants around this area.
		.' Release 6 Quartz Rocklings |q 26375/1
	step //2071
		'Use the Jade Crystal Clusters |use Jade Crystal Cluster##58500
		.collect Jade Crystal Composite##58783 |q 26377
	step //2072
		goto 59.6,41.4
		.' Use your Jade Crystal Composite |use Jade Crystal Composite##58783
		.' Lure an Agitated Tunneler |q 26377/1
	step //2073
		goto 59.3,40.6
		.from Twilight Laborer##42924+, Twilight Priestess##42823+, Twilight Duskwarden##42917+
		.kill 12 Lorthuna's Gate Cultists |q 26376/2 
	step //2074
		goto 56.5,41.0
		.talk Quartz Stonetender##42899
		..turnin Loose Stones##26375
	step //2075
		goto 56.5,42.7
		.talk Diamant the Patient##42467
		..turnin Hatred Runs Deep##26376
		..turnin Unsolid Ground##26377
		..accept Violent Gale##26426
	step //2076
		goto 51.7,31.6
		.' Get next to Felsen the Enduring |tip He's a big white rock giant.
		.' Find Felsen the Enduring |q 26426/1
	step //2077
		goto 58.4,25.7
		.' Fly to the mouth of this cave
		.' Find the entrance to the Crumbling Depths |q 26426/2
		.' Click the Quest Complete box that displays on the right side of the screen under your minimap
		..turnin Violent Gale##26426
		..accept Depth of the Depths##26869
	step //2078
		goto 64.5,21.7 |n
		.' Follow the path |goto 64.5,21.7,0.5 |noway |c
	step //2079
		goto 65.3,18.4 |n
		.' Follow the path |goto 65.3,18.4,0.5 |noway |c
	step //2080
		goto 66.4,20.6
		.' Click the Gigantic Painite Cluster |tip It looks like a green crystal cluster near the mouth of the cave.
		..turnin Depth of the Depths##26869
		..accept A Rock Amongst Many##26871
	step //2081
		goto 64.3,23.5
		.' Follow the path to this spot, then jump down |goto 64.3,23.5,0.5 |noway |c
	step //2082
		goto 58.3,25.5 |n
		.' Leave the cave |goto 58.3,25.5,0.5 |noway |c
	step //2083
		goto 56.5,42.7
		.talk Diamant the Patient##42467
		..turnin A Rock Amongst Many##26871
		..accept Entrenched##26436
	step //2084
		goto 34.3,34.3
		.talk Kor the Immovable##42469
		..turnin Entrenched##26436
		..accept Intervention##26438
		..accept Making Things Crystal Clear##26437
	step //2085
		goto 34.6,34.2
		.talk Berracite##43344
		..accept Putting the Pieces Together##26439
	step //2086
		goto 30.5,46.8
		.from Jaspertip Borer##42524+, Jaspertip Swarmer##42521+, Jaspertip Ravager##42525+, Jaspertip Crystal-gorger##43171+
		.kill 12 Jaspertip flayers |q 26438/1
		.' Click Chalky Crystal Formations |tip They look like big white blocks on the ground around this area.
		.get 8 Chalky Crystal Formation |q 26437/1 
		.' Click Dormant Stonebound Elementals |tip They look like crumbled rock elementals on the ground around this area.
		.' Reform 6 Stonebound Elementals |q 26439/1
	step //2087
		goto 34.3,34.3
		.talk Kor the Immovable##42469
		..turnin Intervention##26438
		..turnin Making Things Crystal Clear##26437
	step //2088
		goto 34.5,34.4
		.talk Berracite##43344
		..turnin Putting the Pieces Together##26439
	step //2089
		'Next to you:
		.talk Pebble##43116
		..accept Clingy##26440
	step //2090
		goto 30.1,47.7
		.' Get next to the huge green crystals
		.' Bring Pebble to the crystal formation |q 26440/1
	step //2091
		'Next to you:
		.talk Pebble##43116
		..turnin Clingy##26440
		..accept So Big, So Round...##26441
	step //2092
		goto 34.3,34.3
		.talk Kor the Immovable##42469
		..turnin So Big, So Round...##26441
		..accept Petrified Delicacies##26507
		..accept Rock Bottom##26575
	step //2093
		goto 47.6,26.8
		.kill Gorgonite |q 26575/1
	step //2094
		goto 47.5,26.8
		.' Click Petrified Stone Bats |tip They looks like black stone bats laying on the ground around this area.
		.get 12 Petrified Stone Bat |q 26507/1
	step //2095
		'Next to you:
		.talk Pebble##43116
		..turnin Petrified Delicacies##26507
	step //2096
		goto 34.3,34.3
		.talk Kor the Immovable##42469
		..turnin Rock Bottom##26575
		..accept Steady Hand##26576
		..accept Rocky Upheaval##26577
	step //2097
		goto 39.9,19.4
		.talk Terrath the Steady##42466
		..turnin Steady Hand##26576
		..accept Don't. Stop. Moving.##26656
	step //2098
		goto 39.9,19.4
		.talk Terrath the Steady##42466
		..' Tell him you are ready to escort a group of elementals across the open.
		.' Speak to Terrath the Steady |q 26656/1
	step //2099
		goto 51.1,14.7
		.' Go to this spot
		.' Escort 5 Opalescent Guardians to safety |q 26656/2 |tip Run on the ground with your mount, don't fly or you the rock elementals will disappear when you get too far away from them.
	step //2100
		goto 39.9,19.4
		.talk Terrath the Steady##42466
		..turnin Don't. Stop. Moving.##26656
		..accept Hard Falls##26657
		..accept Fragile Values##26658
	step //2101
		goto 35.4,22.5
		.from Stone Trogg Beast Tamer##43598 |tip He moves all around this area capturing basilisks, so you may need to look around a bit for him.
		.get Stonework Mallet |q 26658/1
	step //2102
		goto 39.9,19.4
		.talk Terrath the Steady##42466
		..turnin Fragile Values##26658
	step //2103
		goto 36.5,18.8
		.kill 6 Stone Drake |q 26657/1 |tip They will fall to the ground with half health, so you can kill them, even though they are elite.
	step //2104
		goto 40.0,19.4
		.talk Terrath the Steady##42466
		..turnin Hard Falls##26657
		..accept Resonating Blow##26659
	step //2105
		goto 32.7,24.3
		.' Use your Stonework Mallet next to the Pale Resonating Crystal |use Stonework Mallet##60266 |tip It's a huge green crystal sitting on the ground.
		.' Strike the Pale Resonating Crystal |q 26659/1
		.from Aeosera##43641 |tip Click the Boulder Platforms to jump from rock to rock while fighting Aeosera.  When she is casting her Breath Fire ability, jump to another rock and attack her while she is breathing fire to the other rock.  Repeat this until she surrenders.
		.' Defeat Aeosera |q 26659/2
	step //2106
		goto 33.1,24.1
		.talk Terrath the Steady##42466
		..turnin Resonating Blow##26659
	step //2107
		'Hearth to the Temple of Earth |goto 49.2,51.9,0.5 |use Hearthstone##6948 |noway |c
	step //2108
		goto 49.5,53.3
		.talk Earthcaller Yevaa##42573
		..accept The Reliquary##27953
	step //2109
		goto 51.3,50.1
		.talk Examiner Rowe##44823
		..turnin The Reliquary##27953
		..accept The Twilight Plot##27005
	step //2110
		goto 51.3,50.0
		.talk Reliquary Jes'ca Darksun##44818
		..accept Fly Over##27008
	step //2111
		goto 39.0,74.2
		.' Go to this spot next to the big white portal
		.' Investigate the Master's Gate |q 27008/1 
	step //2112
		goto 40.1,72.2
		.from Twilight Cryptomancer##44855+, Twilight Crusher##44849+, Twilight Armsman##44847+
		.get Masters' Gate Plans |q 27005/1
	step //2113
		goto 51.3,50.1
		.talk Examiner Rowe##44823
		..turnin The Twilight Plot##27005
	step //2114
		goto 51.3,50.0
		.talk Reliquary Jes'ca Darksun##44818
		..turnin Fly Over##27008
		..accept Fight Fire and Water and Air with...##27043
	step //2115
		goto 51.3,50.1
		.talk Examiner Rowe##44823
		..accept Decryption Made Easy##27041
	step //2116
		goto 40.8,66.3
		.from Bound Water Elemental##44886
		.' Acquire the Water Ward |q 27043/2
	step //2117
		goto 36.0,67.4
		.from Bound Fire Elemental##44887
		.' Acquire the Fire Ward |q 27043/1
	step //2118
		goto 40.5,72.4
		.from Bound Air Elemental##44885
		.' Acquire the Air Ward |q 27043/3
	step //2119
		goto 40.2,67.5
		.' Click One-Time Decryption Engines |tip They look like machines around this area with a circular scroll spinning around them, and yellow cores floating in the middle of the spinning scrolls.
		.' Decrypt 6 Plans |q 27041/1
		.' Click the Quest Complete box that displays on the right side of the screen under your minimap
		..turnin Decryption Made Easy##27041
		..accept The Wrong Sequence##27059
	step //2120
		goto 39.1,73.9
		.' Click the Waygate Controller |tip It looks like a cylinder stone container with a stone ring on top of it, sitting in front of the huge white portal.
		.' Destroy the Waygate |q 27059/1
	step //2121
		goto 39.9,62.2
		.kill Haethen Kaul |q 27043/4 |tip He's up on a huge floating rock.
	step //2122
		goto 51.3,50.0
		.talk Examiner Rowe##44823
		..turnin The Wrong Sequence##27059
		..accept That's No Pyramid!##28293
	step //2123
		goto 51.3,50.0
		.talk Reliquary Jes'ca Darksun##44818
		..turnin Fight Fire and Water and Air with...##27043
	step //2124
		goto 72.2,54.0
		.talk Gorsik the Tumultuous##42472
		..turnin Rocky Upheaval##26577
		..accept Doomshrooms##26578
		..accept Gone Soft##26579
		..accept Familiar Intruders##26580
	step //2125
		goto 71.8,47.6
		.talk Windspeaker Lorvarius##43395
		..turnin Familiar Intruders##26580
		..accept A Head Full of Wind##26581
	step //2126
		goto 73.6,40.8
		.kill 8 Fungal Behemoth |q 26579/1
		.from Doomshroom##+ |tip They look like orange mushrooms around this area.
		.' Destroy 10 Doomshrooms |q 26578/1
		.' Gather a sample of the red mist|q 26581/1 |tip There are small clouds of red mist that float around on the ground around this area.  Walk into one of them to gather a sample.
	step //2127
		goto 71.8,47.6
		.talk Windspeaker Lorvarius##43395
		..turnin A Head Full of Wind##26581
		..accept Unnatural Causes##26582
	step //2128
		goto 72.2,54.0
		.talk Gorsik the Tumultuous##42472
		..turnin Doomshrooms##26578
		..turnin Gone Soft##26579
		..turnin Unnatural Causes##26582
		..accept Shaken and Stirred##26584
		..accept Corruption Destruction##26585
	step //2129
		goto 68.5,26.4
		.talk Ruberick##43442
		..accept Wrath of the Fungalmancer##26583
	step //2130
		goto 68.6,29.1 |n
		.' Enter the cave |goto 68.6,29.1,0.5 |noway |c
	step //2131
		goto 69.8,31.9
		.talk Earthmender Norsala##43503
		..' Tell her you're ready when she is
		.kill Fungalmancer Glop |q 26583/2 |tip Follow him each time he runs away.  Avoid the mushrooms as you walk, they will give you a debuff.  While fighting Fungalmancer Glop, kill the Boomshrooms he creates.  Don't let them grow too big, they will explode and deal a lot of damage.
	step //2132
		goto 70.2,33.8 |n
		.' Follow the path up |goto 70.2,33.8,0.5 |noway |c
	step //2133
		goto 68.6,29.1 |n
		.' Leave the cave |goto 68.6,29.1,0.5 |noway |c
	step //2134
		goto 68.5,26.3
		.talk Ruberick##43442
		..turnin Wrath of the Fungalmancer##26583
	step //2135
		goto 69.4,24.8
		.kill 8 Verlok Pillartumbler |q 26584/1
		.' Click Verlok Miracle-grow |tip They look like gray bags sitting on the ground around this area.
		.get 8 Verlok Miracle-grow |q 26585/1
	step //2136
		goto 72.2,54.0
		.talk Gorsik the Tumultuous##42472
		..turnin Shaken and Stirred##26584
		..turnin Corruption Destruction##26585
		..accept At the Stonemother's Call##26750
	step //2137
		goto 56.3,12.2
		.talk Therazane##42465
		..turnin At the Stonemother's Call##26750
		..accept Audience with the Stonemother##26752
	step //2138
		'Watch the dialogue
		.' Attend the Stonemother's Audience |q 26752/1
	step //2139
		goto 56.1,13.5
		.talk Earthcaller Torunscar##43809
		..turnin Audience with the Stonemother##26752
		..accept Rallying the Earthen Ring##26827
	step //2140
		'Hearth to the Temple of Earth |goto 49.2,51.9,0.5 |use Hearthstone##6948 |noway |c
	step //2141
		goto 49.9,50.1
		.talk Hargoth Dimblaze##44644
		..' Tell him you are joining an assault on Lorthuna's Gate and he is needed.
		.' Skip to the next step in the guide
	step //2142
		goto 51.5,51.8
		.talk Stormcaller Jalara##44633
		..' Tell her you are joining an assault on Lorthuna's Gate and she is needed.
		.' Skip to the next step in the guide
	step //2143
		goto 49.9,50.1
		.talk Hargoth Dimblaze##44644
		..' Tell him you are joining an assault on Lorthuna's Gate and he is needed.
		.' Rally 5 Earthen Ring |q 26827/1
	step //2144
		goto 49.6,53.0
		.talk Maruut Stonebinder##43065
		..turnin Rallying the Earthen Ring##26827
		..accept Our Part of the Bargain##26828
	step //2145
		goto 63.3,25.0
		.talk Therazane##44025
		..turnin Our Part of the Bargain##26828
		..accept The Stone March##26829
		..accept Therazane's Mercy##26832
	step //2146
		goto 62.6,26.9
		.talk Boden the Imposing##44080
		..accept The Twilight Flight##26831
	step //2147
		goto 62.4,31.8
		.from High Priestess Lorthuna##42914 |tip She is in a small room on the top of this building.  She is elite, but you can still kill her.  She will run away when she is almost dead.
		.' Defeat High Priestess Lorthuna |q 26832/2
	step //2148
		goto 58.9,32.9
		.from Boldrich Stonerender##42923
		.' Defeat Boldrich Stonerender |q 26832/1
	step //2149
		goto 63.1,38.1
		.from Zoltrik Drakebane##42918 |tip You will eventually get on a stone drake and fly after Zoltrik Drakebane.  You can use your Jump ability to jump onto his drake, if you are a melee class.  Either way, you will land on a rock with him and kill him there.
		.' Defeat Zoltrik Drakebane |q 26831/1
	step //2150
		goto 64.1,36.9
		.talk Terrath the Steady##42614
		..turnin The Twilight Flight##26831
	step //2151
		goto 60.3,33.2
		.from Defaced Earthrager##44076+, Twilight Soulreaper##42916+, Twilight Priestess##42823+
		.kill 15 Twilight Precipice Cultists |q 26829/1
	step //2152
		goto 63.3,25.0
		.talk Therazane##44025
		..turnin The Stone March##26829
		..turnin Therazane's Mercy##26832
		..accept Word In Stone##26833
	step //2153
		goto 49.6,53.0
		.talk Maruut Stonebinder##43818
		..turnin Word In Stone##26833
		..accept Undying Twilight##26875
	step //2154
		goto 50.7,49.6
		.kill 12 Twilight Invaders |q 26875/1
		.kill Desecrated Earthrager |q 26875/2
		.' Click the Quest Complete box that displays on the right side of the screen under your minimap
		..turnin Undying Twilight##26875
		..accept The Binding##26971
	step //2155
		goto 49.6,52.9
		.kill High Priestess Lorthuna |q 26971/1 
	step //2156
		goto 49.6,52.9
		.talk Earthcaller Torunscar##43835
		..turnin The Binding##26971
	step //2157
		goto 49.8,53.4
		.talk Therazane##43792
		..accept The Stone Throne##26709
	step //2158
		goto 56.4,12.1
		.talk Therazane##42465
		..turnin The Stone Throne##26709
	step //2159
		'Hearth to the Temple of Earth |goto 49.2,51.9,0.5 |use Hearthstone##6948 |noway |c
	step //2160
		goto 50.9,53.1
		.' Click the Portal to Orgrimmar |tip It's a red swirling portal.
		.' Teleport to Orgrimmar |goto Orgrimmar |noway |c
]])
ZygorGuidesViewer:RegisterInclude("H_Therazane_DailyQuest", [[
		'Increasing your Therazane reputation to Revered will unlock more daily quests. |tip Use the THERAZANE REPUTATION guide in the Cataclysm Reputation section to do this.
	step //2161
		goto Deepholm,56.1,14.4
		.talk Felsen the Enduring##43805
		..accept Fear of Boring##27046 |daily
		..accept Motes##27047 |daily
		..accept Beneath the Surface##28488 |daily |tip This quest can be offered at random and may not be offered every day.
	step //2162
		goto 56.6,14.1
		.talk Terrath the Steady##43806
		..accept The Restless Brood##28391 |daily |tip This quest can be offered at random if you have at least Revered reputation with Therazane.  However, the quest may not be offered every day.
		only if rep ('Therazane') >= Revered
	step //2163
		goto 55.4,14.2
		.talk Pyrite Stonetender##44945
		..accept Lost In The Deeps##26710 |daily |tip This quest can be offered at random and may not be offered every day.
	step //2164
		goto 57.3,12.5
		.talk Gorsik the Tumultuous##43804
		..accept Soft Rock##27049 |daily
		..accept Fungal Fury##27050 |daily
	step //2165
		goto 59.6,14.0
		.talk Ruberick##44973
		..accept Through Persistence##27051 |daily
		..accept Glop, Son of Glop##28390 |daily |only if rep ('Therazane') >= Revered |tip This quest can be offered at random if you have at least Revered reputation with Therazane.  However, the quest may not be offered every day.
	step //2166
		goto 32.7,24.3
		.' Use your Stonework Mallet next to the Pale Resonating Crystal |use Stonework Mallet##60266 |tip It's a huge green crystal sitting on the ground.
		.' Strike the Pale Resonating Crystal |q 28391/1
		.from Aeosera##43641 |tip Click the Boulder Platforms to jump from rock to rock while fighting Aeosera.  When she is casting her Breath Fire ability, jump to another rock and attack her while she is breathing fire to the other rock.  Repeat this until she surrenders.
		.' Defeat Aeosera |q 28391/2
		only if rep ('Therazane') >= Revered
	step //2167
		goto 56.6,14.1
		.talk Terrath the Steady##43806
		..turnin The Restless Brood##28391
		only if rep ('Therazane') >= Revered
	step //2168
		goto 58.3,25.6 |n
		.' Enter the cave |goto 58.3,25.6,0.5 |noway |c
	step //2169
		goto 61.3,26.2
		.talk Ricket##44968
		..accept Underground Economy##27048 |daily |tip This quest can be offered at random and may not be offered every day.
	step //2170
		goto 66.1,28.1
		.' Follow the path inside the cave
		.' Click the Ruby Gemstone Cluster |tip It looks like 3 dark colored spinning rings with a bunch of red crystals spinning above them.
		.from Enormous Gyreworm##48533
		.get Ruby Crystal Cluster |q 28488/1
	step //2171
		goto 63.6,23.0
		.' Use Ricket's Tickers next to Deep Alabaster Crystals |use Ricket's Tickers##65514 |tip They look like huge white rocks around this area.
		.get 3 Deep Alabaster Crystal |q 27048/1
	step //2172
		goto 62.6,23.9 |n
		.' Follow this path |goto 62.6,23.9,0.5 |noway |c
	step //2173
		goto 61.8,19.7
		.' Use Ricket's Tickers next to Deep Celestite Crystals |use Ricket's Tickers##65514 |tip They look like huge blue rocks around this area.
		.get 3 Deep Celestite Crystal |q 27048/2
	step //2174
		goto 62.0,18.0 |n
		.' Follow this path |goto 62.0,18.0,0.5 |noway |c
	step //2175
		goto 64.4,18.6
		.' Use Ricket's Tickers next to Deep Amethyst Crystals |use Ricket's Tickers##65514 |tip They look like huge purple rocks around this area.
		.get 3 Deep Amethyst Crystal |q 27048/3
	step //2176
		goto 65.3,18.4 |n
		.' Follow this path |goto 65.3,18.4,0.5 |noway |c
	step //2177
		goto 66.4,20.2
		.' Use Ricket's Tickers next to Deep Garnet Crystals |use Ricket's Tickers##65514 |tip They look like huge red rocks around this area.
		.get 3 Deep Garnet Crystal |q 27048/4	
	step //2178
		goto 63.6,23.9
		.' All around inside this cave:
		.from Gorged Gyreworm##42766+, Gyreworm##44257+
		.kill 10 Gyreworm |q 27046/1
		.' Click Painite Shards |tip They look like small green glowing crystals sitting on the ground all around inside this cave.
		.get 10 Painite Mote |q 27047/1
	step //2179
		goto 63.1,20.8
		.talk Pebble##49956
		..' Tell him to follow you
	step //2180
		goto 64.2,17.6 |n
		.' Follow this path |goto 64.2,17.6,0.5 |noway |c
	step //2181
		goto 61.3,26.2
		.talk Ricket##44968
		..turnin Underground Economy##27048
	step //2182
		goto 58.3,25.6 |n
		.' Leave the cave |goto 58.3,25.6,0.5 |noway |c
	step //2183
		goto 58.3,25.6
		.' Wait in this spot until Pebble bobbles around appreciatively and then disappears into the distance
		.' Bring Pebble to safety |q 26710/1
	step //2184
		goto 74.0,41.2
		.kill 8 Fungal Behemoth |q 27049/1
		.from Verlok Grubthumper##43367+, Verlok Shroomtender##43368+
		.get Bag of Verlok Miracle-Grow |q 27051/1
		.' Click Sprouting Crimson Mushrooms |tip They look like tiny mushrooms on the ground around this area.  Try to only click the solid blue, solid red, or white-brown ones.  The blue ones with red spots will explode and hurt you. 
		.' Destroy 10 Freshly Sprouted Mushrooms |q 27050/1
	step //2185
		goto 68.6,29.1 |n
		.' Enter the cave |goto 68.6,29.1,0.5 |noway |c
	step //2186
		goto 69.8,31.9
		.talk Earthmender Norsala##43503
		..' Tell her you're ready when she is
		.kill Fungalmancer Glop |q 28390/1 |tip Follow him each time he runs away.  Avoid the mushrooms as you walk, they will give you a debuff.  While fighting Fungalmancer Glop, kill the Boomshrooms he creates.  Don't let them grow too big, they will explode and deal a lot of damage.
	step //2187
		goto 70.2,33.8 |n
		.' Follow the path up |goto 70.2,33.8,0.5 |noway |c
	step //2188
		goto 68.6,29.1 |n
		.' Leave the cave |goto 68.6,29.1,0.5 |noway |c
	step //2189
		goto 55.4,14.2
		.talk Pyrite Stonetender##44945
		..turnin Lost In The Deeps##26710
	step //2190
		goto 57.3,12.5
		.talk Gorsik the Tumultuous##43804
		..turnin Soft Rock##27049
		..turnin Fungal Fury##27050
	step //2191
		goto 59.6,14.0
		.talk Ruberick##44973
		..turnin Through Persistence##27051
		..turnin Glop, Son of Glop##28390 |only if rep ('Therazane') >= Revered
	step //2192
		goto Deepholm,56.1,14.4
		.talk Felsen the Enduring##43805
		..turnin Fear of Boring##27046
		..turnin Motes##27047
		..turnin Beneath the Surface##28488
]])

--------------------------------------------------------------------------------------------------------------------------------------
-- ACHIEVEMENTS
--------------------------------------------------------------------------------------------------------------------------------------

ZygorGuidesViewer:RegisterInclude("H_Explorer_Kalimdor",[[
	step //2193
		' This guide assumes you have a flying mount and can fly in Azeroth as well. You can do this
		.' without having a flying mount but it will be much more efficient with one.
		|confirm always
	step //2194
	label	"start"
		' Explore Azshara |achieve 852
		' Explore Durotar |achieve 728
		' Explore Northern Barrens |achieve 750
		' Explore Southern Barrens |achieve 4996
		' Explore Dustwallow Marsh |achieve 850
		' Explore Thousand Needles |achieve 846
		' Explore Tanaris |achieve 851
		' Explore Un'Goro Crater |achieve 854
		' Explore Uldum |achieve 4865
		' Explore Silithus |achieve 856
		' Explore Ferals |achieve 849
		' Explore Desolace |achieve 848
		' Explore Mulgore |achieve 736
		' Explore Stonetalon Mountains |achieve 847
		' Explore Ashenvale |achieve 845
		' Explore Mount Hyjal |achieve 4863
		' Explore Winterspring |achieve 857
		' Explore Moonglade |achieve 855
		' Explore Felwood |achieve 853
		' Explore Darkshore |achieve 844
		' Explore Teldrassil |achieve 842
		' Explore Azuremyst Isle |achieve 860
		' Explore Bloodmyst Isle |achieve 861       
		|confirm always
	step //2195
		'Skipping next part of guide |next "+n_barrens" |only if step:Find("+durotar"):IsComplete()
		'Proceeding next step |next |only if default
	step //2196
		goto Orgrimmar,45.4,8.5
		.' Discover Orgrimmar |achieve 728/12
	step //2197
		goto Durotar,54.0,9.0 
		.' Discover Skull Rock |achieve 728/11
	step //2198
		goto 52.4,24.2
		.' Discover Drygulch Ravine |achieve 728/10
	step //2199
		goto 53.5,43.4 
		.' Discover Razor Hill |achieve 728/7
	step //2200
		goto 58.1,60.2 
		.' Discover Tiragarde Keep |achieve 728/6
	step //2201
		goto 66.6,82.9 
		.' Discover Echo Isles |achieve 728/5
	step //2202
		goto 56.1,75.8 
		.' Discover Sen'jin Village |achieve 728/4
	step //2203
		goto 48.5,79.1 
		.' Discover Northwatch Foothold |achieve 728/2
	step //2204
		goto 44.5,62.2 
		.' Discover Valley of Trials |achieve 728/1
	step //2205
		goto 44.6,50.6 
		.' Discover Razormane Grounds |achieve 728/8
	step //2206
		goto 40.5,40.0 
		.' Discover Southfury Watershed |achieve 728/3
	step //2207
		goto 40.3,24.7 
		.' Discover Thunder Ridge |achieve 728/9
	step //2208
	label	"durotar"
		'Explore Durotar |achieve 728
	step //2209
	label	"n_barrens"
		'Skipping next part of guide |next "+s_barrens" |only if step:Find("+n_barrens1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2210
		goto Northern Barrens,67.2,12.1 
		.' Discover Boulder Lode Mine |achieve 750/1
	step //2211
		goto 55.7,18.5 
		.' Discover The Sludge Fen |achieve 750/4
	step //2212
		goto 39.6,14.1 
		.' Discover The Mor'shan Rampart |achieve 750/3
	step //2213
		goto 25.5,31.7 
		.' Discover The Dry Hills |achieve 750/6
	step //2214
		goto 36.8,45.9 
		.' Discover The Forgotten Pools |achieve 750/7
	step //2215
		goto 43.1,35.4 
		.' Discover Dreadmist Peak |achieve 750/5
	step //2216
		goto 54.9,41.1 
		.' Discover Grol'dom Farm |achieve 750/8
	step //2217
		goto 67.0,41.3 
		.' Discover Far Watch Post |achieve 750/9
	step //2218
		goto 58.8,50.0 
		.' Discover Thorn Hill |achieve 750/10
	step //2219
		goto 50.2,57.3 
		.' Discover The Crossroads |achieve 750/11
	step //2220
		goto 40.3,73.9 
		.' Discover Lushwater Oasis |achieve 750/2
	step //2221
		goto 55.7,78.6 
		.' Discover The Stagnant Oasis |achieve 750/12
	step //2222
		goto 70.3,84.1 
		.' Discover The Merchant Coast |achieve 750/14
	step //2223
	label	"n_barrens1"
		'Explore Northern Barrens |achieve 750
	step //2224
	label	"s_barrens"
		'Skipping next part of guide |next "+dustwallow" |only if step:Find("+s_barrens1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2225
		goto Southern Barrens,68.8,49.1 
		.' Discover Northwatch Hold |achieve 4996/7
	step //2226
		goto 52.2,48.6 
		.' Discover Forward Command |achieve 4996/3
	step //2227
		goto 47.8,33.68
		.' Discover The Overgrowth |achieve 4996/10
	step //2228
		goto 39.3,22.3
		.' Discover Hunter's Hill |achieve 4996/6
	step //2229
		goto 36.5,11.1 
		.' Discover Honor's Stand |achieve 4996/5
	step //2230
		goto 42.4,44.0
		.' Discover Vendetta Point |achieve 4996/11
	step //2231
		goto 44.9,54.3
		.' Discover Ruins of Taurajo |achieve 4996/9
	step //2232
		goto 41.0,78.2
		.' Discover Frazzlecraz Motherlode |achieve 4996/4
	step //2233
		goto 50.7,84.0
		.' Discover Bael Modan |achieve 4996/1
	step //2234
	label	"s_barrens1"
		'Explore Southern Barrens |achieve 4996
	step //2235
	label	"dustwallow"
		'Skipping next part of guide |next "+thousand" |only if step:Find("+dustwallow1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2236
		goto Dustwallow Marsh,29.7,49.0 
		.' Discover Shady Rest Inn |achieve 850/5
	step //2237
		goto 36.3,30.4 
		.' Discover Brackenwall Village |achieve 850/7
	step //2238
		goto 41.4,12.4 
		.' Discover Blackhoof Village |achieve 850/2
	step //2239
		goto 76.0,17.5 
		.' Discover Alcaz Island |achieve 850/9
	step //2240
		goto 61.5,30.2 
		.' Discover Dreadmurk Shore |achieve 850/6
	step //2241
		goto 67.1,49.8 
		.' Discover Theramore Isle |achieve 850/1
	step //2242
		goto 46.6,46.1 
		.' Discover Direhorn Post |achieve 850/3
	step //2243
		goto 41.4,75.1 
		.' Discover Mudsprocket |achieve 850/4
	step //2244
		goto 43.4,75.5 
		.' Discover Wyrmbog |achieve 850/8
	step //2245
	label	"dustwallow1"
		' Explore Dustwallow Marsh |achieve 850
	step //2246
	label	"thousand"
		'Skipping next part of guide |next "+tanaris" |only if step:Find("+thousand1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2247
		goto Thousand Needles,88.4,47.8 
		.' Discover Splithoof Heights |achieve 846/10
	step //2248
		goto 51.7,30.0 
		.' Discover Razorfen Downs |achieve 846/2
	step //2249
		goto 33.6,38.6 
		.' Discover Darkcloud Pinnacle |achieve 846/8
	step //2250
		goto 32.1,18.3 
		.' Discover The Great Lift |achieve 846/1
	step //2251
		goto 13.4,10.3 
		.' Discover Westreach Summit |achieve 846/7
	step //2252
		goto 13.1,37.5 
		.' Discover Highperch |achieve 846/12
	step //2253
		goto 31.1,58.8 
		.' Discover Twilight Bulwark |achieve 846/6
	step //2254
		goto 47.0,50.7 
		.' Discover Freewind Post |achieve 846/9
	step //2255
		goto 54.9,63.2 
		.' Discover The Twilight Withering |achieve 846/5
	step //2256
		goto 67.1,85.7 
		.' Discover Sunken Dig Site |achieve 846/3
	step //2257
		goto 92.4,78.8 
		.' Discover Southsea Holdfast |achieve 846/4
	step //2258
	label	"thousand1"
		' Explore Thousand Needles |achieve 846
	step //2259
	label	"tanaris"
		'Skipping next part of guide |next "+ungoro" |only if step:Find("+tanaris1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2260
		goto Tanaris,37.3,14.3 
		.' Discover Zul'Farrak |achieve 851/15
	step //2261
		goto 40.9,27.3 
		.' Discover Sandsorrow Watch |achieve 851/2
	step //2262
		goto 52.3,45.4 
		.' Discover Broken Pillar |achieve 851/6
	step //2263
		goto 55.1,40.9 
		.' Discover Abyssal Sands |achieve 851/5
	step //2264
		goto 64.2,50.0 
		.' Discover Caverns of Time |achieve 851/16
	step //2265
		goto 71.6,49.4 
		.' Discover Lost Rigger Cove |achieve 851/4
	step //2266
		goto 63.0,59.2 
		.' Discover Southbreak Shore |achieve 851/9
	step //2267
		goto 53.7,67.6 
		.' Discover The Gaping Chasm |achieve 851/10
	step //2268
		goto 53.6,91.7 
		.' Discover Land's End Beach |achieve 851/12
	step //2269
		goto 37.8,77.7 
		.' Discover Valley of the Watchers |achieve 851/3
	step //2270
		goto 40.8,70.6
		.' Discover  Southmoon Ruins |achieve 851/13
	step //2271
		goto 47.2,64.9
		.' Discover Eastmoon Ruins |achieve 851/11
	step //2272
		goto 30.4,66.4
		.' Discover Thistleshrub Valley |achieve 851/14
	step //2273
		goto 41.0,55.5
		.' Discover Dunemaul Compound |achieve 851/8
	step //2274
		goto 34.3,45.3
		.' Discover The Noxious Lair |achieve 851/7
	step //2275
	label	"tanaris1"
		' Explore Tanaris |achieve 851
	step //2276
	label	"ungoro"
		'Skipping next part of guide |next "+uldum" |only if step:Find("+ungoro1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2277
		goto Un'Goro Crater,77.1,39.2 
		.' Discover Ironstone Plateau |achieve 854/11
	step //2278
		goto 39.2,34.3
		.' Discover The Roiling Gardens |achieve 854/5
	step //2279
		goto 65.7,14.3
		.' Discover Fungal Rock |achieve 854/2
	step //2280
		goto 51.4,25.6
		.' Discover Lakkari Tar Pits |achieve 854/12
	step //2281
		goto 42.2,41.7
		.' Discover Mossy Pile |achieve 854/4
	step //2282
		goto 29.0,35.8
		.' Discover The Screaming Reaches |achieve 854/6
	step //2283
		goto 34.4,54.0
		.' Discover Golakka Hot Springs |achieve 854/7
	step //2284
		goto 33.2,70.7
		.' Discover Terror Run |achieve 854/8
	step //2285
		goto 54.5,48.0
		.' Discover Fire Plume Ridge |achieve 854/1
	step //2286
		goto 54.0,60.9
		.' Discover Marshal's Stand |achieve 854/3
	step //2287
		goto 67.9,54.8
		.' Discover The Marshlands |achieve 854/10
	step //2288
		goto 51.1,77.5
		.' Discover The Slithering Scar |achieve 854/9
	step //2289
	label	"ungoro1"
		' Explore Un'Goro Crater |achieve 854
	step //2290
	label	"uldum"
		'Skipping next part of guide |next "+silithus" |only if step:Find("+uldum1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2291
		goto Uldum,64.5,16.1
		.' Discover Khartut's Tomb |achieve 4865/3
	step //2292
		goto 69.0,21.8
		.' Discover The Gate of Unending Cycles |achieve 4865/19
	step //2293
		goto 64.6,31.8 
		.' Discover Obelisk of the Stars |achieve 4865/9
	step //2294
		goto 67.1,40.9 
		.' Discover Nahorn |achieve 4865/6
	step //2295
		goto 84.7,52.8
		.' Discover The Cursed Landing |achieve 4865/18
	step //2296
		goto 80.3,60.0
		.' Discover The Trail of Devastation |achieve 4865/21
	step //2297
		goto 63.9,73.3
		.' Discover Lost City of the Tol'vir |achieve 4865/4
	step //2298
		goto 51.2,82.0
		.' Discover Neferset City |achieve 4865/7
	step //2299
		goto 43.7,70.4
		.' Discover Cradle of the Ancients |achieve 4865/2
	step //2300
		goto 45.6,56.2
		.' Discover Obelisk of the Sun |achieve 4865/10
	step //2301
		goto 54.3,52.2
		.' Discover Akhenet Fields |achieve 4865/1
	step //2302
		goto 58.3,40.9
		.' Discover Vir'naal Dam |achieve 4865/22
	step //2303
		goto 60.5,39.2
		.' Discover Tahret Grounds |achieve 4865/16
	step //2304
		goto 54.8,32.4
		.' Discover Ramkahen |achieve 4865/12
	step //2305
		goto 49.0,38.4
		.' Discover Mar'at |achieve 4865/5
	step //2306
		goto 46.1,15.5
		.' Discover Ruins of Ahmtul |achieve 4865/13
	step //2307
		goto 40.8,22.9
		.' Discover Obelisk of the Moon |achieve 4865/8
	step //2308
		goto 33.7,30.9
		.' Discover Temple of Uldum |achieve 4865/17
	step //2309
		goto 40.5,39.9
		.' Discover Orsis |achieve 4865/11
	step //2310
		goto 32.1,65.5
		.' Discover Ruins of Ammon |achieve 4865/14
	step //2311
		goto 20.8,61.8
		.' Discover Schnottz's Landing |achieve 4865/15
	step //2312
	label	"uldum1"
		' Explore Uldum |achieve 4865
	step //2313
	label	"silithus"
		'Skipping next part of guide |next "+feralas" |only if step:Find("+silithus1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2314
		goto Silithus,60.0,71.7
		.' Discover Hive'Regal |achieve 856/5
	step //2315
		goto 32.0,78.9
		.' Discover The Scarab Wall |achieve 856/6
	step //2316
		goto 31.4,53.8
		.' Discover Hive'Zora |achieve 856/4
	step //2317
		goto 30.9,16.0
		.' Discover The Crystal Vale |achieve 856/1
	step //2318
		goto 49.4,22.4
		.' Discover Hive'Ashi |achieve 856/7
	step //2319
		goto 54.4,34.2
		.' Discover Cenarion Hold |achieve 856/3
	step //2320
		goto 65.3,47.4
		.' Discover Southwind Village |achieve 856/2
	step //2321
		goto 81.3,17.8
		.' Discover Valor's Rest |achieve 856/8
	step //2322
	label	"silithus1"
		' Explore Silithus |achieve 856
	step //2323
	label	"feralas"
		'Skipping next part of guide |next "+desolace" |only if step:Find("+feralas1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2324
		goto  Feralas,75.9,62.4
		.' Discover The Writhing Deep |achieve 849/8
	step //2325
		goto 83.0,40.9
		.' Discover Lower Wilds |achieve 849/1
	step //2326
		goto 76.5,44.4
		.' Discover Camp Mojache |achieve 849/9
	step //2327
		goto 75.6,29.8
		.' Discover Gordunni Outpost |achieve 849/11
	step //2328
		goto 68.7,40.3
		.' Discover Grimtotem Compound |achieve 849/10
	step //2329
		goto 60.4,35.6
		.' Discover Dire Maul |achieve 849/5
	step //2330
		goto 67.7,58.5
		.' Discover Darkmist Ruins |achieve 849/12
	step //2331
		goto 58.6,73.0
		.' Discover Ruins of Isildien |achieve 849/7
	step //2332
		goto 55.4,56.2
		.' Discover Feral Scar Vale |achieve 849/6
	step //2333
		goto 49.7,49.2
		.' Discover The Forgotten Coast |achieve 849/4
	step //2334
		goto 45.8,49.6
		.' Discover Feathermoon Stronghold |achieve 849/13
	step //2335
		goto 28.5,49.1
		.' Discover Ruins of Feathermoon |achieve 849/2
	step //2336
		goto 46.3,17.9
		.' Discover The Twin Colossals |achieve 849/3
	step //2337
	label	"feralas1"
		' Explore Ferals |achieve 849
	step //2338
	label	"desolace"
		'Skipping next part of guide |next "+mulgore" |only if step:Find("+desolace1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2339
		goto Desolace,36.1,88.6
		.' Discover Gelkis Village |achieve 848/12
	step //2340
		goto 51.3,78.5
		.' Discover Mannoroc Coven |achieve 848/13
	step //2341
		goto 36.5,69.9
		.' Discover Thargad's Camp |achieve 848/2
	step //2342
		goto 24.2,70.9
		.' Discover Shadowprey Village |achieve 848/11
	step //2343
		goto 35.34,57.2
		.' Discover Valley of Spears |achieve 848/9
	step //2344
		goto 29.9,29.4
		.' Discover Slitherblade Shore |achieve 848/16
	step //2345
		goto 28.7,9.01
		.' Discover Ranazjar Isle |achieve 848/8
	step //2346
		goto 51.5,10.0
		.' Discover Tethris Aran |achieve 848/1
	step //2347
		goto 54.5,25.2
		.' Discover Thunder Axe Fortress |achieve 848/5
	step //2348
		goto 66.7,8.7
		.' Discover Nijel's Point |achieve 848/3
	step //2349
		goto 78.2,21.6
		.' Discover Sargeron |achieve 848/4
	step //2350
		goto 74.7,45.6
		.' Discover Magram Territory |achieve 848/7
	step //2351
		goto 56.1,47.3
		.' Discover Cenarion Wildlands |achieve 848/6
	step //2352
		goto 50.7,59.0
		.' Discover Kodo Graveyard |achieve 848/10
	step //2353
		goto 70.6,74.8 
		.' Discover Shok'Thokar |achieve 848/14
	step //2354
		goto 80.3,79.3
		.' Discover Shadowbreak Ravine |achieve 848/15
	step //2355
	label	"desolace1"
		' Explore Desolace |achieve 848
	step //2356
	label	"mulgore"
		'Skipping next part of guide |next "+stonetalon" |only if step:Find("+mulgore1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2357
		goto Mulgore,32.3,50.6
		.' Discover Bael'dun Digsite |achieve 736/10
	step //2358
		goto 35.5,61.3
		.' Discover Palemane Rock |achieve 736/2
	step //2359
		goto 53.8,85.8
		.' Discover Red Cloud Mesa |achieve 736/1
	step //2360
		goto 53.7,66.7
		.' Discover Winterhoof Water Well |achieve 736/4
	step //2361
		goto 47.8,58.4
		.' Discover Bloodhoof Village |achieve 736/3
	step //2362
		goto 61.1,60.5
		.' Discover The Rolling Plains |achieve 736/5
	step //2363
		goto 62.7,42.6
		.' Discover The Venture Co. Mine |achieve 736/6
	step //2364
		goto 54.2,47.9
		.' Discover Ravaged Caravan |achieve 736/7
	step //2365
		goto 44.9,43.5
		.' Discover Thunderhorn Water Well |achieve 736/9
	step //2366
		goto 59.82,19.9
		.' Discover Red Rocks |achieve 736/11
	step //2367
		goto 54.2,20.9
		.' Discover The Golden Plains |achieve 736/8
	step //2368
		goto 43.1,14.2
		.' Discover Wildmane Water Well |achieve 736/13
	step //2369
	label	"mulgore1"
		' Explore Mulgore |achieve 736
	step //2370
	label "stonetalon"
		'Skipping next part of guide |next "+ashenvale" |only if step:Find("+stonetalon1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2371
		goto Stonetalon Mountains,72.6,92.4
		.' Discover Malaka'jin |achieve 847/9
	step //2372
		goto 76.7,75.8
		.' Discover Unearthed Grounds |achieve 847/5
	step //2373
		goto 69.6,85.1
		.' Discover Greatwood Vale |achieve 847/12
	step //2374
		goto 63.4,88.7
		.' Discover Boulderslide Ravine |achieve 847/11
	step //2375
		goto 59.6,78.9
		.' Discover Webwinder Path |achieve 847/10
	step //2376
		goto 57.2,72.7
		.' Discover Webwinder Hollow |achieve 847/6
	step //2377
		goto 48.8,76.3
		.' Discover Ruins of Eldre'thar |achieve 847/3
	step //2378
		goto 49.3,63.4
		.' Discover Sun Rock Retreat |achieve 847/12
	step //2379
		goto 31.6,71.5
		.' Discover The Charred Vale |achieve 847/15
	step //2380
		goto 37.0,54.3
		.' Discover Battlescar Valley |achieve 847/1
	step //2381
		goto 35.8,31.5
		.' Discover Thal'darah Overlook |achieve 847/4
	step //2382
		goto 40.9,19.9
		.' Discover Stonetalon Peak |achieve 847/17
	step //2383
		goto 45.1,30.2
		.' Discover Cliffwalker Post |achieve 847/8
	step //2384
		goto 51.6,47.3
		.' Discover Mirkfallon Lake |achieve 847/16
	step //2385
		goto 59.1,57.7
		.' Discover Windshear Hold |achieve 847/7
	step //2386
		goto 66.9,66.2
		.' Discover Krom'gar Fortress |achieve 847/2
	step //2387
		goto 66.9,49.3
		.' Discover Windshear Crag |achieve 847/13
	step //2388
	label	"stonetalon1"
		' Explore Stonetalon Mountains |achieve 847
	step //2389
	label	"ashenvale"
		'Skipping next part of guide |next "+hyjal" |only if step:Find("+ashenvale1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2390
		goto Ashenvale,32.6,65.6
		.' Discover The Ruins of Stardust |achieve 845/10
	step //2391
		goto 35.9,50.2
		.' Discover Astranaar |achieve 845/9
	step //2392
		goto 21.4,55.3
		.' Discover The Shrine of Aessina |achieve 845/8
	step //2393
		goto 20.2,41.1
		.' Discover Lake Falathim |achieve 845/5
	step //2394
		goto 27.5,37.7
		.' Discover Maestra's Post |achieve 845/6
	step //2395
		goto 26.0,19.7
		.' Discover Orendil's Retreat |achieve 845/2
	step //2396
		goto 37.0,32.9
		.' Discover Thistlefur Village |achieve 845/7
	step //2397
		goto 48.9,46.4
		.' Discover Thunder Peak |achieve 845/4
	step //2398
		goto 53.2,32.6
		.' Discover The Howling Vale |achieve 845/11
	step //2399
		goto 59.7,50.0
		.' Discover Raynewood Retreat |achieve 845/12
	step //2400
		goto 68.2,47.9
		.' Discover Splintertree Post |achieve 845/14
	step //2401
		goto 80.4,49.7
		.' Discover Satyrnaar |achieve 845/15
	step //2402
		goto 83.1,65.3
		.' Discover Felfire Hill |achieve 845/18
	step //2403
		goto 87.4,58.6
		.' Discover Warsong Lumber Camp |achieve 845/17
	step //2404
		goto 93.4,39.2
		.' Discover Bough Shadow |achieve 845/16
	step //2405
	label	"ashenvale1"
		' Explore Ashenvale |achieve 845 
	step //2406
	label "hyjal"
		'Skipping next part of guide |next "+winter" |only if step:Find("+hyjal1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2407
		goto Mount Hyjal,72.5,76.7
		.' Discover Gates of Sothann |achieve 4863/5
	step //2408
		goto 76.0,64.9
		.' Discover Darkwhisper Gorge |achieve 4863/4
	step //2409
		goto 53.4,55.1
		.' Discover The Scorched Plain |achieve 4863/10
	step //2410
		goto 45.3,80.5
		.' Discover The Throne of Flame |achieve 4863/11
	step //2411
		goto 31.4,84.9
		.' Discover Sethria's Roost |achieve 4863/7
	step //2412
		goto 25.5,64.5
		.' Discover Rim of the World |achieve 4863/1
	step //2413
		goto 31.8,53.5
		.' Discover Ashen Lake |achieve 4863/3
	step //2414
		goto 32.9,51.2
		.' Discover The Flamewake |achieve 4863/9
	step //2415
		goto 28.5,27.5
		.' Discover Shrine of Goldrinn |achieve 4863/8
	step //2416
		goto 45.1,26.0
		.' Discover The Circle of Cinders |achieve 4863/2
	step //2417
		goto 63.4,21.0
		.' Discover Nordrassil |achieve 4863/6
	step //2418
	label	"hyjal1"
		' Explore Mount Hyjal |achieve 4863
	step //2419
	label	"winter"
		'Skipping next part of guide |next "+azshara" |only if step:Find("+winter1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2420
		goto Winterspring,59.8,85.5
		.' Discover Frostwhisper Gorge |achieve 857/12
	step //2421
		goto 64.5,77.2
		.' Discover Owl Wing Thicket |achieve 857/9
	step //2422
		goto 67.8,64.4
		.' Discover Ice Thistle Hills |achieve 857/8
	step //2423
		goto 68.1,48.5
		.' Discover Winterfall Village |achieve 857/9
	step //2424
		goto 59.9,48.9
		.' Discover Everlook |achieve 857/6
	step //2425
		goto 62.7,24.7
		.' Discover The Hidden Grove |achieve 857/10
	step //2426
		goto 45.3,15.4
		.' Discover Frostsaber Rock |achieve 857/11
	step //2427
		goto 47.7,39.1
		.' Discover Starfall Village |achieve 857/4
	step //2428
		goto 51.1,55.1
		.' Discover Lake Kel'Theril |achieve 857/3
	step //2429
		goto 54.8,62.9
		.' Discover Mazthoril |achieve 857/5
	step //2430
		goto 36.4,56.7
		.' Discover Timbermaw Post |achieve 857/2
	step //2431
		goto 31.9,49.3
		.' Discover Frostfire Hot Springs |achieve 857/1
	step //2432
	label	"winter1"
		' Explore Winterspring |achieve 857
	step //2433
	label	"azshara"
		'Skipping next part of guide |next "+moon" |only if step:Find("+azshara1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2434
		goto Azshara,52.25,26.95 
		.' Discover Darnassian Base Camp |achieve 852/7
	step //2435
		goto 73.69,20.98
		.' Discover Bitter Reaches |achieve 852/4
	step //2436
		goto 80.90,32.34
		.' Discover Tower of Eldara |achieve 852/5
	step //2437
		goto 69.89,34.83
		.' Discover Ruins of Arkkoran |achieve 852/6
	step //2438
		goto 58.29,51.00
		.' Discover Bilgewater Harbor |achieve 852/3
	step //2439
		goto 68.41,75.62
		.' Discover Southridge Beach |achieve 852/13
	step //2440
		goto 64.65,79.31
		.' Discover Ravencrest Monument |achieve 852/14
	step //2441
		goto 56.99,76.50
		.' Discover Storm Cliffs |achieve 852/17
	step //2442
		goto 46.54,76.25
		.' Discover The Secret Lab |achieve 852/8
	step //2443
		goto 39.83,84.67
		.' Discover The Ruined Reaches |achieve 852/16
	step //2444
		goto 35.72,73.99
		.' Discover Lake Mennar |achieve 852/15
	step //2445
		goto 26.75,77.96
		.' Discover Orgrimmar Rear Gate |achieve 852/11
	step //2446
		goto 21.04,57.1
		.' Discover Gallywix Pleasure Palace |achieve 852/1
	step //2447
		goto 39.21,55.46
		.' Discover The Shattered Strand |achieve 852/2
	step //2448
		goto 31.95,50.02
		.' Discover Ruins of Eldarath |achieve 852/12
	step //2449
		goto 25.47,38.00
		.' Discover Bear's Head |achieve 852/9
	step //2450
		goto 33.06,32.76
		.' Discover Blackmaw Hold |achieve 852/10
	step //2451
	label	"azshara1"
		' Explore Azshara |achieve 852
	step //2452
	label	"moon"
		'Skipping next part of guide |next "+felwood" |only if step:Find("+moon1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2453
		goto Moonglade,67.8,53.8
		.' Discover Stormrage Barrow Dens |achieve 855/4
	step //2454
		goto 52.5,55.4
		.' Discover Lake Elune'ara |achieve 855/1
	step //2455
		goto 48.2,37.9
		.' Discover Nighthaven |achieve 855/2
	step //2456
		goto 36.3,38.8
		.' Discover Shrine of Remulos |achieve 855/3
	step //2457
	label	"moon1"
		' Explore Moonglade |achieve 855
	step //2458
	label	"felwood"
		'Skipping next part of guide |next "+darkshore" |only if step:Find("+felwood1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2459
		goto Felwood,61.2,11.5
		.' Discover Felpaw Village |achieve 853/1
	step //2460
		goto 62.6,26.7
		.' Discover Talonbranch Glade |achieve 853/2
	step //2461
		goto 50.3,26.0
		.' Discover Irontree Woods |achieve 853/3
	step //2462
		goto 43.6,18.6
		.' Discover Jadefire Run |achieve 853/4
	step //2463
		goto 43.1,41.9
		.' Discover Shatter Scar Vale |achieve 853/5
	step //2464
		goto 52.2,78.2
		.' Discover Emerald Sanctuary |achieve 853/10
	step //2465
		goto 56.6,86.8
		.' Discover Morlos'Aran |achieve 853/12
	step //2466
		goto 48.0,89.2
		.' Discover Deadwood Village |achieve 853/11
	step //2467
		goto 41.8,85.4
		.' Discover Jadefire Glen |achieve 853/9
	step //2468
		goto 38.0,72.3
		.' Discover Ruins of Constellas |achieve 853/8
	step //2469
		goto 37.0,59.1
		.' Discover Jaedenar |achieve 853/7
	step //2470
	label	"felwood1"
		' Explore Felwood |achieve 853
	step //2471
	label	"darkshore"
		'Skipping next part of guide |next "+teldrassil" |only if step:Find("+darkshore1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2472
		goto Darkshore,40.3,86.2
		.' Discover The Master's Glaive |achieve 844/11
	step //2473
		goto 32.0,84.0
		.' Discover Nazj'vel |achieve 844/10
	step //2474
		goto 42.5,69.5
		.' Discover Wildbend River |achieve 844/4
	step //2475
		goto 43.7,60.5
		.' Discover Ameth'Aran |achieve 844/8
	step //2476
		goto 43.96,39.82 
		.' Discover Withering Thicket |achieve 844/5
	step //2477
		goto 42.9,54.9
		.' Discover The Eye of the Vortex |achieve 844/7
	step //2478
		goto 37.9,44.1
		.' Discover Ruins of Auberdine |achieve 844/1
	step //2479
		goto 51.2,19.2
		.' Discover Lor'danel |achieve 844/9
	step //2480
		goto 63.9,21.9
		.' Discover Ruins of Mathystra |achieve 844/6
	step //2481
		goto 72.5,17.3 
		.' Discover Shatterspear Vale |achieve 844/2
	step //2482
		goto 65.9,7.0
		.' Discover Shatterspear War Camp |achieve 844/3
	step //2483
	label	"darkshore1"
		' Explore Darkshore |achieve 844
	step //2484
	label	"teldrassil"
		'Skipping next part of guide |next "+azure" |only if step:Find("+teldrassil1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2485
		goto Teldrassil,55.0,61.0
		.' Discover Lake Al'Ameth |achieve 842/6
	step //2486
		goto 55.6,51.2
		.' Discover Dolanaar |achieve 842/3
	step //2487
		goto 64.7,49.1
		.' Discover Starbreeze Village |achieve 842/8
	step //2488
		goto 55.0,91.0
		.' Rut'theran Village |achieve 842/12
	step //2489
		goto 58.4,33.0
		.' Discover Shadowglen |achieve 842/1
	step //2490
		goto 50.7,38.0
		.' Discover The Cleft |achieve 842/2
	step //2491
		goto 46.16,50.68 
		.' Ban'ethil Hollow |achieve 842/4
	step //2492
		goto 44.4,34.4
		.' Discover Wellspring Lake |achieve 842/10
	step //2493
		goto 40.0,26.7
		.' Discover The Oracle Glade |achieve 842/9
	step //2494
		goto 30.4,50.1
		.' Discover Darnassus |achieve 842/11
	step //2495
		goto 41.9,56.9
		.' Discover Pools of Arlithrien |achieve 842/7
	step //2496
		goto 44.8,67.4
		.' Discover Gnarlpine Hold |achieve 842/5
	step //2497
	label	"teldrassil1"
		' Explore Teldrassil |achieve 842
	step //2498
	label	"azure"
		'Skipping next part of guide |next "+blood" |only if step:Find("+azure1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2499
		goto 52.4,89.3 
		.' Ride the boat to Azuremyst Isle |tip Make sure to avoid Alliance Guards as best you can
		.' Ride to Azuremyst Isle |goto Azuremyst Isle |noway |c
	step //2500
		goto Azuremyst Isle,23.7,54.0
		.' Discover Valaar's Berth |achieve 860/16
	step //2501
		goto 26.5,65.1
		.' Discover Bristlelimb Village |achieve 860/4
	step //2502
		goto 12.7,78.6
		.' Discover Silvermyst Isle |achieve 860/13
	step //2503
		goto 32.0,79.3
		.' Discover Wrathscale Point |achieve 860/17
	step //2504
		goto 37.0,58.4
		.' Discover Pod Cluster |achieve 860/10
	step //2505
		goto 49.3,50.7
		.' Discover Azure Watch |achieve 860/3
	step //2506
		goto 46.6,72.4
		.' Discover Odesyus' Landing |achieve 860/9
	step //2507
		goto 52.7,61.3
		.' Discover Pod Wreckage |achieve 860/11
	step //2508
		goto 58.3,67.0
		.' Discover Geezle's Camp |achieve 860/7
	step //2509
		goto 61.3,53.6
		.' Discover Ammen Ford |achieve 860/2
	step //2510
		goto 77.6,43.7
		.' Discover Ammen Vale |achieve 860/1
	step //2511
		goto 52.7,41.8
		.' Discover Moongraze Woods |achieve 860/8
	step //2512
		goto 29.2,35.1
		.' Discover The Exodar |achieve 860/15
	step //2513
		goto 35.3,12.4
		.' Discover Silting Shore |achieve 860/12
	step //2514
		goto 46.0,20.0
		.' Discover Stillpine Hold |achieve 860/14
	step //2515
		goto 58.8,17.6
		.' Discover Emberglade |achieve 860/5
	step //2516
		goto 47.7,6.6
		.' Discover Fairbridge Strand |achieve 860/6
	step //2517
	label	"azure1"
		' Explore Azuremyst Isle |achieve 860
	step //2518
	label	"blood"
		'Skipping next part of guide |next "+end" |only if step:Find("+blood1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2519
		goto Bloodmyst Isle,61.9,90.0 |kessel's crossing
	step //2520
		goto 57.4,81.0
		.' Discover The Lost Fold |achieve 861/22
	step //2521
		goto 67.0,78.2
		.' Discover Bristlelimb Enclave |achieve 861/7
	step //2522
		goto 69.0,66.6
		.' Discover Wrathscale Lair |achieve 861/27
	step //2523
		goto 85.4,52.8
		.' Discover Bloodcurse Isle |achieve 861/5
	step //2524
		goto 72.0,29.6
		.' Discover Wyrmscar Island |achieve 861/28
	step //2525
		goto 73.4,20.9
		.' Discover Talon Stand |achieve 861/14
	step //2526
		goto 81.0,20.1
		.' Discover The Bloodcursed Reef |achieve 861/16
	step //2527
		goto 74.4,7.5
		.' Discover Veridian Point |achieve 861/25
	step //2528
		goto 62.6,25.4
		.' Discover The Crimson Reach |achieve 861/16
	step //2529
		goto 54.2,17.1
		.' Discover The Warp Piston |achieve 861/24
	step //2530
		goto 56.1,34.9
		.' Discover Ragefeather Ridge |achieve 861/12
	step //2531
		goto 61.6,45.2
		.' Discover Ruins of Loreth'Aran |achieve 861/13
	step //2532
		goto 54.6,55.4
		.' Discover Blood Watch |achieve 861/6
	step //2533
		goto 51.7,76.6
		.' Discover Middenvale |achieve 861/9
	step //2534
		goto 43.9,84.7
		.' Discover Mystwood |achieve 861/10
	step //2535
		goto 33.2,90.3
		.' Discover Blacksilt Shore |achieve 861/3
	step //2536
		goto 37.9,75.7
		.' Discover Nazzivian |achieve 861/11
	step //2537
		goto 38.5,59.5
		.' Discover The Cryo-Core |achieve 861/19
	step //2538
		goto 45.9,45.1
		.' Discover Bladewood |achieve 861/4
	step //2539
		goto 40.8,33.0
		.' Discover Axxarien |achieve 861/2
	step //2540
		goto 38.7,21.9
		.' Discover The Bloodwash |achieve 861/17
	step //2541
		goto 32.7,19.8
		.' Discover The Hidden Reef |achieve 861/21
	step //2542
		goto 29.2,36.8
		.' Discover The Foul Pool |achieve 861/20
	step //2543
		goto 30.2,46.2
		.' Discover Vindicator's Rest |achieve 861/26
	step //2544
		goto 24.4,41.2
		.' Discover Tel'athion's Camp |achieve 861/15
	step //2545
		goto 18.8,30.9
		.' Discover Amberweb Pass |achieve 861/1
	step //2546
		goto 18.0,53.4
		.' Discover The Vector Coil |achieve 861/23
	step //2547
	label	"blood1"
		' Explore Bloodmyst Isle |achieve 861
	step //2548
	label "end"
		' Congratulations! You have Explored Kalimdor |achieve 43 |only if achieved(43)
		' Congratulations! You have Explored Cataclysm |achieve 4868 |only if achieved(4868)
		' Congratulations! You have Earned the Achievement World Explorer! |achieve 46 |only if achieved(46)
		.' You have not fully explored Kalimdor |only if not achieved(43)
		|confirm |next "start" |only if not achieved(43)	
]])

ZygorGuidesViewer:RegisterInclude("H_Explorer_EasternKingdoms",[[
	step //2549
		' This guide assumes you have a flying mount and can fly in Azeroth as well. You can do this
		.' without having a flying mount but it will be much more efficient with one.
		|confirm always
	step //2550
	label	"start"
		' Explore Elwynn Forest |achieve 776
		' Explore Badlands |achieve 765
		' Explore Burning Steppes |achieve 775
		' Explore Duskwood |achieve 778
		' Explore Loch Modan |achieve 779
		' Explore Tirisfal Glades |achieve 768
		' Explore Searing Gorge |achieve 774
		' Explore Ghostlands |achieve 858
		' Explore The Cape of Stranglethorn |achieve 4995
		' Explore The Hinterlands |achieve 773
		' Explore Wetlands |achieve 841
		' Explore Western Plaguelands |achieve 770
		' Explore Isle of Quel'Danas |achieve 868
		' Explore Arathi Highlands |achieve 761
		' Explore Blasted Lands |achieve 766
		' Explore Dun Morogh |achieve 627
		' Explore Hillsbrad Foothills |achieve 772
		' Explore Redridge Mountains |achieve 780
		' Explore Eversong Woods |achieve 859
		' Explore Silverpine Forest |achieve 769
		' Explore Northern Stranglethorn |achieve 781
		' Explore Swamp of Sorrows |achieve 782
		' Explore Westfall |achieve 802
		' Explore Deadwind Pass |achieve 777
		' Explore Eastern Plaguelands |achieve 771 
		' Explore Vashj'ir |achieve 4825
		' Explore Deepholm |achieve 4864
		' Explore Twilight Highlands |achieve 4866        
		|confirm
	step //2551
		'Skipping next part of guide |next "+vashj'ir" |only if step:Find("+deepholm1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2552
		#include "portal_deepholm"
	step //2553
		goto Deepholm,55.8,75.4
		.' Discover Storm's Fury Wreckage |achieve 4864/5
	step //2554
		goto 68.3,77.8
		.' Discover Twilight Overlook |achieve 4864/10
	step //2555
		goto 62.9,58.5
		.' Discover Deathwing's Fall |achieve 4864/1
	step //2556
		goto 74.2,40.7
		.' Discover Crimson Expanse |achieve 4864/12
	step //2557
		goto 56.6,10.9
		.' Discover Therazane's Throne |achieve 4864/8
	step //2558
		goto 39.8,18.6
		.' Discover The Pale Roost |achieve 4864/7
	step //2559
		goto 26.8,32.6
		.' Discover Needlerock Chasm |achieve 4864/2
	step //2560
		goto 21.7,47.7
		.' Discover Needlerock Slag |achieve  4864/3
	step //2561
		goto 26.3,69.5
		.' Discover Stonehearth |achieve 4864/4
	step //2562
		goto 35.2,80.3
		.' Discover The Quaking Fields |achieve 4864/9
	step //2563
		goto 39.2,69.1
		.' Discover Masters' Gate |achieve 4864/11
	step //2564
	label	"deepholm1"
		' Explore Deepholm |achieve 4864
	step //2565
		goto Deepholm,50.9,53.1
		.' Click on the Portal to Orgrimmar |tip It looks like a blue and red swirling portal.
		.' Teleport to Orgrimmar |goto Orgrimmar |noway |c
	step //2566
	label	"vashj'ir"
		'Skipping next part of guide |next "+strangle" |only if step:Find("+vashj'ir1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2567
		#include "portal_vashj'ir"
	step //2568
		goto Abyssal Depths,54.1,63.9
		.' Discover Korthun's End |achieve 4825/5
	step //2569
		goto 42.2,70.0
		.' Discover Underlight Canyon |achieve 4825/3
	step //2570
		goto 22.1,80.2
		.' Discover Abandoned Reef |achieve 4825/1
	step //2571
		goto 32.3,54.1
		.' Discover L'ghorek |achieve 4825/6
	step //2572
		goto 39.4,19.3
		.' Discover Deepfin Ridge |achieve 4825/4
	step //2573
		goto 54.9,43.5
		.' Discover Seabrush |achieve 4825/7
	step //2574
		goto 71.5,29.8
		.' Discover Abyssal Breach |achieve 4825/2
	step //2575
		goto Shimmering Expanse,50.9,21.5
		.' Discover Shimmering Grotto |achieve 4825/20
	step //2576
		goto 47.9,37.8
		.' Discover Silver Tide Hollow |achieve 4825/21
	step //2577
		goto 43.6,48.4
		.' Discover Glimmerdeep Gorge |achieve 4825/9
	step //2578
		goto 33.7,72.4
		.' Discover Ruins of Vashj'ir |achieve 4825/19
	step //2579
		goto 55.4,83.0
		.' Discover Beth'mora Ridge |achieve 4825/16
	step //2580
		goto 59.2,56.5
		.' Discover Nespirah |achieve 4825/17
	step //2581
		goto 66.4,41.7
		.' Discover Ruins of Thelserai Temple |achieve 4825/18
	step //2582
		goto Kelp'thar Forest,58.8,81.4
		.' Discover The Clutch |achieve 4825/12
	step //2583
		goto 61.5,58.9
		.' Discover Gnaws' Boneyard |achieve 4825/10
	step //2584
		goto 53.2,56.2
		.' Discover Gurboggle's Ledge |achieve 4825/11
	step //2585
		goto 39.7,29.7
		.' Discover Legion's Fate |achieve 4825/14
	step //2586
		goto 50.3,24.1 
		.' Discover Seafarer's Tomb |achieve 4825/13
	step //2587
		goto Kelp'thar Forest,64.8,49.3
		.' Discover The Skeletal Reef |achieve 4825/15
	step //2588
	label	"vashj'ir1"
		' Explore Vashj'ir |achieve 4825
	step //2589
		#include "hearth"
	step //2590
	label	"strangle"
		'Skipping next part of guide |next "+n_strangle" |only if step:Find("+strangle1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2591
		goto The Cape of Stranglethorn,39.7,71.0
		.' Discover Booty Bay |achieve 4995/1
	step //2592
		goto 43.5,81.4
		.' Discover The Wild Shore |achieve 4995/10
	step //2593
		goto 60.8,81.6
		.' Discover Jaquero Isle |achieve 4995/5
	step //2594
		goto 50.5,58.1
		.' Discover Mistvale Valley |achieve 4995/6
	step //2595
		goto 43.0,49.1
		.' Discover Nek'mani Wellspring |achieve 4995/7
	step //2596
		goto 34.1,32.4
		.' Discover Hardwrench Hideaway |achieve 4995/4
	step //2597
		goto 46.3,22.5
		.' Discover Gurubashi Arena |achieve 4995/3
	step //2598
		goto 54.4,30.3
		.' Discover Ruins of Jubuwal |achieve 4995/9
	step //2599
		goto 62.2,43.7
		.' Discover Ruins of Aboraz |achieve 4995/8
	step //2600
		goto 62.4,28.1
		.' Discover Crystalvein Mine |achieve 4995/2
	step //2601
	label	"strangle1"
		' Explore The Cape of Stranglethorn |achieve 4995
	step //2602
	label	"n_strangle"
		'Skipping next part of guide |next "+westfall" |only if step:Find("+n_strangle1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2603
		goto Northern Stranglethorn,53.2,66.0
		.' Discover Fort Livingston |achieve 781/4
	step //2604
		goto 59.0,55.2
		.' Discover Balia'mah Ruins |achieve 781/2
	step //2605
		goto 66.9,50.9
		.' Discover Mosh'Ogg Ogre Mound |achieve 781/11
	step //2606
		goto 64.7,39.7
		.' Discover Bambala |achieve 781/3
	step //2607
		goto 83.9,32.5
		.' Discover Zul'Gurub |achieve 781/16
	step //2608
		goto 60.2,19.9
		.' Discover Kurzen's Compound |achieve 781/8
	step //2609
		goto 46.7,9.5
		.' Discover Rebel Camp |achieve 781/7
	step //2610
		goto 44.1,19.8
		.' Discover Nesingwary's Expedition |achieve 781/6
	step //2611
		goto 42.2,38.4
		.' Discover Kal'ai Ruins |achieve 781/9
	step //2612
		goto 46.1,52.9
		.' Discover Mizjah Ruins |achieve 781/10
	step //2613
		goto 37.8,48.4
		.' Discover Grom'gol Base Camp |achieve 781/1
	step //2614
		goto 33.0,42.5
		.' Discover The Vile Reef |achieve 781/14
	step //2615
		goto 34.3,36.2
		.' Discover Bal'lal Ruins |achieve 781/13
	step //2616
		goto 19.2,25.6
		.' Discover Zuuldaia Ruins |achieve 781/5
	step //2617
		goto 26.4,20.2
		.' Discover Ruins of Zul'Kunda |achieve 781/15
	step //2618
	label	"n_strangle1"
		' Explore Northern Stranglethorn |achieve 781
	step //2619
	label	"westfall"
		'Skipping next part of guide |next "+duskwood" |only if step:Find("+westfall1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2620
		goto Westfall,63.4,72.5
		.' Discover The Dust Plains |achieve 802/14
	step //2621
		goto 44.9,82.0
		.' Discover The Dagger Hills |achieve 802/12
	step //2622
		goto 30.0,86.8
		.' Discover Westfall Lighthouse |achieve 802/11
	step //2623
		goto 33.9,73.6
		.' Discover Demont's Place |achieve 802/10
	step //2624
		goto 42.4,65.5
		.' Discover Moonbrook |achieve 802/8
	step //2625
		goto 38.2,52.3
		.' Discover Alexston Farmstead |achieve 802/9
	step //2626
		goto 39.2,43.2
		.' Discover The Raging Chasm |achieve 802/13
	step //2627
		goto 45.3,34.9
		.' Discover the Molsen Farm |achieve 802/6
	step //2628
		goto 44.9,23.9
		.' Discover Jangolode Mine |achieve 802/5
	step //2629
		goto 51.0,21.4
		.' Discover Furlbrow's Pumpkin Farm |achieve 802/3
	step //2630
		goto 57.7,15.8
		.' Discover The Jansen Stead |achieve 802/4
	step //2631
		goto 54.4,32.3
		.' Discover Saldean's Farm |achieve 802/2
	step //2632
		goto 55.9,49.3
		.' Discover Sentinel Hill |achieve 802/1
	step //2633
		goto 61.5,59.2
		.' Discover the Dead Acre |achieve 802/7
	step //2634
	label	"westfall1"
		' Explore Westfall |achieve 802
	step //2635
	label	"duskwood"
		'Skipping next part of guide |next "+deadwind" |only if step:Find("+duskwood1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2636
		goto Duskwood,10.1,44.3
		.' Discover The Hushed Bank |achieve 778/1
	step //2637
		goto 19.6,41.3
		.' Discover Raven Hill Cemetery |achieve 778/4
	step //2638
		goto 19.8,55.2
		.' Discover Raven Hill |achieve 778/3
	step //2639
		goto 21.4,69.9
		.' Discover Addle's Stead |achieve 778/2
	step //2640
		goto 35.8,72.7
		.' Discover Vul'Gol Ogre Mound |achieve 778/5
	step //2641
		goto 51.0,74.0
		.' Discover The Yorgen Farmstead |achieve 778/7
	step //2642
		goto 63.8,71.9
		.' Discover The Rotting Orchard |achieve 778/9
	step //2643
		goto 46.8,38.6
		.' Discover Twilight Grove |achieve 778/6
	step //2644
		goto 54.6,21.2
		.' Discover The Darkened Bank |achieve 778/13
	step //2645
		goto 64.7,37.7
		.' Discover Brightwood Grove |achieve 778/8
	step //2646
		goto 77.1,35.9
		.' Discover Manor Mistmantle |achieve 778/12
	step //2647
		goto 74.5,46.2
		.' Discover Darkshire |achieve 778/11
	step //2648
		goto 79.7,66.1
		.' Discover Tranquil Gardens Cemetery |achieve 778/10
	step //2649
	label	"duskwood1"
		' Explore Duskwood |achieve 778
	step //2650
	label	"deadwind"
		'Skipping next part of guide |next "+blasted" |only if step:Find("+deadwind1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2651
		goto Deadwind Pass,45.1,35.8
		.' Discover Deadman's Crossing |achieve 777/1
	step //2652
		goto 42.6,68.8
		.' Discover Karazhan |achieve 777/3
	step //2653
		goto 58.6,64.7
		.' Discover The Vice |achieve 777/2
	step //2654
	label	"deadwind1"
		' Explore Deadwind Pass |achieve 777
	step //2655
	label	"blasted"
		'Skipping next part of guide |next "+swamp" |only if step:Find("+blasted1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2656
		goto Blasted Lands,39.5,12.9
		.' Discover Dreadmaul Hold |achieve 766/1
	step //2657
		goto 45.1,26.7
		.' Discover Rise of the Defiler |achieve 766/9
	step //2658
		goto 47.1,40.1
		.' Discover Dreadmaul Post |achieve 766/7
	step //2659
		goto 54.4,52.9
		.' Discover The Dark Portal |achieve 766/5
	step //2660
		goto 32.3,45.7
		.' Discover The Tainted Scar |achieve 766/8
	step //2661
		goto 34.2,72.3
		.' Discover The Tainted Forest |achieve 766/14
	step //2662
		goto 44.5,86.1
		.' Discover Surwich |achieve 766/12
	step //2663
		goto 50.7,70.9
		.' Discover Sunveil Excursion |achieve 766/11
	step //2664
		goto 65.8,78.0
		.' Discover The Red Reaches |achieve 766/13
	step //2665
		goto 69.1,33.5
		.' Discover Shattershore |achieve 766/10
	step //2666
		goto 60.3,28.4
		.' Discover Serpent's Coil |achieve 766/4
	step //2667
		goto 64.3,15.8
		.' Discover Nethergare Keep |achieve 766/3
	step //2668
	label	"blasted1"
		' Explore Blasted Lands |achieve 766
	step //2669
	label	"swamp"
		'Skipping next part of guide |next "+redridge" |only if step:Find("+swamp1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2670
		goto Swamp of Sorrows,67.8,74.9
		.' Discover Stagalbog |achieve 782/7
	step //2671
		goto 84.2,38.9
		.' Discover Sorrowmurk |achieve 782/8
	step //2672
		goto 77.3,13.7
		.' Discover Misty Reed Strand |achieve 782/10
	step //2673
		goto 72.3,12.8
		.' Discover Bogpaddle |achieve 782/9
	step //2674
		goto 68.4,35.8
		.' Discover Marshtide Watch |achieve 782/12
	step //2675
		goto 62.6,50.0
		.' Discover Pool of Tears |achieve 782/6
	step //2676
		goto 48.8,42.1
		.' Discover The Shifting Mire |achieve 782/4
	step //2677
		goto 47.1,54.2
		.' Discover Stonard |achieve 782/5
	step //2678
		goto 18.6,68.1
		.' Discover Purespring Cavern |achieve 782/11
	step //2679
		goto 22.3,49.4
		.' Discover Splinterspear Junction |achieve 782/3
	step //2680
		goto 14.7,35.8
		.' Misty Valley |achieve 782/1
	step //2681
		goto 28.8,32.1
		.' Discover The Harborage |achieve 782/2
	step //2682
	label	"swamp1"
		' Explore Swamp of Sorrows |achieve 782
	step //2683
	label	"redridge"
		'Skipping next part of guide |next "+elwynn" |only if step:Find("+redridge1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2684
		goto Redridge Mountains,38.2,68.5
		.' Discover Lakeridge Highway |achieve 780/4
	step //2685
		goto 41.9,52.6
		.' Discover Lake Everstill |achieve 780/2
	step //2686
		goto 53.4,54.7
		.' Discover Camp Everstill |achieve 780/13
	step //2687
		goto 60.9,52.5
		.' Discover Stonewatch Keep |achieve 780/10
	step //2688
		goto 64.7,71.3
		.' Discover Render's Valley |achieve 780/8
	step //2689
		goto 81.0,62.4
		.' Discover Shalewind Canyon |achieve 780/12
	step //2690
		goto 47.2,39.2
		.' Discover Alther's Mill |achieve 780/6
	step //2691
		goto 35.1,12.8
		.' Discover Render's Camp |achieve 780/9
	step //2692
		goto 30.2,26.1
		.' Discover Redridge Canyons |achieve 780/5
	step //2693
		goto 25.5,43.4
		.' Discover Lakeshire |achieve 780/1
	step //2694
		goto 19.7,59.1
		.' Discover Three Corners |achieve 780/3
	step //2695
	label	"redridge1"
		' Explore Redridge Mountains |achieve 780
	step //2696
	label	"elwynn"
		'Skipping next part of guide |next "+burning" |only if step:Find("+elwynn1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2697
		goto Elwynn Forest,83.5,66.9
		.' Discover Eastvale Logging Camp |achieve 776/8
	step //2698
		goto 84.8,79.4
		.' Discover Ridgepoint Tower |achieve 776/9
	step //2699
		goto 69.4,79.4
		.' Discover Brackwell Pumpkin Patch |achieve 776/7
	step //2700
		goto 64.6,69.3
		.' Discover Tower of Azora |achieve 776/6
	step //2701
		goto 52.9,66.2
		.' Discover Crystal Lake |achieve 776/10
	step //2702
		goto 48.5,85.8
		.' Discover Jerod's Landing |achieve 776/5
	step //2703
		goto 39.5,80.3
		.' Discover Fargodeep Mine |achieve 776/4
	step //2704
		goto 24.5,73.3
		.' Discover Westbrook Garrison |achieve 776/2
	step //2705
		goto 42.1,64.7
		.' Discover Goldshire |achieve 776/3
	step //2706
		goto 50.4,42.5
		.' Discover Northshire Valley |achieve 776/1
	step //2707
		goto 74.0,51.5
		.' Discover Stone Cairn Lake |achieve 776/11
	step //2708
	label	"elwynn1"
		' Explore Elwynn Forest |achieve 776
	step //2709
	label	"burning"
		'Skipping next part of guide |next "+badlands" |only if step:Find("+burning1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2710
		goto Burning Steppes,66.7,77.5
		.' Discover Blackrock Pass |achieve 775/4
	step //2711
		goto 73.5,68.0
		.' Discover Morgan's Vigil |achieve 775/2
	step //2712
		goto 73.9,53.4
		.' Discover Terror Wing Path |achieve 775/3
	step //2713
		goto 69.7,40.5
		.' Discover Dreadmaul Rock |achieve 775/1
	step //2714
		goto 56.6,37.4
		.' Discover Ruins of Thaurissan |achieve 775/5
	step //2715
		goto 36.1,53.5
		.' Discover Black Tooth Hovel |achieve 775/6
	step //2716
		goto 24.3,57.7
		.' Discover The Whelping Downs |achieve 775/8
	step //2717
		goto 32.3,36.5
		.' Discover Blackrock Stronghold |achieve 775/7
	step //2718
		goto 20.7,29.2
		.' Discover Blackrock Mountain |achieve 775/10
	step //2719
		goto 9.4,27.5
		.' Discover Altar of Storms |achieve 775/9
	step //2720
	label	"burning1"
		' Explore Burning Steppes |achieve 775
	step //2721
	label	"badlands"
		'Skipping next part of guide |next "+searing" |only if step:Find("+badlands1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2722
		goto Badlands 68.0,48.2
		.' Discover Lethlor Ravine |achieve 765/1
	step //2723
		goto 60.1,20.7
		.' Discover Camp Kosh |achieve 765/8
	step //2724
		goto 38.3,11.6
		.' Discover Uldaman |achieve 765/3
	step //2725
		goto 41.1,26.5
		.' Discover Angor Fortress |achieve 765/7
	step //2726
		goto 27.4,38.
		.' Discover The Dustbowl |achieve 765/6
	step //2727
		goto 17.7,41.7
		.' Discover New Kargath |achieve 765/10
	step //2728
		goto 17.2,63.0
		.' Discover Camp Cagg |achieve 765/4
	step //2729
		goto 31.7,54.6
		.' Discover Scar of the Worldbreaker |achieve 765/5
	step //2730
		goto 46.5,57.4
		.' Discover Agmond's End |achieve 765/2
	step //2731
		goto 52.3,51.2
		.' Discover Bloodwatcher Point |achieve 765/9
	step //2732
	label	"badlands1"
		' Explore Badlands |achieve 765
	step //2733
	label	"searing"
		'Skipping next part of guide |next "+dun" |only if step:Find("+searing1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2734
		goto Searing Gorge,39.9,82.9
		.' Discover Blackrock Mountain |achieve 774/8
	step //2735
		goto 21.2,80.1
		.' Discover Balckchar Cave |achieve 774/3
	step //2736
		goto 23.8,31.8
		.' Discover Firewatch Ridge |achieve 774/1
	step //2737
		goto 37.7,29.9
		.' Discover Thorium Point |achieve 774/7
	step //2738
		goto 52.7,49.6
		.' Discover The Cauldron |achieve 774/2
	step //2739
		goto 71.8,26.8
		.' Discover Dustfire Valley |achieve 774/6
	step //2740
	label	"searing1"
		' Explore Searing Gorge |achieve 774
	step //2741
	label	"dun"
		'Skipping next part of guide |next "+loch" |only if step:Find("+dun1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2742
		goto Dun Morogh,84.1,51.8
		.' Discover Helm's Bed Lake |achieve 627/10
	step //2743
		goto 76.5,57.2
		.' Discover Gol'Bolar Quarry |achieve 627/11
	step //2744
		goto 71.5,46.2
		.' Discover Amberstill Ranch |achieve 627/9
	step //2745
		goto 67.2,53.9
		.' Discover The Tundrid Hills |achieve 627/8
	step //2746
		goto 58.6,57.7
		.' Discover Frostmane Front |achieve 627/3
	step //2747
		goto 53.6,50.5
		.' Discover Kharanos |achieve 627/7
	step //2748
		goto 48.3,52.8
		.' Discover The Grizzled Den |achieve 627/14
	step //2749
		goto 43.9,64.5
		.' Discover Coldridge Pass |achieve 627/1
	step //2750
		goto 34.6,75.6
		.' Discover Coldridge Valley |achieve 627/2
	step //2751
		goto 31.5,51.9
		.' Discover Frostmane Hold |achieve 627/13
	step //2752
		goto 33.8,37.5
		.' Discover New Tinkertown |achieve 627/4
	step //2753
		goto 41.4,40.2
		.' Discover Iceflow Lake |achieve 627/15
	step //2754
		goto 48.3,37.9
		.' Discover Shimmer Ridge |achieve 627/6
	step //2755
		goto 59.6,33.8
		.' Discover Gates of Ironforge |achieve 627/16
	step //2756
		goto 78.0,24.2
		.' Discover Ironforge Airfield |achieve 627/5
	step //2757
		goto 90.3,37.6
		.' Discover North Gate Outpost |achieve 627/12
	step //2758
	label	"dun1"
		' Explore Dun Morogh |achieve 627
	step //2759
	label	"loch"
		'Skipping next part of guide |next "+twilight" |only if step:Find("+loch1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2760
		goto Loch Modan,20.3,78.5
		.' Discover Valley of Kings |achieve 779/11
	step //2761
		goto 32.5,78.3
		.' Discover Stonesplinter Valley |achieve 779/10
	step //2762
		goto 38.0,60.7
		.' Discover Grizzlepaw Ridge |achieve 779/8
	step //2763
		goto 69.4,65.3
		.' Discover Ironband's Excavation Site |achieve 779/7
	step //2764
		goto 82.3,65.0
		.' Discover The Farstrider Lodge |achieve 779/6
	step //2765
		goto 71.0,23.8
		.' Discover Mo'grosh Stronghold |achieve 779/3
	step //2766
		goto 35.2,47.6
		.' Discover Thelsamar |achieve 779/9
	step //2767
		goto 20.2,17.1
		.' Discover North Gate Pass |achieve 779/5
	step //2768
		goto 34.8,21.5
		.' Discover Silver Stream Mine |achieve 779/4
	step //2769
		goto 48.0,11.4
		.' Discover Stonewrought Dam |achieve 779/2
	step //2770
	label	"loch1"
		' Explore Loch Modan |achieve 779
	step //2771
	label	"twilight"
		'Skipping next part of guide |next "+wetlands" |only if step:Find("+twilight1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2772
		goto Twilight Highlands,18.9,51.4
		.' Discover Grim Batol |achieve 4866/10
	step //2773
		goto 28.18,37.67
		.' Discover Dragonmaw Pass |achieve 4866/4 
	step //2774
		goto 29.0,47.8
		.' Discover Wyrms' Bend |achieve 4866/26
	step //2775
		goto 36.39,38.03 
		.' The Gullet |achieve 4866/19
	step //2776
		goto 39.9,46.6
		.' The Twilight Breach |achieve 4866/21
	step //2777
		goto 43.2,58.1
		.' Discover Victor's Point |achieve 4866/25
	step //2778
		goto 46.1,77.2
		.' Discover Crushblow |achieve 4866/3
	step //2779
		goto 49.5,68.8
		.' Discover Dunwald Ruins |achieve 4866/6
	step //2780
		goto 64.4,78.9
		.' Discover Obsibian Forest |achieve 4866/15
	step //2781
		goto 71.0,70.9
		.' Discover Twilight Shore |achieve 4866/23
	step //2782
		goto 80.7,76.8
		.' Discover Highbank |achieve 4866/11
	step //2783
		goto 76.0,53.0
		.' Discover Dragonmaw Port |achieve 4866/5
	step //2784
		goto 59.9,57.0
		.' Discover Firebeards's Patrol |achieve 4866/7
	step //2785
		goto 54.0,62.9
		.' Discover Highland Forest |achieve 4866/12
	step //2786
		goto 50.7,56.9
		.' Discover Crucible of Carnage |achieve 4866/2
	step //2787
		goto 54.1,42.7
		.' Discover Bloodgulch |achieve 4866/1
	step //2788
		goto 62.7,46.0
		.' Discover Gorshak War Camp |achieve 4866/9
	step //2789
		goto 71.0,38.8
		.' Discover Slithering Cove |achieve 4866/17
	step //2790
		goto 76.8,14.5
		.' Discover The Krazzworks |achieve 4866/20
	step //2791
		goto 54.9,17.3
		.' Discover Kirthaven |achieve 4866/14
	step //2792
		goto 57.9,30.3
		.' Discover The Black Breach |achieve 4866/18
	step //2793
		goto 50.2,29.1
		.' Discover Thundermar |achieve 4866/22
	step //2794
		goto 47.8,10.6
		.' The Maw of Madness |achieve 4866/27
	step //2795
		goto 43.6,18.1
		.' Ruins of Drakgor |achieve 4866/16
	step //2796
		goto 44.3,27.3
		.' Discover Humboldt Conflagration |achieve 4866/13
	step //2797
		goto 38.3,29.0
		.' Discover Glopgut's Hollow |achieve 4866/8
	step //2798
		goto 25.3,21.0
		.' Discover Vermillion Redoubt |achieve 4866/24
	step //2799
	label	"twilight1"
		' Explore Twilight Highlands |achieve 4866
	step //2800
	label	"wetlands"
		'Skipping next part of guide |next "+arathi" |only if step:Find("+wetlands1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2801
		goto Wetlands,67.9,34.9
		.' Discover Raptor Ridge |achieve 841/16
	step //2802
		goto 57.9,40.6
		.' Discover Greenwarden's Grove |achieve 841/11
	step //2803
		goto 61.9,56.6
		.' Discover Mosshide Fen |achieve 841/12
	step //2804
		goto 58.4,71.0
		.' Discover Slabchisel's Survey |achieve 841/15
	step //2805
		goto 50.0,76.4
		.' Discover Dun Algaz |achieve 841/14
	step //2806
		goto 52.2,61.4
		.' Discover Thelgen Rock |achieve 841/10
	step //2807
		goto 48.5,48.0
		.' Discover Angerfang Encampment |achieve 841/9
	step //2808
		goto 35.8,48.9
		.' Discover Whelgar's Excavation Site |achieve 841/4
	step //2809
		goto 10.2,58.2
		.' Discover Menethil Harbor |achieve 841/1
	step //2810
		goto 19.3,46.9
		.' Discover Black Channel Marsh |achieve 841/2
	step //2811
		goto 18.9,36.0
		.' Discover Bluegill Marsh |achieve 841/3
	step //2812
		goto 24.5,24.3
		.' Discover Sundown Marsh |achieve 841/5
	step //2813
		goto 32.5,17.6
		.' Discover Saltspray Glen |achieve 841/6
	step //2814
		goto 43.6,25.9
		.' Discover Ironbeard's Tomb |achieve 841/7
	step //2815
		goto 46.9,16.5
		.' Discover Dun Modr |achieve 841/8
	step //2816
	label	"wetlands1"
		' Explore Wetland |achieve 841
	step //2817
	label	"arathi" 
		'Skipping next part of guide |next "+hillsbrad" |only if step:Find("+arathi1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2818
		goto Arathi Highlands,41.3,91.0
		.' Discover Thandol Span |achieve 761/8
	step //2819
		goto 49.1,78.9
		.' Discover Boulderfist Hall |achieve 761/9
	step //2820
		goto 61.6,70.3
		.' Discover Witherbark Village |achieve 761/12
	step //2821
		goto 56.4,57.6
		.' Discover Go'Shek Farm |achieve 761/13
	step //2822
		goto 69.3,37.2
		.' Discover Hammerfall |achieve 761/16
	step //2823
		goto 59.3,32.8
		.' Discover Circle of East Binding |achieve 761/15
	step //2824
		goto 49.9,41.3
		.' Discover Dabyrie's Farmstead |achieve 761/14
	step //2825
		goto 47.3,51.4
		.' Discover Circle of Outer Binding |achieve 761/11
	step //2826
		goto 39.8,46.4
		.' Discover Refuge Pointe |achieve 761/10
	step //2827
		goto 30.1,59.3
		.' Discover Circle of Inner Binding |achieve 761/7
	step //2828
		goto 23.8,81.8
		.' Discover Faldir's Cove |achieve 761/6
	step //2829
		goto 16.5,64.1
		.' Discover Stromgarde Keep |achieve 761/5
	step //2830
		goto 27.5,44.2
		.' Discover Boulder'gor |achieve 761/3
	step //2831
		goto 27.0,27.1
		.' Discover Northfold Manor |achieve 761/2
	step //2832
		goto 13.0,36.4
		.' Discover Galen's Fall |achieve 761/4
	step //2833
	label	"arathi1"
		' Explore Arathi Highlands |achieve 761
	step //2834
	label	"hillsbrad"
		'Skipping next part of guide |next "+silver" |only if step:Find("+hillsbrad1"):IsComplete()
		'Proceeding next step |next |only if default
		step //2835
		goto Hillsbrad Foothills,68.3,60.0
		.' Discover Durnholde Keep |achieve 772/10
	step //2836
		goto 68.1,32.9
		.' Discover Chillwind Point |achieve 772/5
	step //2837
		goto 58.3,23.4
		.' Discover Strahnbrad |achieve 772/22
	step //2838
		goto 57.51,74.96
		.' Discover Nethander Stead |achieve 772/15
	step //2839
		goto 52.4,12.6
		.' Discover The Uplands |achieve 772/26
	step //2840
		goto 44.9,9.1
		.' Discover Dandred's Fold |achieve 772/7
	step //2841
		goto 45.3,29.0
		.' Discover Ruins of Alterac |achieve 772/17
	step //2842
		goto 43.2,38.5
		.' Discover Growless Cave |achieve 772/13
	step //2843
		goto 55.6,38.5
		.' Discover Sofera's Naze |achieve 772/20
	step //2844
		goto 56.7,46.9
		.' Discover Tarren Mill |achieve 772/23
	step //2845
		goto 49.6,46.7
		.' Discover Corrahn's Dagger |achieve 772/3
	step //2846
		goto 48.97,71.89
		.' Discover Ruins of Southshore |achieve 772/18
	step //2847
		goto 44.2,48.6
		.' Discover The Headland |achieve 772/24
	step //2848
		goto 40.0,47.6
		.' Discover Gavin's Naze |achieve 772/12
	step //2849
		goto 35.06,26.14
		.' Discover Misty Shore |achieve 772/14
	step //2850
		goto 33.8,46.5
		.' Discover Brazie Farmstead |achieve 772/2
	step //2851
		goto 30.4,36.2
		.' Discover Dalaran Crater |achieve 772/6
	step //2852
		goto 29.5,63.6
		.' Discover Southpoint Gate |achieve 772/21
	step //2853
		goto 34.0,73.8
		.' Discover Azurlode Mine |achieve 772/1
	step //2854
		goto 27.0,85.6
		.' Discover Purgation Isle |achieve 772/16
	step //2855
	label	"hillsbrad1"
		' Explore Hillsbrad Foothills |achieve 772
	step //2856
	label	"silver"
		'Skipping next part of guide |next "+tirisfal" |only if step:Find("+silver1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2857
		goto Silverpine Forest,46.1,79.5
		.' Discover The Battlefront |achieve 769/1
	step //2858
		goto 42.2,63.2
		.' Discover Shadowfang Keep |achieve 769/12
	step //2859
		goto 50.9,66.6
		.' Discover The Forsaken Front |achieve 769/3
	step //2860
		goto 61.2,62.4
		.' Discover Ambermill |achieve 769/11
	step //2861
		goto 46.1,51.0
		.' Discover Olsen's Farthing |achieve 769/10
	step //2862
		goto 45.0,40.0
		.' Discover The Sepulcher |achieve 769/8
	step //2863
		goto 37.3,28.0
		.' Discover North Tide's Beachead |achieve 769/5
	step //2864
		goto 34.8,12.4
		.' Discover The Skittering Dark |achieve 769/4
	step //2865
		goto 44.9,18.8
		.' Discover Forsaken Rear Guard |achieve 769/15
	step //2866
		goto 53.2,25.6
		.' Discover Valgan's Field |achieve 769/7
	step //2867
		goto 56.5,34.7
		.' Discover The Decrepit Fields |achieve 769/2
	step //2868
		goto 59.3,45.4
		.' Discover Deep Elem Mine |achieve 769/9
	step //2869
		goto 69.1,26.8
		.' Discover Fenris Isle |achieve 769/6
	step //2870
		goto 62.0,8.7
		.' Discover Forsaken High Command |achieve 769/13
	step //2871
	label	"silver1"
		' Explore Silverpine Forest |achieve 769
	step //2872
	label	"tirisfal"
		'Skipping next part of guide |next "+w_plague" |only if step:Find("+tirisfal1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2873
		goto Tirisfal Glades,32.2,63.8
		.' Discover Deathknell |achieve 768/1
	step //2874
		goto 45.1,65.4
		.' Discover Nightmare Vale |achieve 768/4
	step //2875
		goto 53.8,58.7
		.' Discover Cold Hearth Manor |achieve 768/5
	step //2876
		goto 46.2,51.4
		.' Discover Calston Estate |achieve 768/16
	step //2877
		goto 38.4,48.9
		.' Discover Solliden Farmstead |achieve 768/9
	step //2878
		goto 45.6,32.9
		.' Discover Agamand Mills |achieve 768/3
	step //2879
		goto 56.9,35.6
		.' Discover Garren's Haunt |achieve 768/7
	step //2880
		goto 59.7,50.9
		.' Discover Brill |achieve 768/6
	step //2881
		goto 68.3,45.0
		.' Discover Brightwater Lake |achieve 768/8
	step //2882
		goto 78.4,26.9
		.' Discover Scarlet Watch Post |achieve 768/11
	step //2883
		goto 87.00,47.2
		.' Discover Venomweb Vale |achieve 768/12
	step //2884
		goto 79.1,54.7
		.' Discover Crusader Outpost |achieve 768/10
	step //2885
		goto 73.7,60.0
		.' Discover Balnir Farmstead |achieve 768/9
	step //2886
		goto 84.9,69.4
		.' Discover The Bulwark |achieve 768/15
	step //2887
	label	"tirisfal1"
		' Explore Tirisfal Glades |achieve 768
	step //2888
	label	"w_plague"
		'Skipping next part of guide |next "+hinterlands" |only if step:Find("+w_plague1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2889
		goto Western Plaguelands,27.0,57.7
		.' Discover The Bulwark |achieve 770/5
	step //2890
		goto 36.5,54.6
		.' Discover Felstone Field |achieve 770/6
	step //2891
		goto 45.1,51.2
		.' Discover Dalson's Farm |achieve 770/7
	step //2892
		goto 46.0,45.5
		.' Discover Redpine Dell |achieve 770/11
	step //2893
		goto 47.2,33.4
		.' Northridge Lumber Camp |achieve 770/9
	step //2894
		goto 44.9,17.0
		.' Discover Hearthglen |achieve 770/10
	step //2895
		goto 64.4,40.1
		.' Discover The Weeping Cave |achieve 770/13
	step //2896
		goto 69.6,50.7
		.' Discover Thondroril River |achieve 770/14
	step //2897
		goto 63.9,58.2
		.' Discover Gahrron's Withering |achieve 770/12
	step //2898
		goto 54.9,66.2
		.' Discover The Writhing Haunt |achieve 770/8
	step //2899
		goto 54.6,85.5
		.' Discover Sorrow Hill |achieve 770/3
	step //2900
		goto 68.3,81.1
		.' Discover Caer Darrow |achieve 770/2
	step //2901
	label	"w_plague1"
		' Explore Western Plaguelands |achieve 770
	step //2902
	label	"hinterlands"
		'Skipping next part of guide |next "+e_plague" |only if step:Find("+hinterlands1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2903
		goto The Hinterlands,13.9,45.0
		.' Discover Aerie Peak |achieve 773/1
	step //2904
		goto 23.1,33.5
		.' Discover Plaguemist Ravine |achieve 773/2
	step //2905
		goto 33.3,45.6
		.' Discover Quel'Danil Lodge |achieve 773/4
	step //2906
		goto 34.6,72.0
		.' Discover Shadra'Alor |achieve 773/5
	step //2907
		goto 40.5,59.3
		.' Discover Valorwind Lake |achieve 773/6
	step //2908
		goto 48.4,66.9
		.' Discover The Altar of Zul |achieve 773/9
	step //2909
		goto 49.0,52.1
		.' Discover The Creeping Ruin |achieve 773/8
	step //2910
		goto 63.1,74.7
		.' Discover Jintha'Alor |achieve 773/13
	step //2911
		goto 72.7,66.1
		.' Discover The Overlook Cliffs |achieve 773/14
	step //2912
		goto 73.2,54.2
		.' Discover Shaol'watha |achieve 773/12
	step //2913
		goto 57.6,42.6
		.' Discover Skulk Rock |achieve 773/11
	step //2914
		goto 62.7,24.1
		.' Discover Seradane |achieve 773/10
	step //2915
	label	"hinterlands1"
		' Explore The Hinterlands |achieve 773
	step //2916
	label	"e_plague"
		'Skipping next part of guide |next "+ghost" |only if step:Find("+e_plague1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2917
		goto Eastern Plaguelands,35.1,84.2
		.' Discover Darrowshire |achieve 771/6
	step //2918
		goto 24.0,78.8
		.' Discover The Undercroft |achieve 771/3
	step //2919
		goto 22.6,66.0
		.' The Marris Stead |achieve 771/2
	step //2920
		goto 12.5,26.3
		.' Discover Terrordale |achieve 771/20
	step //2921
		goto 26.8,9.8
		.' Discover Statholme |achieve 771/22
	step //2922
		goto 33.6,24.4
		.' Discover Plaguewood |achieve 771/21
	step //2923
		goto 36.1,44.8
		.' Discover The Fungal Vale |achieve 771/5
	step //2924
		goto 35.7,68.5
		.' Discover Crown Guard Tower |achieve 771/4
	step //2925
		goto 57.4,74.1
		.' Discover Lake Mereldar |achieve 771/9
	step //2926
		goto 55.6,62.9
		.' Discover Corin's Crossing |achieve 771/8
	step //2927
		goto 46.3,43.5
		.' Discover Blackwood Lake |achieve 771/15
	step //2928
		goto 48.1,13.1
		.' Discover Quel'Lithien Lodge |achieve 771/19
	step //2929
		goto 50.5,20.5
		.' Discover Northpass Tower |achieve 771/18
	step //2930
		goto 62.4,41.7
		.' Discover Eastwall Tower |achieve 771/14
	step //2931
		goto 68.7,56.5
		.' Discover Pestilent Scar |achieve 771/7
	step //2932
		goto 75.6,75.2
		.' Discover Tyr's Hand |achieve 771/10
	step //2933
		goto 87.1,78.5
		.' Discover Ruins of the Scarlet Enclave |achieve 771/23
	step //2934
		goto 76.8,53.9
		.' Discover Light's Hope Chapel |achieve 771/11
	step //2935
		goto 78.1,35.8
		.' Discover The Noxious Glade |achieve 771/13
	step //2936
		goto 66.1,25.0
		.' Discover Northdale |achieve 771/16
	step //2937
		goto 66.4,10.3
		.' Discover Zul'Mashar |achieve 771/17
	step //2938
	label	"e_plague1"
		' Explore Eastern Plaguelands |achieve 771
	step //2939
	label	"ghost"
		'Skipping next part of guide |next "+eversong" |only if step:Find("+ghost1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2940
		goto 54.4,7.0
		.' Go through the Portal to Ghostlands |tip It looks like a big swirling portal.
		.' Teleport to Ghostlands |goto Ghostlands |noway |c
	step //2941
		goto Ghostlands,48.2,84.3
		.' Discover Thalassian Pass |achieve 858/16
	step //2942
		goto 33.1,79.9
		.' Discover Deatholme |achieve 858/10
	step //2943
		goto 12.4,57.0
		.' Discover Windrunner Spire |achieve 858/13
	step //2944
		goto 17.9,41.4
		.' Discover Windrunner Village |achieve 858/4
	step //2945
		goto 25.0,15.0
		.' Discover Goldenmist Village |achieve 858/3
	step //2946
		goto 33.4,32.2
		.' Discover Sanctum of the Moon |achieve 858/5
	step //2947
		goto 34.3,47.6
		.' Discover Bleeding Ziggurat |achieve 858/14
	step //2948
		goto 40.4,49.8
		.' Discover Howling Ziggurat |achieve 858/9
	step //2949
		goto 47.12,32.8
		.' Discover Tranquillien |achieve 858/1
	step //2950
		goto 54.7,49.7
		.' Sanctum of the Sun |achieve 858/6
	step //2951
		goto 66.6,58.9
		.' Discover Zeb'Nowa |achieve 858/11
	step //2952
		goto 77.3,64.4
		.' Discover Amani Pass |achieve 858/12
	step //2953
		goto 72.4,31.7
		.' Discover Farstrider Enclave |achieve 858/8
	step //2954
		goto 78.6,18.7
		.' Discover Dawnstart Spire |achieve 858/7
	step //2955
		goto 60.46,11.7
		.' Discover Suncrown Village |achieve 858/2
	step //2956
		goto 48.39,11.51
		.' Discover Elrendar Crossing |achieve 858/15
	step //2957
	label	"ghost1"
		' Explore Ghostlands |achieve 858
	step //2958
	label	"eversong"
		'Skipping next part of guide |next "+isle_q" |only if step:Find("+eversong1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2959
		goto Eversong Woods,36.2,86.0
		.' Discover The Scorched Grove |achieve 859/13
	step //2960
		goto 44.1,85.8
		.' Discover Runestone Falithas |achieve 859/19
	step //2961
		goto 55.8,84.2
		.' Discover Rusestone Shan'dor |achieve 859/20
	step //2962
		goto 62.2,79.3
		.' Discover Zeb'Watha |achieve 859/25
	step //2963
		goto 65.9,78.6
		.' Discover Lake Elrendar |achieve 859/18
	step //2964
		goto 72.0,79.3
		.' Discover Tor'Watha |achieve 859/12
	step //2965
		goto 64.6,73.1
		.' Discover Elreandar Falls |achieve 859/16
	step //2966
		goto 61.2,63.7
		.' Discover Farstrider Rereat |achieve 859/7
	step //2967
		goto 55.7,56.4
		.' Discover Stillwhisper Pond |achieve 859/8
	step //2968
		goto 60.6,54.2
		.' Discover Thuron's Livery |achieve 859/23
	step //2969
		goto 71.6,45.3
		.' Discover Azurebreeze Coast |achieve 859/15
	step //2970
		goto 52.4,39.4
		.' Disocver Silvermoon City |achieve 859/14
	step //2971
		goto 31.3,16.0
		.' Discover Sunstrider Isle |achieve 859/1
	step //2972
		goto 42.9,39.3
		.' Discover Ruins of Silvermoon |achieve 859/2
	step //2973
		goto 42.7,50.4
		.' Discover North Sanctum |achieve 859/5
	step //2974
		goto 35.3,57.6
		.' Discover West Sanctum |achieve 859/3
	step //2975
		goto 28.5,57.8
		.' Discover Tranquil Shore |achieve 859/24
	step //2976
		goto 29.4,69.3
		.' Discover Sunsail Anchorage |achieve 859/4
	step //2977
		goto 23.5,74.8
		.' Discover Golden Strand |achieve 859/22
	step //2978
		goto 33.4,77.6
		.' Discover Goldenbough Pass |achieve 859/17
	step //2979
		goto 38.3,73.5
		.' Discover Saltheril's Haven |achieve 859/21
	step //2980
		goto 43.9,73.7
		.' Discover Fairbreeze Village |achieve 859/10
	step //2981
		goto 52.3,73.1
		.' Discover East Sanctum |achieve 859/6
	step //2982
		goto 54.2,71.9
		.' Discover The Living Wood |achieve 859/11
	step //2983
		goto 36.2,86.0
		.' Discover The Scorched Grove |achieve 859/13
	step //2984
	label	"eversong1"
		' Explore Eversong Woods |achieve 859
	step //2985
	label	"isle_q"
		'Skipping next part of guide |next "+end" |only if step:Find("+isle_q1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2986
		|fly Shattered Sun Staging Area
	step //2987
	label	"isle_q1"
		' Explore Isle of Quel'Danas |achieve 868
	step //2988
	label	"end"
		' Congratulations! You have Explored the Eastern Kingdoms |achieve 42 |only if achieved(42)
		.' Congratulations! You have Explored Cataclysm |achieve 4868 |only if achieved(4868)
		' Congratulations! You have Earned the Achievement World Explorer! |achieve 46 |only if achieved(46)
		.' You have not explored all of Eastern Kingdoms yet |only if not achieved(42)
		|confirm |next "start" |only if not achieved(42)	
]])

ZygorGuidesViewer:RegisterInclude("H_Explorer_Outlands",[[
	step //2989
		' This guide assumes you have a flying mount. You can do this guide
		.' without having a flying mount but it will be much more efficient with one.
		|confirm always
	step //2990
	label	"start"
		' Explore Hellfire Peninsula |achieve 862
		' Explore Terokkar Forest |achieve 867
		' Explore Shadowmoon Valley |achieve 864
		' Explore Nagrand |achieve 866
		' Explore Zangarmarsh |achieve 863
		' Explore Blade's Edge Mountains |achieve 865
		' Explore Netherstorm |achieve 843                 
		|confirm always
	step //2991
		#include "darkportal"
	step //2992
		'Skipping next part of guide |next "+terokkar" |only if step:Find("+hellfire1"):IsComplete()
		'Proceeding next step |next |only if default
	step //2993
		goto Hellfire Peninsula,87.7,50.3
		.' Discover The Stair of Destiny |achieve 862/1
	step //2994
		goto 62.0,17.8
		.' Discover Throne of Kil'jaeden |achieve 862/12
	step //2995
		goto 58.9,31.2
		.' Discover Forge Camp: Mageddon |achieve 862/18
	step //2996
		goto 55.4,38.7
		.' Disocver Thrallmar |achieve 862/11
	step //2997
		goto 70.0,50.4
		.' Discover The Legion Front |achieve 862/10
	step //2998
		goto 79.1,72.9
		.' Discover Void Ridge |achieve 862/16
	step //2999
		goto 70.1,73.6
		.' Discover Zeth'Gor |achieve 862/13
	step //3000
		goto 54.3,84.3
		.' Discover Expedition Armory |achieve 862/2
	step //3001
		goto 45.3,82.5
		.' Discover The Warp Fields |achieve 862/17
	step //3002
		goto 54.8,64.5
		.' Discover Honor Hold |achieve 862/5
	step //3003
		goto 47.2,52.9
		.' Discover Hellfire Citadel |achieve 862/4 
	step //3004
		goto 41.2,32.6
		.' Discover Pools of Aggonar |achieve 862/7
	step //3005
		goto 31.3,26.9
		.' Discover Mag'har Post |achieve 862/6
	step //3006
		goto 23.5,40.0
		.' Discover Temple of Telhamat |achieve 862/9 
	step //3007
		goto 26.9,62.3
		.' Discvoer Falcon Watch |achieve 862/3
	step //3008
		goto 27.5,77.0
		.' Discover Den of Haal'esh |achieve 862/14
	step //3009
		goto 14.3,41.0
		.' Discover Fallen Sky Ridge |achieve 862/15
	step //3010
		goto 13.3,59.4
		.' Discover Ruins of Sha'naar |achieve 862/8
	step //3011
	label	"hellfire1"
		' Explore Hellfire Peninsula |achieve 862
	step //3012
	label	"terokkar"
		'Skipping next part of guide |next "+shadowmoon" |only if step:Find("+terokkar1"):IsComplete()
		'Proceeding next step |next |only if default
	step //3013
		goto Terokkar Forest,59.9,17.0
		.' Discover Razorthorn Shelf |achieve 867/11
	step //3014
		goto 53.0,29.1
		.' Discover Tuurem |achieve 867/7
	step //3015
		goto 43.8,20.2
		.' Discover Cenarion Thicket |achieve 867/3
	step //3016
		goto 29.1,23.3
		.' Discover Shattrath City |achieve 867/8
	step //3017
		goto 22.4,10.5
		.' Discover The Barrier Hills |achieve 867/10
	step //3018
		goto 17.8,65.4
		.' Discover Bleeding Hollow Ruins |achieve 867/1
	step //3019
		goto 24.4,59.9
		.' Discover Veil Rhaze |achieve 867/19
	step //3020
		goto 31.3,52.5
		.' Discover Shadow Tomb |achieve 867/17
	step //3021
		goto 37.5,49.6
		.' Discover Refugee Caravan |achieve 867/15
	step //3022
		goto 42.9,51.0
		.' Discover Carrion Hill |achieve 867/14
	step //3023
		goto 39.5,39.4
		.' Discover Grangol'var Village |achieve 867/5
	step //3024
		goto 46.6,43.0
		.' Discover Stonebreaker Hold |achieve 867/6
	step //3025
		goto 60.6,40.2
		.' Discover Raastok Glade |achieve 867/9
	step //3026
		goto 71.7,34.7
		.' Discover Firewing Point |achieve 867/4
	step //3027
		goto 66.5,52.3
		.' Discover Bonechewer Ruins |achieve 867/12
	step //3028
		goto 57.1,56.6
		.' Discover Allerian Stronghold |achieve 867/2
	step //3029
		goto 49.1,66.0
		.' Discover Writhing Mound |achieve 867/20
	step //3030
		goto 39.5,65.5
		.' Discover Ring of Observance |achieve 867/16
	step //3031
		goto 33.0,71.8
		.' Discover Auchenai Grounds |achieve 867/13
	step //3032
		goto 43.9,76.1
		.' Discover Derelict Caravan |achieve 867/18
	step //3033
		goto 58.9,76.4
		.' Discover Skettis |achieve 867/21
	step //3034
	label	"terokkar1"
		' Explore terokkar Forest |achieve 867
	step //3035
	label	"shadowmoon"
		'Skipping next part of guide |next "+nagrand" |only if step:Find("+shadowmoon1"):IsComplete()
		'Proceeding next step |next |only if default
	step //3036
		goto Shadowmoon Valley,24.1,39.2
		.' Discover Legion Hold |achieve 864/3
	step //3037
		goto 29.8,52.3
		.' Discover Illidari Point |achieve 864/12
	step //3038
		goto 35.5,60.2
		.' Discover Wildhammer Stronghold |achieve 864/10 
	step //3039
		goto 44.9,66.8
		.' Discover Eclipse Point |achieve 864/2
	step //3040
		goto 70.8,85.7
		.' Discover Netherwing Ledge |achieve 864/4
	step //3041
		goto 64.2,58.5
		.' Discover Netherwing Fields |achieve 864/13
	step //3042
		goto 57.3,50.1
		.' Discover Warden's Cage |achieve 864/9
	step //3043
		goto 49.8,41.2
		.' Discover The Hand of Gul'dan |achieve 864/8 
	step //3044
		goto 39.6,39.6
		.' Discover The Deathforge |achieve 864/7
	step //3045
		goto 29.4,26.1
		.' Discover Shadowmoon Village |achieve 864/5
	step //3046
		goto 45.3,26.3
		.' Discover Coilskar Point |achieve 864/1
	step //3047
		goto 61.5,26.1
		.' Discover Altar of Sha'tar |achieve 864/11
	step //3048
		goto 77.6,40.6
		.' Discover The Black Temple |achieve 864/6
	step //3049
	label	"shadowmoon1"
		' Explore Shadowmoon Valley |achieve 864
	step //3050
	label	"nagrand"
		'Skipping next part of guide |next "+zangar" |only if step:Find("+nagrand1"):IsComplete()
		'Proceeding next step |next |only if default
	step //3051
		goto Nagrand,74.3,52.9
		.' Discover Windyreed Village |achieve 866/18
	step //3052
		goto 75.1,66.8
		.' Discover Burning Blade Ruins |achieve 866/12
	step //3053
		goto 68.9,79.9
		.' Discover Kil'sorrow Fortress |achieve 866/4
	step //3054
		goto 62.5,64.3
		.' Discover Clan Watch |achieve 866/13
	step //3055
		goto 65.8,54.0
		.' Discover The Ring of Trials |achieve 866/9
	step //3056
		goto 49.8,55.9
		.' Discover Southwind Cleft |achieve 866/15
	step //3057
		goto 52.8,69.1
		.' Discover Telaar |achieve 866/8
	step //3058
		goto 42.0,71.8
		.' Discover Spirit Fields |achieve 866/6
	step //3059
		goto 42.5,44.0
		.' Discover Halaa |achieve 866/3
	step //3060
		goto 33.5,44.7
		.' Discover Sunspring Post |achieve 866/7
	step //3061
		goto 20.6,51.3
		.' Discover Forge Camp: Fear |achieve 866/1
	step //3062
		goto 10.8,39.2
		.' Discover The Twilight Ridge |achieve 866/16
	step //3063
		goto 25.9,37.1
		.' Discover Forge Camp: Hate |achieve 866/14
	step //3064
		goto 29.7,24.6
		.' Discover Warmaul Hill |achieve 866/11
	step //3065
		goto 33.9,18.4
		.' Discover Zangar Ridge |achieve 866/19
	step //3066
		goto 46.9,18.9
		.' Discover Laughing Skull Ruins |achieve 866/5
	step //3067
		goto 56.1,36.4
		.' Discover Garadar |achieve 866/2
	step //3068
		goto 60.8,21.1
		.' Discover Throne of the Elements |achieve 866/10
	step //3069
		goto 72.4,36.3
		.' Discover Windyreed Pass |achieve 866/17
	step //3070
	label	"nagrand1"
		' Explore Nagrand |achieve 866
	step //3071
	label	"zangar"
		'Skipping next part of guide |next "+blade" |only if step:Find("+zangar1"):IsComplete()
		'Proceeding next step |next |only if default
	step //3072
		goto Zangarmarsh,70.6,79.9
		.' Discover Darkcrest Shore |achieve 863/18
	step //3073
		goto 83.5,82.0
		.' Discover Umbrafen Village |achieve 863/11
	step //3074
		goto 81.1,63.4
		.' Discover Cenarion Refuge |achieve 863/1
	step //3075
		goto 82.5,37.5
		.' Discover The Dead Mire |achieve 863/8
	step //3076
		goto 68.5,49.2
		.' Discover Teredor |achieve 863/7
	step //3077
		goto 62.7,41.2
		.' Discover Bloodscale Grounds |achieve 863/14
	step //3078
		goto 58.6,61.8
		.' Discover The Lagoon |achieve 863/9
	step //3079
		goto 47.8,51.7
		.' Discover Twin Spire Ruins |achieve 863/10
	step //3080
		goto 44.9,66.3
		.' Discover Feralfen Village |achieve 863/3
	step //3081
		goto 31.8,52.3
		.' Discover Zabra'jin |achieve 863/17
	step //3082
		goto 29.0,60.7
		.' Discover Quagg Ridge |achieve 863/6
	step //3083
		goto 14.5,61.9
		.' Discover The Spawning Glen |achieve 863/16 
	step //3084
		goto 17.8,49.6
		.' Discover Sporeggar |achieve 863/12
	step //3085
		goto 21.7,39.6
		.' Discover Marshlight Lake |achieve 863/5
	step //3086
		goto 18.0,23.1
		.' Disocver Ango'rosh Grounds |achieve 863/2
	step //3087
		goto 18.6,8.0
		.' Discover Ango'rosh Stronghold |achieve 863/13
	step //3088
		goto 33.6,35.3
		.' Discover Hewn Bog |achieve 863/4
	step //3089
		goto 44.9,25.2
		.' Discover Orebor Harborage |achieve 863/15
	step //3090
	label	"zangar1"
		' Explore Zangarmarsh |achieve 863
	step //3091
	label	"blade"
		'Skipping next part of guide |next "+nether" |only if step:Find("+blade1"):IsComplete()
		'Proceeding next step |next |only if default
	step //3092
		goto Blade's Edge Mountains,29.1,81.0
		.' Discover Forge Camp: Terror |achieve 865/10
	step //3093
		goto 30.5,59.5
		.' Discover Vortex Summit |achieve 865/26
	step //3094
		goto 33.5,41.1
		.' Discover Forge Camp: Wrath |achieve 865/11
	step //3095
		goto 31.9,27.5
		.' Discover Raven's Wood |achieve 865/16
	step //3096
		goto 39.6,19.9
		.' Discover Grishnath |achieve 865/12
	step //3097
		goto 51.7,16.7
		.' Discover Bash'ir Landing |achieve 865/1
	step //3098
		goto 68.0,10.8
		.' Discover Crystal Spine |achieve 865/21
	step //3099
		goto 77.9,25.9
		.' Discover Broken Wilds |achieve 865/6
	step //3100
		goto 72.0,22.9
		.' Discover Skald |achieve 865/19
	step //3101
		goto 67.7,23.5
		.' Discover Gruul's Lair |achieve 865/13 
	step //3102
		goto 55.6,26.2
		.' Discover Bloodmaul Camp |achieve 865/4
	step //3103
		goto 40.7,53.0
		.' Discover Bladespire Hold |achieve 865/3
	step //3104
		goto 37.0,65.4
		.' Discover Sylvanaar |achieve 865/20
	step //3105
		goto 36.4,78.7
		.' Discover Veil Lashh |achieve 865/23
	step //3106
		goto 46.3,77.2
		.' Discover Bloodmaul Outpost |achieve 865/5 
	step //3107
		goto 48.0,64.9
		.' Discover Jagged Ridge |achieve 865/14
	step //3108
		goto 56.0,69.0
		.' Discover Razor Ridge |achieve 865/17
	step //3109
		goto 64.2,61.0
		.' Discover Death's Door |achieve 865/8
	step //3110
		goto 53.1,54.7
		.' Discover Thunderlord Stronghold |achieve 865/22
	step //3111
		goto 53.6,43.9
		.' Discover Circle of Blood |achieve 865/7
	step //3112
		goto 61.2,36.5
		.' Discover Ruuan Weald |achieve 865/18
	step //3113
		goto 65.1,31.6
		.' Discover Veil Ruuan |achieve 865/24
	step //3114
		goto 65.9,36.8
		.' Discover Bladed Gulch |achieve 865/2
	step //3115
		goto 74.7,41.8
		.' Discover Forge Camp: Anger |achieve 865/9
	step //3116
		goto 73.9,62.6
		.' Discover Mok'Nathal Village |achieve 865/15
	step //3117
		goto 77.1,75.2
		.' Discover Vekhaar Stand |achieve 865/25
	step //3118
	label	"blade1"
		' Explore Blade's Edge Mountains |achieve 865 
	step //3119
	label	"nether"
		'Skipping next part of guide |next "+end" |only if step:Find("+nether1"):IsComplete()
		'Proceeding next step |next |only if default
	step //3120
		goto Netherstorm,23.5,72.9
		.' Discover Manaforge B'naar |achieve 843/2
	step //3121
		goto 28.4,77.5
		.' Discover The Heap |achieve 843/9
	step //3122
		goto 33.5,66.0
		.' Discover Area 52 |achieve 843/1
	step //3123
		goto 39.7,73.5
		.' Discover Arklon Ruins |achieve 843/10
	step //3124
		goto 48.8,84.5
		.' Discover Manaforge Coruu |achieve 843/3
	step //3125
		goto 57.1,88.5
		.' Discover Kirin'Var Village |achieve 843/12
	step //3126
		goto 56.0,77.8
		.' Discover Sunfury Hold |achieve 843/15
	step //3127
		goto 59.6,68.2
		.' Discover Maforge Duro |achieve 843/4
	step //3128
		goto 75.8,62.5
		.' Discover Tempest Keep |achieve 843/8
	step //3129
		goto 72.5,38.7
		.' Discover Celestial Ridge |achieve 843/11
	step //3130
		goto 61.7,38.2
		.' Discover Manaforge Ultris |achieve 843/6
	step //3131
		goto 55.1,43.5
		.' Discover Ethereum Staging Grounds |achieve 843/19
	step //3132
		goto 54.4,21.3
		.' Discover Ruins of Farahlon |achieve 843/7
	step //3133
		goto 49.5,17.0
		.' Discover Netherstone |achieve 843/13
	step //3134
		goto 46.1,9.6
		.' Discover Eco-Dome Farfield |achieve 843/18
	step //3135
		goto 29.9,16.0
		.' Discover Socrethar's Seat |achieve 843/20
	step //3136
		goto 37.5,26.4
		.' Discover Forge Base: Oblivion |achieve 843/21
	step //3137
		goto 45.1,35.8
		.' Discover The Stormspire |achieve 843/16
	step //3138
		goto 45.3,53.7
		.' Discover Eco-Dome Midrealm |achieve 843/22
	step //3139
		goto 32.9,54.9
		.' Discover ruins of Enkaat |achieve 843/14
	step //3140
		goto 23.2,55.9
		.' Discover Gyro-Plank Bridge |achieve 843/17
	step //3141
		goto 26.8,39.3
		.' Discover Manaforge Ara |achieve 843/5
	step //3142
	label	"nether1"
		' Explore Netherstorm |achieve 843
	step //3143
	label	"end"
		' Congratulations! You have Explored Outlands! |achieve 44 |only if achieved(44)
		' Congratulations! You have Earned the Achievement World Explorer! |achieve 46 |only if achieved(46)
		' You have not fully explored Outlands yet |only if not achieved(44)
		|confirm |next "start" |only if not achieved(44)		
]])

ZygorGuidesViewer:RegisterInclude("H_Explorer_Northrend",[[
	step //3144
		' This guide is required that you have a flying mount. You can _NOT_ do this guide
		.' without having a flying mount.
		|confirm always
	step //3145
	label	"start"
		' Explore Borean Tundra |achieve 1264
		' Explore Dragonblight |achieve 1265
		' Explore Zul'Drak |achieve 1267
		' Explore Crystalsong Forest |achieve 1457
		' Explore Icecrown |achieve 1270
		' Explore Howling Fjord |achieve 1263
		' Explore Grizzly Hills |achieve 1266
		' Explore Sholazar Basin |achieve 1268
		' Explore Storm Peaks |achieve 1269       
		|confirm always
	step //3146
		#include "rideto_borean"
	step //3147
	label	"borean"
		'Skipping next part of guide |next "+sholazar" |only if step:Find("+borean1"):IsComplete()
		'Proceeding next step |next |only if default
	step //3148
		goto Borean Tundra,43.4,53.2
		.' Discover Warsong Hold |achieve 1264/10
	step //3149
		goto 57.7,69.3
		.' Discover Valiance Keep |achieve 1264/11
	step //3150
		goto 47.4,81.1
		.' Discover Riplash Stand |achieve 1264/3
	step //3151
		goto 27.9,51.6
		.' Discover Garrosh's Landing |achieve 1264/5
	step //3152
		goto 25.8,38.4
		.' Discover Coldarra |achieve 1264/7
	step //3153
		goto 46.1,34.8
		.' Discover Amber Ledge |achieve 1264/9
	step //3154
		goto 50.2,24.3
		.' Discover Steeljaw's Carvan |achieve 1264/2
	step //3155
		goto 50.2,10.3
		.' Discover Bor'gorok Outpost |achieve 1264/8
	step //3156
		goto 66.3,28.5
		.' Discover The Geyser Fields |achieve 1264/12
	step //3157
		goto 66.2,51.1
		.' Discover Kaskala |achieve 1264/4
	step //3158
		goto 82.4,46.4
		.' Discover Death's Stand |achieve 1264/6
	step //3159
		goto 87.6,25.1
		.' Discover Temple City of En'kilah |achieve 1264/1
	step //3160
		goto 76.4,16.4
		.' Discover The Dens of the Dying |achieve 1264/13
	step //3161
	label	"borean1"
		' Explore Borean Tundra |achieve 1264
	step //3162
	label	"sholazar"
		'Skipping next part of guide |next "+icecrown" |only if step:Find("+sholazar1"):IsComplete()
		'Proceeding next step |next |only if default
	step //3163
		goto Sholazar Basin,81.0,55.4
		.' Discover Makers' Overlook |achieve 1268/4
	step //3164
		goto 65.9,60.1
		.' Discover The Lifeblood Pillar |achieve 1268/8
	step //3165
		goto 53.7,52.5
		.' Discover Rainspeaker Canopy |achieve 1268/7
	step //3166
		goto 48.0,63.2
		.' Discover River's Heart |achieve 1268/1
	step //3167
		goto 36.0,75.3
		.' Discover The Mosslight Pillar |achieve 1268/3
	step //3168
		goto 24.3,81.7
		.' Discover Kartak's Hold |achieve 1268/11
	step //3169
		goto 33.3,52.3
		.' Discover The Suntouched Pillar |achieve 1268/6
	step //3170
		goto 29.7,40.1
		.' Discover Makers' Perch |achieve 1268/5
	step //3171
		goto 24.5,33.5
		.' Discover The Stormwright's Shelf |achieve 1268/12
	step //3172
		goto 46.8,26.1
		.' Discover The Savage Thicket |achieve 1268/2
	step //3173
		goto 29.5,36.3
		.' Discover The Glimmering Pillar |achieve 1268/10
	step //3174
		goto 74.5,34.6
		.' Discover The Avalanche |achieve 1268/9
	step //3175
	label	"sholazar1"
		' Explore Sholazar Basin |achieve 1268
	step //3176
	label	"icecrown"
		'Skipping next part of guide |next "+dragon" |only if step:Find("+icecrown1"):IsComplete()
		'Proceeding next step |next |only if default
	step //3177
		goto Icecrown,8.9,42.9
		.' Discover Onslaught Harbor |achieve 1270/3
	step //3178
		goto 27.1,39.0
		.' Discover Jotunheim |achieve 1270/13
	step //3179
		goto 36.5,24.1
		.' Discover Valhalas |achieve 1270/8
	step //3180
		goto 44.4,22.6
		.' Discover The Shadow Vault |achieve 1270/15
	step //3181
		goto 52.8,30.6
		.' Discover Aldur'thar: The Desolation Gate |achieve 1270/6
	step //3182
		goto 63.7,44.0
		.' Discover The Bombardment |achieve 1270/1
	step //3183
		goto 74.0,37.7
		.' Discover Sindragosa's Fall |achieve 1270/7
	step //3184
		goto 78.4,60.2
		.' Discover Scourgeholme |achieve 1270/14
	step //3185
		goto 83.8,73.4
		.' Valley of Echoes |achieve 1270/9
	step //3186
		goto 69.2,64.4
		.' Discover The Broken Front |achieve 1270/4
	step //3187
		goto 54.9,56.2
		.' Discover Ymirheim |achieve 1270/10
	step //3188
		goto 43.6,56.5
		.' Discover The Conflagration |achieve 1270/11
	step //3189
		goto 33.1,66.4
		.' Discover The Fleshwerks |achieve 1270/5
	step //3190
		goto 48.4,70.6
		.' Discover Corp'rethar: The Horror Gate |achieve 1270/12
	step //3191
		goto 54.2,85.8
		.' Discover Icecrown Citadel |achieve 1270/2
	step //3192
	label	"icecrown1"
		' Explore Icecrown |achieve 1270
	step //3193
	label	"dragon"
		'Skipping next part of guide |next "+crystal" |only if step:Find("+dragon1"):IsComplete()
		'Proceeding next step |next |only if default
	step //3194
		goto Dragonblight,36.0,15.0
		.' Discover Angrathar the Wrath Gate |achieve 1265/10
	step //3195
		goto 38.4,31.9
		.' Discover Obsidian Dragonshrine |achieve 1265/3
	step //3196
		goto 25.1,43.2
		.' Discover Icemist Village |achieve 1265/7
	step //3197
		goto 13.8,46.2
		.' Discover Westwind Refugee Camp |achieve 1265/13
	step //3198
		goto 36.9,47.8
		.' Discover Agmar's Hammer |achieve 1265/11
	step //3199
		goto 39.7,67.0
		.' Discover Lake Indu'le |achieve 1265/2
	step //3200
		goto 47.3,48.7
		.' Discover Ruby Dragonshrine |achieve 1265/3
	step //3201
		goto 54.9,32.7
		.' Discover Galakrond's Rest |achieve 1265/1
	step //3202
		goto 59.7,49.8
		.' Discover Wyrmrest Temple |achieve 1265/12
	step //3203
		goto 63.5,72.7
		.' Discover Emerald Dragonshrine |achieve 1265/8
	step //3204
		goto 71.0,75.2
		.' Discover New Hearthglen |achieve 1265/4
	step //3205
		goto 77.1,60.0
		.' Discover Venomspite |achieve 1265/14
	step //3206
		goto 82.5,70.7
		.' Discover The Forgotten Shore |achieve 1265/15
	step //3207
		goto 88.9,44.0
		.' Discover Naxxramas |achieve 1265/5
	step //3208
		goto 83.6,25.6
		.' Discover Light's Trust |achieve 1265/6
	step //3209
		goto 72.7,25.6
		.' Discover Scarlet Point |achieve 1265/17
	step //3210
		goto 61.8,19.5
		.' Discover The Crystal Vice |achieve 1265/16
	step //3211
		goto 50.0,17.5
		.' Discover Coldwind Heights |achieve 1265/9
	step //3212
	label	"dragon1"
		' Explore Dragonblight |achieve 1265
	step //3213
	label	"crystal"
		'Skipping next part of guide |next "+storm" |only if step:Find("+crystal1"):IsComplete()
		'Proceeding next step |next |only if default
	step //3214
		goto Crystalsong Forest,26.4,61.4
		.' Discover The Azure Front |achieve 1457/1
	step //3215
		goto 14.5,44.1
		.' Discover Violet Stand |achieve 1457/7
	step //3216
		goto 13.1,33.9
		.' Discover The Great Tree |achieve 1457/6
	step //3217
		goto 16.0,15.4
		.' Discover The Decrepit Flow |achieve 1457/2
	step //3218
		goto 43.0,42.5
		.' Discover Forlorn Woods |achieve 1457/4
	step //3219
		goto 64.7,60.4
		.' Discover The Unbound Thicket |achieve 1457/8
	step //3220
		goto 75.2,83.0
		.' Discover Windrunner's Overlook |achieve 1457/5
	step //3221
		goto 76.9,46.3
		.' Discover Sunreaver's Command |achieve 1457/3
	step //3222
	label	"crystal1"
		' Explore Crystalsong Forest |achieve 1457
	step //3223
	label	"storm"
		'Skipping next part of guide |next "+zul" |only if step:Find("+storm1"):IsComplete()
		'Proceeding next step |next |only if default
	step //3224
		goto The Storm Peaks,35.1,84.0
		.' Discover Sparksocket Minefield |achieve 1269/7
	step //3225
		goto 35.3,68.7
		.' Discover Bor's Breath |achieve 1269/4
	step //3226
		goto 35.9,58.0
		.' Discover Temple of Storms |achieve 1269/12
	step //3227
		goto 29.4,73.8
		.' Discover Frosthold |achieve 1269/15
	step //3228
		goto 24.0,60.5
		.' Discover Valkyrion |achieve 1269/5
	step //3229
		goto 23.9,50.1
		.' Discover Nidavelir |achieve 1269/16
	step //3230
		goto 27.3,41.9
		.' Discover Snowdrift Plains |achieve 1269/13
	step //3231
		goto 32.2,39.6
		.' Discover Narvir's Cradle |achieve 1269/2
	step //3232
		goto 41.3,17.4
		.' Discover Ulduar |achieve 1269/10
	step //3233
		goto 50.3,44.7
		.' Discover Terrace of the Makers |achieve 1269/6
	step //3234
		goto 64.8,44.8
		.' Discover Temple of Life |achieve 1269/9
	step //3235
		goto 72.9,48.5
		.' Discover Thunderfall |achieve 1269/11
	step //3236
		goto 64.4,59.1
		.' Discover Dun Niffelem |achieve 1269/3
	step //3237
		goto 40.9,57.2
		.' Discover Engine of the Makers |achieve 1269/8
	step //3238
		goto 47.8,68.2
		.' Discover Brunnhildar Village |achieve 1269/1
	step //3239
		goto 47.1,81.6
		.' Discover Garm's Bane |achieve 1269/14
	step //3240
	label	"storm1"
		' Explore The Storm Peaks |achieve 1269
	step //3241
	label	"zul"
		'Skipping next part of guide |next "+grizzly" |only if step:Find("+zul1"):IsComplete()
		'Proceeding next step |next |only if default
	step //3242
		goto Zul'Drak,17.0,57.3
		.' Discover Thrym's End |achieve 1267/12
	step //3243
		goto 28.2,45.1
		.' Discover Voltarus |achieve 1267/11
	step //3244
		goto 40.5,38.8
		.' Discover Altar of Sseratus |achieve 1267/4
	step //3245
		goto 53.3,36.5
		.' Discover Altar of Rhunok |achieve 1267/5
	step //3246
		goto 83.7,16.7
		.' Discover Gundrak |achieve 1267/1
	step //3247
		goto 73.2,45.6
		.' Discover Altar of Mam'toth |achieve 1267/7
	step //3248
		goto 76.9,59.3
		.' Discover Altar of Quetz'lun |achieve 1267/6
	step //3249
		goto 59.3,57.8
		.' Discover Zim'Torga |achieve 1267/9
	step //3250
		goto 64.4,68.9
		.' Discover Altar of Har'koa |achieve 1267/8
	step //3251
		goto 62.0,77.6
		.' Discover Kolrama |achieve 1267/14
	step //3252
		goto 48.2,56.4
		.' Discover Ampitheater of Anguish |achieve 1267/3
	step //3253
		goto 41.7,76.8
		.' Discover Drak'Sorta Fields |achieve 1267/2
	step //3254
		goto 32.0,76.4
		.' Discover Light's Breach |achieve 1267/13
	step //3255
		goto 21.1,75.2
		.' Discover Zeramas |achieve 1267/10
	step //3256
	label	"zul1"
		' Explore Zul'Drak |achieve 1267
	step //3257
	label	"grizzly"
		'Skipping next part of guide |next "+howling" |only if step:Find("+grizzly1"):IsComplete()
		'Proceeding next step |next |only if default
	step //3258
		goto Grizzly Hills,17.5,23.6
		.' Discover Drak'Tharon Keep |achieve 1266/2
	step //3259
		goto 15.8,49.6
		.' Discover Granite Springs |achieve 1266/5
	step //3260
		goto 21.3,65.3
		.' Discover Conquest Hold |achieve 1266/1
	step //3261
		goto 14.5,84.4
		.' Discover Venture Bay |achieve 1266/9
	step //3262
		goto 29.0,76.5
		.' Discover Voldrune |achieve 1266/10
	step //3263
		goto 31.4,57.9
		.' Discover Amberpine Lodge |achieve 1266/11
	step //3264
		goto 36.0,37.9
		.' Discover Blue Sky Logging Grounds |achieve 1266/12
	step //3265
		goto 48.2,42.2
		.' Discover Grizzlemaw |achieve 1266/6
	step //3266
		goto 56.8,28.4
		.' Discover Westfall Brigade Encampment |achieve 1266/14
	step //3267
		goto 68.1,14.8
		.' Discover Thor Modan |achieve 1266/8
	step //3268
		goto 71.8,27.9
		.' Discover Drakil'jin Ruins |achieve 1266/3
	step //3269
		goto 64.9,45.6
		.' Discover Camp Oneqwah |achieve 1266/13
	step //3270
		goto 77.9,59.3
		.' Discover Dun Argol |achieve 1266/4
	step //3271
		goto 50.3,57.2
		.' Discover Rage Fang Shrine |achieve 1266/7
	step //3272
	label	"grizzly1"
		' Explore Grizzly Hills |achieve 1266
	step //3273
	label	"howling"
		'Skipping next part of guide |next "+end" |only if step:Find("+howling1"):IsComplete()
		'Proceeding next step |next |only if default
	step //3274
		goto Howling Fjord,36.6,9.5
		.' Discover Gjalerbron |achieve 1263/9
	step //3275
		goto 47.8,12.1
		.' Discover Camp Winterhoof |achieve 1263/3
	step //3276
		goto 54.2,16.8
		.' Discover The Twisted Glade |achieve 1263/17
	step //3277
		goto 60.7,12.8
		.' Discover Fort Wildervar |achieve 1263/12
	step //3278
		goto 68.6,26.5
		.' Discover Giant's Run |achieve 1263/9
	step //3279
		goto 78.1,27.3
		.' Discover Vengeance Landing |achieve 1263/5
	step //3280
		goto 78.2,46.2
		.' Discover Ivald's Ruin |achieve 1263/13
	step //3281
		goto 72.5,71.3
		.' Discover Baelgun's Excavation Site |achieve 1263/20
	step //3282
		goto 67.9,52.8
		.' Discover Nifflevar |achieve 1263/8
	step //3283
		goto 66.6,39.1
		.' Discover Baleheim |achieve 1263/21
	step //3284
		goto 57.6,35.9
		.' Discover Cauldros Isle |achieve 1263/2
	step //3285
		goto 58.3,45.9
		.' Discover Utgarde Keep |achieve 1263/18
	step //3286
		goto 50.1,54.1
		.' Discover Halgrind |achieve 1263/14
	step //3287
		goto 52.9,69.0
		.' Discover New Agamand |achieve 1263/15
	step //3288
		goto 34.3,75.5
		.' Discover Scalawag Point |achieve 1263/7
	step //3289
		goto 24.9,57.7
		.' Discover Kamagua |achieve 1263/1
	step //3290
		goto 40.0,50.6
		.' Discover Ember Clutch |achieve 1263/10
	step //3291
		goto 45.1,33.1
		.' Discover Skorn |achieve 1263/16
	step //3292
		goto 30.3,41.4
		.' Discover Westguard Keep |achieve 1263/19
	step //3293
		goto 31.3,25.9
		.' Discover Steel Gate |achieve 1263/6
	step //3294
		goto 27.0,24.1
		.' Discover Apothecary Camp |achieve 1263/4
	step //3295
	label	"howling1"
		' Explore Howling Fjord |achieve 1263
	step //3296
	label	"end"
		' Congratulations! You have Explored Northrend |achieve 45 |only if achieved(45)
		' Congratulations! You have Earned the Achievement World Explorer! |achieve 46 |only if achieved(46)
		.' You have not fully discovered Northrend yet |only if not achieved(45)
		|confirm |next "start" |only if not achieved(45)
]])



--------------------------------------------------------------------------------------------------------------------------------------
-- REPUTATIONS
--------------------------------------------------------------------------------------------------------------------------------------
ZygorGuidesViewer:RegisterInclude("Mag'har_Neutral",[[
		'Skipping Mag'har Rep Section |next "+end" |only if rep ("The Mag'har") >= Neutral
		'Proceeding Mah'Har Rep Section |next |only if default
	step //3297
		goto Hellfire Peninsula,55,36
		.talk Nazgrel##3230
		.accept The Assassin##9400
	step //3298
		goto 33.6,43.5
		.' Go to this spot
		.' Find Krun Spinebreaker |q 9400/1
	step //3299
		goto 33.6,43.5
		.' Click the Fel Orc Corpse |tip It's a corpse laying halfway up the hill.
		..turnin The Assassin##9400
		..accept A Strange Weapon##9401
	step //3300
		goto 55,36
		.talk Nazgrel##3230
		..turnin A Strange Weapon##9401
		..accept The Warchief's Mandate##9405
	step //3301
		goto 54.2,37.9
		.talk Far Seer Regulkut##16574
		..turnin The Warchief's Mandate##9405
		..accept A Spirit Guide##9410
	step //3302
		goto 33.6,43.5
		.' Use your Ancestral Spirit Wolf Totem next to the Fel Orc Corpse |use Ancestral Spirit Wolf Totem##23669 |tip It's a corpse laying halfway up the hill.
		.' Follow the spirit wolf |tip Stay close to the wolf and follow it until it stops, or you will not be able to turn in the quest.
		.' Follow the wolf to this spot|goto 32,27.8,0.5|c
	step //3303
		goto 32,27.8
		.talk Gorkan Bloodfist##16845
		..turnin A Spirit Guide##9410
		..accept The Mag'har##9406
	step //3304
	label "end"
		goto 55,36
		.talk Nazgrel##3230
		..turnin The Mag'har##9406
]])


ZygorGuidesViewer:RegisterGuideSorting({
	"Leveling Guides",
	"Loremaster Guides",
	"Dailies Guides",
	"Events Guides",
	"Dungeon Guides",
	"Gear Guides",
	"Professions Guides",
	"Achievements Guides",
	"Pets & Mounts Guide",
	"Titles",
	"Reputations Guides",
	"Macro Guides",
})
