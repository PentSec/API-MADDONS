
AlphaQuestHelper
================

AlphaQuestHelper makes QuestHelper Icons and "ants" that normally appear only on the WorldMap, visible on AlphaMap.


Change Log
==========

Changes in v1.01.20400 from v1.00.20400
---------------------------------------

- Cartographer compatibility update



v1.00.20400
-----------

- released 04/05/2008
