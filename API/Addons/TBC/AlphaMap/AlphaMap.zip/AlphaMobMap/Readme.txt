
AlphaMobMap
===========

AlphaMobMap makes MobMap icons that normally appear only on the WorldMap, visible on AlphaMap.

If you have "MapNotes (Fan's Update)" installed [v4.14.20300 or later], then you can create temporary or permanent MapNotes to track via the WorldMap and/or Minimap.

1.) <ALT>-Click on the AlphaMap MobMap icon to create a temporary Thottbott Map and Mininote

2.) <CTRL>-Click on the AlphaMap MobMap icon to create a permanent MapNote (Also active as Mininote)

3.) <CTRL>-<SHIFT>-Click on the AlphaMap MobMap icon to create a permanent MapNote NOT active as a Mininote



Change Log
==========

v1.00.20300
-----------

- released 02/02/2008
