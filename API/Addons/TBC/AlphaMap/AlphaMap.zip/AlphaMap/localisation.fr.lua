--------------------------------------------------------------------------
-- localization.lua <French>
--------------------------------------------------------------------------
--
--	À	\195\128
--	Á	\195\129
--	Â	\195\130
--	Ä	\195\132
--	È	\195\136
--	É	\195\137
--	Ê	\195\138
--	Ë	\195\139
--	Î	\195\142
--	Ï	\195\143
--	Ô	\195\148
--	Ö	\195\150
--	Û	\195\155
--	Ü	\195\156
--	à	\195\160
--	á	\195\161
--	â	\195\162
--	ä	\195\164
--	è	\195\168
--	é	\195\169
--	ê	\195\170
--	ë	\195\171
--	î	\195\174
--	ï	\195\175
--	ô	\195\180
--	ö	\195\182
--	û	\195\187
--	ü	\195\188
--	'Œ	\39\197\146
--
--------------------------------------------------------------------------

if ( GetLocale() == "frFR" ) then

SLASH_ALPHAMAPSLASH1		= "/AlphaMap";
SLASH_ALPHAMAPSLASH2		= "/am";

AM_SLASH_LOAD_HELP_USAGE	= "Alpha Map"

BINDING_HEADER_ALPHAMAP		= "AlphaMap";
BINDING_NAME_TOGGLEALPHAMAP	= "Afficher/masquer la carte";
BINDING_NAME_INCREMENTALPHAMAP	= "Augmenter l'opacité";
BINDING_NAME_DECREMENTALPHAMAP	= "Diminuer l'opacité";
BINDING_NAME_CLEARVIEWALPHAMAP	= "Afficher/masquer les notes et les icônes";
BINDING_NAME_CYCLEWMMODE	= "Change le style de la carte";
BINDING_NAME_HOT_SPOT		= "Fonction 'HotSpot'";

--Colored State values
ALPHA_MAP_GREEN_ENABLED		= "|c0000FF00Activé|r";
ALPHA_MAP_RED_DISABLED		= "|c00FF0000Désactivé|r";

--Slash Help
AM_SLASH_HELP_USAGE		= "Utilisation : /alphamap or /am:";
AM_SLASH_HELP_ENABLE		= "/am enable - active AlphaMap";
AM_SLASH_HELP_DISABLE		= "/am disable - désactive AlphaMap";
AM_SLASH_HELP_RESET		= "/am reset - restaure les options par défaut";
AM_SLASH_HELP_RAID		= "/am raid - affiche les icônes de Raid";
AM_SLASH_HELP_PTIPS		= "/am ptips - affiche les bulle d'aide (groupe)";
AM_SLASH_HELP_MNTIPS		= "/am mntips - affiche les info-bulles de MapNotes";
AM_SLASH_HELP_GTIPS		= "/am gtips - affiche les info-bulles de Gatherer";
AM_SLASH_HELP_MNGTIPS		= "/am mngtips - affiche info-les bulles de MapNotes Gathering";
AM_SLASH_HELP_MOVESLIDER	= "/am moveslider - bloque/débloque le réglage de l'opacité";
AM_SLASH_HELP_SLIDER		= "/am slider - affiche/masque le réglage de l'opacité";
AM_SLASH_HELP_GATHERER		= "/am gatherer - active/désactive le support de Gatherer";
AM_SLASH_HELP_MAPNOTES		= "/am mapnotes - active/désactive le support de MapNotes";
AM_SLASH_HELP_GATHERING		= "/am gathering - active/désactive le support de MapNotes Gathering";
AM_SLASH_HELP_AUTOCLOSE		= "/am combat - fermer AlphaMap au début du combat";
AM_SLASH_HELP_AUTOOPEN		= "/am reopen - réouvrir AlphaMap à la fin du combat";
AM_SLASH_HELP_WMCLOSE		= "/am wmclose - fermer AlphaMap à la fermeture de la carte du monde";
AM_SLASH_HELP_LOCK		= "/am lock - empêcher le déplacement de la carte";
AM_SLASH_HELP_SCALE		= "/am scale |c0000AA00<valeur>|r - règle l'échelle de la carte (de 0.0 à 1.0)";
AM_SLASH_HELP_DDSCALE		= "/am ddscale |c0000AA00<valeur>|r - règle l'échelle du sélecteur de carte (de 0.3 à 1.4)";
AM_SLASH_HELP_TOG		= "|c00FF0000/am tog  - affiche/masque la carte|r";
AM_SLASH_HELP_ALPHA		= "/am alpha |c0000AA00<valeur>|r - règle la transparence de la carte (de 0.0 à 1.0)";
AM_SLASH_HELP_MINIMAP		= "/am minimap - affiche/masque le bouton sur la MiniMap";
AM_SLASH_HELP_SEARCH		= "/am -s <texte à rechercher>";
AM_SLASH_HELP_HELP		= "/am help  <OU>  /am ?  - affiche cette aide";

ALPHA_MAP_LOAD_CONFIRM		= "|c00A335EDAlphaMap |c0000FF00v."..ALPHA_MAP_VERSION.." |c00A335ED est chargé - Tapez "..SLASH_ALPHAMAPSLASH1.." ou "..SLASH_ALPHAMAPSLASH2.." pour les options.|r";

ALPHA_MAP_ENABLED		= "|c0000BFFFAlphaMap est maintenant "..ALPHA_MAP_GREEN_ENABLED;
ALPHA_MAP_DISABLED		= "|c0000BFFFAlphaMap est maintenant "..ALPHA_MAP_RED_DISABLED;

ALPHA_MAP_UI_LOCKED		= "AlphaMap: Interface |c00FF0000figée|r.";
ALPHA_MAP_UI_UNLOCKED		= "AlphaMap: Interface |c0000FF00déplaçable|r.";
ALPHA_MAP_UI_LOCK_HELP		= "Cochez cette option pour empêcher de déplacer l'interface d'AlphaMap.";

ALPHA_MAP_DISABLED_HINT		= "Note: AlphaMap est "..ALPHA_MAP_RED_DISABLED..".  Tapez |C0000AA00'/am Enable'|R le réactiver.";

ALPHA_MAP_CONFIG_SLIDER_STATE	= "AlphaMap: Déplacement du contrôle d'opacité ";
ALPHA_MAP_CONFIG_COMBAT_STATE	= "AlphaMap: Fermeture auto. au début du combat ";
ALPHA_MAP_CONFIG_REOPEN_STATE	= "AlphaMap: Réouverture à la fin du combat ";
ALPHA_MAP_CONFIG_RAID_STATE	= "AlphaMap: Icônes de Raid ";
ALPHA_MAP_CONFIG_PTIPS_STATE	= "AlphaMap: Info-bulles de groupe/raid ";
ALPHA_MAP_CONFIG_MNTIPS_STATE	= "AlphaMap: Info-bullles de MapNodes ";
ALPHA_MAP_CONFIG_MNGTIPS_STATE	= "AlphaMap: Info-bulles de MapNotes Gathering ";
ALPHA_MAP_CONFIG_GTIPS_STATE	= "AlphaMap: Info-bulles de Gatherer ";
ALPHA_MAP_CONFIG_WMCLOSE_STATE	= "AlphaMap: Fermeture auto. à la fermeture de la carte du monde ";
ALPHA_MAP_CONFIG_GATHERING_STATE = "AlphaMap: Support de MapNotes Gathering ";
ALPHA_MAP_CONFIG_GATHERER_STATE	= "AlphaMap: Support de Gatherer ";
ALPHA_MAP_CONFIG_MAPNOTES_STATE	= "AlphaMap: Support de MapNotes ";

-- Options
AM_OPTIONS			= "Options";
AM_OPTIONS_TITLE		= "Options d'AlphaMap";
AM_OPTIONS_RESET		= "Réinitialiser";
AM_OPTIONS_CLOSE		= "Fermer";

AM_OPTIONS_ANGLESLIDER		= "Angle du bouton de la mini-carte : ";
AM_OPTIONS_RADIUSLIDER		= "Distance du bouton de la mini-carte : ";
AM_OPTIONS_ALPHASLIDER		= "Opacité de la carte : ";
AM_OPTIONS_SCALESLIDER		= "Echelle de la carte : ";

-- Tab 1
AM_OPTIONS_GENERAL              = "Général";

AM_OPTIONS_ADDONS		= "Notes et icônes";
AM_OPTIONS_MAPNOTES		= " Afficher les notes de MapNotes";
AM_OPTIONS_MAPNOTES_TOOLTIPS	= " Activer les info-bulles";
AM_OPTIONS_MAPNOTESG		= " Afficher les icônes de Map Notes Gathering";
AM_OPTIONS_MAPNOTESG_TOOLTIPS 	= " Activer les info-bulles";
AM_OPTIONS_GATHERER		= " Afficher les icônes de Gatherer";
AM_OPTIONS_GATHERER_TOOLTIPS	= " Activer les info-bulles";
AM_OPTIONS_RAID_PINS		= " Afficher les membres du groupe de raid";
AM_OPTIONS_PARTY_TOOLTIPS	= " Activer les info-bulles";
AM_OPTIONS_CLEARVIEW_OFF	= " Masquer toutes les notes et icônes";
AM_OPTIONS_CLEARVIEW_ON		= " |c00FF0000Masquer toutes les notes et icônes|r";

AM_OPTIONS_MISC			= "Autres options";
AM_OPTIONS_SLIDER		= " Afficher le contrôle d'opacité";
AM_OPTIONS_SLIDER_MOVE		= " Autoriser le déplacement";
AM_OPTIONS_AUTOCLOSE_COMBAT	= " Fermer quand le combat commence";
AM_OPTIONS_AUTOOPEN_COMBAT	= " Réouvrir quand le combat est fini";
AM_OPTIONS_AUTOCLOSE_WORLDMAP	= " Fermer avec la carte du monde";
AM_OPTIONS_MINIMAP		= " Afficher le bouton de la mini-carte";
AM_OPTIONS_MAP_LOCK		= " Figer la position de la carte";
AM_OPTIONS_LEGACYPLAYER		= " Utiliser l'icône standard du joueur";

-- Tab 2
AM_OPTIONS_MAPS1		= "Cartes spéciales (1)";

AM_OPTIONS_DUNGEON_NOTES	= "Points d'intérêt";
AM_OPTIONS_DM_NOTES		= " Afficher les P.O.I. sur la carte";
AM_OPTIONS_DM_NOTES_TOOLTIPS	= " Activer les info-bulles";
AM_OPTIONS_DM_NOTES_BCKGRND	= " Utiliser un fond de couleur";
AM_OPTIONS_DM_NBG_SET		= "Choisir la couleur";
AM_OPTIONS_DM_NOTESCALE		= " Taille du texte : ";

AM_OPTIONS_DUNGEON_FRAMES	= "Descriptions";
AM_OPTIONS_DM_HEADER		= " Afficher l'entête";
AM_OPTIONS_DM_EXTRA		= " Afficher les notes générales";
AM_OPTIONS_DM_KEY		= " Afficher les détails";
AM_OPTIONS_DM_KEY_TOOLTIPS	= " Activer les info-bulles";

AM_OPTIONS_DM_MISC		= "Divers";
AM_OPTIONS_DM_MAP_BCKGRND	= " Utiliser un fond de couleur pour la carte";
AM_OPTIONS_DM_MBG_SET		= "Choisir la couleur";
AM_OPTIONS_DM_TEXT_BCKGRND	= " Utiliser un fond de couleur pour le texte";
AM_OPTIONS_DM_TEXTBG_SET	= "Choisir la couleur";

-- Tab 3
AM_OPTIONS_MAPS2		= " ... 2 ";
AM_OPTIONS_TYPE_ALL		= "Paramètres des cartes des %s";
AM_OPTIONS_TYPE_SAVE_LABEL	= "Réglages des cartes des %s";
AM_OPTIONS_TYPE_SAVE		= "Appliquer %s à toutes les cartes des %s";
AM_MANUAL_APPLY			= "MAINTENANT";
AM_AUTO_APPLY			= "automatiquement";

AM_OPTIONS_BG_MESSAGES		= "Messages des Champs de bataille";

AM_OPTIONS_BG_USE_AM		= "Utiliser les cartes CdB d'AlphaMap\nplutôt que celles de Blizzard";
AM_AUTO_OPEN			= "Ouverture auto. des cartes CdB";

-- Tab 4
AM_OPTIONS_MAPS			= "Sélecteur et HotSpot";
AM_OPTIONS_MAP_BOXES		= "Position du sélecteur";
AM_OPTIONS_DOCK_IT		= " Dans la fenêtre des options";
AM_OPTIONS_FREE_IT		= " Déplacement libre";
AM_OPTIONS_MAP_IT		= " Attaché à la carte";
AM_OPTIONS_HOW_TO_MAP		= "Point d'attache";
AM_OPTIONS_HOTSPOT_BEHAVE	= "Comportement du HotSpot";
AM_OPTIONS_HOTSPOT_DISABLE	= " Activer le HotSpot";
AM_OPTIONS_HOTSPOT_MINIMAP	= " Utiliser aussi le bouton de la mini-carte";
AM_OPTIONS_HOTSPOT_OPEN		= " Afficher la carte (si masquée)";
AM_OPTIONS_HOTSPOT_OPACITY	= " Rendre la carte 100% opaque";
AM_OPTIONS_HOTSPOT_WORLDI	= " Afficher/masquer les icônes et les notes";
AM_OPTIONS_HOTSPOT_DUNGI	= " Afficher/masquer les P.O.I. (villes, BG, etc.)";
AM_OPTIONS_HOTSPOT_NBG		= " Afficher/masquer le fond des P.O.I.";
AM_OPTIONS_HOTSPOT_MBG		= " Afficher/masquer le fond de la carte";
AM_OPTIONS_HOTSPOT_INFO		= " Afficher/masquer les descriptions";

AM_ANCHOR_POINT 		= {	{ Display = "Bord supérieur",		-- Localise
					  Command = "TOP" },			-- Do NOT Localise
					{ Display = "Coin supérieur droit",	-- Localise
					  Command = "TOPRIGHT" },		-- Do NOT Localise
					{ Display = "Bord droit",		-- Localise
					  Command = "RIGHT" },			-- Do NOT Localise
					{ Display = "Coin inférieur droit",	-- Localise
					  Command = "BOTTOMRIGHT" },		-- Do NOT Localise
					{ Display = "Bord inférieur",		-- Localise
					  Command = "BOTTOM" },			-- Do NOT Localise
					{ Display = "Coin inférieur gauche",	-- Localise
					  Command = "BOTTOMLEFT" },		-- Do NOT Localise
					{ Display = "Bord gauche",		-- Localise
					  Command = "LEFT" },			-- Do NOT Localise
					{ Display = "Coin supérieur gauche",	-- Localise
					  Command = "TOPLEFT" }			-- Do NOT Localise
				};
AM_OPTIONS_MAP_LINK		= "au";

AM_OPTIONS_UNDOCKED		= "Le sélecteur de carte est ";
AM_OPTIONS_FREE			= "déplaçable";
AM_OPTIONS_FREE_LOCKED		= " (mais bloqué)";	-- Unused ?
AM_OPTIONS_MAPPED		= "attaché à la carte";

AM_AUTO_SWITCH			= "Afficher automatiquement les cartes des %s";	-- Unused ?

-- Tab 5
AM_MISC				= "Divers";

AM_OPTIONS_NUN_AUTO		= "Support de NotesUNeed";	-- Unused ?
AM_OPTIONS_NUN_FORMAT		= " Envoyer des notes formatées";
AM_OPTIONS_NUN_MESSAGES		= "Envoi auto. des notes";

AM_OPTIONS_WMOTHER		= "Autres réglages divers";
AM_OPTIONS_WM_ESCAPE		= " Fermer la carte avec la touche <Echap>";
AM_OPTIONS_WM_MOUSE		= " Réagir à la souris (cf. FAQ)";
AM_OPTIONS_MUTE			= " Ouverture et fermeture muettes";
AM_OPTIONS_COORDS		= " Afficher les coordonnées (x, y)";
AM_OPTIONS_HELP_TIPS		= " Afficher les bulles d'aide (options et sélecteur)";

AM_OPTIONS_WMAP_MODES		= "Affichage de la carte du monde";
AM_OPTIONS_WMAP_SMODE		= "Standard";
AM_OPTIONS_WMAP_OMODE		= "Compact";

AM_OPTIONS_GMAP_MODES		= "Carte Blizzard d'origine";
AM_OPTIONS_GMAP_ALLOW		= " Patcher la carte Blizzard";
AM_OPTIONS_GMAP_CHANGE		= " Modifier la carte Blizzard";


-- Unused ???
AM_OPTIONS_ZONE_SELECTOR	= "Afficher le sélecteur de carte";
AM_OPTIONS_GENERAL_CHAT		= "Chat";
AM_OPTIONS_DUNGEON		= "Instances";
AM_OPTIONS_RESTORE		= "Appliquer";

-- Future development
AM_OPTIONS_WMAP_MINIMODE	= "Minimap Textures";
AM_OPTIONS_WMAP_ZMINIMODE	= "Zoomed Minimap";

-- Details
AM_INSTANCE_TITLE_LOCATION	= "Emplacement ";
AM_INSTANCE_TITLE_LEVELS	= "Niveaux ";
AM_INSTANCE_TITLE_PLAYERS	= "Joueurs max. ";

AM_INSTANCE_CHESTS		= "Coffre ";
AM_INSTANCE_STAIRS		= "Escaliers";
AM_INSTANCE_ENTRANCES		= "Entrée ";
AM_INSTANCE_EXITS		= "Sortie ";
AM_LEADSTO			= "Mène vers...";
AM_INSTANCE_PREREQS		= "Pré-requis : ";
AM_INSTANCE_GENERAL		= "Notes générales : ";
AM_RARE				= "(rare)";
AM_VARIES			= "(lieu aléatoire)";
AM_WANDERS			= "(patrouille)";
AM_OPTIONAL			= "(optionnel)";

AM_NO_LIMIT			= "aucune limite";

AM_MOB_LOOT 			= "Mob Loot";
AM_RBOSS_DROP 			= "Random Boss Drops";
AM_ENCHANTS			= "Enchants";
AM_PVP_SET			= "Sets JcJ";
AM_CLASS_SETS			= "Sets de classe";

AM_PVP				= "JcJ";

AM_OPTIONS_GROUP_DEFAULT	= " Groupe ou raid";	-- ??
AM_OPTIONS_PARTY		= " Groupe";
AM_OPTIONS_RAID			= " Raid";
AM_OPTIONS_GUILD		= " Guilde";

AM_BG_ONLY			= "Plus que";
AM_BG_ALL			= "Toutes";
AM_BG_BASE			= "base";
AM_BG_BASES			= "bases";
AM_BG_REQUIRED			= "%s %d %s nécessaires pour gagner %s";

AM_EXTERIOR			= "Extérieur";

AM_RCMENU_INC			= " Inc ";		-- as in 5 inc Blacksmith   or  3 inc farm
AM_RCMENU_ZERG			= "Zerg";		-- as in Zerg Inc Frostwolf GY
AM_OK				= "OK";
AM_RCMENU_HIGHLIGHT		= "Highlight";		-- as in leave this note highlighted on the map
AM_RCMENU_NUN_AUTO		= "Auto-Send Note";	-- send the NotesUNeed note for the current map note to Raid/Party/...
AM_RCMENU_NUN_MAN		= "Manual Send Note";
AM_RCMENU_NUN_OPEN		= "Open Note";
AM_RCMENU_AFLAG			= "Drapeau de l'Alliance ";
AM_RCMENU_HFLAG			= "Drapeau de la Horde ";
AM_RCMENU_FLAGLOC		= {	"Notre tunnel",
					"Our Roof",
					"Va vers l'ouest",
					"Va vers l'est",
					"Au milieu",
					"Leur tunnel",
					"Their Roof",
					"Their Flag Room",
					"Their GY"
				};

AM_OPENING			= "Série de quêtes d'accès à AQ";

AM_HORDE			= "Horde";
AM_PICKED			= { 	word = "ramassé",
					posWord = " par ",
					extraChars = 2 };

AM_NEUTRAL			= "Neutre";
AM_FRIENDLY			= "Amical";
AM_HONOURED			= "Honoré";
AM_REVERED			= "Révéré";
AM_EXALTED			= "Exalté";

AM_CONFIG_SAVED			= "Préférences enregistrées pour : ";

AM_CANCEL			= "Annuler";

AM_CORPSE_TXT			= "Cadavre";
AM_RESET_INSTANCE		= "Réinitialiser";

AM_PERFORMANCE_WARNING1		= "AlphaMap a détecté un problème de performances avec les add-ons suivants : ";
AM_PERFORMANCE_WARNING2		= "AlphaMap ignore les mises à jour causées par cet add-on.\nYou only need to report this Warning message if you think it has caused another problem.";

AM_UPDATE_WARNING		= AM_YELLOW.."AlphaMap|r\n\nMouse Interaction Mode (Map Zoom) Now Uses the "..AM_GREEN.."<ALT>|r Key.\nNOT the "..AM_RED.."<CONTROL>|r Key\n ";

--------------------------------------------------------------------------------------------------------------------------------------
-- TOOLTIPS															    --
--------------------------------------------------------------------------------------------------------------------------------------

AM_TT_MINIMAP_BUTTON	= "AlphaMap\nClic gauche pour afficher la carte\nClic droit pour les options";
AM_TT_ALPHA_BUTTON1	= "AlphaMap";
AM_TT_ALPHA_BUTTON2	= "Clic gauche pour afficher la carte\nClic droit pour les options";
AM_TT_PAUSE1		= "Pause";
AM_TT_PAUSE2		= "Click to Pause map updates and allow you to open/close without resetting to current map Also use if another conflicting AddOn continually resets the AlphaMap to the current zone";
AM_TT_PLAY1		= "Play";
AM_TT_PLAY2		= "i.e. Click now to Un-Pause map updates";
AM_TT_HOTSPOT1		= "HotSpot";
AM_TT_HOTSPOT2		= "Quick Mouse-Over facility to change the AlphaMap view e.g. show/hide the map or Notes/Icons, or make fully opaque See Map Selector Tab of Options for full list (Key Binding available)";
AM_TT_LOCK1		= "Lock Map Selector";
AM_TT_LOCK2		= "Un-lock to show a frame with which to move the Map Selection drop down boxes";
AM_TT_TAB1		= "Original AlphaMap Options";
AM_TT_TAB2A		= "Specific options only for Maps included with AlphaMap and NOT Blizzard maps.";
AM_TT_TAB2B		= "e.g. Map/Note/Text backgrounds, and which notes/extra information to show NOTE : Only applies to AlphaMap Maps, and not applicable when viewing world map zones";
AM_TT_TAB3A		= "Further settings only applicable to AlphaMap Maps";
AM_TT_TAB3B		= "NOTE : Only applies to AlphaMap Maps, and not applicable when viewing world map zones";
AM_TT_TAB4		= "Set the position of the Map Selector Drop Down box controls  and define Hot Spot behaviour";
AM_TT_TAB5		= "Miscallaneous AlphaMap settings and integration with other AddOns";
AM_TT_MAPNOTES		= "Enable display of MapNotes, CTMap_Mod notes, MetaMapNotes, MapNotes(Cosmos)";
AM_TT_RAID1		= "Un-Check to ONLY show Party Pins";
AM_TT_RAID2		= "(Even when in Raid)";
AM_TT_CLEAR1		= "Show/Hide all above Enabled Icons/Notes Also see Key Binding for same function";
AM_TT_CLEAR2		= "e.g. Quick way to un-clutter the map OR Hide all, and use Hot Spot to make them visible when needed";
AM_TT_SLIDER		= "Show an Opacity Slider Control On the AlphaMap";
AM_TT_SLIDERM1		= "Check to enable movement of the on-map Opacity Slider";
AM_TT_SLIDERM2		= "Drop anywhere on the Map to re-locate it there Drop 'off' the AlphaMap to detach it (Can also be moved with the mouse when the Control key is pressed in Mouse Interaction mode)";
AM_TT_ACLOSE1		= "Auto-Close AlphaMap when entering Combat";
AM_TT_ACLOSE2		= "(Useful if you play with map always displayed)";
AM_TT_AOPEN		= "Auto-Re-Open AlphaMap when leaving Combat";
AM_TT_LEGACY1		= "Original Player & Party Directional Icons";
AM_TT_LEGACY2		= "May suffer from blinking Minimap Icons";
AM_TT_AM_NOTES1		= "Display AlphaMap's on-map notes";
AM_TT_AM_NOTES2		= "(These are NOT the same as MapNotes  and can not be changed)";
AM_TT_ALL_INSTANCE1	= "Un-check to save the settings for each Instance map seperately";
AM_TT_ALL_INSTANCE2	= "e.g. you might want a dark background for Zul'Farrak, but a light one for Molten Core. Keep checked if you want to make sure that when you make ANY change to ANY Instance Map then the settings will be copied to ALL the other Instance maps";
AM_TT_KEY		= "i.e. Show Map Legend";
AM_TT_ALL_BG1		= "Un-check to save the settings for each Battleground map seperately";
AM_TT_ALL_BG2		= "e.g. you might want AV to display at a larger scale than Warsong.  Keep checked if you want to make sure that when you make ANY change to ANY Battleground Map then the settings will be copied to ALL the other Battleground maps";
AM_TT_ALL_NI1		= "Un-check to save the settings for each Non-Instance map seperately";
AM_TT_ALL_NI2		= "e.g. you might not want to display the Map Legend for dungeon exteriors   but do want it for World Boss maps.  Keep checked if you want to make sure that when you make ANY change to ANY Non-Instance Map then the settings will be copied to ALL the other Non-Instance maps";
AM_TT_MSG		= "Battleground Messages will be sent to :";
AM_TT_MSG_DFLT2		= " - your Raid if you were in a Raid BEFORE you entered the Battleground\n - your Party if you were in a Party BEFORE you entered the Battleground\n - the Battleground channel otherwise";
AM_TT_MSG_PARTY2	= " - only your Party as long as you were in a Raid or Party BEFORE you entered the Battleground\n - the Battleground channel otherwise";
AM_TT_MSG_BG2		= " - the Battleground channel only";
AM_TT_AUTO_BG1		= "Makes AlphaMap's Battleground map the default map to be used in Battlegrounds";
AM_TT_AUTO_BG2		= "Battlegound maps will open automatically when you enter a Battleground if this option is checked Un-Check if you wish to use the normal Blizzard style map in Battlegrounds (The map will not open automatically when you enter a BG)";
AM_TT_NUN_F1		= "Formatted NotesUNeed notes can be added to the database of people who receive them";
AM_TT_NUN_F2		= "(However, people without NotesUNeed installed will see extra formatting characters rather than just the note's text.)";
AM_TT_NUN		= "NotesUNeed notes will be auto-sent to :";
AM_TT_NUN_DFLT2		= " - your Raid if in a Raid\n - your Party if in a Party\n - otherwise you will just '/Say' the note  \n\nNote that Raid/Party messages will fail inside Battlegrounds unless \nyou were in the Raid/Party BEFORE you entered the Battleground";
AM_TT_NUN_PARTY2	= " - only your Party, if you are in a Raid OR Party\n - otherwise you will just '/Say' the note \n\nNote that Raid/Party messages will fail inside Battlegrounds unless \nyou were in the Raid/Party BEFORE you entered the Battleground";
AM_TT_NUN_GUILD2	= " - your Guild";
AM_TT_MOUSE1		= "Mouse Interaction mode allows you to Control-Click the AlphaMap";
AM_TT_MOUSE2		= "Normally the AlphaMap is invisible to the mouse. However, in mouse interaction mode, then when the Control key is pressed you will be able to see the name of map regions that your mouse hovers  over, and can Control-Left Click and Control-Right Click to zoom in and out. When in Mouse Interaction mode, you can also Control-Click on the AlphaMap Slider and on-map Coordinates to reposition them";
AM_TT_MUTE		= "Toggle the sound when Opening/Closing the AlphaMap";
AM_TT_XY		= "Toggle the display of Player/Cursor coordinates";
AM_TT_STANDARD		= "Standard View - world map Zones as displayed in the original Blizzard Map";
AM_TT_COMPACT1		= "Compact View - Only display explorable areas in the current Zone";
AM_TT_COMPACT2		= "Note that areas that you have NOT discovered will not be displayed unless you have installed MozzFullWorldMap (Fan's Update) AddOn";
AM_TT_BLIZZ_ALLOW1	= "While checked, AlphaMap will save any changes you make to the Blizzard Map position/opacity/scale";
AM_TT_BLIZZ_ALLOW2	= "Un-Check to restore the original Blizzard Map settings This requires a 'ReloadUI' during which the game will pause for a few seconds";
AM_TT_BLIZZ_CHANGE1	= "While checked, then changes to the opacity and scale sliders below Will only affect the original Blizzard Map";
AM_TT_HELP_TIPS1	= "Toggle Help Tooltips";
AM_TT_HELP_TIPS2	= "Does not affect on map icon tooltips";

--------------------------------------------------------------------------------------------------------------------------------------
-- Everything below should be localised apart from the 'filename', 'lootid' entries which should NOT be changed                     --
-- The first  'name'  field is used to equate with in game Zone name information to help determine when the player is in a specific --
-- Instance, and must therefore be spelt IDENTICALLY to the names of the Instances as displayed by the WoW Client in other native   --
-- frames.															    --
--------------------------------------------------------------------------------------------------------------------------------------

AM_TYP_WM			= "World Map";
AM_TYP_GM			= "Blizzard Map";

--AM_TYP_INSTANCE		= "Instances";
--AM_TYP_BG			= "Battlegrounds";
--AM_TYP_WORLDBOSSES	= "World Bosses";
--AM_TYP_CAVES		= "Caves";

end
