
--[[
--AlphaMap Simplified Chinese
--Locolized by springsnow (2006/7/14)(3区-吉安娜-浮云)
--Last Updated:2006/9/23
--之所以汉化此插件其实是因为自己一直在用，以前用的旧版本的有人汉化，大约已经有一年没有更新国汉化了，
--为了自己使用方便，于是就尝试自己汉化了，由于本人基本没进过战场，所以战场部分可能汉化不太完整，
--希望大家能够给予帮助。
--]]






if( GetLocale() == "zhCN" ) then

	SLASH_ALPHAMAPSLASH1 = "/AlphaMap";
	SLASH_ALPHAMAPSLASH2 = "/am";

	AM_SLASH_LOAD_HELP_USAGE	= "Alpha Map"

	BINDING_HEADER_ALPHAMAP        = "AlphaMap 按键绑定";
	BINDING_NAME_TOGGLEALPHAMAP    = "开启/关闭 AlphaMap";
	BINDING_NAME_INCREMENTALPHAMAP = "增加 AlphaMap 透明度";
	BINDING_NAME_DECREMENTALPHAMAP = "减少 AlphaMap 透明度";
	BINDING_NAME_CLEARVIEWALPHAMAP	= "显示/隐藏所有标记/图标";
	BINDING_NAME_CYCLEWMMODE	= "循环世界地图模式";
	BINDING_NAME_HOT_SPOT		= "热点";

	--Colored State values
	ALPHA_MAP_GREEN_ENABLED = "|c0000FF00启用|r";
	ALPHA_MAP_RED_DISABLED = "|c00FF0000禁用|r";

	--Slash Help
	AM_SLASH_HELP_USAGE         = "AlphaMap 使用方法: /alphamap 或 /am:";
	AM_SLASH_HELP_ENABLE        = "/am enable - 启用/重新启用 AlphaMap";
	AM_SLASH_HELP_DISABLE       = "/am disable - 禁用 AlphaMap";
	AM_SLASH_HELP_RESET         = "/am reset - 重置 AlphaMap 选项为默认值.";
	AM_SLASH_HELP_RAID          = "/am raid - 显示团队标记";
	AM_SLASH_HELP_PTIPS         = "/am ptips - 显示队伍提示信息";
	AM_SLASH_HELP_MNTIPS        = "/am mntips - 显示 MapNotes 提示信息";
	AM_SLASH_HELP_GTIPS         = "/am gtips - 显示 Gatherer 提示信息";
	AM_SLASH_HELP_MNGTIPS       = "/am mngtips - 显示 MapNotes Gathering 提示信息";
	AM_SLASH_HELP_MOVESLIDER    = "/am moveslider - 开启/关闭移动透明调节条";
	AM_SLASH_HELP_SLIDER        = "/am slider - 开启/关闭显示透明调节条显示";
	AM_SLASH_HELP_GATHERER      = "/am gatherer - 开启/关闭对 Gatherer 的支持";
	AM_SLASH_HELP_MAPNOTES      = "/am mapnotes - 开启/关闭对 MapNotes 的支持";
	AM_SLASH_HELP_GATHERING     = "/am gathering - 开启/关闭对 MapNotes Gathering 的支持";
	AM_SLASH_HELP_AUTOCLOSE     = "/am combat - 开启/关闭战斗中自动关闭";
	AM_SLASH_HELP_AUTOOPEN	    = "/am reopen - 开启/关闭战斗结束后重新开启";
	AM_SLASH_HELP_WMCLOSE       = "/am wmclose - 开启/关闭世界地图关闭时自动关闭";
	AM_SLASH_HELP_LOCK          = "/am lock - 开启/关闭 AlphaMap 移动功能";
	AM_SLASH_HELP_SCALE         = "/am scale |c0000AA00<数值>|r - 设置 Alphamap 窗口比例 (范围 0.0 - 1.0)";
	AM_SLASH_HELP_TOG           = "|c00FF0000/am tog  - 开启/关闭 Alphamap 显示|r";
	AM_SLASH_HELP_ALPHA         = "/am alpha |c0000AA00<数值>|r - 设置 AlphaMap 透明度 (范围 0.0 - 1.0)";
	AM_SLASH_HELP_MINIMAP	    = "/am minimap - 开启/关闭显示迷你地图按钮";
	AM_SLASH_HELP_HELP	    = "/am help  <或>  /am ?  - 列出 AlphaMap 的命令行";

	ALPHA_MAP_LOAD_CONFIRM = "|c00A335EDAlphaMap |c0000FF00v."..ALPHA_MAP_VERSION.." |c00A335ED 载入 - 输入 "..SLASH_ALPHAMAPSLASH1.." 或 "..SLASH_ALPHAMAPSLASH2.." 显示选项|r";

	ALPHA_MAP_ENABLED = "|c0000BFFFAlphaMap 当前已 "..ALPHA_MAP_GREEN_ENABLED;
	ALPHA_MAP_DISABLED = "|c0000BFFFAlphaMap 当前已 "..ALPHA_MAP_RED_DISABLED;

	ALPHA_MAP_UI_LOCKED = "AlphaMap: 用户界面 |c00FF0000锁定|r.";
	ALPHA_MAP_UI_UNLOCKED = "AlphaMap: 用户界面 |c0000FF00未锁定|r.";
	ALPHA_MAP_UI_LOCK_HELP = "如果点选此选项, 那么 AlphaMap 将被锁定在该位置不能再进行移动.";

	ALPHA_MAP_DISABLED_HINT = "提示: AlphaMap 已 "..ALPHA_MAP_RED_DISABLED..".  输入 |C0000AA00'/am Enable'|R 命令重新启用它.";

	ALPHA_MAP_CONFIG_SLIDER_STATE       = "AlphaMap: 透明调节条移动 ";
	ALPHA_MAP_CONFIG_COMBAT_STATE       = "AlphaMap: 战斗时自动关闭 ";
	ALPHA_MAP_CONFIG_REOPEN_STATE	    = "AlphaMap: 战斗结束后重新开启 ";
	ALPHA_MAP_CONFIG_RAID_STATE         = "AlphaMap: 团队标记 ";
	ALPHA_MAP_CONFIG_PTIPS_STATE        = "AlphaMap: 队伍/团队提示信息 ";
	ALPHA_MAP_CONFIG_MNTIPS_STATE       = "AlphaMap: MapNotes 提示信息 ";
	ALPHA_MAP_CONFIG_MNGTIPS_STATE      = "AlphaMap: MapNotes Gathering 提示信息 ";
	ALPHA_MAP_CONFIG_GTIPS_STATE        = "AlphaMap: Gatherer 提示信息 ";
	ALPHA_MAP_CONFIG_WMCLOSE_STATE      = "AlphaMap: 关闭世界地图时关闭 ";
	ALPHA_MAP_CONFIG_GATHERING_STATE    = "AlphaMap: MapNotes Gathering 支持 ";
	ALPHA_MAP_CONFIG_GATHERER_STATE     = "AlphaMap: Gatherer 支持 ";
	ALPHA_MAP_CONFIG_MAPNOTES_STATE     = "AlphaMap: MapNotes 支持 ";

	AM_OPTIONS			= "选项";
	AM_OPTIONS_TITLE		= "AlphaMap "..AM_OPTIONS;
	AM_OPTIONS_RESET		= "重置全部";
	AM_OPTIONS_CLOSE		= "关闭";
	AM_OPTIONS_MAPNOTES		= "显示 Map Notes";
	AM_OPTIONS_MAPNOTES_TOOLTIPS	= "显示 Map Notes 提示信息";
	AM_OPTIONS_MAPNOTESG		= "显示 MapNotes Gathering 图标";
	AM_OPTIONS_MAPNOTESG_TOOLTIPS 	= "显示 MapNotes Gathering 提示信息";
	AM_OPTIONS_GATHERER		= "显示 Gatherer 图标";
	AM_OPTIONS_GATHERER_TOOLTIPS	= "显示 Gatherer 提示信息";
	AM_OPTIONS_PARTY_TOOLTIPS	= "显示队伍/团队提示信息";
	AM_OPTIONS_RAID_PINS		= "显示团队标记 ";
	AM_OPTIONS_SLIDER		= "在地图上显示透明度调节条";
	AM_OPTIONS_SLIDER_MOVE		= "允许移动透明度调节条";
	AM_OPTIONS_AUTOCLOSE_COMBAT	= "战斗开始时关闭地图";
	AM_OPTIONS_AUTOOPEN_COMBAT	= "战斗结束后重新打开地图";
	AM_OPTIONS_AUTOCLOSE_WORLDMAP	= "当世界地图关闭时关闭地图";
	AM_OPTIONS_ANGLESLIDER		= "小地图角度  : ";
	AM_OPTIONS_RADIUSLIDER		= "小地图半径 : ";
	AM_OPTIONS_ALPHASLIDER		= "地图透明度 : ";
	AM_OPTIONS_SCALESLIDER		= " 地图缩放  : ";
	AM_OPTIONS_MAP_LOCK		= "锁定 AlphaMap 位置";
	AM_OPTIONS_MINIMAP		= "显示小地图图标";
	AM_OPTIONS_CLEARVIEW_OFF	= "隐藏已激活的图标";
	AM_OPTIONS_CLEARVIEW_ON		= "|c00FF0000所有图标当前隐藏|r";
	AM_OPTIONS_LEGACYPLAYER		= "显示原始风格玩家图标";
	AM_OPTIONS_ZONE_SELECTOR	= "显示地图选择器";
	AM_OPTIONS_GENERAL		= "综合";
	AM_OPTIONS_GENERAL_CHAT		= "综合聊天";
	AM_OPTIONS_DUNGEON		= "地下城";
	AM_OPTIONS_MAPS			= "地图选择器";
	AM_OPTIONS_ADDONS		= "世界地图标记 & 图标 : ";
	AM_OPTIONS_MISC			= "内部插件选项 : ";
	AM_OPTIONS_DUNGEON_NOTES	= "AlphaMap 标记选项 : ";
	AM_OPTIONS_DUNGEON_FRAMES	= "地下城额外信息 : ";
	AM_OPTIONS_DM_NOTES		= "显示 AlphaMap 标记";
	AM_OPTIONS_DM_NOTES_TOOLTIPS	= "显示 AlphaMap 标记提示信息";
	AM_OPTIONS_DM_NOTES_BCKGRND	= "显示标记背景";
	AM_OPTIONS_DM_NBG_SET		= "设置标记背景颜色";
	AM_OPTIONS_DM_HEADER		= "显示页眉信息";
	AM_OPTIONS_DM_EXTRA		= "显示页脚信息";
	AM_OPTIONS_DM_KEY		= "显示地图关键点";
	AM_OPTIONS_DM_KEY_TOOLTIPS	= "显示地图关键点提示信息";
	AM_OPTIONS_RESTORE		= "应用";
	AM_MISC				= "其他";
	AM_OPTIONS_DM_MISC		= AM_MISC.." : ";
	AM_OPTIONS_DM_MAP_BCKGRND	= "显示地图背景";
	AM_OPTIONS_DM_MBG_SET		= "设置地图背景颜色";
	AM_OPTIONS_DM_TEXT_BCKGRND	= "显示文本背景";
	AM_OPTIONS_DM_TEXTBG_SET	= "设置文本背景颜色";
	AM_OPTIONS_MAP_BOXES		= "AlphaMap 选择器位置 :";
	AM_OPTIONS_UNDOCKED		= "AlphaMap 选择器 : ";
	AM_OPTIONS_FREE			= "自由浮动";
	AM_OPTIONS_FREE_LOCKED		= "(锁定)";
	AM_OPTIONS_MAPPED		= "吸附到 AlphaMap";
	AM_OPTIONS_DOCK_IT		= "嵌入到选项窗口";
	AM_OPTIONS_FREE_IT		= "自由浮动";
	AM_OPTIONS_MAP_IT		= "吸附到 AlphaMap";
	AM_OPTIONS_HOW_TO_MAP		= "嵌入到 AlphaMap 从 : ";
	AM_OPTIONS_MAP_LINK		= "到";
	AM_OPTIONS_HOTSPOT_BEHAVE	= "热点状态 : ";
	AM_OPTIONS_HOTSPOT_DISABLE	= "启用热点功能";
	AM_OPTIONS_HOTSPOT_OPEN		= "如果 AlphaMap 已关闭则开启";
	AM_OPTIONS_HOTSPOT_OPACITY	= "完全不透明 AlphaMap";
	AM_OPTIONS_HOTSPOT_WORLDI	= "开启/关闭世界地图图标/标记";
	AM_OPTIONS_HOTSPOT_DUNGI	= "开启/关闭地下城 AlphaMap 标记";
	AM_OPTIONS_HOTSPOT_NBG		= "开启/关闭标记背景";
	AM_OPTIONS_HOTSPOT_MBG		= "开启/关闭地图背景";
	AM_OPTIONS_HOTSPOT_MINIMAP	= "启用小地图按钮为热点";
	AM_OPTIONS_HOTSPOT_INFO		= "开启/关闭关键点/页眉/页脚";
	AM_OPTIONS_BG_USE_AM		= "当在战场中时使用 AlphaMap 的战场地图作为默认值";
	AM_OPTIONS_TYPE_SAVE_LABEL	= "所有%1控制选项 : ";
	AM_OPTIONS_TYPE_ALL		= "设置改变影响到所有%s";
	AM_OPTIONS_TYPE_SAVE		= "应用到所有%1";
	AM_OPTIONS_BG_MESSAGES		= "发送战c信息到 : ";
	AM_OPTIONS_RAID			= "团队";
	AM_OPTIONS_PARTY		= "小队";
	AM_OPTIONS_GUILD		= "公会";
	AM_OPTIONS_GROUP_DEFAULT	= "分组从属";
	AM_OPTIONS_NUN_AUTO		= "自动发送 NuN 标记设置";
	AM_OPTIONS_NUN_FORMAT		= "发送格式化信息";
	AM_OPTIONS_NUN_MESSAGES		= "自动发送 NuN 标记到 : ";
	AM_OPTIONS_WMAP_MODES		= "世界地图查看模式 :";
	AM_OPTIONS_GMAP_MODES		= "暴雪地图设置 :";
	AM_OPTIONS_GMAP_ALLOW		= "允许改变到暴雪地图";
	AM_OPTIONS_GMAP_CHANGE		= "选中以改变暴雪地图";
	AM_OPTIONS_WMAP_SMODE		= "标准";
	AM_OPTIONS_WMAP_OMODE		= "简洁";
	AM_OPTIONS_WMAP_MINIMODE	= "小地图材质";
	AM_OPTIONS_WMAP_ZMINIMODE	= "放大小地图";
	AM_OPTIONS_WMOTHER		= "其他地图控制 : ";
	AM_OPTIONS_WM_ESCAPE		= "启用 <ESC> 关闭";
	AM_OPTIONS_WM_MOUSE		= "启用鼠标交互";
	AM_OPTIONS_MUTE			= "静音";
	AM_OPTIONS_COORDS		= "(x, y)";
	AM_OPTIONS_MAPS1		= "AlphaMap 地图 1";
	AM_OPTIONS_MAPS2		= "  ..... 2";
	AM_OPTIONS_HELP_TIPS		= "帮助提示信息";

	AM_INSTANCE_TITLE_LOCATION	= "位置 ";
	AM_INSTANCE_TITLE_LEVELS	= "等级 ";
	AM_INSTANCE_TITLE_PLAYERS	= "最大玩家数 ";
	AM_INSTANCE_CHESTS		= "箱子 ";
	AM_INSTANCE_STAIRS		= "楼梯";
	AM_INSTANCE_ENTRANCES		= "入口 ";
	AM_INSTANCE_EXITS		= "出口 ";
	AM_LEADSTO			= "通往...";
	AM_INSTANCE_PREREQS		= "先决条件 : ";
	AM_INSTANCE_GENERAL		= "综合标记 : ";
	AM_RARE				= "(稀有)";
	AM_VARIES			= "(多个位置)";
	AM_WANDERS			= "(巡逻)";
	AM_OPTIONAL			= "(可选)";

	AM_NO_LIMIT			= "无玩家限制";

	AM_MOB_LOOT 			= "怪物掉落";
	AM_RBOSS_DROP 			= "随机首领掉落";
	AM_ENCHANTS			= "附魔";
	AM_CLASS_SETS			= "职业套装";
	AM_TIER0_SET			= "T0套装";
	AM_TIER1_SET			= "T1套装";
	AM_TIER2_SET			= "T2套装";
	AM_TIER3_SET			= "T3套装";
	AM_TIER4_SET			= "T4套装";
	AM_PVP_SET			= "PVP套装";

	AM_PVP				= "PvP";

	AM_ANCHOR_POINT 	= {	{ Display = "上",			-- Localise
					  Command = "TOP" },					-- Do NOT Localise
					{ Display = "右上",		-- Localise
					  Command = "TOPRIGHT" },				-- Do NOT Localise
					{ Display = "右",			-- Localise
					  Command = "RIGHT" },					-- Do NOT Localise
					{ Display = "右下",		-- Localise
					  Command = "BOTTOMRIGHT" },				-- Do NOT Localise
					{ Display = "下",			-- Localise
					  Command = "BOTTOM" },				-- Do NOT Localise
					{ Display = "左下",		-- Localise
					  Command = "BOTTOMLEFT" },				-- Do NOT Localise
					{ Display = "左",			-- Localise
					  Command = "LEFT" },					-- Do NOT Localise
					{ Display = "左上",			-- Localise
					  Command = "TOPLEFT" }				-- Do NOT Localise
				};

	AM_BG_BASE			= "基地";
	AM_BG_BASES			= "基地";
	AM_BG_REQUIRED			= "需要获胜 !";

	AM_EXTERIOR = " 外部";

	AM_RCMENU_INC			= " Inc ";		-- as in 5 inc Blacksmith   or  3 inc farm
	AM_RCMENU_ZERG			= "Zerg";		-- as in Zerg Inc Frostwolf GY
	AM_OK				= "确定";
	AM_RCMENU_HIGHLIGHT		= "高亮";		-- as in leave this note highlighted on the map
	AM_RCMENU_NUN_AUTO		= "自动发送标记";	-- send the NotesUNeed note for the current map note to Raid/Party/...
	AM_RCMENU_NUN_MAN		= "手动发送标记";
	AM_RCMENU_NUN_OPEN		= "打开标记";
	AM_RCMENU_AFLAG			= "联盟军旗 ";
	AM_RCMENU_HFLAG			= "部落军旗 ";
	AM_RCMENU_FLAGLOC		= {	"己方隧道",
						"己方屋顶",
						"到西边区",
						"到东边去",
						"在中间",
						"对方隧道",
						"对方屋顶",
						"对方军旗房间",
						"对方墓地"
					};

	AM_OPENING = "AQ Opening Quest Chain";

	AM_HORDE		= "部落";
	AM_PICKED		= { 	word = "拔起了" };



	-- Deutsch
	--AM_PICKED		= {	word = "aufgenommen" };

	-- Francais
	--AM_PICKED		= {	word = "ramass\195\169",
	--				posWord = " par ",
	--				extraChars = 2 };

	AM_NEUTRAL		= "中立";
	AM_FRIENDLY		= "友善";
	AM_HONOURED		= "尊敬";
	AM_REVERED		= "崇敬";
	AM_EXALTED		= "崇拜";

	AM_CONFIG_SAVED			= "AlphaMap 设置改变为 : ";

	AM_CANCEL			= "取消";

	AM_CORPSE_TXT			= "Dead";
	AM_RESET_INSTANCE		= "Reset";

	--------------------------------------------------------------------------------------------------------------------------------------
	-- TOOLTIPS															    --
	--------------------------------------------------------------------------------------------------------------------------------------

	AM_TT_MINIMAP_BUTTON	= "AlphaMap\n左击开启/关闭 AlphaMap\n右击开启/关闭选项";
	AM_TT_ALPHA_BUTTON1	= "AlphaMap";
	AM_TT_ALPHA_BUTTON2	= "左击开启/关闭 AlphaMap\n右击开启/关闭选项";
	AM_TT_PAUSE1		= "暂停";
	AM_TT_PAUSE2		= "点击后暂停地图刷新并允许你打开/关闭而不重置到当前地图\n如果其他相冲突的插件继续重置 AlphaMap 到当前区域则\n仍然起作用";
	AM_TT_PLAY1		= "播放";
	AM_TT_PLAY2		= "即点击后立刻终止暂停地图刷新功能";
	AM_TT_HOTSPOT1		= "热点";
	AM_TT_HOTSPOT2		= "快速将鼠标掠过该工具以改变 AlphaMap 查看方式\n例如显示/隐藏地图或者标记/图标, 或者使其完全显示\n查看选项中的地图选择器标签以获取完整列表\n(可绑定按键)";
	AM_TT_LOCK1		= "锁定地图选择器";
	AM_TT_LOCK2		= "解锁显示一个用来移动地图选择器下拉列表的框体";
	AM_TT_TAB1		= "初始 AlphaMap 选项";
	AM_TT_TAB2A		= "特定选项仅用于 AlphaMap 包含的地图而非暴雪地图.";
	AM_TT_TAB2B		= "例如地图/标记/文本背景, 及显示的标记/额外信息\n注意 : 仅应用于 AlphaMap 地图, 查看世界地图区域时不适用";
	AM_TT_TAB3A		= "进一步设置仅适用于 AlphaMap 地图";
	AM_TT_TAB3B		= "注意 : 仅应用于 AlphaMap 地图, 查看世界地图区域时不适用";
	AM_TT_TAB4		= "设置世界地图选择器下拉列表位置\n及定义热点的状态";
	AM_TT_TAB5		= "其他 AlphaMap 设置及与其他插件的配合";
	AM_TT_MAPNOTES		= "启用显示 MapNotes, CTMap_Mod notes, MetaMapNotes, MapNotes(Cosmos)";
	AM_TT_RAID1		= "反选仅显示小队位置点";
	AM_TT_RAID2		= "(即使在团队中)";
	AM_TT_CLEAR1		= "显示/隐藏所有上面启用的图标/标记\n也有同样功能的按键绑定";
	AM_TT_CLEAR2		= "例如迅速地清理地图\或者\隐藏全部, 并在需要时使用热点来使它们可见";
	AM_TT_SLIDER		= "显示一个透明度滑动控制条在 AlphaMap 上";
	AM_TT_SLIDERM1		= "钩选以启用移动透明度滑动条功能";
	AM_TT_SLIDERM2		= "放置在地图上任意位置以重新定位其在那儿\n放置在'超出' AlphaMap 范围处以分离它\n(在鼠标交互模式下当CTRL键被按下时可以\n随鼠标移动)";
	AM_TT_ACLOSE1		= "当进入战斗时自动关闭 AlphaMap";
	AM_TT_ACLOSE2		= "(如果你总是开启地图进行游戏则非常有用)";
	AM_TT_AOPEN		= "当离开战斗时自动重新打开 AlphaMap";
	AM_TT_LEGACY1		= "原始玩家 & 队伍方向图标";
	AM_TT_LEGACY2		= "也许会遇到小地图图标闪烁的情形";
	AM_TT_AM_NOTES1		= "显示 AlphaMap 地图标记";
	AM_TT_AM_NOTES2		= "(这和 MapNotes 不同\n而且不可以被改变)";
	AM_TT_ALL_INSTANCE1	= "反选单独为每个副本地图保存设置";
	AM_TT_ALL_INSTANCE2	= "例如你也许想为祖尔法拉克设置一个较暗的背景, 而熔火之心则\n设置一个明亮的背景.\n\n请保持钩选如果你确定你希望当你对任意副本地图做出任何改变时\n设该置复制到所有其它副本地图";
	AM_TT_KEY		= "即显示地图说明";
	AM_TT_ALL_BG1		= "反选单独为每个战场地图保存设置";
	AM_TT_ALL_BG2		= "例如你也许想奥特兰克战场地图相对于战歌峡谷显示得更大.\n\n请保持钩选如果你确定你希望当你对任意战场地图做出任何改变时\n该设置复制到所有其它战场地图";
	AM_TT_ALL_NI1		= "反选单独为每个非副本地图保存设置";
	AM_TT_ALL_NI2		= "例如你也许不想为地下城外部显示地图说明\n但是想让它在世界首领地图上显示.\n\n请保持钩选如果你确定你希望当你对任意非副本地图做出任何改变时\n该设置复制到所有其它非副本地图";
	AM_TT_MSG		= "战场信息将被发送到 :";
	AM_TT_MSG_DFLT2		= " - 你的团队, 如果你在进入战场前已经在一个团队中\n - 你的小队, 如果你在进入战场前已经在一个小队中\n - 否则战场频道";
	AM_TT_MSG_PARTY2	= " - 仅你的小队, 如果你在进入战场前已经在一个团队或小队中\n - 否则战场频道";
	AM_TT_MSG_BG2		= " - 仅战场频道";
	AM_TT_AUTO_BG1		= "在战场中使用 AlphaMap 的战场地图作为默认地图";
	AM_TT_AUTO_BG2		= "如果此选项被钩选则当你进入战场时战场地图将自动打开\n\n如果你宁愿在战场中使用普通的暴雪风格地图则反选\n(当你进入战场时地图将不会自动打开)";
	AM_TT_NUN_F1		= "格式化的 NotesUNeed 标记可以被添加到接收到它们的人的数据库中";
	AM_TT_NUN_F2		= "(然后, 没有安装 NotesUNeed 的人将看到额外的文字而不只是标记的文本.)";
	AM_TT_NUN		= "NotesUNeed 标记将被自动发送到:";
	AM_TT_NUN_DFLT2		= " - 你的团队, 如果在团队中\n - 你的小队, 如果在小队中\n - 否则你只能 '/Say' 发送标记\n\n注意除非你在进战场前已经在团队/小队中\n否则在战场中团队/小队信息发送将失败";
	AM_TT_NUN_PARTY2	= " - 仅你的小队, 如果你在团队或者小队中\n - 否则你将只能 '/Say' 发送标记\n\n注意除非你在进战场前已经在团队/小队中\n否则在战场中团队/小队信息发送将失败";
	AM_TT_NUN_GUILD2	= " - 你的公会";
	AM_TT_MOUSE1		= "鼠标交互模式允许你 CTRL-点击 AlphaMap";
	AM_TT_MOUSE2		= "通常 AlphaMap 对于鼠标来说不可见.\n然而, 在鼠标交互\n模式下, 当 CTRL 键被按下你将可以看见你鼠标悬停处的地图地区\n名称, 并且可以 CTRL-左击 和 CTRL-右击来进行缩放.\n\n当在鼠标交互模式时, 你也可以 CTRL-点击 \nAlphaMap 滑动条和地图坐标来重新定位它们";
	AM_TT_MUTE		= "开启/关闭打开/关闭 AlphaMap 的声音";
	AM_TT_XY		= "开启/关闭显示玩家/鼠标坐标";
	AM_TT_STANDARD		= "标准查看 - 世界地图地区与原始暴雪地图一样显示";
	AM_TT_COMPACT1		= "简洁查看 - 仅显示当前地区已探索的区域";
	AM_TT_COMPACT2		= "你尚未探索的区域将不被显示\n除非你已经安装了 MozzFullWorldMap (Fan's Update) 插件";
	AM_TT_BLIZZ_ALLOW1	= "当钩选时, AlphaMap 将保存你对暴雪地图的\n位置/透明度/缩放度所做的任意改变";
	AM_TT_BLIZZ_ALLOW2	= "反选后恢复原始的暴雪地图设置\n这需要'重载用户界面'在此期间游戏将会\n暂停几秒";
	AM_TT_BLIZZ_CHANGE1	= "当钩选时, 下面的透明度和缩放度滑动条\n将仅影响原始的暴雪地图";
	AM_TT_HELP_TIPS1	= "开启/关闭帮助提示信息";
	AM_TT_HELP_TIPS2	= "不影响地图图标提示信息";

	--------------------------------------------------------------------------------------------------------------------------------------
	-- Everything below should be localised apart from the 'filename', 'lootid' entries which should NOT be changed                               --
	-- The first  'name'  field is used to equate with in game Zone name information to help determine when the player is in a specific --
	-- Instance, and must therefore be spelt IDENTICALLY to the names of the Instances as displayed by the WoW Client in other native   --
	-- frames.															    --
	--------------------------------------------------------------------------------------------------------------------------------------

	AM_TYP_WM			= "世界地图";
	AM_TYP_GM			= "暴雪地图";

	AM_TYP_INSTANCE 	= "副本";
	AM_TYP_BG			= "战场地图";
	AM_TYP_WORLDBOSSES	= "非副本地图";
	AM_TYP_CAVES		= "Caves";

end