v3.23.20400 (Fan's Update)

Includes Maps for Instances, Battlegrounds, & World Bosses, and the major non-Instance Cave systems

Basically, AlphaMap is a scalable, moveable, transparent WorldMap that the user can have on screen while they continue to play and interact with the world.

Move the AlphaMap by  holding down Control & Alt keys, and moving via the yellow movement bars at the top and bottom of the map.

Supported by PartySpotter, and MozzFullWorldMap(Fan's Update).

Native support for MapNotes, Gatherer, MetaMapNotes, CTMapMod, FlightMap, AtlasLoot, and NotesUNeed


See Patch Notes / Change History for specific details of functional changes/bug fixes



FEATURES NOT TO MISS

- World Map replacement mode via the 'Mouse Interaction' checkbox in the Miscallaneous Tab of the Options. ALT-Clicking on the AlphaMap will allow you to zoom in/out via left/right clicks. Without the <Alt> key pressed, then AlphaMap will remain invisible to the mouse as per current functionality.

- World Map 'Compact' veiwing mode, which will trim the world map, and only show explorable areas; so that keeping the map up on screen uses even less space.
The 'Standard'/'Compact' veiwing modes can be switched via a key binding.
NOTE : A side affect of this will mean that characters won't see areas they haven't discovered yet. If you would like to use Compact viewing mode, but STILL be able to see ALL areas in the current Map, you will need to install 'MozzFullWorldMap (Fans Update)'

- Special Battlefield options for reporting positions and incoming.  (Note that the Raid Group numbered icons in the pictures are only available with the 'PartySpotter' AddOn installed)



FEATURES IN MORE DETAIL


High Quality Instance Maps :
lots of options allowing you to change the scale, alpha, the display of notes, note backgrounds, map background, Instance Header and Footer information, instance legend, the ability to change the colour of the note and/or map backgrounds.
Compatible with the latest versions of AtlasLoot (v1.60 and later). Atlas not required if you need to save memory.
Instance settings are saved separately to the World Map settings, so you don't have to change the way AlphaMap is displayed every time you enter/exit an Instance.
Or, save all Instance map settings separately allowing you to have different Instance maps set to different sizes, etc. Uncheck the box on the 'Dungeons' tab of the Options frame.


High Quality BattleGround Maps :
Minimap textured maps of Battlegrounds displaying all player units, and Battleground flags/objectives.
In Warsong Gulch, extra flag icons record which players have picked up which flags. Left click on a flag to target the carrier. Right click the flag to bring up a menu allowing you to report the flag's position to Raid/Party/General chat.
In Arathi Basin, the number of bases required to win is displayed next to your Faction's entry point. When ever the number of bases you need to win changes, a message is sent to your chat box to inform you of this. If you have the Scrolling Combat Text AddOn installed, then this message will also be displayed in the center of the screen. Right click on bases to report the number of incoming enemy to Raid/Party/General chat.
In Alterac Valley, Right click on bases to report the number of incoming enemy to Raid/Party/General chat.
As per all AlphaMap maps, the scale, alpha, and position of the maps can be changed and will be saved separately from the World Map settings or the Instance map settings.
Or, save all Battleground map settings independantly from each other allowing you to show the large Alterac Valley map at a smaller scale than the small Warsong Gulch map - Uncheck the box on the 'Battlegrounds' tab of the Options frame.


World Boss Maps & Instance Exteriors Caves :
For example, maps for Gnomeregan dungeon (before you enter the Instance), Dire Maul exterior, and Maraudon Exterior; And zoomed minimap style maps for the World Bosses Lord Kazzak, Azuregos, and all 4 of the Four Dragons. All these maps are capable of displaying player units, and all save their settings spearately from each other, and from the World, Instance and Battleground maps.


All the above maps have AlphaMap notes detailing key locations, mobs, etc. These notes can be clicked to do one or more of the following :
Left Click
- If the note leads to another map, then that map will be displayed. e.g. links between LBRS/UBRS/BWL, DM maps, etc.
- If the note has Loot noted for it, a small gold coin will be displayed next to it, and left clicking will show the AtlasLoot frame
Righ Click will raise a menu with several possible options
- You can leave a particular map note highlighted
- In Battlegrounds, there are special options for reporting the number of enemy incoming on a base, or the location of a flag carrier
- If you have NotesUNeed installed, then you can open a NotesUNeed note, or Send the NotesUNeed note text to your Raid/Party/Guild. i.e. store the tactics for a particular boss in a NotesUNeed note, and then send those tactics to your Raid via the right click menu for that boss on the AlphaMap.



Original Credits : Jeremy Walsh, Telic, Alchemys Indomane

Version 2 Credits :

Most of the High Quality Maps are courtesy of Niflheim. Thanks Niflheim :)

But I created the following maps myself, so send any corrections to me :

Dire Maul Overview, West, East, North, & Exterior
LBRS, UBRS
Gnomregan & Gnomregan Exterior
Stratholme
Warsong, AB, and AV Battlegrounds
Maraudon Exterior

Localisation Credits
German : Eike Hanus, Stardust
Traditional Chinese : Arith Hsu
Simplified Chinese : springsnow

BC Credits :

Again thanks to Niflheim for allowing use of his Instance maps :)
Gruul's Lair & Eye of the Storm BG map courtesy of myself :)
Auchindoun and Tempest Keep and most BC maps courtesy of Daveish <- he's like Niflheim on speed :)

Big thank you to Daveish, who made his AtlasLoot data and frames available for other AddOns to access :)
And to Asurn for AtlasQuest and helping to make AlphaMap compatible.



------------------
AlphaMap's Options
------------------

1.) First, please remember that AlphaMap can save options for different maps completely separately, so changing a setting when you are viewing a World map zone won't necessarily have any affect when you view one of AlphaMap's maps such as an Instance map, or Battleground map. The name of the map (or type of map) that you are changing the settings for is in the bottom right of the Options frame.

2.) Some settings are global and you should check the 'Global Variables' section of the 'Readme.txt' file if you need any clarification.

3.) You can only access options for AlphaMap's custom maps if you have one of AlphaMap's custom maps open (or it was the last type of map you had open). I did this to try and prevent confusion; For example, it didn't make sense to change how AlphaMap's internal notes are displayed when the player is viewing a World map zone (and I can't predict whether you are intending to change the note settings for Instances, or Battlegrounds, or Non-Instances.)

4.) If you have an AlphaMap Map open, then the "AlphaMap Maps 1" and "AlphaMap Maps 2" tabs are accessible. However, on Tab 2, the Battleground checkboxes are only availabe if the last map you had open was a Battleground map, and the Instance checkboxes are only available if the last map you had open was an Instance map, etc. etc.





----------------
Global Varibales
----------------

As mentioned above in the sections on High Quality Instance/Battleground/Exterior Maps, most of the settings can be saved separately for each map automatically, e.g. the transparency, scale, position, etc.   So to change the settings for Naxxramas, you should first display the map for Naxxramas in AlphaMap, and then open the options. (If you have the 'Changes affect ALL INSTANCE Maps' checkbox checked on the Dungeons Tab, then opening ANY Instance map, and then opening the Options will allow you to change the Options for ALL instance maps.)

However, some variables are always saved globally, sometimes because it just doesn't make sense to save them individually for each map, and sometimes because its just too difficult to implement without problems.  The following settings are Global no matter which map you are displaying :

- Enable/Disable AlphaMap
- Checkbox controlling whether setting changes apply to ALL Instance Maps or should be saved independantly
- Checkbox controlling whether setting changes apply to ALL Battleground Maps or should be saved independantly
- Checkbox controlling whether setting changes apply to ALL Non-Instance Maps or should be saved independantly
- Whether the AlphaMap position is Locked or not.  (Maps can still be saved in different positions before this option locks them all where they are)
- Whether the legacy player arrow is used or the new one that fixes the old Minimap blink issue
- Where the AlphaMap map selector is docked
- The position of the Minimap Button
- The mode of the World Map view : Standard/Compact
- Whether the 'Escape' key can be used to close AlphaMap
- Whether the Mouse Interaction mode of 'Ctrl-Click' map selection is enabled or not
- Whether or not to play sounds when the map opens/closes, or should be muted
- Whether or not the original game World Map frame can be changed or not
- The toggle of Help Tooltips



------------
Known Issues
------------

Some other AddOns that reset the world map, may prevent you from using AlphaMap to view World Zones other than the one you are currently in. e.g. Telo's Infobar Coordinates will constantly reset the map to the current zone. (The AddOn 'cMinimapCoordinates' provides similar functionality without affecting AlphaMap)
To counter this problem I have provided a 'Pause' button next to the AlphaMap Map Selector drop down boxes. Clicking this will pause map updates to AlphaMap, allowing you to manually select other areas to view. Also, the map will still update when your character physically changes Map zones, but other background events that would otherwise reset the map should still be ignored.
This is not the normal mode of use, and is only provided as a helper function for people who can't live without a conflicting AddOn.

NOTE:
1.) The Hot Spot function can not make the AlphaMap opaque if the Options frame is open.


2.) BG objective Icons are deliberately duplicated to the left of the map.
This was done to make sure that their status is always easy to see even when player dots are obscuring the actual on map icons - it also means the right click menu is always still available for the user to report Incoming enemies.




--------------
Change History
--------------

Changes in v3.23.20400 from v3.22.20400
---------------------------------------

- AlphaQuestHelper update for compatibility with Cartographer AND QuestHelper





Changes in v3.22.20400 from v3.21.20400
---------------------------------------

- fixed a problem where BG objectives wouldn't update on the world map 'style' maps

- PvP objectives should now update even when the map is paused

- fixed a problem where player dots would disappear in certain circumstances



Changes in v3.21.20400 from v3.20.20400
---------------------------------------

- new AlphaQuestHelper plugin now included to show QuestHelper Icons and "Ants" on AlphaMap
NOTE : this will ONLY work with the NEXT release of QuestHelper
i.e. versions LATER than 	"QuestHelper 0.44.17-gf3f3830"
With earlier versions, the QuestHelper icons will not remain attached to AlphaMap, so please await the next release of QuestHelper
You should probably leave the AlphaQuestHelper plugin disabled until a compatible QuestHelper is released



Changes in v3.20.20400 from v3.19.20400
---------------------------------------

- Fix to MozzFullWorldMap compatibility (that resulted in a blank map)



Changes in v3.19.20400 from v3.18.20400
---------------------------------------

- Major French localisation update. Thx to Septh :)

- fix to problem where newly explored areas would not update immediately

- fix to Arathi Basin Stables and Lumber Mill timer on all Clients

- further fix to Arathi Basin Lumber Mill timer on French Client



Changes in v3.18.20400 from v3.17.20400
---------------------------------------

- fix to problem where on map icons & player dots would pause



Changes in v3.17.20400 from v3.16.20400
---------------------------------------

- update to TomTom support to include distances in Tooltip info
Right-click menu functionality requires TomTom r131 or later.



Changes in v3.16.20400 from v3.15.20400
---------------------------------------

- fix to Map switching ability and potential Paused status bug



Changes in v3.15.20400 from v3.10.20400
---------------------------------------

- IMPORTANT LOCALISATION FIXES FOR FRENCH & GERMAN CLIENTS

- updated support for TomTom
Sadly, TomTom has changed and is hiding much of its information, so I can no longer reliably include distance information in the Tooltip;
Neither, can I reliably make the Right click menu available from TomTom dots.
(At least not without virtually writing my own version of TomTom... ;)




Changes in v3.10.20400 from v3.00.20300
---------------------------------------

- toc update

- added maps for Magister's Terrace, Sunwell Plateau

- fix to DropDown box use where the "default" map in a zone is a custom AlphaMap Map

- new option to control whether BG maps should auto-open when entering a BG
i.e. now separate to the option controlling whether you use AlphaMap maps or World BG maps in Battlegrounds

- improvement to Search facility to highlight on-map notes where multiple pages of notes exist

- some small bug fixes and changes to Options text

- some small database fixes



Changes in v3.00.20300 from v2.97.20300
---------------------------------------

- Map categories are now defined as separate Plugins so you can pick and choose which maps you want to load
Other Plugins for other maps can be created and registered with AlphaMap

- split the non-Instance Raid category in to 2 types : WorldBosses, and Instance Exteriors

- added Instance Exterior maps for CoT, Coilfang, Auchindoun, Sunken Temple, Blackfathom Deeps, The Deadmines, Scarlet Monastery, & Karazahn
All show player/raid dots.

- added a new Searching feature to help find/highlight particular Mobs/NPCs
Works via a new slash command "/am -s <Search for this text>"
All AlphaMap maps with Notes containing the text will be reported to the chat frame.
If an AlphaMap map is open and has notes containing the text, then those notes will be highlighted.
"/am -s" without any other text will turn off search highlights on the map.

- updated the way that the map selector drop down boxes are updated - BIG improvement in usability overall

- allowed map changing again by <Alt>-clicking at the edge of the map.
To Zoom in to particular world map textures, hold <Shift> & <Alt> down when left clicking the AlphaMap
(<Alt> Right click to zoom out)

- fixed a bug that would happen when moving from Arathi Basin to another Battleground

- fixed an Instance progress bug, where the key symbols for bosses would change to GY symbols and be displayed, even though the key was hidden



Changes in v2.97.20300 from v2.96.20300
---------------------------------------

- fixed an issue with the Instance / BG maps being mistakenly left in a zoomed state
Instance/BG maps will auto-zoom out when you change map.
<Alt>-Left Click to zoom in on a particular part of the Instance or Battleground map
<Alt>-Right Click to zoom out to the full map view again

- spam guard now in place to try and reduce Arathi Basin message spam when when the number of bases required to win is too close to call

- Gatherer and Astrolabe compatibility update

- fixed issue of the WorldMap not scaling immediately while using the slider

- MetaMapNotes support

- changes to MetaMap and Cartographer support.
Changes to the WorldMap are NOT possible using Alphamap if either of these AddOns is installed, to prevent conflicting settings
Also, change to prevent confusion between Cartographer Gatherer and the genuine article which resulted in an error



Changes in v2.96.20300 from v2.95.20300
---------------------------------------

- fixed a problem with tooltip scale being corrupted after clicking BG objectives



Changes in v2.95.20300 from v2.94.20300
---------------------------------------

- New maps for Black Temple, The Eye, and World Bosses Doomwalker and Highlord Kruul
Only one map is supplied for Black Temple, but don't forget that AlphaMap allows you to zoom in to Instance maps by holding down the <Alt> key while left/right clicking.
So you can zoom in to particular wings of the instance to get a detailed view.

- Corrections to World Boss Encounters in Feralis, Ashenvale, and Blasted Lands

- Big database update for Instance Notes and AtlasLoot Enhanced

- Bug fix to Battleground Timers in AV and AB to display time till capture
(Note that as before, the time till capped is shown in the Tooltip for a Tower/Base, and to reduce performance costs is only calculated once when you mouse over the objective)

- New BG functionality based on Time till capped information :
Left-Clicking on a Tower that is changing hands will refresh the Timer information in the tooltip without having to wiggle the mouse around
<Control> Left-Clicking on a Tower that is changing hands will broadcast the Timer information to the Battleground Channel

- Bug fix to the Battleground calculation in AB to display the number of bases needed to win

- New BG functionality in AB
Can manually check the number of bases required to win by Left-Clicking on any of the Objectives - Farm, Blacksmith, etc.
<Control> Left-Clicking on any objective will broadcast the number of bases required to win to the Battleground Channel

- Note that you can still report Incoming enemies to BG Objectives by Right clicking on them and selecting the message to send

- TomTom compatibility changes (displayed by default with no option to turn off atm)

- MobMap compatibility changes via Plugin AddOn called "AlphaMobMap"
So enable AlphaMobMap via the Blizzard AddOn screen in order to display MobMap markers on AlphaMap

- Bug fix to Key bindings to change opacity

- Bug fix to make moving the AlphaMap much less fiddly and prevent it from dropping accidentally

- AlphaMap should now scale in situ, rather than being re-centered when changing size

- Pressing of the Escape key should now close the WorldMap if "modified" by AlphaMap



Changes in v2.94.20300 from v2.93.20300
---------------------------------------

- fixed AlphaMap's ability to modify the original Blizzard Map (Miscallaneous Tab Option)


- the Map Selector drop down boxes have been slightly reduced in size by default, and will remain a constant size no matter which UI Scale is selected.
If you are not happy with the default size, then the following slash command can be used to change it :

/am ddscale <value>

The default scale value for the Map Selector controls is 0.7, and can be changed to any value between 0.3 and 1.4.
For example : 

/am ddscale 0.64			-- will reduce the size of the Map Selector boxes slightly

Use "/am ddscale" on its own to reset to the default value again.
The command will report the old and new values being set.
As an option that will be rarely used, there is no corresponding GUI component for this Option yet - perhaps later ;)
NOTE : This option controls the size of the Map Selector frame both when attached to the AlphaMap, or Free Floating.


Changes in v2.93.20300 from v2.92.20300
---------------------------------------

- Fixed a graphical glitch on the Terokkar Forest map

- Fixed a bug when positioning the Minimap button

- Normalised the scaling of the Map Selector drop down boxes

- Rotating Minimap support (for updating the AlphaMap Player arrorw)

- Repositioned the Player ping

- Provided a new slash command to help in reporting issues where the AlphaMap is not automatically updating to the expected map
/am info
If the map is not automatically updating to what you expect, then please use this slash command when reporting the problem to me, and make sure you copy ALL 3 lines of information from the chat window.



Changes in v2.92.20300 from v2.91.20200
---------------------------------------

- updated Shadow Labyrinth boss loot information
(Credit : BoaConstrictor)

- WoW Patch 2.3 compatibility changes and a toc update ofc



Changes in v2.91.20200 from v2.91.20100
---------------------------------------

- simply a toc update



Changes in v2.91.20100 from v2.90.20003
---------------------------------------

- toc update

- some AtlasLoot updates, some small corrections, and a map for The Black Temple



Changes in v2.90.20003 from v2.81.20003
---------------------------------------

- BIG CHANGE TO FUNCTIONALITY : PLEASE READ !!!
The Mouse Interaction Mode which allows you to Zoom in and out of world map Zones NOW USES THE  <ALT>  KEY.
NOT THE <CONTROL> KEY.

- As Above, to move the on map Coordinates, you now need to use the <ALT> Key, and NOT the <Control> Key.



- IMPORTANT CHANGE TO MapNotes(Fan's Update) COMPATIBILITY
You can now Create and Edit MapNotes on world zone maps in AlphaMap, using the standard <Control>-Right Click method of interaction.
You should now also see Party Notes, and Thottbott Markers on the AlphaMap world zone maps.
You can create a Party Note on the AlphaMap, but will need to hold down both the <Control> & <Shift> keys.
This functionality requires the latest version of "MapNotes (Fan's Update)".  (v3.40.20003 or later)
NOTE: As a Result of this change the AlphaMap Option to hide MapNotes Tooltips no longer works when using MapNotes (Fan's Update); And only applies to the tooltip's displayed when using CTMapMod or MetaMap



- USEFUL NEW INSTANCE/BATTLEGROUND FEATURES
Zoom in to see Instance Maps in more detail by <Alt>-Left Clicking on them. (2x zoom)
Zoom out again by <Alt>-Right Clicking
Useful for quick checking areas in detail without having to change the scale of the map frame itself, or focusing in more detail on particular dungeon wings.
NOTE : Must have Mouse Interaction Mode enabled. (Enabled by default).
NOTE : Can't currently zoom in on maps created from in-game Minimap Textures such as World Boss maps (these are already zoomed minimap textures, so I didn't dedicate any time to it ;)

- Can now scale the AlphaMap Notes on Instance/BattleGround/WorldBoss Maps to suit your needs
For example - open up an Instance Map;
Open up the AlphaMap Options;
Click on the Second Tab;
You will see the options have been slightly re-organised, and there is now a slider on the left hand side allowing you to change the size of the on-map icons
AlphaMap key symbols are not affected by this re-sizing, but are now slightly larger by default.



- NEW BETA TEST LEVEL FEATURE
Can now Zoom in on WorldMap areas using the normal <Alt>-Click method - basically this means you can zoom even further on world map zones and see individual "discoverable areas" as a single enlarged area of the map - at the moment, I'm afraid no map icons will be displayed on 'zoomed' map areas.
Sometimes this feature is useful for quickly seeing part of the map more clearly,  sometimes not so useful ;)
Let me know what you think.



- BATTLEGROUND CHANGE
BattleGround Tooltips will now show the Amount of time until a Graveyard or Objective is Captured by a Faction.
Only Roughly accurate to within a couple of seconds, and only calculated when you mouse over the objective to keep performance impact to a minimum, but a good guide-line none the less.

- fix to make sure automatically opened AlphaMap BG maps show player icons correctly when moving from one BG to another

- updated the Eye of the Storm BG map to include secondary icons for the Capture objectives, as they are often obscured by player icons



- IMPORTANT BUG FIX FOR PEOPLE WHO DO NOT USE AlphaMap Battleground Maps as Default Maps in BG
Thank you to dw420 for their error reports



OTHER IMPORTANT CHANGES
- New Maps for :
Serpentshrine Cavern
Cavern of Time : Old Hillsbrad Foothills
Cavern of Time : Battle for Mount Hyjal
Cavern of Time : Black Morass
Karazahn
Lord Kazzak map updated to Outland Doom Lord Kazzak map
Zul'Aman
( Some created myself, some thanks again to Daveish :)

- Updated for latest Gatherer Beta

- Added support for Gatherer's control of Icon Sizes

- Added secondary BG Objecive Icons to the Eye of the Storm BG map, as status often obscured by Player Icons



- if AlphaMap on-map Instance note tooltips have been disabled, then neither will the note be highlighted when you mouse over it

- Miscallaneous data corrections, and updates, including localisation corrections and Atlas Loot IDs

- Thottbott compatibility update







Changes in v2.81.20003 from v2.80.20003
---------------------------------------

- fix for people not using Gatherer



Changes in v2.80.20003 from v2.70.20003
---------------------------------------

- updated the Eye of the Storm Battleground coordinate system to display Players correctly now :)

- added the following Maps courtesy of Daveish <- He's like Niflheim on speed ;)
Auchindoun: Auchenai Crypts
Auchindoun: Shadow Labyrinth
Auchindoun: Sethekk Halls
Auchindoun: Mana-Tombs
Tempest Keep: The Arcatraz
Tempest Keep: The Botanica
Tempest Keep: The Mechanar

- added support for the latest Gatherer Beta
NOTE: everything should work fine during normal play, but if viewing other World Map Zones other than the one where your character is located while using Gatherer, you may suffer from a performance impact and find Drop down boxes impossible to use. The AlphaMap Pause button can be used to solve these issues for the time being.
However, if you have used any AddOn that alters the original Blizzard WorldMap, such as the Miscallaneous AlphaMap Option, then you may also notice these problems when trying to use the original Blizzard WorldMap to view other zones, in which case the AlphaMap pause button will not help as it is linked to the Gatherer Minimap processing. I will investigate to see if this is solvable from within AlphaMap if the problem still exists when Gatherer reaches a Gamma release, as I believe that Gatherer's Astrolabe library is still being tweaked.

- AlphaMap will now highlight Named Bosses on Instance maps if you Target them

- when Named bosses in Instances are killed, AlphaMap will now flag them with a GraveYard symbol
If the Instance is a normal Party Instance, then the bosses will reset automatically when you leave the Party-Instance.
If the Instance is a Raid Instance, you will have to use the new Reset button.
If you don't receive the system message when a Named Mob dies, then your AlphaMap may still be updated by one of two automatic methods :
1.) targetting the corpse of the Named Mob will update its status on the AlphaMap Instance map
2.) other users of AlphaMap in the same Raid will send notification messages to you to update your Instance details
Failing that, you can use the new "Dead" option on the note Right-Click Menu to toggle the status of that boss.
NOTE: you can't note a boss as Dead unless you are inside an instance, but you are allowed to toggle the status back to life whether in an Instance or not

- corrected the Hellfire Ramparts map, and updated the notes. ty Pleegwat :)

- updated some more AtlasLoot Enhanced Loot IDs

- removed the AlphaMap Options frame link to AtlasLoot as no longer required

- fixed the problem where the AlphaMap Coordinates couldn't be moved by holding down the Control key



Changes in v2.70.20003 from v2.66.20000
---------------------------------------


IMPORTANT CHANGES IN FUNCTIONALITY

- the Lock Map Option has been removed. Simply hold the <Control> and <Alt> keys down at the same time, and the movement bars at the top and bottom of the Map will become visible for you to move the map. Different maps will still store there positions separately.

- when scaling the AlphaMap, it will now be re-anchored to the center of the screen; This should stop the AlphaMap disappearing off the screen when you scale it requiring you to re-position it several times potentially. Now just scale it in the center of the screen, and use the new <Control><Alt>-Drag method of movement.


MISCALLANEOUS CHANGES

- toc update

- fixed a problem when trying to Zoom back in to a Continent from the 'Cosmic' map via the Mouse while updating is paused

- timing issues would sometimes stop Battleground maps opening automatically when entering a BG; This should now be fixed. Maps will auto-close when you leave a BG if they auto-opened when you entered.

- added a new map for BlackRock Mountain before entering an Instance

- fixed Player coordinate problems in non-Instance Gnomregan Exterior, etc.

- updated the Scrolling Combat Text interface to the latest release for that AddOn

- couple of small performance improvements
(However, you should still use the provided Pause button if you have other AddOns that continually reset the map, this can also improve performance as well as preventing other AddOns from resetting the map)

- improved compatibility with NotesUNeed

- added 'Placeholder' entries for most of the new BC Maps. This means most Instances are now listed, but where no map is yet available, then AlphaMap will show a warning graphic instead of the map, but you will be able to access AtlasLoot items from the frame. Where no specific map is available, then the Instance name will be postfixed with  '(x)'

NOTE 1 : If you don't want to see any entries where no map is yet available, then delete the 'Placeholder.blp' file from the \AddOns\AlphaMap\Maps  directory

NOTE 2 : Remember that if you don't want to use AlphaMap for viewing Battleground/Instance/WorldBoss Maps, then you can simply delete the relevant .blp  file from the \AddOns\AlphaMap\Maps  directory and those maps won't be shown in the drop down boxes.  For example, if you just want to show BattleGround maps in AlphaMap, but not Instance maps, then you can delete or move all the Instance  .blp  files you don't want to use, and AlphaMap will no longer show any Instances options in the drop down boxes, but the Battlegrounds will still be available :)
In other words, AlphaMap will cope gracefully with the absence of map files you don't feel you need; So its up to you what maps to keep.



Changes in v2.66.20000 from v2.65.20000
---------------------------------------

- fixed the unattached Map Selector problem again, after having caused it again, after having fixed it the first time ;p
( Doh! I'm tired. )

- fixed the yellow circle locator to ensure it appears over the player even when using the Legacy Player Icons
(Although I may remove that option completely soon, as the old code does not seem to be standing the test of time. Are any people finding it a useful feature ?)



Changes in v2.65.20000 from v2.64.20000
---------------------------------------

- Instances now listed separately in drop down boxes based on the continent where they are located

- New BC Instance Maps provided with the kind permission of Niflheim :)

- Included new BC Battleground map for Eye of the Storm

- update for German Client Battleground Objectives

- fixed the problem of the UI disappearing if combat starts while the WorldMap is open

- small compatibility changes for WoW 2.xx and Burning Crusade

- can no longer Target Flag carriers in Warsong Gulch

- Drop Down boxes will now remain docked to the Options frame between log ins

- fix to ensure no .scale error during first time installs





Changes in v2.64.20000 from v2.63.20000
---------------------------------------

- Important bug fix for displaying World Maps
(For those who don't have MozzFullWorldMap (Fan's Update) installed ;)




Changes in v2.63.20000 from v2.62.11200
---------------------------------------

- updated to support new API, and The Burning Crusade Expansion pack

- one small bug fix for compatibility with MapNotes (Fan's Update) v3.10.20000




Changes in v2.62.11200 from v2.53.11200
---------------------------------------

- updated to support the latest version of AtlasLoot Enhanced

- some database updates



Changes in v2.60.11200 from v2.53.11200
---------------------------------------

- updated to support latest version of AtlasLoot Enhanced
PLEASE NOTE :
Left Click the "AL" Button - shows original Sets
Right Click the "AL" Button - shows the new Faction Rewards

- compatibility changes to support the upcoming release of  "MapNotes (Fan's Update)"
MapNotes (Fan's Update)  will support the creation of MapNotes on AlphaMap Instance/Battleground/WorldBoss Maps, plus the ability to Ctrl-Alt-Drag notes to move their position, a note searching feature, and some bug fixes.

- made sure the WorldMap Blackout frame won't appear when using Windowed mode at different UI scales

- fixed a "Friedhof der Frostwolf" error in the German Localised Alterac Valley map



Changes in v2.53.11200 from v2.52.11200
---------------------------------------

- update for Simplified Chinese Localisation (Thanks to Springsnow)

- stopped drop down boxes reverting to world zones when map opens after selecting an Instance/BG/Raid map

- stopped player position pinging when showing maps that the player is not currently in

- stopped the player icon appearing on maps it shouldn't appear on when the Pause button is clicked



Changes in v2.52.11200 from v2.50.11200
----------------------------------------

- changes to make compatible with the next release of AtlasQuest. ( AtlasQuest version 3.14.30 and later should work with AlphaMap ) Check for new "AQ" button at the top right of instance style maps.

- new AtlasLoot button at top right of Instance maps allowing quick access to AtlasLoot Sets

- also fixed small problem where AtlasLoot Legendary sets not accessible

- AlphaMap will now automatically open an Instance map when you select "Instances", or a Battleground map when you select "Battlegrounds", etc. It will try to remember the last map you had open, or just open the first map in the Drop Down list.

- improved the coordinate system in Alterac Valley so player positions are now more accurate

- some small database corrections for Warsong and Alterac Valley

- movement bars are now hidden when the Control key is pressed in Mouse Interaction mode, to stop them interfering with mouse clicks at the edge of the map.

- formatted the tooltips with default line breaks (with a couple of deliberate exceptions)

- German localisation updates from Stardust



Changes in v2.50.11200 from v2.32.11200
---------------------------------------

- Pause functionality now much improved and should now successfully prevent map resets caused by more troublseome conflicting AddOns such as Telo's Infobar Coordinates.

- now properly fixed the sending of messages in Battlegrounds. Note that you still need to be in a Raid/Party BEFORE you enter a Battleground in order to send AlphaMap Battleground messages to Raid/Party members

- Added help Tooltips for the Map Selector controls, and the Options. (Only English tooltips available currently)
These tooltips can be turned off/on via the 'Help Tooltips' checkbox in the Miscallaneous Tab of the Options.
I haven't provided Tooltips for every option, just those I thought needed clarification.

- Options slightly reorganised.  You should now only be able to access Instance options when the last map you opened was an Instance map, and only be able to access the Battleground options if the last map you had open was a Battleground map, and so on...
Please see the "AlphaMap's Options" section of the 'Readme.txt' file for more details.

- Added map of the exterior of Uldaman

- Added map of the exterior of Wailing Caverns

- Improved performance by reducing AlphaMap's memory footprint by roughly 50% (approx. 1.3Mb reduction)

- added an Earth/Cosmos button for accessing AlphaMap Options

- updated compatibility with latest version of Gatherer (Supports Gatherer filtering options and latest gatherer types - you may need to update your version of Gatherer. I had no problems displaying icons recorded from earlier versions in the latest one)

- slightly increased the size of the font used to display player/cursor coordinates

- made the AlphaMap note highlighting much more noticable

- fixed a silly bug which prevented Simplified Chinese Localisation from working

- slightly increased the size of the player icon at smaller scales, and slightly corrected the player ping animation position and made it more visible
(You can use the HotSpot (by mousing over it) to highlight player position on the map)

- default alpha setting for AlphaMap maps (i.e. Instance maps, etc.) is now fully opaque



Changes in v2.32.11200 from v2.31.11200
---------------------------------------

- fixed the issue where the AlphaMap on-map slider would reattach itself to the AlphaMap after the user has moved it off the map to detach it

- corrected the spelling of the French localistion for the Gold Mine in Arathi Basin (not verified)


Changes in v2.31.11200 from v2.30.11200
---------------------------------------

- small fix to stop "MozzFullWorldMap (Fan's Update)" being a mandatory requirement for Compact viewing mode
Still recommended however. Note that if you don't have MFWM installed and enabled, then only regions in which you have discovered at least one area will be displayed in Compact mode and completely un-explored (undiscovered) maps will be displayed in Standard mode.


Changes in v2.30.11200 from v2.25.11200
---------------------------------------

- 99% localised for Simplified Chinese courtesy of springsnow

- German localisation update courtesy of StarDust

- Now displays both the player(green) and the cursor(yellow) coordinates. These can be turned off by the new '(x, y)' option on the Miscallaneous Tab of the Options frame. Saved on a per map basis, so you can show coords on the world map, and perhaps in BG maps, but turn them off for Instance maps, etc.

- Changed the default behaviour to have Mouse Interaction mode turned on. So press the Ctrl-Key to use the mouse to zoom in and out of map regions

- When in Mouse Interaction mode and the Control key is pressed, the displayed Coordinates can be moved with the mouse and attached anywhere else on the AlphaMapFrame. Again, the position of the Coordinates is saved on a per map basis, so you can move them to the right on the World Map, while leaving them in the default position for BG maps, etc.

- Small re-organisation of the Options tabs and new Options for the following features :
1.) Can now show backgrounds for the text frames when veiwing Instance/BG/Raid maps. The colour and alpha setting of the text background can be changed independantly of the map or note backgrounds. New option on the "AlphaMap Maps 1" Tab of the options frame.
2.) New optins to control Non-Instance map settings in just the same way as Instance or Battleground maps. i.e. you can check an option so that when you make a change to ANY Non-Instance map, it will affect ALL Non-Instance maps. Similarly, there is a new button for a one off application of the current AlphaMap Settings to ALL Non-Instance maps.  These new options have been added to the 'Non-Instance' section of the 'AlphaMap Maps 2' Tab of the options frame.

- Added support for the sending of messages via the new 'Battleground' Channel.
Important : Due to the way that Blizzard have changed the grouping system in Battlegrounds, it has become 'difficult' for me to determine whether a player is really capable of broadcasting messages to a Raid or not.  i.e. you can appear to be in a Raid, but not be able to send Raid messages if the Raid was one formed automatically on entering a BattleGround.
For this reason, the ability to broadcast BG messages to Raid or Party members is dependant on you being in a Raid or Party BEFORE you entered the Battleground. Otherwise, the only type of messages you will be able to send is 'Battleground' messages - even if you join a 'proper' Raid/Party after entering the Battleground.

- fixed the Arathi Basin calculation of the number of bases required to win which was broken by changes in WoW 1.12

- small database corrections, and added links to AtlasLoot Tier sets from Instance maps

- now more compatible with MobileMinimapButtons (although MobileMinimapButtons may reset the Radius of your AlphaMap button if you use a non-standard AlphaMap Radius setting - this can't currently be avoided without disabling MobileMinimapButtons as MobileMinimapButtons 'automatically' interferes with AlphaMap)

- the current map zone is now reset whenever the AlphaMap or World Maps are closed. This should ensure that other AddOns that calculate the player's map coordinates do not report incorrect values after different maps were viewed.
(This does not correct the issue of certain other coordinate AddOns resetting the map, as this can not be sensibly corrected from within AlphaMap and requires those other AddOns to be changed - the pause button can be used to try and correct this, but I can't promise anything)

- increased the frame Strata of some frames so that they aren't obscured by other windows/buttons

- fix to prevent the black background appearing for some users who still found this to be a problem after having changed the original World Map Frame scale

- fix to make sure that MozzFullWorldMap(Fan's Update) world map check box control is still accessable when the World Map scale has been changed

- When using the latest version of MozzFullWorldMap(Fan's Update) v2.05.11200 or later, AlphaMap will stay in Compact viewing mode even when you have discovered no areas on a particular map.

- fixed the 'Reset All' button so that it does again reset all the options

- changed the tooltip anchor for the Minimap button to the WoW game default position (lower right of screen)

- Mouse Interaction mode is not available if the AlphaMap was opened via the HotSpot key binding (This was done to prevent certain errors that could occur)





Changes in v2.25.11200 from v2.25.11100
---------------------------------------

- Simply a .toc update for the latest WoW patch


Changes in v2.25.11100 from v2.12.11100
---------------------------------------

- Enhanced the Mouse Interaction mode by adding zone labels to show the names of areas/POIs that the mouse is over when the <Ctrl> key is pressed

- Added a key binding to toggle the HotSpot functionality. This is not availabe when the Options frame is open, and the hot spot veiw will be cancelled when the Options frame is opened.

- German Localisation for the GUI Options, in addition to the Drop Down boxes and Instance/Boss names that were already German localised

- 95% Localised for Traditional Chinese (Thanks to Arith Hsu)

- Compatible with AtlasLoot v1.18.00 and later (New Buttons in the Miscallaneous Tab of the AlphaMap Options frame)

- Added the ability to change the Position, Scale and Opacity of the Original Blizzard WorldMap Frame. Check the option to "Allow changes to the Blizzard Map" under the Miscallaneous Tab. This is just an extra feature as I prefer having some control over the original WorldMap rather than it being permanently Full Screen.
The original WorldMap Frame can be moved anywhere on screen and will remember where it was left as long as the "Allow changes to the Blizzard Map" option is checked.
The original Blizzard WorldMap's scale and alpha can ONLY be changed when the "Check to change the Blizzard Map" option is checked - when checked, then the other AlphaMap options will be hidden/disabled, and only the scale and alpha setting will be usable.
PLEASE NOTE :
1.) To Reset the games WorldMap, simply Un-check the "Allow changes to Blizzard Map" checkbox - Un-Checking this option will ReLoad your User Interface. This will cause a significant pause, and is similar to re-logging in to the game world (without having to log out first).
2.) Some other AddOns may not like it if you change the scale of Blizzard's original WorldMap Frame. I have tested with Titan Coordinates, and Gatherer, and MapNotes(Continued), which all seem fine, but if you have an AddOn that won't display or play nicely with a personalised WorldMapFrame, then you just might not be able to use this option. (Or it might only be a very small change for the author of the other AddOn to make it compatible with a scaled WorldMap)
3.) If you have MetaMap installed, then you don't really need this option, so I don't want to see any reports of errors due to this option being used at the same time as MetaMap - just leave the option unchecked.

- Two changes that mean the on-map Opacity Slider can now be moved anywhere on the AlphaMap and it will remember where you anchored it :
1.) Firstly, the slider's value can't be changed while you moving it.
2.) Secondly, if you 'drop' the opacity slider anywhere on the AlphaMap, then it will re-anchor itself in that position and remember where you left it. If you 'drop' it anywhere else on screen, then it will no longer move when the AlphaMap is moved, and it will remember where you left it on your game screen instead.

- Control of the on-map Opacity Slider is no longer global, and its settings can now be saved separately on a per map basis. i.e. you can have the slider showing for world map views, but hidden, or in a different anchor position, on Instance/Battleground/Raid maps.

- Improved the Minimap button as HotSpot functionality. If you use the Minimap button as a Hotspot to temporarily open the map, then clicking on the Minimap button will make sure the AlphaMap stays open when your mouse leaves the Hotspot.

- When in Mouse Interaction mode and the Control key is pressed, the on-map Opacity Slider can be moved (and can not be used to alter the alpha setting of the map)

- Mouse Interaction mode for changing the map you are looking at should now work even when background map updating is 'Paused'

- Added a 'Mute' option which stops the page turning sound when the map opens/closes, or you change pages on the Map Key. (You will still hear clicks when using the Drop Down boxes to select a map however)

- Users who don't wish to use AlphaMap's Instance/Battelground/Raid maps, can now remove them from the "\AlphaMap\Maps" folder, and they will no longer be available to view within the game. So if you want the BattleGround maps, but not the Instance maps, then delete the .blp files you don't want, or move them to the "\AlphaMap\Maps\UnusedMaps" folder.

- Fix to make sure that the AtlasLoot frame closes if open when you change the map you are viewing

- Fixed a small problem where the Map Key 'seems' to disappear. This could happen if you were viewing the second page of key notes for one instance style map, and then try to view another instance style map that has only 1 page of key notes.

- Fixed a small problem when displaying Gatherer icons with 'missing' user configuration details

- Reworked the fix to prevent the AlphaMap displaying automatically when loggin-in / changing zones. The Map should display when you select "Attached to Map" as the docking position for the drop down boxes if the map was closed before the option was checked.

- While in Flight, the 'Pause' button will prevent zone changes from updating the AlphaMap. Changing zone at any other time will still update the AlphaMap even when paused. (Pausing was really only provided to prevent map updates that AlphaMap doesn't recognise as 'valid', and changing zone is normally treated as a valid trigger for an update to the AlphaMap)

- Fixed the position of the 'Secondary' EastFrostwolf Tower Icon on the Alterac Valley Map, and a couple of other small database updates

- Made compatible with the latest version of MetaMapFWM

- Changed the default position of the Map Selector drop down boxes to be nearer the top of the screen if 'Free Floating' and not yet manually placed

- Some small changes for compatibility with Cosmos versions of MapNotes and Atlas

- Changed the default behaviour to not close the AlphaMap when combat starts





Changes in v2.12.11100 from v2.11.11100
---------------------------------------

- Fixed the issue that would cause the AlphaMap to display when first logging in, or changing zone



Changes in v2.11.11100 from v2.10.11100
---------------------------------------

- Made compatible with the latest version of AtlasLoot

- Small adjustment to the 'Mouse Interaction' mode to prevent problems in Instances/Battlegrounds. Note that the on-map clicking to zoom between World Map areas won't work while in Instances/Battlegrounds even if you have manually selected a World Map from the drop down boxes. Only the drop down boxes can be used in these 'special' areas.

- Small bug fix to the new 'Escape' key functionality to make it global.  Note that some settings are always global for all your maps and are not saved on a per map basis. e.g. the Minimap Button position.  See the section on Global Variables in the notes.

- Fixed the error connected to the Map Noting OptionsSet



Changes in v2.10.11100 from v2.05.11100
---------------------------------------

- NEW FEATURE : World Map replacement mode via new option on the Miscallaneous Tab to allow Mouse interaction with AlphaMap. When checked, then the user can <CTRL-Click> on AlphaMap to zoom in and out of map zones just as they do on the World Map. CTRL-Right click to zoom out, and CTRL-Left click to zoom in on a continent/zone.  If the Ctrl key is not pressed, then the AlphaMap is still completely invisible to the mouse as per standard functionality, and you can still select mobs/players through the map.

- NEW FEATURE : Added an Option on the Miscallaneous Tab allowing the user to close the AlphaMap with the 'Escape' key (Disabled by default)

- Fixed a small compatibility issue with TinyTip AddOn where mousing over the MiniMap icon would reset the tooltip scale

- Improved compatibility with other language clients. Also included limited localisation for French and German clients meaning that AlphaMap should now update automatically to the correct map when entering/exiting Instances and BattleGrounds, and the names of Instances and some mobs will be in the local client language



Changes in v2.05.11100 from v2.01.11100
---------------------------------------

- NEW FEATURE : Added a new World Map Viewing mode, controlled from a new check box on the Miscallaneous Tab of the Options Frame
Compact mode shows a trimmed version of the World Map displaying only explorable areas in the current map.
A side affect of this means you won't see areas you haven't discovered yet. If you would like to use Compact viewing mode, but STILL be able to see ALL areas in the current Map, you will need to install 'MozzFullWorldMap (Fans Update)'

- Added a key binding so that you can cycle between the Standard and Compact viewing modes of the World Map

- Added a map for Maraudon Dungeon (outside of Instance)

- Fixed an issue where the Map Selector drop down boxes were not remembering where they were anchored

- Fixed a bug message that can be displayed in Warsong Gulch while using the normal World Map view

- Made AlphaMap more compatible with GuildMap, ensuring that the drop down boxes can be used to display any map while the Pause map updating feature is activated (Previously, GuildMap would still interfere with the drop down boxes while map updates were paused.)



Changes in v2.01.11100 from v2.00.11100
---------------------------------------

- Stopped the AtlasLoot frame from appearing transparent if the AlphaMap frame alpha setting is changed.
- If you have the "Use Instance map in Battlegrounds" check box checked, then AlphaMap will autoshow the Battleground map when you enter any Battleground.
- Improved the Pause button functionality. While paused you can still manually show any map you want. Also, while paused, the map will be updated when you change map areas,  but other background events that reset the map should still be ignored.  Again, please note this is just a small helper function if you have other AddOns that are resetting your map, and I don't think most people will need it.  It also has limitations in that new notes/icons that are added to/deleted from the World Map will not be shown in AlphaMap until you manually refresh the display by 'unpausing' it; Battleground objectives won't be up to date while the map is paused either. So, please no unnecessary complaints about 'quirky' behaviour while the map is paused - this is not the normal mode of use ;)


AlphaMap Fan's Update v2.00.11100 - Major Release
-------------------------------------------------

- ADDED THE ABILITY TO DISPLAY INSTANCE MAPS. AlphaMap will automatically display the map of the Insance you are in when opened. All maps come with notes, and these are compatible with the new version of AtlasLoot(Atlas not required if you want to save memory).

- ADDED THE ABILITY TO DISPLAY MiniMap Versions of Battleground maps which can display the battleground objectives, flags, and team mates.
-  Warsong map includes special Flag icons which take note of the Flag carrrier's name. Click on the flag to target the carrier.
-  Arathi basin map includes a numeric display next to your Faction's spawn entrance displaying how many bases you need to win. Also, when this number changes, a message is displayed in your default chat window. If you have SCT installed, then you will see this message in the center of your screen before it fades.

- ADDED THE ABILITY TO DISPLAY exterior Dungeon/Raid maps showing player locations. e.g. the Gnomeregan dungeon before entering the instance, and zoomed minimap views of Lord Kazzak, and Emerald Dragon World Boss locations.

- The notes on the Instance/Battleground/Raid maps can be left clicked :
-   If the note leads to another map, then that map will be displayed. e.g. links between LBRS/UBRS/BWL,  DM maps, etc.
-   If the note has Loot noted for it, a small gold coin will be displayed next to it, and left clicking will show the AtlasLoot frame
- Right clicking a note can display a menu with several possible options
-   You can leave a particular map note highlighted
-   In Battlegrounds, there are special options for reporting the number of enemy incoming on a base, or the location of a flag carrier
-   If you have NotesUNeed installed, then you can open a NotesUNeed note, or Send the NotesUNeed note text to your Raid/Party/Guild. i.e. store the tactics for a particular boss in a NotesUNeed note, and then send those tactics to your Raid via the right click menu for that boss on the AlphaMap.

- ADDED new Map Selector frame so that you can view any World Map Zone, Battleground or Instance in AlphaMap no matter where you are. This Map Selector frame can be attached to the AlphaMap, docked to the Options frame, or moved anywhere on screen and locked in place.

- The new Map Selector frame has a 'Hot Spot' which you can program to do different things when ever you place your mouse over it. So for example, you can use it as a quick way to display the AlphaMap and then close it again by moving your mouse away. Or, you can play with the AlphaMap displayed but without any notes and being very transparent, and use the Hot Spot to make the AlphaMap opaque and display all the notes until you move your mouse away again.

- Added lots of options so that you can customise the way that AlphaMap displays Instances/BattleGround/Raid maps, such as whether or not to display notes, a map key, tooltips, note and map backgrounds, and the colour of the note and map backgrounds

- IMPORTANT : By default, AlphaMap will save your display settings differently for viewing World Map zones, Battlegrounds, and Instance maps.
So for example, you can display the World map as a transparent AlphaMap in the center of the screen;
But Instance maps can be displayed with a smaller fully opaque AlphaMap in the upper right of the screen;
And Battleground maps could be displayed with a differently scaled map without the map key showing.
And because the settings are saved separately you don't have to manually change your settings each time you exit/enter an Instance or Battleground.
Or you can change this option in the settings and allow every Instance to save its settings independantly of other Instance maps - For example you might find it useful to set the scale of the Ragefire Chasm map to 40%, but want the Zul'farak map to be 60%...
Exterior raid maps like Gnomeregan Exterior, and Lord Kazzak all save their settings separately from each other, and from Instance and Battleground maps.
Basically, you should set up a particular map the way you like it once, and then that is the way it will display in the future, and you don't have to keep adjusting the map display every time you go in to a BattleGround/Instance/Raid map, and again when you exit.

- New Key binding that will quickly show/hide all the 'enabled' on screen AlphaMap notes and icons.

- Icons displayed on the AlphaMap no longer shrink out of existance when you reduce the map scale. They will only shrink to a minimum size, allowing you to have a really small AlphaMap with notes and player markers that are still visible and useful. Similarly, they don't grow beyond a certain maximum size if you scale the map up either.

- Tooltips displayed over the AlphaMap won't shrink out of existance when you reduce the map scale; And are now compatible with the display of NotesUNeed tooltips (Display of NotesUNeed merged map notes will require a NotesUNeed update)

- AlphaMap can now be moved via bars at the top AND bottom of the map. These bars are highlighted when the mouse is over them, but are not highlighted and become 'mouse transparent' if the AlphaMap position is locked.

- FIXED THE MINIMAP BLINKING ISSUE. This fix replaces the way in which the player arrow is shown on the AlphaMap, and arrows pointing toward Party members are no longer displayed on the AlphaMap.
- Added the option to display the old style player arrow, if minimap blinking was not an issue for you. The new player arrow is the default.

- The new Map Selector frame has a 'Pause' map updates button. This should not normally be needed, but occasionally, you may wish to stop background events from changing the map you are viewing. (Especially if you have other AddOns installed that access Map functions). When 'paused' then you won't be able to change the World Map area being viewed in AlphaMap. This is only intended for temporary use, and if map updates are paused when you move from one World Map area to another, then Player icons may appear on the incorrect map.

- Various small tweaks to the code


NOTE:
1.) The Hot Spot function can not make the AlphaMap opaque if the Options frame is open.





AlphaMap Fan's Update v1.60.11000
---------------------------------

- Added support for FlightMap
- Added a checkbox control for displaying the minimap button, and setting is saved between sessions
- Fixed an graphical glitch displaying MetaMapNotes
- The Auto-ReOpen AlphaMap after combat option is now off by default. Also made sure it doesn't reopen after manually closing.



AlphaMap Fan's Update v1.52.11000
---------------------------------

- Fixed the PartySpotter compatibility issue



AlphaMap Fan's Update v1.51.11000
---------------------------------

- Options GUI will now show/hide the Opacity Slider
- Stopped AlphaMap appearing after combat unless it was definitely open before combat
- Fixed the text for the Option to re-open AlphaMap after combat




AlphaMap Fan's Update v1.50.11000
---------------------------------

- Added a Minimap button. Left-click to toggle AlphaMap. Right-click to toggle Options

- Added a new Frame for graphically setting AlphaMap Options

- Added compatibility for MetaMap Notes : controlled via the existing MapNoting Options

- Added compatibility for CTMapMod Notes : controlled via the existing MapNoting Options (This includes the CTMapMod herb/ore notes)

- Gatherer filters now filter what displays on the AlphaMap

- Added an option to Re-open the AlphaMap automatically when Combat finishes

- MozzFullWorldMap Support.  AlphaMap offers 2 tiers of support for MozzFullWorldMap :
1.) AlphaMap now functions correctly with current version of "MozzFullWorldMap 1.10 + configurable!" : i.e. this simply fixes an issue caused by MFW that would prevent AlphaMap from working correctly;  But does NOT allow you to see Undiscovered areas in AlphaMap.
2.) Support for future release of MFW / MetaMapFWM : I have made some requests to the authors of both "MozzFullWorldMap 1.10 + configurable!", and "MetaMapFWM" to make some small changes in their mods which will allow access to their functionality from other AddOns.  Support to use this functionality is built in to this version of AlphaMap, and would allow users to toggle the display of undiscovered areas. However, this functionality will not be available until the next releases of MozzFullWorldMap / MetaMapFWM,  and only if those authors do update their AddOns to be compatible.  If these negotiations fail to bear fruit, then I will consider importing (repeating) all the MFW code in to AlphaMap itself in a future release.

- Ping !   When you open AlphaMap, your characters location will be Pinged, to highlight your location when you first open it.  As per WorldMap functionality

- To fix an issue with blank tooltips when mousing over location/gatherer/player icons on the Minimap, the Player/Minimap icons will disappear from the AlphaMap when you Mouse Over the Minimap Cluster.  (However, 'local' party icons on the Minimap can still blink when your mouse is not over the Minimap, and AlphaMap is visible. This is an issue that is probably not possible for me to fix, as the Minimap drawing/updating seems to be an internal WoW function. The only alternative I have is to stop displaying the Minimap icons on the AlphaMap - player location could still be flagged, but I don't believe it would be possible for you see a directional arrow indicating your posistion and heading, and the arrows indicating the direction of fellow party members would also not be available.  Let me know what you think.)

- Performance improvements. Basically, I felt that updating the map every frame was overkill. For me, the map was updating roughly 30 times per second. This version of AlphaMap will only update player icons roughly 10 times a second, and only update MapNotes, and other more static icons, roughly 2 times a second. Let me know if anyone finds any major issues with this approach.




AlphaMap Fan's Update v1.03.11000
---------------------------------

- toc Update for v1.10 of WoW



AlphaMap Fan's Update v1.03.1900
--------------------------------

- Centered the AlphaMap, and made sure Slider appears on the map when using /am reset
- Completely discarded the Old Saved Variables method which may have been causing some conflicts



AlphaMap Fan's Update v1.02.1900
--------------------------------

- Moved strings to localization.lua (others are welcome to provide translations!)
- Added some functions for colored feedback.
- Added /am reset, /am enable, /am disable slash commands



AlphaMap Fan's Update v1.01.1900
--------------------------------

- Updated toc
- Adjusted the Map Scaling function that was preventing the Map from displaying



AlphaMap Fan's Update v1.01.1800
--------------------------------

- Fixed the Corpse Icon (Thanks to Xtro)



AlphaMap Fan's Update v1.00.1800
--------------------------------

- All team mates of your faction are now visible in BattleGrounds, whether or not they are in your Party/Raid
- Improved the Units Tooltips code, to display a list of player names under the mouse as per the tooltips on other maps
- Added BattleGround Flag/Objective statuses
- Has full support for the PartySpotter AddOn







Slash Commands are as follows:
------------------------------

/alphamap or /am:

/am			- displays the options
/am tog			- toggle display of alphamap
/am ?  <OR> /am help	- displays this list of slash commands
/am enable      	- Enable (re-enable) AlphaMap
/am disable     	- Disable AlphaMap
/am reset       	- Reset all config options to defaults
/am raid 		- show Raid Pins
/am ptips 		- show party tooltips
/am mntips 		- show MapNotes tips
/am gtips  		- show Gatherer tips
/am mngtips 		- show MapNotes Gathering tips
/am moveslider 		- toggle movement of the slider
/am slider  		- toggle display of slider
/am gatherer		- toggle support for Gatherer
/am mapnotes		- toggle support for MapNotes
/am gathering		- toggle support for MapNotes Gathering
/am combat		- toggle "Autoclose on Combat"
/am wmclose		- toggle "Autoclose on WorldMap close"
/am lock		- toggle movement of the AlphaMap
/am scale <value>	- set the alphamap window scale
/am alpha <value>	- set the transparency of alphamap in a range from 0.0 - 1.0
/am minimap		- toggles the AlphaMap button on the Minimap Cluster



