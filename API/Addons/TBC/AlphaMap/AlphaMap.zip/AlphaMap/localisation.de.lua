--------------------------------------------------------------------------
-- localization.lua <German>
-- Translation by : Eike Hanus, StarDust
-- Last Update : 8/23/2006
--------------------------------------------------------------------------

-- Ä: C3 84 - \195\132 - �
-- Ö: C3 96 - \195\150 - �
-- Ü: C3 9C - \195\156 - �
-- ß: C3 9F - \195\159 - �
-- ä: C3 A4 - \195\164 - �
-- ö: C3 B6 - \195\182 - �
-- ü: C3 BC - \195\188 - �

if ( GetLocale() == "deDE" ) then

	SLASH_ALPHAMAPSLASH1		= "/AlphaMap";
	SLASH_ALPHAMAPSLASH2		= "/am";

	AM_SLASH_LOAD_HELP_USAGE	= "Alpha Map";

	BINDING_HEADER_ALPHAMAP		= "AlphaMap Tastenbelegung";
	BINDING_NAME_TOGGLEALPHAMAP	= "AlphaMap anzeigen/verbergen";
	BINDING_NAME_INCREMENTALPHAMAP 	= "Verringere AlphaMap Transparenz";
	BINDING_NAME_DECREMENTALPHAMAP 	= "Erh\195\182he AlphaMap Transparenz";
	BINDING_NAME_CLEARVIEWALPHAMAP	= "Zeige/Verstecke alle Notizen/Icons";
	BINDING_NAME_CYCLEWMMODE	= "Weltkartenmodi durchschalten";
	BINDING_NAME_HOT_SPOT		= "Hot Spot";

	--Colored State values
	ALPHA_MAP_GREEN_ENABLED		= "|c0000FF00Aktiviert|r";
	ALPHA_MAP_RED_DISABLED		= "|c00FF0000Deaktiviert|r";

	--Slash Help
	AM_SLASH_HELP_USAGE		= "AlphaMap Benutzung: /alphamap oder /am:";
	AM_SLASH_HELP_ENABLE		= "/am enable - AlphaMap aktivieren / re-aktivieren";
	AM_SLASH_HELP_DISABLE		= "/am disable - AlphaMap deaktivieren";
	AM_SLASH_HELP_RESET		= "/am reset - AlphaMap Optionen auf Standard zur\195\188cksetzen";
	AM_SLASH_HELP_RAID		= "/am raid - Schlachtzug Pins anzeigen";
	AM_SLASH_HELP_PTIPS		= "/am ptips - Gruppen-Tooltipps anzeigen";
	AM_SLASH_HELP_MNTIPS		= "/am mntips - MapNotes Tipps anzeigen";
	AM_SLASH_HELP_GTIPS		= "/am gtips - Gatherer Tipps anzeigen";
	AM_SLASH_HELP_MNGTIPS		= "/am mngtips - MapNotes Gathering Tipps anzeigen";
	AM_SLASH_HELP_MOVESLIDER	= "/am moveslider - Verschiebung der Reglers wechseln";
	AM_SLASH_HELP_SLIDER		= "/am slider - Anzeige des Regles wechseln";
	AM_SLASH_HELP_GATHERER		= "/am gatherer - Unterst\195\188tzung f\195\188r Gatherer wechseln";
	AM_SLASH_HELP_MAPNOTES		= "/am mapnotes - Unterst\195\188tzung f\195\188r MapNotes wechseln";
	AM_SLASH_HELP_GATHERING		= "/am gathering - Unterst\195\188tzung f\195\188r MapNotes Gathering wechseln";
	AM_SLASH_HELP_AUTOCLOSE		= "/am combat - Automatisches Schlie\195\159en im Kampf wechseln";
	AM_SLASH_HELP_AUTOOPEN		= "/am reopen - Automatisches wieder \195\150ffnen nach Kampf wechseln";
	AM_SLASH_HELP_WMCLOSE		= "/am wmclose - Automatisches Schlie\195\159en wenn Weltkarte geschlossen wechseln";
	AM_SLASH_HELP_LOCK		= "/am lock - Verschiebung der AlphaMap wechseln";
	AM_SLASH_HELP_SCALE		= "/am scale |c0000AA00<value>|r - legt die Skalierung der AlphaMap fest (Bereich 0.0 - 1.0)";
	AM_SLASH_HELP_TOG		= "|c00FF0000/am tog  - Anzeige der AlphaMap wechseln|r";
	AM_SLASH_HELP_ALPHA		= "/am alpha |c0000AA00<value>|r - legt die Transparenz der AlphaMap fest (Bereich 0.0 - 1.0)";
	AM_SLASH_HELP_MINIMAP		= "/am minimap - Anzeige des Minimap Buttons wechseln";
	AM_SLASH_HELP_HELP		= "/am help  <ODER>  /am ?  - Liste der AlphaMap Chatbefehle ausgeben";

	ALPHA_MAP_LOAD_CONFIRM		= "|c00A335EDAlphaMap |c0000FF00v."..ALPHA_MAP_VERSION.." |c00A335ED wurde geladen - Gib "..SLASH_ALPHAMAPSLASH1.." oder "..SLASH_ALPHAMAPSLASH2.." ein um die Optionen anzuzeigen.|r";

	ALPHA_MAP_ENABLED		= "|c0000BFFFAlphaMap ist jetzt "..ALPHA_MAP_GREEN_ENABLED;
	ALPHA_MAP_DISABLED		= "|c0000BFFFAlphaMap ist jetzt "..ALPHA_MAP_RED_DISABLED;

	ALPHA_MAP_UI_LOCKED		= "AlphaMap: Benutzerinterface |c00FF0000Gesperrt|r.";
	ALPHA_MAP_UI_UNLOCKED		= "AlphaMap: Benutzerinterface |c0000FF00Offen|r.";
	ALPHA_MAP_UI_LOCK_HELP		= "Wenn diese Option aktiviert ist, wird AlphaMap an der momentanen Position fixiert und kann nicht mehr verschoben werden.";

	ALPHA_MAP_DISABLED_HINT		= "Hint: AlphaMap is "..ALPHA_MAP_RED_DISABLED..".  Type |C0000AA00'/am Enable'|R to re-enable.";

	ALPHA_MAP_CONFIG_SLIDER_STATE   = "AlphaMap: Regler Verschiebung ";
	ALPHA_MAP_CONFIG_COMBAT_STATE   = "AlphaMap: Auto-Schlie\195\159en im Kampf ";
	ALPHA_MAP_CONFIG_REOPEN_STATE	= "AlphaMap: Wieder \195\150ffnen nach Kampf ";
	ALPHA_MAP_CONFIG_RAID_STATE     = "AlphaMap: Schlachtzug Pins ";
	ALPHA_MAP_CONFIG_PTIPS_STATE    = "AlphaMap: Gruppe/Schlachtzug Tooltipps ";
	ALPHA_MAP_CONFIG_MNTIPS_STATE   = "AlphaMap: MapNotes ToolTips ";
	ALPHA_MAP_CONFIG_MNGTIPS_STATE  = "AlphaMap: MapNotes Gathering Tooltipps ";
	ALPHA_MAP_CONFIG_GTIPS_STATE    = "AlphaMap: Gatherer ToolTips ";
	ALPHA_MAP_CONFIG_WMCLOSE_STATE  = "AlphaMap: AlphaMap mit Weltkarte schlie\195\159en ";
	ALPHA_MAP_CONFIG_GATHERING_STATE= "AlphaMap: MapNotes Gathering Unterst\195\188tzung ";
	ALPHA_MAP_CONFIG_GATHERER_STATE = "AlphaMap: Gatherer Unterst\195\188tzung ";
	ALPHA_MAP_CONFIG_MAPNOTES_STATE = "AlphaMap: MapNotes Unterst\195\188tzung ";

	AM_OPTIONS			= "Optionen";
	AM_OPTIONS_TITLE		= "AlphaMap "..AM_OPTIONS;
	AM_OPTIONS_RESET		= "R\195\188cksetzen";
	AM_OPTIONS_CLOSE		= "Schlie\195\159en";
	AM_OPTIONS_MAPNOTES		= "MapNotes verwenden";
	AM_OPTIONS_MAPNOTES_TOOLTIPS	= "Tooltipps anzeigen";
	AM_OPTIONS_MAPNOTESG		= "MapNotes Gatherer Icons anzeigen";
	AM_OPTIONS_MAPNOTESG_TOOLTIPS 	= "Tooltipps anzeigen";
	AM_OPTIONS_GATHERER		= "Gatherer Icons anzeigen";
	AM_OPTIONS_GATHERER_TOOLTIPS	= "Tooltipps anzeigen";
	AM_OPTIONS_PARTY_TOOLTIPS	= "Gruppen Tooltipps anzeigen";
	AM_OPTIONS_RAID_PINS		= "Schlachtzug Pins anzeigen";
	AM_OPTIONS_SLIDER		= "Alpha-Slider auf Karten einblenden";
	AM_OPTIONS_SLIDER_MOVE		= "Alpha-Slider verschiebbar";
	AM_OPTIONS_AUTOCLOSE_COMBAT	= "Karte bei Kampfbeginn schlie\195\159en";
	AM_OPTIONS_AUTOOPEN_COMBAT	= "Karte nach Kampfende \195\182ffnen";
	AM_OPTIONS_AUTOCLOSE_WORLDMAP	= "AlphaMap mit Weltkarte schlie\195\159en";
	AM_OPTIONS_ANGLESLIDER		= "Minimap Winkel : ";
	AM_OPTIONS_RADIUSLIDER		= "Minimap Radius : ";
	AM_OPTIONS_ALPHASLIDER		= "Karten-Transparenz : ";
	AM_OPTIONS_SCALESLIDER		= "Karten-Skalierung : ";
	AM_OPTIONS_MAP_LOCK		= "AlphaMap Position fixieren";
	AM_OPTIONS_MINIMAP		= "Minimap-Button anzeigen";
	AM_OPTIONS_CLEARVIEW_OFF	= "Alle Icons verstecken";
	AM_OPTIONS_CLEARVIEW_ON		= "|c00FF0000Derzeit sind alle Icons ausgeblendet|r";
	AM_OPTIONS_LEGACYPLAYER		= "Spieler-Icon im WoW-Stil anzeigen";
	AM_OPTIONS_ZONE_SELECTOR	= "Zeige Kartenselektor";
	AM_OPTIONS_GENERAL		= "Allgemein";
	AM_OPTIONS_GENERAL_CHAT		= "Allgemeiner Chat";
	AM_OPTIONS_DUNGEON		= "Instanzen";
	AM_OPTIONS_MAPS			= "Kartenselektor";
	AM_OPTIONS_ADDONS		= "Weltkarten Notizen & Icons :";
	AM_OPTIONS_MISC			= "Interne AddOn Optionen :";
	AM_OPTIONS_DUNGEON_NOTES	= "Notiz Optionen :";
	AM_OPTIONS_DUNGEON_FRAMES	= "Zusatzinformationen :";
	AM_OPTIONS_DM_NOTES		= "Notizen anzeigen";
	AM_OPTIONS_DM_NOTES_TOOLTIPS	= "Tooltipps anzeigen";
	AM_OPTIONS_DM_NOTES_BCKGRND	= "Notiz-Hintergrund anzeigen";
	AM_OPTIONS_DM_NBG_SET		= "Hintergrundfarbe w\195\164hlen";
	AM_OPTIONS_DM_HEADER		= "Kopfzeilen Information anzeigen";
	AM_OPTIONS_DM_EXTRA		= "Fu\195\159zeilen Information anzeigen";
	AM_OPTIONS_DM_KEY		= "Kartenlegende anzeigen";
	AM_OPTIONS_DM_KEY_TOOLTIPS	= "Tooltipps anzeigen";
	AM_OPTIONS_RESTORE		= "Anwenden";
	AM_MISC				= "Verschiedenes";
	AM_OPTIONS_DM_MISC		= AM_MISC.." : ";
	AM_OPTIONS_DM_MAP_BCKGRND	= "Karten-Hintergrund anzeigen";
	AM_OPTIONS_DM_MBG_SET		= "Hintergrundfarbe w\195\164hlen";
	AM_OPTIONS_DM_TEXT_BCKGRND	= "Text-Hintergrund anzeigen";
	AM_OPTIONS_DM_TEXTBG_SET	= "Hintergrundfarbe w\195\164hlen";
	AM_OPTIONS_MAP_BOXES		= "Position des AlphaMap Selektors :";
	AM_OPTIONS_UNDOCKED		= "AlphaMap Selektor ist : ";
	AM_OPTIONS_FREE			= "Frei Beweglich";
	AM_OPTIONS_FREE_LOCKED		= "(Fixiert)";
	AM_OPTIONS_MAPPED		= "Mit AlphaMap verbunden";
	AM_OPTIONS_DOCK_IT		= "Mit Optionsfenster verbunden";
	AM_OPTIONS_FREE_IT		= "Frei beweglich";
	AM_OPTIONS_MAP_IT		= "Mit AlphaMap verbunden";
	AM_OPTIONS_HOW_TO_MAP		= "Position auf der AlphaMap : ";
	AM_OPTIONS_MAP_LINK		= "an";
	AM_OPTIONS_HOTSPOT_BEHAVE	= "HotSpot Verhalten :";
	AM_OPTIONS_HOTSPOT_DISABLE	= "HotSpot Funktion verwenden";
	AM_OPTIONS_HOTSPOT_OPEN		= "AlphaMap \195\182ffnen falls geschlossen";
	AM_OPTIONS_HOTSPOT_OPACITY	= "Komplett undurchsichtige AlphaMap";
	AM_OPTIONS_HOTSPOT_WORLDI	= "Welt Icons/Notizen umschalten";
	AM_OPTIONS_HOTSPOT_DUNGI	= "Instanzen AlphaMap Notizen umschalten";
	AM_OPTIONS_HOTSPOT_NBG		= "Notiz Hintergrund umschalten";
	AM_OPTIONS_HOTSPOT_MBG		= "Karten Hintergrund umschalten";
	AM_OPTIONS_HOTSPOT_MINIMAP	= "Minimap Icon als HotSpot verwenden";
	AM_OPTIONS_HOTSPOT_INFO		= "Schl\195\188ssel/Kopf/Fu\195\159 umschalten";
	AM_OPTIONS_BG_USE_AM		= "Instanzkarten auf Schlachtfeldern zulassen";
	AM_OPTIONS_TYPE_SAVE_LABEL	= "Einstellungen f\195\188r alle %s :";
	AM_OPTIONS_TYPE_ALL		= "Einstellungen betreffen ALLE %s Karten";
	AM_OPTIONS_BG_MESSAGES		= "Schlachtfeld-Nachrichten versenden an :";
	AM_OPTIONS_RAID			= "Raid";
	AM_OPTIONS_PARTY		= "Gruppe";
	AM_OPTIONS_GUILD		= "Gilde";
	AM_OPTIONS_GROUP_DEFAULT	= "Gruppenabh\195\164ngig";
	AM_OPTIONS_NUN_AUTO		= "Auto-Sende NuN Notiz Einstellungen";
	AM_OPTIONS_NUN_FORMAT		= "Formatierte Notizen senden";
	AM_OPTIONS_NUN_MESSAGES		= "NuN Notizen automatisch versenden an : ";
	AM_OPTIONS_WMAP_MODES		= "Weltkarten Ansichtsmodi :";
	AM_OPTIONS_GMAP_MODES		= "Blizzard Karten-Einstellungen :";
	AM_OPTIONS_GMAP_ALLOW		= "\195\132nderungen der Blizzard Karten zulassen";
	AM_OPTIONS_GMAP_CHANGE		= "Aktivieren, um die Blizzard Karten zu ver\195\164ndern";
	AM_OPTIONS_WMAP_SMODE		= "Standard";
	AM_OPTIONS_WMAP_OMODE		= "Kompakt";
	AM_OPTIONS_WMAP_MINIMODE	= "Minimap Texturen";
	AM_OPTIONS_WMAP_ZMINIMODE	= "Gezoomte Minimap";
	AM_OPTIONS_WMOTHER		= "Einstellungen f\195\188r andere Karten : ";
	AM_OPTIONS_WM_ESCAPE		= "Schlie\195\159en mit <ESC> zulassen";
	AM_OPTIONS_WM_MOUSE		= "Mausinteraktion zulassen";
	AM_OPTIONS_MUTE			= "Stumm";
	AM_OPTIONS_COORDS		= "(x, y)";
	AM_OPTIONS_MAPS1		= "AlphaMap Karten 1";
	AM_OPTIONS_MAPS2		= "  ..... 2";
	AM_OPTIONS_HELP_TIPS		= "Hilfe Tooltips";

	AM_INSTANCE_TITLE_LOCATION	= "Region ";
	AM_INSTANCE_TITLE_LEVELS	= "Levelbereich ";
	AM_INSTANCE_TITLE_PLAYERS	= "Max. Spielerzahl ";
	AM_INSTANCE_CHESTS		= "Truhe ";
	AM_INSTANCE_STAIRS		= "Treppe ";
	AM_INSTANCE_ENTRANCES		= "Eingang ";
	AM_INSTANCE_EXITS		= "Ausgang ";
	AM_LEADSTO			= "Pfad...";
	AM_INSTANCE_PREREQS		= "Vorbedingung : ";
	AM_INSTANCE_GENERAL		= "Allgemeine Notizen : ";
	AM_RARE				= "(Selten)";
	AM_VARIES			= "(Variiert)";
	AM_WANDERS			= "(Patroliert)";
	AM_OPTIONAL			= "(Optional)";

	AM_NO_LIMIT			= "Keine Spielerbegrenzung";

	AM_MOB_LOOT 			= "Mob Loot";
	AM_RBOSS_DROP 			= "Zuf\195\164llige Boss Drops";
	AM_ENCHANTS			= "Verzauberungen";
	AM_CLASS_SETS			= "Klassen Sets";
	AM_TIER0_SET			= "Tier 0 Sets";
	AM_TIER1_SET			= "Tier 1 Sets";
	AM_TIER2_SET			= "Tier 2 Sets";
	AM_TIER3_SET			= "Tier 3 Sets";
	AM_TIER4_SET			= "Tier 4 Sets";
	AM_PVP_SET			= "PvP Sets";

	AM_PvP				= "PvP";

	AM_ANCHOR_POINT 	= {	{ Display = "Oben",			-- Localise
					  Command = "TOP" },					-- Do NOT Localise
					{ Display = "Oben Rechts",		-- Localise
					  Command = "TOPRIGHT" },				-- Do NOT Localise
					{ Display = "Rechts",			-- Localise
					  Command = "RIGHT" },					-- Do NOT Localise
					{ Display = "Unten Rechts",		-- Localise
					  Command = "BOTTOMRIGHT" },				-- Do NOT Localise
					{ Display = "Unten",			-- Localise
					  Command = "BOTTOM" },					-- Do NOT Localise
					{ Display = "Unten Links",		-- Localise
					  Command = "BOTTOMLEFT" },				-- Do NOT Localise
					{ Display = "Links",			-- Localise
					  Command = "LEFT" },					-- Do NOT Localise
					{ Display = "Oben Links",		-- Localise
					  Command = "TOPLEFT" }					-- Do NOT Localise
				};

	AM_BG_ONLY			= "Nur";
	AM_BG_ALL			= "Alle";
	AM_BG_BASE			= "Basis";
	AM_BG_BASES			= "Basen";
	AM_BG_REQUIRED		= "Erforderlich um zu gewinnen !";
	
	AM_EXTERIOR			= " Au\195\159erhalb";

	AM_RCMENU_INC			= " Inc ";		-- as in 5 inc Blacksmith   or  3 inc farm
	AM_RCMENU_ZERG			= "Zerg";		-- as in Zerg Inc Frostwolf GY
	AM_OK				= "OK";
	AM_RCMENU_HIGHLIGHT		= "Hervorheben";		-- as in leave this note highlighted on the map
	AM_RCMENU_NUN_AUTO		= "Notiz Automatisch Senden";	-- send the NotesUNeed note for the current map note to Raid/Party/...
	AM_RCMENU_NUN_MAN		= "Notiz Manuell Senden";
	AM_RCMENU_NUN_OPEN		= "Notiz \195\150ffnen";
	AM_RCMENU_AFLAG			= "Allianz Flagge ";
	AM_RCMENU_HFLAG			= "Horde Flagge ";
	AM_RCMENU_FLAGLOC		= {	"Unser Tunnel",
						"Unser Dach",
						"Westw\195\164rts",
						"Ostw\195\164rts",
						"In der Mitte",
						"Deren Tunnel",
						"Deren Dach",
						"Deren Flaggenraum",
						"Deren Friedhof"
					};

	AM_OPENING = "AQ Opening Quest Chain";

	AM_HORDE			= "Horde";
	--AM_PICKED			= { 	word = "picked",
		--				posWord = " by ",
		--				extraChars = 1 };

	-- Deutsch
	AM_PICKED			= {	word = "aufgenommen" };

	AM_NEUTRAL			= "Neutral";
	AM_FRIENDLY			= "Freundlich";
	AM_HONOURED			= "Wohlwollend";
	AM_REVERED			= "Respektvoll";
	AM_EXALTED			= "Ehrf\195\188rchtig";

	AM_CONFIG_SAVED			= "AlphaMap Einstellungen ge\195\164ndert f\195\188r : ";

	AM_CANCEL			= "Abbrechen";

	AM_CORPSE			= "Tot";
	AM_RESET_INSTANCE		= "R\195\188cksetzen";

	AM_UPDATE_WARNING	= AM_YELLOW.."AlphaMap|r\n\nMausinteraktion Modus (Karte Zoom) verwendet jetzt "..AM_GREEN.."<ALT>|r\nNICHT "..AM_RED.."<CONTROL>|r\n ";

	--------------------------------------------------------------------------------------------------------------------------------------
	-- TOOLTIPS															    --
	--------------------------------------------------------------------------------------------------------------------------------------

	AM_TT_MINIMAP_BUTTON	= "AlphaMap\nLinksklick \195\182ffnet AlphaMap.\nRechtsklick \195\182ffnet Optionen.";
	AM_TT_ALPHA_BUTTON1	= "AlphaMap";
	AM_TT_ALPHA_BUTTON2	= "Linksklick \195\182ffnet AlphaMap.\nRechtsklick \195\182ffnet Optionen.";
	AM_TT_PAUSE1		= "Update Pause";
	AM_TT_PAUSE2		= "Klicken um Kartenupdates zu verhindern und die aktuelle Karte zu \195\182ffnen/schlie\195\159en ohne die momentane Karte zur\195\188ckzusetzen. Kann auch verwendet werden, falls ein anderes AddOn im Konflikt mit AlphaMap steht und die angezeigte Karte st\195\164ndig auf die momentane zur\195\188cksetzt.";
	AM_TT_PLAY1		= "Update Starten";
	AM_TT_PLAY2		= "Klicken um wieder Kartenupdates durchzuf\195\188hren.";
	AM_TT_HOTSPOT1		= "HotSpot";
	AM_TT_HOTSPOT2		= "\195\132ndert die AlphaMap Ansicht, wenn der Mauszeiger \195\188ber das Icon bewegt wird. z.B. Karte oder Notizen/Icons anzeigen/verbergen oder die Karte komplett sichtbar machen. Siehe Abschnitt 'Kartenselektor' f\195\188r Optionen.\n(Bindung an ein Tastenk\195\188rzel m\195\182glich)";
	AM_TT_LOCK1		= "Kartenselektor fixieren";
	AM_TT_LOCK2		= "Wenn nicht aktiviert, wird der Kartenselektor (Drop-Down) in einem eigenen Fenster angezeigt, welches beliebig verschoben werden kann.";
	AM_TT_TAB1		= "Allgemeine Optionen";
	AM_TT_TAB2A		= "Spezifische Optionen, welche ausschlie\195\159lich f\195\188r Karten von AlphaMap selbst gelten";
	AM_TT_TAB2B		= "z.B. Hintergrund der Karten/Notizen/Text und welche Notizen/Extrainfos angezeigt werden sollen.\nHINWEIS: Betrifft nur Karten von AlphaMap und nicht die Zonen der Weltkarte.";
	AM_TT_TAB3A		= "Erweiterte Optionen, welche ausschlie\195\159lich f\195\188r Karten von AlphaMap selbst gelten";
	AM_TT_TAB3B		= "HINWEIS: Betrifft nur Karten von AlphaMap und nicht die Zonen der Weltkarte.";
	AM_TT_TAB4		= "Festlegen der Position des Kartenselektors sowie des Verhaltens vom HotSpot";
	AM_TT_TAB5		= "Sonstige Optionen und Integration in andere AddOns";
	AM_TT_MAPNOTES		= "MapNotes, CTMap_Mod Notes, MetaMapNotes und KartenNotizen(Cosmos) anzeigen.";
	AM_TT_RAID1		= "Wenn nicht aktiviert, werden nur die Pins der Gruppenmitglieder auf den Karten angezeigt.";
	AM_TT_RAID2		= "(auch wenn du dich in einer Schlachtzugsgruppe befindest)";
	AM_TT_CLEAR1		= "Alle oben angew\195\164hlten Icons/Notizen anzeigen oder verbergen. Siehe auch Tastenbelegung f\195\188r die selbe Funktionalit\195\164t.";
	AM_TT_CLEAR2		= "Schnelle M\195\182glichkeit um eine un\195\188bersichtliche Karte wieder \195\188bersichtlicher zu machen indem z.B. alle Icons und Notizen ausgeblendet und mittles des HotSpots wieder sichtbar gemacht werden.";
	AM_TT_SLIDER		= "Schieberegler f\195\188r die Transparenz der Karten auf der AlphaMap anzeigen.";
	AM_TT_SLIDERM1		= "Wenn aktiviert, kann der Schieberegler auf der AlphaMap verschoben werden.";
	AM_TT_SLIDERM2		= "Den Schieberegler aus der Karte 'heraus' ziehen um jenen frei zu stellen (kann auch mit der Maus verschoben werden, wenn die Strg-Taste im Maus-Interaktionsmodus gedr\195\188ckt wird).";
	AM_TT_ACLOSE1		= "AlphaMap automatisch schlie\195\159en, wenn du in einen Kampf eintrittst.";
	AM_TT_ACLOSE2		= "(hilfreich, wenn du z.B. beim Spielen die Karte immer anzeigst)";
	AM_TT_AOPEN		= "AlphaMap automatisch wieder \195\182ffnen, wenn du einen Kampf verl\195\164sst.";
	AM_TT_LEGACY1		= "Originale Icons f\195\188r die Anzeige der eigenen Position und jener von Gruppenmitgliedern verwenden.";
	AM_TT_LEGACY2		= "Das blinkende Minimap-Icon leidet eventuell darunter.";
	AM_TT_AM_NOTES1		= "AlphaMap's eigene Hinweise anzeigen.";
	AM_TT_AM_NOTES2		= "(sind NICHT die selben wie die KartenNotizen und k\195\182nnen nicht ver\195\164ndert werden)";
	AM_TT_ALL_INSTANCE1	= "Wenn nicht aktiviert, werden die Einstellungen f\195\188r jede Instanzkarte getrennt abgespeichert.";
	AM_TT_ALL_INSTANCE2	= "Wenn du z.B. einen dunklen Hintergrund f\195\188r die Karte von Zul'Farak m\195\182chtest aber einen hellen f\195\188r jene von Molten Core.\n\nWenn aktiviert, wird JEGLICHE Ver\195\164nderung der Einstellungen EINER Instanzkarte automatisch auf ALLE anderen selbigen \195\188bertragen.";
	AM_TT_KEY		= "Die Kartenlegende anzeigen.";
	AM_TT_ALL_BG1		= "Wenn nicht aktiviert, werden die Einstellungen f\195\188r jede Schlachtfeldkarte getrennt abgespeichert.";
	AM_TT_ALL_BG2		= "Wenn du z.B. die Karte vom Aratibecken mit einer h\195\182heren Skalierung anzeigen m\195\182chtest als jene der Warsongschlucht.\n\nWenn aktiviert, wird JEGLICHE Ver\195\164nderung der Einstellungen EINER Schlachgfeldkarte automatisch auf ALLE anderen selbigen \195\188bertragen.";
	AM_TT_ALL_NI1		= "Wenn nicht aktiviert, werden die Einstellungen f\195\188r jede nicht-Instanzkarte getrennt abgespeichert.";
	AM_TT_ALL_NI2		= "Wenn du z.B. die Kartenlegende von normalen Zonen nicht anzeigen m\195\182chtest, f\195\188r Karten der Weltbosse aber schon.\n\nWenn aktiviert, wird JEGLICHE Ver\195\164nderung der Einstellungen EINER nicht-Instanzkarte automatisch auf ALLE anderen selbigen \195\188bertragen.";
	AM_TT_MSG		= "Schlachtfeld Nachrichten senden an:";
	AM_TT_MSG_DFLT2		= " - deine Schlachtzugsgruppe, wenn du in einer warst BEVOR du das Schlachtfeld betreten hast\n - deine Gruppe, wenn du in einer warst BEVOR du das Schlachtfeld betreten hast\n - ansonsten an den Channel des Schlachtfeldes";
	AM_TT_MSG_PARTY2	= " - deine Gruppe, wenn du in einer Gruppe oder Schlachtzugsgruppe warst BEVOR du das Schlachtfeld betreten hast\n - ansonsten an den Channel des Schlachtfeldes";
	AM_TT_MSG_BG2		= " - an den Channel des Schlachtfeldes";
	AM_TT_AUTO_BG1		= "Macht die Schlachtfeldkarte von AlphaMap zur Standardkarte auf Schlachtfeldern.";
	AM_TT_AUTO_BG2		= "Wenn aktiviert, wird die Karte des Schlachtfeldes automatisch angezeigt sobald du ein Schlachtfeld betrittst.\n\nWenn nicht aktiviert, werden die normalen Blizzard-Karten auf Schlachtfeldern verwendet.\n(die Karte des Schlachtfeldes wird dann nicht automatisch angezeigt sobald du ein Schlachtfeld betrittst)";
	AM_TT_NUN_F1		= "Formatierte NotesUNeed Notizen an Mitspielern senden und zu deren Datenbank hinzuf\195\188gen, welche diese empfangen k\195\182nnen.";
	AM_TT_NUN_F2		= "(Wie auch immer, Mitspieler welche NotesUNeed nicht installiert haben sehen besondere formatierte Zeichen und nicht nur den Notiz-Text)";
	AM_TT_NUN		= "NotesUNeed Notizen senden an:";
	AM_TT_NUN_DFLT2		= " - deine Schlachtzugsgruppe, wenn du dich in einer befindest\n - deine Gruppe, wenn du dich in einer befindest\n - ansonsten werden die Notizen nur \195\188ber '/Say' ausgegeben\n\nBeachte, dass Schlachzugsgruppen/Gruppen-Nachrichten innerhalb von Schlachtfeldern nicht \nfunktionieren au\195\159er du warst in einer BEVOR du das Schlachtfeld betreten hast.";
	AM_TT_NUN_PARTY2	= " - deine Gruppe, wenn du dich in einer Gruppe oder Schlachtzugsgruppe befindest\n - ansonsten werden die Notizen nur \195\188ber '/Say' ausgegeben\n\nBeachte, dass Schlachzugsgruppen/Gruppen-Nachrichten innerhalb von Schlachtfeldern nicht \nfunktionieren au\195\159er du warst in einer BEVOR du das Schlachtfeld betreten hast.";
	AM_TT_NUN_GUILD2	= " - deine Gilde";
	AM_TT_MOUSE1		= "Der Maus-Interaktionsmodus erlaubt ein Strg-Klick auf den AlphaMap Karten.";
	AM_TT_MOUSE2		= "Normalerweise ist AlphaMap unsichtbar f\195\188r die Maus.\nIm Maus-Interaktionsmodus kann bei gedr\195\188ckter Strg-Taste die Maus \195\188ber die Weltkarte bewegt und somit die einzelnen Gebiete hervorgehoben und deren Name angezeigt werden (wie bei der normalen Blizzard Weltkarte auch). Dar\195\188berhinaus kann mittles Strg-Rechts-Klick und Strg-Links-Klick auf der Karte gezoomt werden.\n\nIm Maus-Interaktionsmodus kann der Schieberegler und die Koordinaten auch mittels Strg-Klick neu positioniert werden.";
	AM_TT_MUTE		= "Aktiviert/Deaktiviert das Abspielen eines Sounds wenn AlphaMap ge\195\182ffnet oder geschlossen wird.";
	AM_TT_XY		= "Zwischen der Anzeige der Koordinaten des Spielers und Mauszeigers wechseln.";
	AM_TT_STANDARD		= "Standardansicht - Weltkarten Zonen wie auf der originalen Blizzard Karte.";
	AM_TT_COMPACT1		= "Kompaktansicht - nur entdeckbare Gebiete in der momentanen Zone anzeigen.";
	AM_TT_COMPACT2		= "Hinweis: Noch NICHT entdeckte Gebiete werden nicht angezeigt au\195\159er das AddOn 'MozzFullWorldMap (Fan's Update)' ist installiert.";
	AM_TT_BLIZZ_ALLOW1	= "Wenn aktiviert, speichert AlphaMap jegliche \195\132nderungen an den Blizzard Karten (Transparenz, Position, Skalierung).";
	AM_TT_BLIZZ_ALLOW2	= "Wenn nicht aktiviert, werden die originalen Blizzard Karteneinstellungen wieder hergestellt.\nDies erfordert ein 'ReloadUI', wodurch das Spiel f�r einige Sekunden nicht mehr reagieren kann.";
	AM_TT_BLIZZ_CHANGE1	= "Wenn aktiviert, werden jegliche \195\132nderungen der Transparenz und Skalierung mittels unterer Schieberegler nur auf die originalen Blizzard Karten angewendet.";
	AM_TT_HELP_TIPS1	= "Hilfe Tooltips anzeigen/verbergen.";
	AM_TT_HELP_TIPS2	= "Beeinflusst nicht die Anzeige der Icon Tooltips auf den AlphaMap Karten.";


	--------------------------------------------------------------------------------------------------------------------------------------
	-- Everything below should be localised apart from the 'filename', 'lootid' entries which should NOT be changed                               --
	-- The first  'name'  field is used to equate with in game Zone name information to help determine when the player is in a specific --
	-- Instance, and must therefore be spelt IDENTICALLY to the names of the Instances as displayed by the WoW Client in other native   --
	-- frames.															    --
	--------------------------------------------------------------------------------------------------------------------------------------

	AM_TYP_WM			= "Weltkarte";
	AM_TYP_GM			= "Blizzard Karte";

	AM_TYP_INSTANCE		= "Instanzen";
	AM_TYP_BG			= "Schlachtfelder";
	AM_TYP_WORLDBOSSES	= "Schlachtzugbosse";
	AM_TYP_CAVES		= "H�hles";

end