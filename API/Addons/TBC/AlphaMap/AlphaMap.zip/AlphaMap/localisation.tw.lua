-- [[
-- AlphaMap v2.11.11100 Traditional Chinese Localization File
-- Initial Translated by: Arith Hsu (2006/07/21)
-- Maintained by: Arith Hsu
-- Last Updated: 2006/07/26
-- Comments:
--    2006/07/27 Arith: 翻譯這個插件的文字，工作量是很龐大的，特別是要去查詢各副本裡的 boss 名稱，還有一些對應的任務名稱和
--                      一些任務注意事項等。期望看到後續有人熱心維護這個翻譯，但是請尊重各個維護翻譯的人的辛勞，你可以把你
--                      的名字加在檔頭，但是請勿移除其他人的名字。
--                      使用簡體中文的朋友如果是拿這個正體中文檔案直接轉簡體，我也沒什麼意見，但是請一樣保留原翻譯者的記錄
--                      另外請注意，正體中文和簡體中文的翻譯還是有諸多的不一致，請自行修正。
-- Revision History:
--    7/26: Complete about 95% translations.
-- ]]

if ( GetLocale() == "zhTW" ) then

	SLASH_ALPHAMAPSLASH1 = "/AlphaMap";
	SLASH_ALPHAMAPSLASH2 = "/am";

	AM_SLASH_LOAD_HELP_USAGE	= "Alpha Map"

	BINDING_HEADER_ALPHAMAP		= "AlphaMap 按鍵設定";
	BINDING_NAME_TOGGLEALPHAMAP	= "顯示 AlphaMap";
	BINDING_NAME_INCREMENTALPHAMAP 	= "增加 AlphaMap 透明度";
	BINDING_NAME_DECREMENTALPHAMAP 	= "降低 AlphaMap 透明度";
	BINDING_NAME_CLEARVIEWALPHAMAP	= "顯示/隱藏所有的註記/圖示";
	BINDING_NAME_CYCLEWMMODE	= "循環切換世界地圖模式";
	BINDING_NAME_HOT_SPOT		= "熱點";

	--Colored State values
	ALPHA_MAP_GREEN_ENABLED = "|c0000FF00啟動|r";
	ALPHA_MAP_RED_DISABLED = "|c00FF0000取消|r";

	--Slash Help
	AM_SLASH_HELP_USAGE         = "AlphaMap 使用語法: /alphamap 或 /am:";
	AM_SLASH_HELP_ENABLE        = "/am enable - 開啟/重新開啟 AlphaMap";
	AM_SLASH_HELP_DISABLE       = "/am disable - 取消 AlphaMap";
	AM_SLASH_HELP_RESET         = "/am reset - 還原 AlphaMap 選項到預設值.";
	AM_SLASH_HELP_RAID          = "/am raid - 顯示團隊標示";
	AM_SLASH_HELP_PTIPS         = "/am ptips - 顯示隊伍提示";
	AM_SLASH_HELP_MNTIPS        = "/am mntips - 顯示地圖註記提示";
	AM_SLASH_HELP_GTIPS         = "/am gtips - 顯示採集提示";
	AM_SLASH_HELP_MNGTIPS       = "/am mngtips - 顯示地圖註記採集類提示";
	AM_SLASH_HELP_MOVESLIDER    = "/am moveslider - 打開移動滑動條";
	AM_SLASH_HELP_SLIDER        = "/am slider - 打開顯示滑動條";
	AM_SLASH_HELP_GATHERER      = "/am gatherer - 打開採集助手的支援";
	AM_SLASH_HELP_MAPNOTES      = "/am mapnotes - 打開地圖註記的支援";
	AM_SLASH_HELP_GATHERING     = "/am gathering - 打開地圖註記採集類的支援";
	AM_SLASH_HELP_AUTOCLOSE     = "/am combat - 啟動戰鬥時自動關閉";
	AM_SLASH_HELP_AUTOOPEN	    = "/am reopen - 啟動戰鬥結束後自動重新打開";
	AM_SLASH_HELP_WMCLOSE       = "/am wmclose - 啟動世界地圖關閉時自動關閉";
	AM_SLASH_HELP_LOCK          = "/am lock - 啟動 AlphaMap 的位置移動";
	AM_SLASH_HELP_SCALE         = "/am scale |c0000AA00<value>|r - 設定 Alphamap 視窗的比例 (範圍 0.0 - 1.0)";
	AM_SLASH_HELP_TOG           = "|c00FF0000/am tog  - 開啟 Alphamap 的顯示|r";
	AM_SLASH_HELP_ALPHA         = "/am alpha |c0000AA00<value>|r - 設定 Alphamap 的透明度 (範圍 0.0 - 1.0)";
	AM_SLASH_HELP_MINIMAP	    = "/am minimap - 開啟小地圖按鍵的顯示";
	AM_SLASH_HELP_HELP	    = "/am help  <OR>  /am ?  - 列出 AlphaMap 的所有命令語法";

	ALPHA_MAP_LOAD_CONFIRM = "|c00A335EDAlphaMap |c0000FF00v."..ALPHA_MAP_VERSION.." |c00A335ED 已經載入. - 輸入 "..SLASH_ALPHAMAPSLASH1.." 或 "..SLASH_ALPHAMAPSLASH2.." 以設定進階選項|r";

	ALPHA_MAP_ENABLED = "|c0000BFFFAlphaMap 現在已"..ALPHA_MAP_GREEN_ENABLED;
	ALPHA_MAP_DISABLED = "|c0000BFFFAlphaMap 現在已"..ALPHA_MAP_RED_DISABLED;

	ALPHA_MAP_UI_LOCKED = "AlphaMap: 使用者界面 |c00FF0000鎖定|r.";
	ALPHA_MAP_UI_UNLOCKED = "AlphaMap: 使用者界面 |c0000FF00解鎖|r.";
	ALPHA_MAP_UI_LOCK_HELP = "如果這個選項被勾選, AlphaMap 的顯示位置將會被鎖定並且不能被移動.";

	ALPHA_MAP_DISABLED_HINT = "提示: AlphaMap 已"..ALPHA_MAP_RED_DISABLED..".  輸入 |C0000AA00'/am Enable'|R 來重新啟動.";

	ALPHA_MAP_CONFIG_SLIDER_STATE       = "AlphaMap: 滑動條移動 ";
	ALPHA_MAP_CONFIG_COMBAT_STATE       = "AlphaMap: 戰鬥時自動關閉 ";
	ALPHA_MAP_CONFIG_REOPEN_STATE	    = "AlphaMap: 戰鬥後重新開啟 ";
	ALPHA_MAP_CONFIG_RAID_STATE         = "AlphaMap: 團隊圖示 ";
	ALPHA_MAP_CONFIG_PTIPS_STATE        = "AlphaMap: 小隊/團隊提示資訊 ";
	ALPHA_MAP_CONFIG_MNTIPS_STATE       = "AlphaMap: 地圖標記提示資訊 ";
	ALPHA_MAP_CONFIG_MNGTIPS_STATE      = "AlphaMap: 地圖標記採集類提示資訊 ";
	ALPHA_MAP_CONFIG_GTIPS_STATE        = "AlphaMap: 採集助手提示資訊 ";
	ALPHA_MAP_CONFIG_WMCLOSE_STATE      = "AlphaMap: 關閉世界地圖時關閉 ";
	ALPHA_MAP_CONFIG_GATHERING_STATE    = "AlphaMap: 支援地圖標記採集類";
	ALPHA_MAP_CONFIG_GATHERER_STATE     = "AlphaMap: 支持採集助手 ";
	ALPHA_MAP_CONFIG_MAPNOTES_STATE     = "AlphaMap: 支援地圖標記";

	AM_OPTIONS			= "選項";
	AM_OPTIONS_TITLE		= "AlphaMap "..AM_OPTIONS;
	AM_OPTIONS_RESET		= "重設";
	AM_OPTIONS_CLOSE		= "關閉";
	AM_OPTIONS_MAPNOTES		= "啟動地圖註記";
	AM_OPTIONS_MAPNOTES_TOOLTIPS	= "顯示地圖註記提示資訊";
	AM_OPTIONS_MAPNOTESG		= "啟動地圖註記採集類圖示";
	AM_OPTIONS_MAPNOTESG_TOOLTIPS 	= "顯示地圖註記採集類提示訊息";
	AM_OPTIONS_GATHERER		= "啟動採集助手圖示";
	AM_OPTIONS_GATHERER_TOOLTIPS	= "顯示採集助手提示資訊";
	AM_OPTIONS_PARTY_TOOLTIPS	= "顯示團隊提示資訊";
	AM_OPTIONS_RAID_PINS		= "啟動團隊圖示";
	AM_OPTIONS_SLIDER		= "在地圖上顯示透明度滑動條";
	AM_OPTIONS_SLIDER_MOVE		= "允許移動透明度滑動條";
	AM_OPTIONS_AUTOCLOSE_COMBAT	= "戰鬥開始時自動關閉";
	AM_OPTIONS_AUTOOPEN_COMBAT	= "戰鬥結束後自動打開";
	AM_OPTIONS_AUTOCLOSE_WORLDMAP	= "關閉世界地圖時自動關閉";
	AM_OPTIONS_ANGLESLIDER		= "小地圖角度: ";
	AM_OPTIONS_RADIUSLIDER		= "小地圖半徑: ";
	AM_OPTIONS_ALPHASLIDER		= "地圖透明度: ";
	AM_OPTIONS_SCALESLIDER		= "地圖大小: ";
	AM_OPTIONS_MAP_LOCK		= "鎖定 AlphaMap 位置";
	AM_OPTIONS_MINIMAP		= "顯示小地圖按鍵";
	AM_OPTIONS_CLEARVIEW_OFF	= "隱藏已啟動的圖示";
	AM_OPTIONS_CLEARVIEW_ON		= "|c00FF0000所有的圖示都已隱藏|r";
	AM_OPTIONS_LEGACYPLAYER		= "顯示傳統格式的玩家圖示";
	AM_OPTIONS_ZONE_SELECTOR	= "顯示地圖選擇器";
	AM_OPTIONS_GENERAL		= "一般";
	AM_OPTIONS_GENERAL_CHAT		= "一般對話";
	AM_OPTIONS_DUNGEON		= "地下城";
	AM_OPTIONS_MAPS			= "地圖選擇器";
	AM_OPTIONS_ADDONS		= "世界地圖註記和圖示: ";
	AM_OPTIONS_MISC			= "內部的插件選項: ";
	AM_OPTIONS_DUNGEON_NOTES	= "地下城註記選項: ";
	AM_OPTIONS_DUNGEON_FRAMES	= "地下城額外的資訊: ";
	AM_OPTIONS_DM_NOTES		= "顯示地下城註記";
	AM_OPTIONS_DM_NOTES_TOOLTIPS	= "顯示地下城註記的提示資訊";
	AM_OPTIONS_DM_NOTES_BCKGRND	= "顯示註記的背景";
	AM_OPTIONS_DM_NBG_SET		= "設定註記的背景顏色";
	AM_OPTIONS_DM_HEADER		= "顯示置頂資訊";
	AM_OPTIONS_DM_EXTRA		= "顯示註腳資訊";
	AM_OPTIONS_DM_KEY		= "顯示地圖鑰匙";
	AM_OPTIONS_DM_KEY_TOOLTIPS	= "顯示地圖要時提示資訊";
	AM_OPTIONS_RESTORE		= "套用";
	AM_MISC				= "雜項";
	AM_OPTIONS_DM_MISC		= AM_MISC.." : ";
	AM_OPTIONS_DM_MAP_BCKGRND	= "顯示地圖背景";
	AM_OPTIONS_DM_MBG_SET		= "設定地圖背景顏色";
	AM_OPTIONS_MAP_BOXES		= "AlphaMap 的位置調整:";
	AM_OPTIONS_UNDOCKED		= "AlphaMap 的位置調整現在已";
	AM_OPTIONS_FREE			= "自由浮動";
	AM_OPTIONS_FREE_LOCKED		= "(鎖定)";
	AM_OPTIONS_MAPPED			= "依附於 AlphaMap";
	AM_OPTIONS_DOCK_IT			= "與選項窗隔連結";
	AM_OPTIONS_FREE_IT			= "自由浮動";
	AM_OPTIONS_MAP_IT			= "依附於 AlphaMap";
	AM_OPTIONS_HOW_TO_MAP		= "AlphaMap 固定於: ";
	AM_OPTIONS_MAP_LINK			= "到";
	AM_OPTIONS_HOTSPOT_BEHAVE	= "熱點的行為: ";
	AM_OPTIONS_HOTSPOT_DISABLE	= "啟動熱點功能";
	AM_OPTIONS_HOTSPOT_OPEN		= "若 AlphaMap 關閉則開啟";
	AM_OPTIONS_HOTSPOT_OPACITY	= "完整顯示 AlphaMap";
	AM_OPTIONS_HOTSPOT_WORLDI	= "開啟世界圖示/註記";
	AM_OPTIONS_HOTSPOT_DUNGI	= "開啟地下城 AlphaMap 註記";
	AM_OPTIONS_HOTSPOT_NBG		= "開啟註記背景";
	AM_OPTIONS_HOTSPOT_MBG		= "開啟地圖背景";
	AM_OPTIONS_HOTSPOT_MINIMAP	= "啟動小地圖按鍵為熱點";
	AM_OPTIONS_HOTSPOT_INFO		= "開啟按鍵/置頂/註腳";
	AM_OPTIONS_BG_USE_AM		= "在戰場使用界面地圖";
	AM_OPTIONS_TYPE_SAVE_LABEL	= "所有%1地圖的控制設定: ";
	AM_OPTIONS_TYPE_ALL			= "將變動套用到所有%1地圖";
	AM_OPTIONS_TYPE_SAVE		= "套用到所有的%1地圖";
	AM_OPTIONS_BG_MESSAGES		= "將戰場訊息送到: ";
	AM_OPTIONS_RAID				= "團隊";
	AM_OPTIONS_PARTY			= "隊伍";
	AM_OPTIONS_GENERAL			= "綜合";
	AM_OPTIONS_GUILD			= "公會";
	AM_OPTIONS_GROUP_DEFAULT	= "Group Dependant";
	AM_OPTIONS_NUN_AUTO			= "自動送出 NuN 註記的設定";
	AM_OPTIONS_NUN_FORMAT		= "送出格式化的註記";
	AM_OPTIONS_NUN_MESSAGES		= "自動送出 NuN 註記給: ";
	AM_OPTIONS_WMAP_MODES		= "世界地圖顯示模式:";
	AM_OPTIONS_GMAP_MODES		= "Blizzard Map Settings :";
	AM_OPTIONS_GMAP_ALLOW		= "Allow changes to Blizzard Map";
	AM_OPTIONS_GMAP_CHANGE		= "Check to change Blizzard Map";
	AM_OPTIONS_WMAP_SMODE		= "標準模式";
	AM_OPTIONS_WMAP_OMODE		= "緊密模式";
	AM_OPTIONS_WMAP_MINIMODE	= "小地圖材質";
	AM_OPTIONS_WMAP_ZMINIMODE	= "放大小地圖";
	AM_OPTIONS_WMOTHER			= "其他的地圖控制: ";
	AM_OPTIONS_WM_ESCAPE		= "啟動 <ESC> 關閉功能";
	AM_OPTIONS_WM_MOUSE		= "啟動滑鼠互動模式";
	AM_OPTIONS_MUTE			= "Mute";
	AM_OPTIONS_COORDS		= "(x, y)";
	AM_OPTIONS_MAPS1		= "AlphaMap 地圖 1";
	AM_OPTIONS_MAPS2		= "  ..... 2";

	AM_INSTANCE_TITLE_LOCATION	= "地點 ";
	AM_INSTANCE_TITLE_LEVELS	= "等級 ";
	AM_INSTANCE_TITLE_PLAYERS	= "玩家上限 ";
	AM_INSTANCE_CHESTS		= "箱子 ";
	AM_INSTANCE_STAIRS		= "階梯";
	AM_INSTANCE_ENTRANCES		= "入口 ";
	AM_INSTANCE_EXITS		= "出口 ";
	AM_LEADSTO			= "通往...";
	AM_INSTANCE_PREREQS		= "前提: ";
	AM_INSTANCE_GENERAL		= "一般註記: ";
	AM_RARE				= "(稀有)";
	AM_VARIES			= "(多個位置)";
	AM_WANDERS			= "(巡邏)";
	AM_OPTIONAL			= "(可選擇)";

	AM_NO_LIMIT			= "沒有玩家限制";

	AM_MOB_LOOT 			= "小怪掉落";
	AM_RBOSS_DROP 			= "首領隨機掉落";
	AM_ENCHANTS			= "附魔";
	AM_CLASS_SETS			= "職業套裝";
	AM_TIER0_SET			= "T0 套裝";
	AM_TIER1_SET			= "T1 套裝";
	AM_TIER2_SET			= "T2 套裝";
	AM_TIER3_SET			= "T3 套裝";
	AM_TIER4_SET			= "T4 套裝";
	AM_PVP_SET			= "PVP 套裝";

	AM_PVP				= "PvP";

	AM_ANCHOR_POINT 	= {	{ Display = "頂端",			-- Localise
					  Command = "TOP" },					-- Do NOT Localise
					{ Display = "右上方",		-- Localise
					  Command = "TOPRIGHT" },				-- Do NOT Localise
					{ Display = "右邊",			-- Localise
					  Command = "RIGHT" },					-- Do NOT Localise
					{ Display = "右下方",		-- Localise
					  Command = "BOTTOMRIGHT" },				-- Do NOT Localise
					{ Display = "底端",			-- Localise
					  Command = "BOTTOM" },					-- Do NOT Localise
					{ Display = "左下方",		-- Localise
					  Command = "BOTTOMLEFT" },				-- Do NOT Localise
					{ Display = "左邊",			-- Localise
					  Command = "LEFT" },					-- Do NOT Localise
					{ Display = "左上方",		-- Localise
					  Command = "TOPLEFT" }					-- Do NOT Localise
				};

	AM_BG_BASE			= "Only 1 Base";
	AM_BG_BASES			= "Bases";
	AM_BG_REQUIRED			= "Required to Win !";

	AM_EXTERIOR = " 外部";

	AM_RCMENU_INC			= " Inc ";		-- as in 5 inc Blacksmith   or  3 inc farm
	AM_RCMENU_ZERG			= "Zerg";		-- as in Zerg Inc Frostwolf GY
	AM_OK				= "OK";
	AM_RCMENU_HIGHLIGHT		= "Highlight";		-- as in leave this note highlighted on the map
	AM_RCMENU_NUN_AUTO		= "自動傳送註記";	-- send the NotesUNeed note for the current map note to Raid/Party/...
	AM_RCMENU_NUN_MAN		= "手動傳送註記";
	AM_RCMENU_NUN_OPEN		= "打開註記";
	AM_RCMENU_AFLAG			= "聯盟旗幟 ";
	AM_RCMENU_HFLAG			= "部落旗幟 ";
	AM_RCMENU_FLAGLOC		= {	"Our Tunnel",
						"Our Roof",
						"Going West",
						"Going East",
						"In Middle",
						"Their Tunnel",
						"Their Roof",
						"Their Flag Room",
						"Their GY"
					};

	AM_OPENING = "AQ Opening Quest Chain";

	AM_HORDE		= "Horde";
	AM_PICKED		= { 	word = "picked",
					posWord = " by ",
					extraChars = 1 };

	-- Deutsch
	--AM_PICKED		= {	word = "aufgenommen" };

	-- Francais
	--AM_PICKED		= {	word = "ramass\195\169",
	--				posWord = " par ",
	--				extraChars = 2 };

	AM_NEUTRAL		= "中立";
	AM_FRIENDLY		= "友善";
	AM_HONOURED		= "尊敬";
	AM_REVERED		= "崇敬";
	AM_EXALTED		= "崇拜";

	AM_CONFIG_SAVED			= "AlphaMap Settings changed for : ";

	AM_CANCEL			= "取消";

	AM_CORPSE_TXT			= "Dead";
	AM_RESET_INSTANCE		= "Reset";

	--------------------------------------------------------------------------------------------------------------------------------------
	-- TOOLTIPS															    --
	--------------------------------------------------------------------------------------------------------------------------------------

	AM_TT_MINIMAP_BUTTON	= "AlphaMap\n按滑鼠左鍵開啟 AlphaMap\n按滑鼠右鍵開啟選項設定";
	AM_TT_ALPHA_BUTTON1		= "AlphaMap";
	AM_TT_ALPHA_BUTTON2		= "按滑鼠左鍵開啟 AlphaMap\n按滑鼠右鍵開啟選項設定";


	--------------------------------------------------------------------------------------------------------------------------------------
	-- Everything below should be localised apart from the 'filename', 'lootid' entries which should NOT be changed                               --
	-- The first  'name'  field is used to equate with in game Zone name information to help determine when the player is in a specific --
	-- Instance, and must therefore be spelt IDENTICALLY to the names of the Instances as displayed by the WoW Client in other native   --
	-- frames.															    --
	--------------------------------------------------------------------------------------------------------------------------------------

	AM_TYP_WM			= "世界地圖";
	AM_TYP_GM			= "Blizzard Map";

	AM_TYP_INSTANCE 	= "副本";
	AM_TYP_BG			= "戰場";
	AM_TYP_WORLDBOSSES	= "非副本地圖";
	AM_TYP_CAVES		= "Caves";

end