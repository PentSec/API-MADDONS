
-- Minimap texture data for World Boss Maps
AM_WorldBosses_Minimap_Data = {
	AM_Kazzak_Map 	= 	{	{	{ 	filename = "b5495897bd4833751deb27a2ed22c894",
									height = 256,
									width = 256,
									texcoordinates = { 0.3, 1, 0.75, 1 }
								},
								{	filename = "cf584aea412c82e4b42cc5424a1d1da5",
									height = 256,
									width = 256,
									texcoordinates = { 0.3, 1, 0, 1 }
								},
								{	filename = "f9ef3e6c36c89e0d1c0e2e035322420e",
									height = 256,
									width = 256,
									texcoordinates = { 0.3, 1, 0, 0.16 }
								}
							},

							{	{ 	filename = "58bae9872bf403ffe17b271360eb3fda",
									height = 256,
									width = 256,
									texcoordinates = { 0, 0.45, 0.75, 1 }
								},
								{	filename = "8097163e3663802e3fbc03dec9d9ff90",
									height = 256,
									width = 256,
									texcoordinates = { 0, 0.45, 0, 1 }
								},
								{	filename = "8b271eeb6cf449f770a053c495c7dcbe",
									height = 256,
									width = 256,
									texcoordinates = { 0, 0.45, 0, 0.16 }
								}
							}
						},

	AM_DoomKazzak_Map = {	{	{ 	filename = "6aa269d9f174f3a65f982669afa4d5c6",
									height = 256,
									width = 256,
									texcoordinates = { 0, 1, 0.6, 1 }
								},
								{	filename = "efc6fc7876c0ff8816ca8ab36c62a554",
									height = 256,
									width = 256,
									texcoordinates = { 0, 1, 0, 1 }
								},
							},

							{	{ 	filename = "44c8c1737f29af1912b7267e07f7c28a",
									height = 256,
									width = 256,
									texcoordinates = { 0, 0.4, 0.6, 1 }
								},
								{	filename = "9a2ce6344196818be3f4dbea5d127f1e",
										height = 256,
									width = 256,
									texcoordinates = { 0, 0.4, 0, 1 }
								},
							}
						},

	AM_Azuregos_Map = 	{	{	{ 	filename = "5bf3e29c8eeea1b6215574dda9628240",
									height = 256,
									width = 256,
									texcoordinates = { 0.8, 1, 0.5, 1 }
								},
								{	filename = "c3f74efe88a5031856e9a52d947b588a",
									height = 256,
									width = 256,
									texcoordinates = { 0.8, 1, 0, 0.8 }
								}
							},

							{	{ 	filename = "0b35146bec8b0125014e4cdf4f6650b1",
									height = 256,
									width = 256,
									texcoordinates = { 0, 1, 0.5, 1 }
								},
								{	filename = "0a528ac01d02882fb85ce22d8350bdf9",
									height = 256,
									width = 256,
									texcoordinates = { 0, 1, 0, 0.8 }
								}
							},

							{	{ 	filename = "9610987325ed4620ea664d36ce376a3b",
									height = 256,
									width = 256,
									texcoordinates = { 0, 0.1, 0.5, 1 }
								},
								{	filename = "da022a0049226275c0afa6920c2bfbd9",
									height = 256,
									width = 256,
									texcoordinates = { 0, 0.1, 0, 0.8 }
								}
							}
						},

	AM_Dragon_Duskwood_Map =	{	{	{	filename = "c69d18b0703f40117eb5b3772aedb8d6",
											height = 256,
											width = 256,
											texcoordinates = { 0.4, 1, 0.1, 1 }
										},
										{	filename = "01977102194646854a915529cf32679a",
											height = 256,
											width = 256,
											texcoordinates = { 0.4, 1, 0, 0.05 }
										}
									},

									{	{	filename = "5eb877c2be769bd35f29e4b5d50d6541",
											height = 256,
											width = 256,
											texcoordinates = { 0, 0.25, 0.1, 1 }
										},
										{	filename = "c141a3e6056cc2264fbeac47d0138270",
											height = 256,
											width = 256,
											texcoordinates = { 0, 0.25, 0, 0.05 }
										}
									}
								},

	AM_Dragon_Hinterlands_Map =	{	{	{	filename = "4f118530542beebc4d9869a6c5eb0508",
											height = 256,
											width = 256,
											texcoordinates = { 0, 1, 0, 1 }
										},
									},
								},

	AM_Dragon_Feralas_Map = {	{	{	filename = "ad19026ebbf0cc02af471ef26a477aa7",
										height = 256,
										width = 256,
										texcoordinates = { 0, 1, 0.83, 1 }
									},
									{	filename = "54fd14015c49c179d94b60493afa9999",
										height = 256,
										width = 256,
										texcoordinates = { 0, 1, 0, 0.83 }
									},
								},
							},

	AM_Dragon_Ashenvale_Map = 	{	{	{	filename = "472abc0dcd5872225ba892e237408f3c",
											height = 256,
											width = 256,
											texcoordinates = { 0.5, 1, 0.33, 1 }
										},
										{	filename = "d5a1f32e8082872ada074404c9a17343",
											height = 256,
											width = 256,
											texcoordinates = { 0.5, 1, 0, 0.33 }
										}
									},

									{	{	filename = "9b2e076e4bbf0e4650986d4b0b4ee469",
											height = 256,
											width = 256,
											texcoordinates = { 0, 0.5, 0.33, 1 }
										},
										{	filename = "8b548da5a6b9fa4acf84da59cf5cb944",
											height = 256,
											width = 256,
											texcoordinates = { 0, 0.5, 0, 0.33 }
										},
									},
								},

	AM_Doomwalker_Map = {	{	{ 	filename = "3727bbdbc924255f1f7cbe4962e89f5e",
									height = 256,
									width = 256,
									texcoordinates = { 0, 1, 0.6, 1 }
								},
								{	filename = "978ca9f4d3f20fbcb3c1eb30ae523c0e",
									height = 256,
									width = 256,
									texcoordinates = { 0, 1, 0, 1 }
								},
								{	filename = "b799830aa31fe67b4c9ac7f41e8ee52c",
									height = 256,
									width = 256,
									texcoordinates = { 0, 1, 0, 0.6 }
								}
							},

							{	{ 	filename = "03d9b7a863f635a683bad1184a157dfb",
									height = 256,
									width = 256,
									texcoordinates = { 0, 1, 0.6, 1 }
								},
								{	filename = "0f507cb8b354bedb05c8418f2d79b9e1",
									height = 256,
									width = 256,
									texcoordinates = { 0, 1, 0, 1 }
								},
								{	filename = "bea3733017e891b1694266a64f467baa",
									height = 256,
									width = 256,
									texcoordinates = { 0, 1, 0, 0.6 }
								}
							}
						},


};