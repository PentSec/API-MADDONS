
This is a plugin AddOn for "AlphaMap (Fan's Update)"

It shows zoomed in Minimap textured maps of World Boss encounters that can display Raid and Party members.
(Especially useful with the "PartySpotter" AddOn installed).

