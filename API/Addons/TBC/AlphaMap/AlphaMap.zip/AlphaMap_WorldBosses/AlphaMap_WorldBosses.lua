

-- Register the map data with the main AddOn
AlphaMap_RegisterMaps(AM_TYP_WORLDBOSSES, AM_ALPHAMAP_WORLDBOSSES_LIST, AM_WorldBosses_Minimap_Data);


