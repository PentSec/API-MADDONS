--------------------------------------------------------------------------
-- localization.lua <French>
--------------------------------------------------------------------------
--
--	�	\195\128
--	�	\195\129
--	�	\195\130
--	�	\195\132
--	�	\195\136
--	�	\195\137
--	�	\195\138
--	�	\195\139
--	�	\195\142
--	�	\195\143
--	�	\195\148
--	�	\195\150
--	�	\195\155
--	�	\195\156
--	�	\195\160
--	�	\195\161
--	�	\195\162
--	�	\195\164
--	�	\195\168
--	�	\195\169
--	�	\195\170
--	�	\195\171
--	�	\195\174
--	�	\195\175
--	�	\195\180
--	�	\195\182
--	�	\195\187
--	�	\195\188
--	'�	\39\197\146
--
--------------------------------------------------------------------------

if ( GetLocale() == "frFR" ) then

AM_TYP_WORLDBOSSES = "Boss mondiaux";

AM_ALPHAMAP_WORLDBOSSES_LIST = {

	-- Azuregos
	{	name = "Azuregos",
		type = AM_TYP_WORLDBOSSES,
		displayname = "Azuregos",
		filename = "AM_Azuregos_Map",
		location = "Azshara (Approx. 56, 81)",
		minimapZoom = 1.5385,
		minimapXOffset = 0,
		minimapYOffset = 0,
		area = "Aszhara",				-- Deliberately spelt Aszhara !
		levels = "60",
		players = AM_NO_LIMIT,
		prereq = "",
		general = "",
		wmData = { minX = 0.485, maxX = 0.62743, minY = 0.71498, maxY = 0.917 },
		amData = { minX = 0.005, maxX = 0.995, minY = 0.005, maxY = 0.995 },
		dtl1 = { text = "Azuregos", colour = AM_RED, coords = { {0, 0} }, symbol = { " " },
				tooltiptxt = "Talk with to trigger combat", lootid = "AAzuregos", leaveGap = 1 }
	},

	-- Les Dragons du Cauchemar
	{	name = "Les Dragons du Cauchemar : Bois de la P�nombre",
		type = AM_TYP_WORLDBOSSES,
		displayname = "Les Dragons du Cauchemar: Bois de la P�nombre",
		filename = "AM_Dragon_Duskwood_Map",
		location = "Bois de la P�nombre : Twighlight Grove (46, 36)",
		minimapZoom = 2.11,
		minimapXOffset = 54,
		minimapYOffset = 0,
		area = "Duskwood",
		levels = "60",
		players = AM_NO_LIMIT,
		prereq = "",
		general = "",
		wmData = { minX = 0.421, maxX = .526, minY = 0.292, maxY = 0.54 },
		amData = { minX = 0.29, maxX = .85, minY = 0.115, maxY = 0.97 },
		dtl1 = { text = "Entr�e", colour = AM_GREEN, coords = { {48, 96} }, symbol = { AM_ENTRANCE },
				tooltiptxt = "", leaveGap = 1 },
		dtl2 = { text = "Emerald Gate", colour = AM_GREEN, coords = { {54, 47} }, symbol = { "1" },
				tooltiptxt = "Boss\nYsondre", special = AM_WANDERS, leaveGap = 1 },
		dtl3 = { text = "Emeriss", colour = AM_RED, coords = { {0, 0} }, symbol = { " " },
				tooltiptxt = "", lootid = "DEmeriss" },
		dtl4 = { text = "Lethon", colour = AM_RED, coords = { {0, 0} }, symbol = { " " },
				tooltiptxt = "", lootid = "DLethon" },
		dtl5 = { text = "Taerar", colour = AM_RED, coords = { {0, 0} }, symbol = { " " },
				tooltiptxt = "", lootid = "DTaerar" },
		dtl6 = { text = "Ysondre", colour = AM_RED, coords = { {0, 0} }, symbol = { " " },
				tooltiptxt = "", lootid = "DYsondre" },
	},

	-- Les Dragons du Cauchemar
	{	name = "Les Dragons du Cauchemar : Les Hinterlands",
		type = AM_TYP_WORLDBOSSES,
		displayname = "Les Dragons du Cauchemar : Les Hinterlands",
		filename = "AM_Dragon_Hinterlands_Map",
		location = "Hinterlands : Seradane (46, 36)",
		minimapZoom = 2,
		minimapXOffset = 0,
		minimapYOffset = 0,
		area = "Hinterlands",
		levels = "60",
		players = AM_NO_LIMIT,
		prereq = "",
		general = "Wandering trios of level 62 & 61 Elites",
		wmData = { minX = 0.561, maxX = .697, minY = 0.159, maxY = 0.362 },
		amData = { minX = 0.005, maxX = .995, minY = 0.005, maxY = 0.995 },
		dtl1 = { text = "Entr�e", colour = AM_GREEN, coords = { {37, 98} }, symbol = { AM_ENTRANCE },
				tooltiptxt = "", leaveGap = 1 },
		dtl2 = { text = "Rothos", colour = AM_RED, coords = { {52.5, 59} }, symbol = { "1" },
				tooltiptxt = "Lvl62 Elite  Draconien", special = AM_WANDERS },
		dtl3 = { text = "Dreamtracker", colour = AM_RED, coords = { {51, 49} }, symbol = { "2" },
				tooltiptxt = "Lvl62 Elite  Draconien" },
		dtl4 = { text = "Emerald Gate", colour = AM_GREEN, coords = { {46, 39} }, symbol = { "3" },
				tooltiptxt = "Boss\nTaerar", leaveGap = 1 },
		dtl5 = { text = "Emeriss", colour = AM_RED, coords = { {0, 0} }, symbol = { " " },
				tooltiptxt = "", lootid = "DEmeriss" },
		dtl6 = { text = "Lethon", colour = AM_RED, coords = { {0, 0} }, symbol = { " " },
				tooltiptxt = "", lootid = "DLethon" },
		dtl7 = { text = "Taerar", colour = AM_RED, coords = { {0, 0} }, symbol = { " " },
				tooltiptxt = "", lootid = "DTaerar" },
		dtl8 = { text = "Ysondre", colour = AM_RED, coords = { {0, 0} }, symbol = { " " },
				tooltiptxt = "", lootid = "DYsondre" },
	},

	-- Les Dragons du Cauchemar
	{	name = "Les Dragons du Cauchemar : Feralas",
		type = AM_TYP_WORLDBOSSES,
		displayname = "Les Dragons du Cauchemar : Feralas",
		filename = "AM_Dragon_Feralas_Map",
		location = "Feralas : Dream Bough (51, 9)",	-- Jademir Lake
		minimapZoom = 2,
		minimapXOffset = 0,
		minimapYOffset = 0,
		area = "Feralas",
		levels = "60",
		players = AM_NO_LIMIT,
		prereq = "",
		general = "Wandering trios of level 62 & 61 Elites",
		wmData = { minX = 0.47695, maxX = .55113, minY = 0.04585, maxY = 0.15963 },
		amData = { minX = 0.005, maxX = .995, minY = 0.005, maxY = 0.995 },
		dtl1 = { text = "Dreamroarer", colour = AM_RED, coords = { {36, 63} }, symbol = { "1" },
				tooltiptxt = "Lvl62 Elite  Draconien\nPatrols round Island", special = AM_WANDERS },
		dtl2 = { text = "Lethlas", colour = AM_RED, coords = { {46, 68} }, symbol = { "2" },
				tooltiptxt = "Lvl62 Elite  Draconien\nPatrols round Island", special = AM_WANDERS },
		dtl3 = { text = "Emerald Gate", colour = AM_GREEN, coords = { {45, 57} }, symbol = { "3" },
				tooltiptxt = "Boss\nEmeriss", leaveGap = 1 },
		dtl4 = { text = "Emeriss", colour = AM_RED, coords = { {0, 0} }, symbol = { " " },
				tooltiptxt = "", lootid = "DEmeriss" },
		dtl5 = { text = "Lethon", colour = AM_RED, coords = { {0, 0} }, symbol = { " " },
				tooltiptxt = "", lootid = "DLethon" },
		dtl6 = { text = "Taerar", colour = AM_RED, coords = { {0, 0} }, symbol = { " " },
				tooltiptxt = "", lootid = "DTaerar" },
		dtl7 = { text = "Ysondre", colour = AM_RED, coords = { {0, 0} }, symbol = { " " },
				tooltiptxt = "", lootid = "DYsondre" },
	},

	-- Les Dragons du Cauchemar
	{	name = "Les Dragons du Cauchemar : Orneval",
		type = AM_TYP_WORLDBOSSES,
		displayname = "Les Dragons du Cauchemar : Orneval",
		filename = "AM_Dragon_Orneval_Map",
		location = "Orneval : Bough Shadow (93, 36)",
		minimapZoom = 2,
		minimapXOffset = 0,
		minimapYOffset = 0,
		area = "Orneval",
		levels = "60",
		players = AM_NO_LIMIT,
		prereq = "",
		general = "Wandering trios of level 62 & 61 Elites",
		wmData = { minX = 0.895, maxX = .984, minY = 0.299, maxY = 0.4286 },
		amData = { minX = 0.005, maxX = .995, minY = 0.005, maxY = 0.995 },
		dtl1 = { text = "Phantim", colour = AM_RED, coords = { {57, 75} }, symbol = { "1" },
				tooltiptxt = "Lvl62 Elite  Draconien", special = AM_WANDERS },
		dtl2 = { text = "Dreamstalker", colour = AM_RED, coords = { {50.4, 57} }, symbol = { "2" },
				tooltiptxt = "Lvl62 Elite  Draconien" },
		dtl3 = { text = "Emerald Gate", colour = AM_GREEN, coords = { {50.8, 48} }, symbol = { "3" },
				tooltiptxt = "Boss\nLethon", leaveGap = 1 },
		dtl4 = { text = "Emeriss", colour = AM_RED, coords = { {0, 0} }, symbol = { " " },
				tooltiptxt = "", lootid = "DEmeriss" },
		dtl5 = { text = "Lethon", colour = AM_RED, coords = { {0, 0} }, symbol = { " " },
				tooltiptxt = "", lootid = "DLethon" },
		dtl6 = { text = "Taerar", colour = AM_RED, coords = { {0, 0} }, symbol = { " " },
				tooltiptxt = "", lootid = "DTaerar" },
		dtl7 = { text = "Ysondre", colour = AM_RED, coords = { {0, 0} }, symbol = { " " },
				tooltiptxt = "", lootid = "DYsondre" },
	},

	-- Lord Kazzak
	{	name = "Doom Lord Kazzak",
		type = AM_TYP_WORLDBOSSES,
		displayname = "Seigneur Funeste Kazzak",
		filename = "AM_DoomKazzak_Map",
		location = "Hellfire Peninsula",
		minimapZoom = 1.4,
		minimapXOffset = 0,
		minimapYOffset = 0,
		area = "Hellfire",
		levels = "70",
		players = AM_NO_LIMIT,
		prereq = "",
		general = "",
		wmData = { minX = 0.555, maxX = 0.703, minY = 0.05885, maxY = 0.27653 },
		amData = { minX = 0.00, maxX = 0.99, minY = 0.01, maxY = 0.98 },
		dtl1 = { text = "Seigneur Funeste Kazzak", colour = AM_RED, coords = { {51.8, 44.1} }, symbol = { "1" },
				tooltiptxt = "", lootid = "KKazzak", leaveGap = 1 },
		dtl2 = { text = "GY", colour = AM_GREEN, coords = { {60, 76} }, symbol = { "GY" },
				tooltiptxt = "", leaveGap = 1 }
	},

	-- HighlordKruul
	{	name = "HighlordKruul",
		type = AM_TYP_WORLDBOSSES,
		displayname = "G�n�ralissime Kruul",
		filename = "AM_DoomKazzak_Map",
		location = "Terres Foudroy�es",
		minimapZoom = 1.42,
		minimapXOffset = 0,
		minimapYOffset = 0,
		area = "BlastedLands",
		levels = "70",
		players = AM_NO_LIMIT,
		prereq = "",
		general = "",
		wmData = { minX = 0.3196, maxX = 0.496, minY = 0.468, maxY = 0.80 },
		amData = { minX = 0.10, maxX = 0.91, minY = 0.01, maxY = 0.99 },
		dtl1 = { text = "Draco the Decrepit", colour = AM_GREEN, coords = { {21, 10} }, symbol = { "1" },
				tooltiptxt = "", leaveGap = 1 },
		dtl2 = { text = "G�n�ralissime Kruul", colour = AM_RED, coords = { {32.5, 84.5} }, symbol = { "2" },
				tooltiptxt = "Boss", lootid = "KKruul", leaveGap = 1 },
	},

	-- Doomwalker
	{	name = "Doomwalker",
		type = AM_TYP_WORLDBOSSES,
		displayname = "Marche-funeste",
		filename = "AM_DoomKazzak_Map",
		location = "Vall�e d'Ombrelune",
		minimapZoom = 1.0,
		minimapXOffset = 0,
		minimapYOffset = 0,
		area = "ShadowmoonValley",
		levels = "70",
		players = AM_NO_LIMIT,
		prereq = "",
		general = "",
		wmData = { minX = 0.555, maxX = 0.703, minY = 0.05885, maxY = 0.27653 },
		amData = { minX = 0.00, maxX = 0.99, minY = 0.01, maxY = 0.98 },
		dtl1 = { text = "Marche-funeste", colour = AM_RED, coords = { {51.8, 44.1} }, symbol = { "1" },
				tooltiptxt = "Boss", lootid = "DDoomwalker", leaveGap = 1 },
	},

};

end
