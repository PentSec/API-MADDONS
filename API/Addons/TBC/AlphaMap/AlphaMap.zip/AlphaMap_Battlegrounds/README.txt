
This is a plugin AddOn for "AlphaMap (Fan's Update)"

It shows pre-made Minimap textured maps of BattleGrounds, that have several unique features to help BG GamePlay.

It will show Battleground Raid members on the map.
(Especially useful with the "PartySpotter" AddOn installed).

If you have Enabled Mouse Interactive mode in then you can Zoom in/out on particular areas of the map by <ALT>-Left/Right clicking;
Especially useful in Alterac Valley where you want to see the Dun Baldar bunkers and Team mates in more detail.

There are several features available for each BG : 

Alterac Valley
______________

Right Click on objectives to open a menu allowing you to report the number of incoming enemies or say it is safe.

The Tooltip for Objectives like towers and grave yards will display the time left until captured.
For performance reasons, this is only calculated when you mouse over the objective itself.
To update the timer on an objective that you are hovering over, simply click the mouse.
To broadcast the time until captured to the Battleground, then <CONTROL>-Click on the objective.


Arathi Basin
____________

Right Click on objectives to open a menu allowing you to report the number of incoming enemies or say it is safe.

The Tooltip for Objectives displays the time left till captured.

AlphaMap will calculate the minimum number of bases your side needs to win the game.
When the number of bases needed to win changes, then this information is reported to the chat frame automatcially.
If you have Scrolling Combat Text installed, then this information is also reported here.

OR, click on any AB objective to manually get an update on the current number of bases to win.

<CONTROL>-Clicking on an AB objective will report the minimum number of bases needed to the Battleground channel.


Warsong Gulch
_____________

The Warsong map has two flags representing the Horde and Alliance flags.

When a flag is picked up, the name of the person holding the flag is displayed on the map.

Right Click on the map to open a menu allowing you to report where the flag carrier is
e.g. "Horde Flag Going West"


Eye of the Storm
________________

Right Click on objectives to open a menu allowing you to report the number of incoming enemies or say it is safe.

