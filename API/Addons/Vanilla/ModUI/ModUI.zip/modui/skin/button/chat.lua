

    local bu = ChatFrameMenuButton
    modSkin(bu, 6)
    modSkinColor(bu, .7, .7, .7)

    for i = 1, 7 do
        local bu = _G['ChatFrame'..i..'BottomButton']
        modSkin(bu, 6)
        modSkinColor(bu, .7, .7, .7)
    end

    --
