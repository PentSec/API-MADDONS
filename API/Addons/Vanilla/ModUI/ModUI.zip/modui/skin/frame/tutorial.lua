

    for i = 1,10 do
        local bu = _G['TutorialFrameAlertButton'..i]
        modSkin(bu, 4)
        modSkinColor(bu, .7, .5, 0)
    end

    --
