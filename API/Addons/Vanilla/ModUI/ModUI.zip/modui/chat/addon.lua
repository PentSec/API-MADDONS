

    if not IsAddOnLoaded'SW_Stats' then return end

    SLASH_MODPS1 = '/dps'
    SlashCmdList['MODPS'] = function(arg) SW_ToggleBarFrame() end

   --
